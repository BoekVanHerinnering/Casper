const sendbriewe_van_abgarus_en_jahwèshuaChapters = [

{
book: 'Sendbriewe_Van_Abgarus_En_Jahwèshua',
chapter: '1',
content: [

"	1 ABGARUS, koning van Edessa, aan JaHWèshua, die goeie Verlosser wat te Jerusalem verskyn het; Groete.	",
"	2 Ek is ingelig omtrent U en die genesings wat U gedoen het sonder die gebruikmaking van medisyne en kruie.	",
"	3 Daar word vertel dat U die blinde weer laat sien, die lamme laat loop, en beide die melaatse gesuiwer en geeste van besoedeling en demone uitdryf, en dat U hulle genees wat lank siek was. Ook die dooies opwek.	",
"	4 En nadat ek dit alles gehoor het, was ek oortuig van een van die volgende, naamlik óf U is El Self wat uit die Hemele neergedaal het om hierdie dinge te doen, óf U is die Seun van Elohim.	",
"	5 Om hierdie rede het ek aan U geskryf, en my opregte begeerte is dat U die moeite sal doen om hierheen te reis om my van ‘n kwaal waaronder ek gebuk gaan, te genees.	",
"	6 Want ek het gehoor dat die Jode U bespot en U boosheid wil aandoen.	",
"	7 My stad is inderdaad klein, maar netjies en groot genoeg vir albei van ons.	",

]
},
{
book: 'Sendbriewe_Van_Abgarus_En_Jahwèshua',
chapter: '2',
content: [
	
"	1 ABGARUS, u is geseënd vir sover u geglo het in My wat u nie gesien het nie.	",
"	2 Want dit is geskrywe aangaande My, dat hulle wat My gesien het nie in My sal glo nie, maar dat hulle wat [My] nie gesien het nie, mag glo en lewe.	",
"	3 Wat betref daardie gedeelte van u brief wat handel oor ‘n besoek wat Ek aan u moet bring, moet Ek u meedeel dat Ek al My verpligtinge in hierdie Aarde moet voltooi, en daarna weer opgeneem word na Hom toe wat My gestuur het.	",
"	4 Maar ná My Hemelvaart sal Ek een van My studente stuur wat u kwaal sal genees, en aan u lewe sal gee, en aan almal wat saam met u is.	",

]
},
{
book: 'Sendbriewe_Van_Abgarus_En_Jahwèshua',
chapter: '3',
content: [

]
},
{
book: 'Sendbriewe_Van_Abgarus_En_Jahwèshua',
chapter: '4',
content: [

]
},


];
