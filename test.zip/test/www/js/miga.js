const migaChapters = [

{
book: 'Miga',
chapter: '1',
content: [

"	1 DIE Woord van JaHWeH wat tot Miga, die Morastiet, gekom het, in die dae van JôWtham, Agas, JegizkiJaH, konings van JeHûWdah; wat hy geprofeteer het aangaande Samaría en Jerusalem.	",
"	2 o Volke, luister almal saam! o Aarde en haar volheid, let op! Sodat my Meester JaHWeH getuie teen julle kan wees, My Meester uit die Woning van Sy Apartheid.	",
"	3 Want kyk, JaHWeH gaan uit Sy Woonplek uit, en Hy daal neer en loop op die Hoogtes van die Aarde.	",
"	4 En die berge smelt onder Hom, en die laagtes skeur oop, soos was voor die vuur, soos water wat langs ’n helling afstroom!	",
"	5 Dit alles vanweë die opstandigheid van Jakob en vanweë die oortredinge van die huis van JisraEl. Wat is die oortreding van Jakob? Is sy nie Samaría nie? En wat is die Hoogtes van JeHûWdah? Is sy nie Jerusalem nie? [JeségiEl 23:5]	",
"	6 Daarom sal Ek Samaría ’n puinhoop maak op die veld, ’n plek om Wingerdstokke te plant; en Ek sal haar klippe in die dal laat afrol en haar fondamente blootlê.	",
"	7 En al haar gesnede afbeeldings sal stukkend geslaan en al wat sy as hoereloon ontvang het, met vuur verbrand word, en al haar idole sal Ek tot ’n verwoesting maak; want uit hoereloon het sy dit versamel, en tot hoereloon sal dit terugkeer.	",
"	8 Oor haar wil Ek rouklaag en huil, kaalvoet en naak loop. Ek wil weeklaag oor die draak en rou oor die dogters van die uile.	",
"	9 Waarlik, haar wonde is ongeneeslik; want dit het gekom tot by JeHûWdah, dit reik tot aan die Poort van My volk, tot by Jerusalem.	",
"	10 Moet dit nie in Gat vertel nie, moenie by almal ween nie! In Bet-Ofra rol julself in die stof en as!	",
"	11 Trek weg in smadelike naaktheid, o inwoners van Safir! Die inwoners van Saänan trek nie uit nie. Die weeklagte van Bet-Haësel sal julle daar die verblyf ontneem.	",
"	12 Want die inwoners van Marot wag in pyn op iets suiwer, omdat besoedeling neerdaal van JaHWeH na die Poort van Jerusalem.	",
"	13 Span die perde voor die wa, o inwoners van Lagis! Dit was die begin van oortreding vir die Dogter van Sion, dat die oortredinge van JisraEl in jou gevind is.	",
"	14 Daarom moet jy ’n afskeidsgeskenk gee aan Moréset-Gat; die huise van Agsib sal ’n valsheid wees vir die konings van JisraEl.	",
"	15 Nogmaals sal Ek jou ’n huurling bring, o inwoner van Marésa; die adel van JisraEl sal tot by Adúllam kom.	",
"	16 Maak ’n kaalte op jou hoof en skeer jou weens jou troetelkinders; maak die kaalplek groot soos dié van ’n aasvoël, omdat hulle van jou af weggevoer is in ballingskap.	",

]
},
{
book: 'Miga',
chapter: '2',
content: [
		
"	1 WEE die wat onreg uitdink en besoedeling smee op hulle bedde; by die môrelig voer hulle dit uit, want dit is in die mag van hulle hand.	",
"	2 Ja, hulle begeer velde en roof dit; ook huise en neem dit. So pleeg hulle dan geweld teenoor die sterk man en sy huis, teenoor die man en sy Erfdeel.	",
"	3 Daarom, so sê JaHWeH: Kyk, Ek bedink besoedeling teen hierdie familie, waar julle jul nekke nie sal kan uittrek nie, en waarby julle nie regop sal kan loop nie; want dit sal ’n tyd van besoedeling wees!	",
"	4 In dié dag sal hulle ’n spreekwoord oor julle aanhef en kerm: Dit is gedaan - sal hulle sê - Ons is heeltemal verwoes; die eiendom van My volk laat Hy van besitter verander. Hoe neem Hy haar van My af! Aan die afvalliges deel Hy Ons velde uit.	",
"	5 Daarom sal daar vir jou niemand wees wat die meetsnoer werp in ’n erfdeel in die vergadering van JaHWeH nie.	",
"	6 Moet nie profeteer nie! sê die [valse] profete. As hulle hieroor nie mag profeteer nie, sal die skande nie ophou nie!	",
"	7 Mag dit gesê word, o huis van Jakob: Sou die Gees van JaHWeH dan ongeduldig wees? Of is dit Sy dade? Is My woorde nie vriendelik teenoor hom wat as opregte wandel nie?	",
"	8 Maar reeds vroeër het My volk vyandig opgetree. Julle pluk die mantel af, weg van die kleed van die wat in gerustheid verbygaan, wat afkerig is van oorlog.	",
"	9 Die vroue van My volk verdryf julle uit die huis wat hulle liefhet; van hulle kinders neem julle My sieraad weg in ewigheid.	",
"	10 Staan op en loop! Want hiér is die rusplek nie, want sy het besoedel geword en sal jou met siekte vernietig.	",
"	11 As iemand gees nawandel en bedrieglik lieg [en sê]: Ek sal vir jou profeteer by wyn en sterk drank - sou hy dan vir hierdie volk ’n profeet wees?	",
"	12 Gewis sal Ek jou geheel en al versamel, o Jakob! Gewis sal Ek vergader die oorblyfsel van JisraEl; almal bymekaarbring soos skape in ’n kraal, soos ’n kudde in sy weiveld; en dit sal dreun van adamiete.	",
"	13 Die deurbreker sal optrek voor hulle uit: hulle sal deurbreek en deur die Poort intrek en daardeur uittrek; en hulle Koning sal voor hulle uit gaan, en JaHWeH heeltemal vooraan.	",

]
},
{
book: 'Miga',
chapter: '3',
content: [
		
"	1 VERDER het ek gesê: Hoor tog, o hoofde van Jakob en owerstes van die huis van JisraEl! Betaam dit julle nie om die Regspraak te ken nie?	",
"	2 Haters van wat suiwer is, en liefhebbers van wat besoedel is, wat die vel aftrek en hulle vlees van hul gebeente;	",
"	3 en wat die vlees van My volk eet en hulle vel van hulle afslag; ook hulle gebeente verbrysel en hulle aan stukke kap soos in ’n pot en soos vleis in ’n pan.	",
"	4 Dan sal hulle JaHWeH aanroep, en Hy sal hulle nie antwoord nie; maar Hy sal Sy Aangesig in dié tyd vir hulle verberg, omdat hulle verkeerde dinge gedoen het.	",
"	5 So sê JaHWeH aangaande die profete wat My volk laat dwaal, wat met julle tande byt, maar Vrede uitroep, julle voed hulle [die volk] nie, maar julle berei en verkondig oorlog!	",
"	6 Daarom sal dit nag word vir julle, sonder ’n gesig, en duister vir julle, sonder insig; ja, die son sal oor die profete ondergaan, en die dag oor hulle verduister word.	",
"	7 En die sieners sal beskaamd staan, en die waarsêers sal bloos, en hulle almal sal die baard bedek, omdat daar geen antwoord van Elohim kom nie.	",
"	8 Ek daarenteen is vol sterkte, mét die Gees van JaHWeH, en Reg en mag, om aan Jakob sy opstandigheid te verkondig en aan JisraEl sy oortreding.	",
"	9 Hoor tog dit, hoofde van die huis van Jakob en owerstes van die huis van JisraEl! Julle wat van die Reg ’n afsku het en al wat reguit is, verdraai;	",
"	10 julle wat Sion bou met bloed en Jerusalem met onreg!	",
"	11 Haar hoofde spreek vonnisse uit vir ’n geskenk, en haar priesters gee onderrig vir loon, en haar profete is waarsêers vir geld. Nogtans steun hulle op JaHWeH en sê: Is JaHWeH nie in ons midde nie? Geen besoedeling sal op ons kom nie!	",
"	12 Daarom sal Sion om julle ontwil soos ’n land omgeploeg en Jerusalem puinhope word en die berg van die huis soos hoë plekke van die woud.	",

]
},
{
book: 'Miga',
chapter: '4',
content: [
		
"	1 EN aan die einde van die dae sal die berg van die Huis van JaHWeH vasstaan op die top van die berge en verhewe wees bo die heuwels, en die volke sal na hom toestroom.	",
"	2 En baie nasies sal heengaan en sê: Kom, laat ons optrek na die Berg van JaHWeH en na die Huis van die Elohey van Jakob, dat Hy ons in Sy Weë kan leer en ons in Sy Paaie kan wandel. Want uit Sion sal die Wet uitgaan en die Woord van JaHWeH uit Jerusalem. [JeshaJaH 2:3]	",
"	3 En Hy sal oordeel tussen baie volke en regspreek vir magtige nasies tot in die verte; en hulle sal van hul swaarde pikke smee en van hul spiese snoeimesse; nie [meer] sal nasie teen nasie die swaard ophef nie, en hulle sal nie meer leer om oorlog te voer nie.	",
"	4 Maar hulle sal sit elkeen onder sy Wingerdstok en onder sy Vyeboom, sonder dat iemand hulle verskrik; want die Mond van JaHWeH van die skeppings-leërmag het dit gespreek. [Boekrol van Henog 10:19]	",
"	5 Want al die volke mag wandel elkeen in die naam van sy gode, maar Ons sal wandel in die Naam van JaHWeH Onse Elohey vir altyd en ewig.	",
"	6 In dié dag, spreek JaHWeH, wil Ek versamel die wat kreupel is, en bymekaarmaak wat verdryf was, en die wat Ek kwaad aangedoen het.	",
"	7 Dan sal Ek die wat kreupel was, tot ’n oorblyfsel maak en wat ver verwyder was, tot ’n magtige nasie. En JaHWeH sal Koning wees oor hulle op die Berg van Sion, van nou af tot in ewigheid.	",
"	8 En U, Toring van die skape, Vesting van die Dogter van Sion, na Jou sal dit kom, ja, die vroeëre heerskappy sal kom, die Koningskap vir die Dogter van Jerusalem. [Spreuke 18:10; Hooglied van Salomo 4:4]	",
"	9 Waarom skreeu Jy nou so hard? Is daar geen koning in Jou nie? Of het Jou raadgewer omgekom, sodat smart Jou aangegryp het soos van Een wat baar? [Psalm 61; Openbaring 12]	",
"	10 Krimp inmekaar en bring voort, o Dogter van Sion, soos Een wat baar! Want nou sal Jy die Stad verlaat en op die veld gaan woon; en Jy sal in Babel aankom - dáár sal Jy gered word, dáár sal JaHWeH Jou verlos uit die handpalms van Jou vyande. [DaniEl 3:1; 4:30]	",
"	11 En nou is daar baie nasies teen Jou versamel wat sê: Laat Haar besoedel word, en laat ons oë met welgevalle neersien op Sion.	",
"	12 Maar hulle ken nie die gedagtes van JaHWeH nie en verstaan nie Sy besluit nie, dat Hy hulle versamel het soos gerwe op die dorsvloer.	",
"	13 Staan op en dors, o Dogter van Sion! Want Ek sal Jou Horing Yster maak en Jou kloue koper, en Jy sal baie volke fyn trap; en Jy sal hulle onregverdige wins aan JaHWeH toewy en hulle rykdom aan die Elohey van die ganse Aarde. [Odes van Salomo 23:13; JeshaJaH 41:15]	",

]
},
{
book: 'Miga',
chapter: '5',
content: [
		
"	1 NOU sal jy by hope bymekaar moet kom, o Dogter van Krygsbendes; [die vyand] het ’n wal teen ons opgegooi; met ’n septer slaan hulle die Regeerder van JisraEl op die kakebeen.	",
"	2 En jy, Beth-Legem2 Éfrata, klein om te wees onder die duisende van JeHûWdah, uit jou sal daar vir My uitgaan Een wat ’n Vors in JisraEl sal wees; en Sy afkoms is uit die voortyd, uit die dae van die ewigheid.	",
"	3 Daarom sal Hy hulle prysgee tot op die tyd dat ’n Barende gebaar het. Dan sal die oorblyfsel van Sy broers saam met die kinders van JisraEl terugkeer.	",
"	4 En Hy sal optree en [hulle] laat wei in die Sterkte van JaHWeH, in my Meester van die Naam van JaHWeH Sy Elohey; en hulle sal rustig woon, want nou sal Hy groot wees tot aan die eindes van die Aarde. [JeshaJaH 4:4]	",
"	5 En Hy sal Vrede wees. Wanneer Assur in Ons Aarde kom en hy Ons paleise wil betree, sal Ons teenoor hom sewe herders stel, en agt vorste uit die adamiete. [Openbaring 1:20]	",
"	6 En hulle sal die Aarde van Assur met die swaard afwei en die Aarde van Nimrod by haar ingange. So sal Hy [Ons] dan van Assur bevry, wanneer hy in Ons Aarde kom en Ons grondgebied betree.	",
"	7 Dan sal die oorblyfsel van Jakob onder baie volke wees soos Dou van JaHWeH, soos reënbuie op die plante, wat op geen adamiet wag nie en ter wille van geen seun van adam vertoef nie.	",
"	8 En die oorblyfsel van Jakob tussen die nasies sal onder baie volke wees soos ’n leeu onder die diere van die woud, soos ’n jong leeu onder troppe kleinvee; wat, as hy deurtrek, vertrap en verskeur sonder dat iemand red.	",
"	9 Jou hand sal bo jou teëstanders verhewe wees, en al jou vyande sal uitgeroei word.	",
"	10 En in dié dag, spreek JaHWeH, sal Ek jou perde uit jou midde uitroei en jou strydwaens vernietig.	",
"	11 Ook sal Ek uitroei die stede van jou Aarde en al jou vestings afbreek.	",
"	12 Verder sal Ek uitroei die towerye uit jou hand, en jy sal geen goëlaars meer hê nie.	",
"	13 En Ek sal uit jou midde uitroei jou gesnede afbeeldings en jou kliptorings, sodat jy jou nie meer voor die werk van jou hande sal neerbuig nie.	",
"	14 En Ek sal uit jou midde uitruk jou Houtkruise en jou stede verwoes.	",
"	15 En Ek sal met Toorn en Grimmigheid wraak neem op die nasies wat nie geluister het nie.	",

]
},
{
book: 'Miga',
chapter: '6',
content: [
		
"	1 HOOR tog wat JaHWeH sê: Staan op, verdedig jou in teenwoordigheid van die berge, en laat die heuwels na jou stem luister!	",
"	2 Hoor, berge, die stryd van JaHWeH! En onwankelbares, grondslae van die Aarde! Want JaHWeH het ’n stryd met Sy volk en sal met JisraEl ’n regsgeding hou.	",
"	3 My volk, wat het Ek jou aangedoen, en waarmee het Ek jou vermoei? Antwoord My!	",
"	4 Ja, Ek het jou uit die Aarde van Egipte laat optrek en jou uit die slawehuis losgekoop, en Ek het voor jou uit gestuur Moshè, Aäron en Mirjam.	",
"	5 My volk, dink tog aan wat Balak, die koning van Moab, beraadslaag het, en wat Bíleam, die seun van Beor, hom geantwoord het, [en wat gebeur het] van Sittim af tot by Gilgal, sodat jy kennis kan dra van die dade van Geregtigheid van JaHWeH.	",
"	6 Waarmee sal Ek JaHWeH tegemoetgaan en My buig voor die hoë Elohey? Sal Ek Hom tegemoetgaan met brandoffers, met jaaroud kalwers?	",
"	7 Sal JaHWeH ’n welbehae hê in duisende ramme en tienduisende strome van olie? Sal Ek My Eersgeborene gee vir My oortreding, die vrug van My liggaam vir die bestrafing van My Siel? (MattithJaHûW 3:17)	",
"	8 Hy het jou bekend gemaak, o adamiet, wat suiwer is; en wat vra JaHWeH van jou anders as om Reg te doen en Medelye lief te hê en nederig te wandel met jou Elohey?	",
"	9 Die Stem van JaHWeH roep tot die Stad - dit is raadsaam om U Naam te vrees - Hoor die roede, en wie dit bestel het.	",
"	10 Is daar nog altyd in die huis besoedelde skatte van die besoedelde, ’n skrale efa wat gruwelik is?	",
"	11 Sal Ek suiwer kan wees by ’n besoedelde weegskaal en by ’n sak vol bedrieglike gewigte?	",
"	12 Want die rykes in [die Stad] is vol geweld, en haar inwoners spreek leuentaal, en hulle tong is bedrog in hulle mond.	",
"	13 So slaan Ek jou dan ook met ’n smartlike wond, met verwoesting weens jou oortredinge.	",
"	14 Jy sal eet, maar nie versadig word nie, sodat jou honger in jou binneste bly; en jy sal wegbring sonder om iets te red; en wat jy red, sal Ek aan die swaard oorgee.	",
"	15 Jy sal saai, maar nie maai nie; jy sal olywe uittrap, maar jou nie met olie salf nie, en nuwe wyn [maak], maar geen wyn drink nie.	",
"	16 Want die Insettinge van Omri word onderhou en al die werke van die huis van Agab; en julle wandel ooreenkomstig hulle planne, sodat Ek jou tot ’n verskrikking maak en haar inwoners ’n bespotting: en die smaad van My volk sal julle dra. [Openbaring 2:20]	",

]
},
{
book: 'Miga',
chapter: '7',
content: [
		
"	1 WEE My, want Ek het geword soos ná die insameling van somervrugte, soos die natrossies van die wynoes: geen tros om te eet nie, My Siel begeer vroeë vye.	",
"	2 Die toegewyde het verdwyn uit die Aarde, en daar is geen opregte meer onder die adamiete nie; hulle loer almal op bloed; hulle jaag elkeen sy broer met die net.	",
"	3 Na die besoedeling gaan die handpalms uit, om haar goed te doen. Die vors bedel, en die regter vra betaling, en die groot [man] spreek die skandelike lus van sy siel uit, en hulle verdraai alles.	",
"	4 Die suiwerste van hulle is soos ’n doringstruik, die mees opregte erger as ’n [doring]heining. Die dag van jou wagte, jou straf, kom; nou sal hulle verwarring daar wees.	",
"	5 Vertrou geen metgesel nie, maak op geen vriend staat nie, let op die poorte van jou mond teenoor haar wat in jou skoot lê.	",
"	6 Want die seun minag die vader, die dogter staan op teen haar moeder, die skoondogter teen haar skoonmoeder, die man se vyande is sy huisgenote!	",
"	7 Maar Ek sal uitsien na JaHWeH, Ek wil wag op die Elohey van My Lossing, My Elohey sal My hoor.	",
"	8 Wees nie bly oor My nie, o My vyand! Al het Ek geval, Ek staan weer op; al sit Ek in Duisternis, JaHWeH [is die] Lig vir My.	",
"	9 Die Toorn van JaHWeH sal Ek dra, want Ek het teen Hom oortree; totdat Hy My saak verdedig en My Reg verskaf. Hy sal My uitlei in die Lig; Ek sal met welgevalle sien hoe Hy Geregtigheid beoefen.	",
"	10 Ook sal My vyandin Haar sien, en skaamte sal haar bedek wat vir My sê: Waar is JaHWeH, jou Elohey? My oë sal met welgevalle op haar neersien. Nou sal sy vertrap word soos modder van die strate.	",
"	11 Daar kom ’n dag om jou mure te herbou! In dié dag sal die gebied ruim wees. [1 Petrus 2:9; Openbaring 21]	",
"	12 Dit is ’n dag dat hulle na jou sal kom van Assur en die stede van Egipte, en van Egipte tot by die Eufraat, en van see tot see, en [van] berg tot berg.	",
"	13 Maar die Aarde sal ’n verwoesting word vanweë haar bewoners, as gevolg van hulle handelinge.	",
"	14 Wei U volk met U Septer, die kudde wat U Erfdeel is, wat afgesonderd woon in ’n bosveld op Karmel; laat hulle wei in Basan en Gílead soos in die ou dae.	",
"	15 Soos in die dae van jou uittog uit die Aarde van Egipte sal Ek hom wonders laat sien.	",
"	16 Die nasies sal dit sien en skaam wees ondanks al hulle krag: hulle sal die hand op die mond lê, hulle ore sal doof word.	",
"	17 Hulle sal stof lek soos Nagash, hulle sal soos wurms uit hul gate uit die Aarde kruip en bewende uit hulle vestings te voorskyn kom, hulle sal sidderende kom na JaHWeH Onse Elohey, en hulle sal vir U vrees.	",
"	18 Wie is ’n El soos U, wat die ongeregtigheid vergewe en by die oortreding van die oorblyfsel van Sy Erfdeel verbygaan? Hy hou Toorn nie vir ewig vas nie, maar het ’n welbehae in Medelye.	",
"	19 Hy sal Hom weer oor Ons ontferm, op Ons dade van ongeregtigheid nie agslaan nie; ja, U sal al hulle oortredinge in die dieptes van die see werp.	",
"	20 U sal bestendigheid bewys aan Jakob, Medelye aan Abraham, wat U aan Ons vaders met ’n eed beloof het sedert die dae van die voortyd.	",

]
}
];