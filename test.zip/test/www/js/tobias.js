const tobiasChapters = [

{
book: 'Tobias',
chapter: '1',
content: [

"	1 DIE verhaal van Tobias, die seun van TobiEl, die seun van GananiEl die seun van AduEl, die seun van GabaEl, uit die geslag van AsaEl, uit die stam van Náftali,	",
"	2 wat in die dae van Salmaneser die koning van Assirië, uit Thisbe, wat suid van Kedes-Naftali bo Aser in Galiléa geleë was, in ballingskap gevoer is.	",
"	3 Ek, Tobias, het al die dae van my lewe in die Weë van Waarheid en Geregtigheid gewandel. Ek het ook baie liefdadigheid bewys aan my broers en my volk wat na die Aarde van die Assiriërs, na Ninevé, saam met my weggevoer was.	",
"	4 Toe ek nog ‘n jongeling in my eie deel van die Aarde, die Adamah [die adamiet se Aarde] van JisraEl, was, het die hele stam van my voorvader Náftali in opstand gekom teen die Tempel in Jerusalem wat uit al die stamme van JisraEl vir al die stamme gekies was om in te slag, en waarin die Tempel van die woning van die Hoogste El gewy en gebou was vir alle geslagte.	",
"	5 En al die stamme wat daarmee saam in opstand gekom het, het hulle bydraes aan die kalf Baäl gebring.	",
"	6 Maar ek het dikwels alleen op die Feesdae na Jerusalem gereis, soos sy as ‘n ewige Insetting aan die hele JisraEl voorgeskryf was, en die eerstelingvrugte en die tiende deel van my produkte en die eerste skeersels met my meegeneem en aan die priesters, die seuns van Aäron, by die altaar gegee.	",
"	7 ‘n Tiende deel van al my produkte het ek gegee aan die Leviete wat in Jerusalem diens gedoen het, en ‘n ander tiende het ek verkoop en die opbrengs daarvan het ek elke jaar in Jerusalem gaan bestee,	",
"	8 en ‘n derde tiende het ek aan die behoeftiges uitgedeel, soos my groot moeder Debora my geleer het, want ek is na die dood van my vader as weeskind agtergelaat.	",
"	9 Toe ek ‘n man geword het, is ek getroud met Hanna, wat uit die geslag van ons familie was, en by haar het ek ‘n seun, Tobias, gehad.	",
"	10 En toe ek in ballingskap na Ninevé gevoer is, het al my broers en verwante die voedsel van die nasies geëet,	",
"	11 maar ek het myself daarvan weerhou,	",
"	12 want ek het met my hele hart aan Elohim bly dink.	",
"	13 En die Hoogste El het my Guns en status in die oë van Salmaneser laat vind, en ek het die inkoper [van die benodigdhede van sy hofhouding] geword.	",
"	14 Ek het toe ‘n reis na Medië onderneem en tien talente silwer by GabaEl, die broer van Gabrias, te Ragae in Medië gedeponeer.	",
"	15 Maar met die dood van Salmaneser het sy seun Sanherib in sy plek koning geword, en omdat die hoofweë onveilig was, kon ek nie meer na Medië reis nie.	",
"	16 In die dae van Salmaneser het ek baie werke van liefdadigheid in belang van my broers gedoen. Ek het my brood aan die hongeriges gegee en my klere aan die wat nakend was	",
"	17 en as ek een van my volksgenote dood en uitgewerp buite die muur van Ninevé sien lê het, het ek hom begrawe.	",
"	18 En as koning Sanherib iemand wat as vlugteling uit JeHûWdah gekom het, doodgemaak het, het ek hom in die geheim begrawe, want hy het baie in sy toorn om die lewe gebring; en die koning het na hulle liggame gesoek, maar kon dit nie vind nie.	",
"	19 Maar een van die Nineviete het heengegaan en die koning omtrent my ingelig dat ek hulle begrawe het, en ek het weggekruip, want toe ek hoor dat ek gesoek word om om die lewe gebring te word, was ek bevrees en het ek gevlug.	",
"	20 Toe is al my besittings gekonfiskeer, en daar is niks vir my oorgelaat nie behalwe my vrou Hanna en my seun Tobias.	",
"	21 Vyftig dae het nouliks verbygegaan of sy twee seuns het hom [Sanherib] om die lewe gebring en na die gebergte van Ararat die wyk geneem. En sy seun Esar-Haddon het in sy plek koning geword. Hy het Achikar, die seun van my broer HanaEl, oor al die uitgawes en administrasie van sy koninkryk aangestel.	",
"	22 Op grond van Achikar se voorspraak, het ek weer na Ninevé kon gaan. Achikar was naamlik die skinker en die seëlbewaarder en was in beheer van die administrasie en die finansies, en Esar Haddon het hom, my neef, tot tweede in rang naas hom verhef.	",
	
]
},
{
book: 'Tobias',
chapter: '2',
content: [
		
"	1 NADAT ek in my huis teruggekom het, en my vrou Hanna en my seun Tobias aan my teruggegee is, is ‘n geurige middagmaal op die Pinksterfees, wat die Fees van die sewe Weke is, vir my voorberei, en ek het aangesit om te eet.	",
"	2 Toe ek die oorvloed kos voor my sien, sê ek vir my seun: Gaan heen en bring elke behoeftige onder ons broers wat jy kan vind en wat aan JaHWeH gedagtig is, en ek sal op jou wag!	",
"	3 En hy kom terug en sê: Vader, een van ons mense is verwurg en lê uitgewerp op die straat.	",
"	4 Toe hardloop ek, voordat ek aan iets geproe het, na buite en bring hom in ‘n kamer totdat die son sou ondergaan.	",
"	5 Daarop het ek teruggekeer, my gewas en my voedsel in droefheid geëet;	",
"	6 en ek het gedink aan die profesie van Amos waar hy sê: Julle feeste sal verander word in droefheid en julle vrolikheid in klaagsang.	",
"	7 En ek het hardop gehuil. En toe die son onder was, gaan ek, grawe ‘n graf en lê hom daarin neer.	",
"	8 En my bure lag vir my en sê: Hy is nog steeds nie bang om oor hierdie dinge om die lewe gebring te word nie. Hy het weggehardloop en hier is hy alweer besig om die dooies te begrawe!	",
"	9 Daardie selfde nag, nadat ek hom begrawe het, keer ek terug, en omdat ek seremonieel besoedel was, gaan ek met onbedekte gesig langs die muur van die voorhof slaap.	",
"	10 En ek wis nie dat daar spreeus in die muur bo my was nie, en omdat my oë onbedek was, val die uitwerpsels van die spreeus in my oë en vorm wit vliese, daarop. Ek gaan toe na die geneeshere, maar hulle kon my nie help nie. Achikar het my egter gedurende twee jaar onderhou, totdat hy na Elymaïs vertrek het. [Boekrol van die Opregte 52:31]	",
"	11 Toe het my vrou Hanna vroulike handwerke vervaardig en dit aan die eienaars [van die handwerk] afgelewer. [Spreuke van Salomo 31]	",
"	12 En hulle het haar loon uitbetaal en haar bowendien ‘n bokkie gegee.	",
"	13 Maar toe sy by my tuiskom, begin die bokkie te blêr. En ek sê vir haar: Waar kom hierdie bokkie vandaan? Is dit gesteel? Gee dit terug aan sy eienaars, want ons het nie die reg om enigiets wat gesteel is, te eet nie.	",
"	14 Maar sy sê vir my: Dit is saam met my loon as ‘n geskenk aan my gegee. Maar ek wou haar nie glo nie en sê haar aan om dit aan sy eienaars terug te besorg, en ek het my vir haar geskaam. Toe antwoord sy en sê vir my: En waar is jou liefdadigheid? Waar is jou geregtigheid? Natuurlik weet jy alles?	",

]
},
{
book: 'Tobias',
chapter: '3',
content: [
		
"	1 TOE het ek bedroef geword en gehuil,en in my smart bid ek en sê:	",
"	2 JaHWeH, U is opreg, en al U werke en al U Weë is Barmhartigheid en Waarheid, en U oordeel altyd in Waarheid en in opregtheid.	",
"	3 Dink aan my en sien my aan; moenie wraak oor my uitoefen vanweë my oortredinge en tekortkominge en vanweë die van my voorvaders wat hulle teen U misdryf het nie, want hulle het U Gebooie nie gehou nie.	",
"	4 U het ons oorgegee aan plundering en gevangeskap en Dood en ons tot ‘n spreekwoord en beskimping gemaak onder al die nasies waaronder ons verstrooi is.	",
"	5 En nou, U oordele wat groot is, is ook waaragtig in die wyse waarop U my oortredinge en die van my vaders besoek het, omdat ons U Gebooie nie gehou en voor U Aangesig nie opreg gewandel het nie.	",
"	6 Handel dan nou met my ooreenkomstig U welbehae; gee bevel om my gees van my af weg te neem, sodat ek verlos mag word en na die stof mag terugkeer, want ek sal liewer sterwe as om te lewe, omdat ek na valse beskuldigings moes luister en smartlike droefheid ondervind het. Gee opdrag om my uit hierdie ellende te verlos en om my na my ewige rusplek te neem; moenie U aangesig van my afkeer nie.	",
"	7 Op daardie selfde dag gebeur dit met Sarah, die dogter van RaguEl, te Ekbatana in Medië, dat sy ook deur die diensmeisies van haar vader verwyt word	",
"	8 omdat sy met sewe mans getroud was, en die gees van besoedeling, Asmodeus hulle doodgemaak het nog voordat hulle volgens die gebruik by haar as vrou kon kom. En hulle sê vir haar: Weet u nie dat u u eggenotes verwurg het nie? U het alreeds sewe gehad en u het die naam van nie een van hulle gedra nie!	",
"	9 Waarom kwel u ons so. As hulle dood is, volg hulle dan! Mag ons nooit enige seun of dogter van u sien nie!	",
"	10 Toe sy hierdie dinge hoor, is sy diep gegrief en het gewens om haarself op te hang, maar sy sê: Ek is die enigste kind van my vader; as ek dit doen, sal ek skande oor hom bring en hom in sy ouderdom met droefheid in die graf laat neerdaal.	",
"	11 En sy het by haar venster gebid en gesê: Geseënd is U, JaHWeH, my Elohey, en geseënd is U verhewe en glansryke Naam in ewigheid; mag al U werke U tot in ewigheid prys,	",
"	12 En nou, JaHWeH, rig ek my aangesig en my oë op U;	",
"	13 gee opdrag om my te verlos van die Aarde af en dat ek geen verwyt meer mag aanhoor nie.	",
"	14 U weet, o JaHWeH, dat ek onskuldig is van enige oortreding met ‘n man;	",
"	15 ek het nooit my naam of die naam van my vader in die deel van die Aarde van my gevangeskap besoedel nie. Ek is die enigste kind van my vader; hy het geen ander kind om sy erfgenaam te wees nie. Hy het geen broer of neef naby hom met wie ek sou kon trou nie. Ek het reeds sewe eggenotes verloor; waarom sal ek nog langer lewe? En as dit U nie behaag om my dood te maak nie, gee dan dat daar na my omgesien sal word, en daar meegevoel aan my betoon sal word, en dat ek nie verdere verwyte mag aanhoor nie.	",
"	16 En albei se gebed is voor die Aangesig van die Glansrykheid van die groot RafaEl verhoor, [Openbaring 8:3]	",
"	17 en hy is gestuur om albei te genees; na Tobias om die wit vliese te verwyder en om Sarah, die dogter van RaguEl, aan Tobias, die seun van Tobias, as vrou te gee en om Asmodeus, die gees van besoedeling, te bind omdat Tobias die reg het om haar te besit. Op dieselfde tydstip het Tobias toe in sy huis gegaan, en het Sarah, die dogter van RaguEl, uit haar bovertrek afgekom.	",

]
},
{
book: 'Tobias',
chapter: '4',
content: [
	
"	1 OP dieselfde dag het Tobias hom die geld herinner wat hy by GabaEl te Ragae in Medië gedeponeer het.	",
"	2. En hy sê by homself: Ek het gevra om te sterwe; waarom sal ek nie my seun Tobias roep en aan hom verduidelik voor ek heengaan nie?	",
"	3 Toe roep hy hom en sê: My seun, as ek te sterwe kom, begrawe my en moenie jou moeder verwaarloos nie; maak voorsiening vir haar solank as jy lewe; doen wat haar welgevallig is en moenie haar in enigiets bedroef nie.	",
"	4 Onthou, my seun, dat sy voor jou geboorte baie gevare vir jou getrotseer het, en as sy te sterwe kom, begrawe haar naas my in een graf.	",
"	5 Jou hele lewe lank, my seun, moet jy gedagtig wees aan JaHWeH, onse Elohey; moenie toegee aan oortredinge en moenie Sy Gebooie oortree nie. Handel jou hele lewe opreg en moenie in die weë van verkeerdheid wandel nie.	",
"	6 Want as jy Reg doen, sal voorspoed jou ondernemings vergesel. Aan almal wat opreg handel, moet jy uit jou besittings liefdadigheid bewys; en moenie dat jou oog dit wat jy aan liefdadigheid gee, misgun nie. Moenie jou aangesig afwend van enige behoeftige nie, en die Aangesig van Elohim sal nie van jou afgewend word nie.	",
"	7 Gee aan liefdadigheid in ooreenstemming met wat jy besit;	",
"	8 as jy min het, moenie bevrees wees om tog ‘n geringe bedrag aan liefdadigheid te gee nie,	",
"	9 want dan sal jy ‘n suiwer skat vir jouself weglê vir die dag van teenspoed;	",
"	10 want liefdadigheid sal jou red van die dood en sal jou weerhou om in die Duisternis te versink.	",
"	11 Liefdadigheid is ‘n welgevallige aanbieding in die oë van die Hoogste El vir elkeen wat dit bewys.	",
"	12 My seun, wees op jou hoede teen enige vorm van onsedelikheid. Ten eerste, neem vir jou ‘n vrou uit die saad van jou voorvaders; moenie trou met ‘n verbasterde wat nie tot die stam van jou vader behoort nie, want ons is seuns van die profete. Onthou, my seun, dat Noag, Abraham, Isak en Jakob, ons voorvaders van ouds, almal met vroue uit hulle eie familie getrou het, en hulle was geseën in hulle kinders, en hulle saad sal die Aarde beërwe.	",
"	13 Daarom, my seun, moet jy jou volksgenote liefhê, en moenie jou broers en die seuns en dogters van jou volk verag deur te weier om met een van hulle te trou nie. Want sodanige veragting voer tot ondergang en tot groot droefheid, en waardeloosheid bring verlies en groot gebrek mee, want waardeloosheid is die moeder van hongersnood.	",
"	14 Die lone van enigiemand wat vir jou werk, moet jy oornag nie agterweë hou nie, maar jy moet hom onmiddellik betaal. As jy Elohim dien, sal jy loon ontvang. My seun, neem jouself in ag in alles wat jy doen en wees goed gedissiplineerd in jou hele optrede.	",
"	15 Moenie aan iemand anders doen wat jy self haat nie. Moenie wyn drink totdat jy dronk word nie; dronkenskap mag jou op jou weg nie vergesel nie.	",
"	16 Gee ‘n deel van jou brood aan die hongeriges en van jou klere aan hulle wat nakend is. Gee jou hele oorskot aan liefdadigheid, en moenie dat jou oog afgunstig wees op dit wat jy aan liefdadigheid bestee nie.	",
"	17 Strooi jou brood uit op die grafte van die opregtes, maar moenie aan wetteloses gee nie.	",
"	18 Vra raad by elke wyse man, en moenie enige waardevolle advies gering ag nie.	",
"	19 Loof JaHWeH Elohim te alle tye en vra Hom om jou weë reguit en jou paaie en voornemens voorspoedig te maak. Want geen nasie besit in homself die regte insig nie, maar JaHWeH beskik alle suiwer dinge en Hy verneder wie Hy wil, volgens Sy welbehae. En nou, my seun, dink aan my bevele en laat dit nie uit jou gedagtes verdwyn nie.	",
"	20 En nou moet ek jou ook nog vertel van die tien talente silwer wat ek by GabaEl, die seun van Gabrias, te Ragae in Medië, gedeponeer het. Moenie bevrees wees nie, my seun, omdat ons arm geword het nie. Jy het meer as genoeg as jy JaHWeH vrees en jou van oortreding weerhou en doen wat welbehaaglik is in Sy Oë.	",

]
},
{
book: 'Tobias',
chapter: '5',
content: [
		
"	1 TOE antwoord Tobias en sê aan hom: Vader, ek sal alles wat u my beveel het, volbring.	",
"	2 Maar hoe sal ek die geld in die hande kry, terwyl ek die man nie ken nie?	",
"	3 Toe het sy vader hom die bewys gegee en aan hom gesê: Soek iemand wat saam met jou kan gaan, en ek sal hom sy loon betaal solank as ek lewe; gaan dan en haal die geld.	",
"	4 En hy gaan om na iemand te soek en hy vind RafaEl wat ‘n Boodskapper was, alhoewel Tobias dit nie geweet het nie.	",
"	5 En hy sê vir hom: Mag ek saam met jou na Ragae in Medië gaan, en is jy bekend met die omgewing?	",
"	6 Toe sê die Boodskapper vir hom: Ek sal saam met jou gaan, want ek ken die pad daarheen en ek het al by ons broer GabaEl vertoef.	",
"	7 En Tobias sê vir hom: Wag op my dat ek my vader daarvan vertel.	",
"	8 En hy sê vir hom: Gaan, en moenie vertoef nie. En hy het heengegaan en aan sy vader gesê: Ek het iemand gevind wat met my wil saamgaan. En hy sê: Roep hom hierheen dat ek kan vasstel tot watter stam hy behoort en of hy ‘n betroubare persoon is om met jou saam te gaan.	",
		
		
"	9 Daarop roep hy hom, en hy kom binne, en hulle groet mekaar.	",
"	10 En Tobias sê vir hom: Broer, vertel my tot watter stam en tot watter familie jy behoort?	",
"	11 En hy sê vir hom: Is jy op soek na ‘n stam en ‘n familie of na ‘n gehuurde metgesel vir jou seun?    En Tobias sê vir hom: Ek wou maar net jou familieverbintenisse en jou naam te wete gekom het, broer.	",
		
"	12 En hy sê: Ek is AzarJaH, die seun van die oudste GanánJaH, iemand uit jou stam.	",
"	13 En hy sê vir hom: Welkom broer! Moenie vir my kwaad wees omdat ek wou weet tot watter stam en familie jy behoort nie; jy is ‘n stamverwant van my en is van ‘n edele en suiwer afkoms. Want ek het GanánJaH en Jatan, die seuns van die oudste Semaja, goed geken, want ons was gewoond om saam na Jerusalem af te reis om daar te aanbid en die eersgeborenes van ons vee en die tiendes van ons produkte aan te bied, want hulle het nie saam met ons broers afgedwaal nie; jy kom uit ‘n suiwer familie, broer.	",
"	14 Maar sê my watter loon moet ek jou gee; sal ‘n dragma per dag vir jou en my seun se onkoste voldoende wees?	",
"	15 En as julle veilig en wel terugkom, sal ek nog by die loon toevoeg!	",
"	16 En hulle het hierin ooreengekom, en hy het aan Tobias [sy seun] gesê: Maak jou gereed vir die reis, en vaarwel!  En sy seun het alles vir die reis in gereedheid gebring, en sy vader het vir hom gesê: Gaan saam met hierdie man, en Elohim wat in die Hemele woon, sal julle reis voorspoedig maak en Sy Boodskapper saam met julle stuur.  Daarop gaan hulle albei heen en reis af, en die seun se hond volg hulle.	",
		
		
"	17 En sy moeder Hanna huil en sê vir Tobias: Waarom het jy ons kind weggestuur? Is hy nie ons staf wanneer hy voor ons in- en uitgaan nie?	",
"	18 Moenie dat geld by geld gevoeg word nie, maar laat die wees soos stof in vergelyking met ons kind.	",
"	19 Want die feit dat JaHWeH ons laat lewe, is vir ons genoeg.	",
"	20 En Tobias sê vir haar: Moenie besorg wees nie, my suster. Hy sal veilig en wel terugkom, en jou oë sal hom sien.	",
"	21 Want ‘n goeie Boodskapper sal met hom saamgaan, en hy sal ‘n voorspoedige reis hê en sal veilig en wel terugkeer.	",
"	22 Toe het sy opgehou om te huil.	",

]
},
{
book: 'Tobias',
chapter: '6',
content: [
		
"	1 EN hulle het heengereis en het teen die aand die Tigris-rivier bereik en die nag daar deurgebring.	",
"	2 En die seun gaan om hom te was, en ‘n vis spring uit die rivier en sou die seun ingesluk het.	",
"	3 Maar die Boodskapper sê vir hom: Gryp die vis! En die seun gryp die vis en gooi hom op die grond uit.	",
"	4 En die Boodskapper sê vir hom: Slag die vis en neem sy hart en lewer en gal en bewaar dit veilig.	",
"	5 En die seun doen soos die Boodskapper hom beveel het, en hulle het die vis gebak en hom geëet. En hulle het saam verder gereis totdat hulle naby Ekbatana gekom het.	",
"	6 Toe vra die seun aan die Boodskapper: Broer AzarJaH, waarvoor is die lewer en die hart en die gal van die vis goed?	",
"	7 En hy sê vir hom: Wat die hart en die lewer betref, as enigiemand deur ‘n demoon of ‘n gees van besoedeling gepla word, dan moet jy [die hart en lewer] voor die betrokke man of vrou in rook laat opgaan, en hulle sal nie meer lastig geval word nie.	",
"	8 En wat die gal betref, as jy dit vryf op iemand wat wit vliese oor sy oë het, sal hy gesond word.	",
"	9 Toe hulle naby Ragae kom,	",
"	10 sê die Boodskapper vir die seun: Broer, ons sal vandag by RaguEl vertoef, want hy is ‘n bloedverwant van jou. Hy het ‘n enigste dogter met die naam van Sarah. Ek gaan hom sê om haar met jou te laat trou	",
"	11 want jy is geregtig om haar te hê omdat jy haar enigste verwant is,	",
"	12 en sy is mooi en verstandig. As jy dan nou na my wil luister, sal ek met haar vader praat, en dan kan ons as ons van Ragae af teruggekeer het, die huwelik voltrek. Want ek weet dat RaguEl haar volgens die Wet van Moshè op straf van die dood nie aan iemand anders kan uithuwelik nie, want dit is jou reg om haar te besit en niemand anders s’n nie.	",
"	13 Toe sê die seun aan die Boodskapper: Broer AzarJaH, ek het verneem dat hierdie meisie reeds aan sewe mans uitgehuwelik was en dat hulle almal in die bruidsvertrek omgekom het.	",
"	14 En nou is ek die enigste kind van my vader en ek is bang dat as ek ingaan, ek net soos die ander sal sterwe, want ‘n demoon is op haar verlief en hy doen slegs hulle leed aan wat naby haar kom. Daarom is ek bevrees dat ek sal sterwe en daardeur die lewe van my vader en moeder met droefheid oor my in die graf sal laat neerdaal; want hulle het geen ander seun om hulle te begrawe nie.	",
"	15 Toe sê die Boodskapper aan hom: Onthou jy nie die bevele wat jou vader jou gegee het, naamlik dat jy vir jou ‘n vrou uit jou eie familie moet neem nie? Daarom moet jy na my luister, broer, want sy moet jou vrou wees; en oor die demoon moet jy jou geen sorge maak nie, want sy sal vannag aan jou gegee word om jou vrou te wees.	",
"	16 En as jy in die bruidsvertrek ingaan, moet jy van die as van die wierook neem en stukkies van die hart en lewer van die vis daarop plaas om sodoende rook te maak,	",
"	17 en die demoon sal dit ruik en wegvlug en nooit weer terugkom nie. En wanneer jy na haar toe gaan, moet julle albei opstaan en tot die barmhartige Elohim roep, en Hy sal julle red en julle barmhartig wees. Moenie bevrees wees nie, want sy was van die begin af vir jou bestem, en jy sal haar verlos, en sy sal saam met jou huis toe gaan, en ek veronderstel dat jy kinders by haar sal hê.   Toe Tobias dit hoor, het hy haar liefgekry en het hy innig aan haar verkleef geraak.	",

]
},
{
book: 'Tobias',
chapter: '7',
content: [
		
"	1 TOE hulle in Ekbatana aankom, het hulle na die huis van RaguEl gegaan, en Sarah het hulle teëgekom en welkom geheet, en hulle het haar gegroet, en sy het hulle in die huis ingeneem.	",
"	2 En RaguEl sê vir sy vrou Edna: Hoe baie lyk hierdie jongman op my neef Tobias!	",
"	3 En RaguEl vra hulle: Waarvandaan kom julle, broers? En hulle sê vir hom: Ons behoort aan die seuns van Náftali wat in Ninevé in gevangeskap verkeer.	",
"	4 En hy sê vir hulle: Is julle bekend met ons familielid Tobias? En hulle sê: Inderdaad! En hy sê vir hulle: Gaan dit goed met hom?	",
"	5 En hulle sê: Hy lewe en is wel en Tobias sê: Hy is my vader!	",
"	6 Toe spring RaguEl op en soen hom en hy huil	",
"	7 en seën hom en sê vir hom: Is jy die seun van daardie edele en suiwer man? En toe hy hoor dat Tobias die gesig van sy oë verloor het, was hy bedroef en het hy gehuil,	",
"	8 en sy vrou Edna en sy dogter Sarah het ook gehuil. En hulle het hulle hartlik verwelkom, en hulle het ‘n ram uit die kudde geslag en voedsel in oorvloed aan hulle voorgesit.  Toe sê Tobias vir RafaEl: Broer AzarJaH, spreek oor die dinge waar-oor ons op reis gepraat het en laat daardie saak afgehandel word.	",
		
"	9 Toe het hy die saak aan RaguEl voorgestel, en RaguEl sê aan Tobias:	",
"	10 Eet, drink en wees vrolik, want jy het die reg om my kind te neem.	",
"	11 Maar ek moet die waarheid aan jou bekend maak. Ek het my kind reeds aan sewe mans gegee, en elke keer wanneer hulle naby haar kom, het hulle dieselfde nag gesterwe. Maar wees vrolik vir die teenswoordige.  Toe sê Tobias: Ek sal niks meer eet voordat u nie ‘n bindende ooreenkoms met my aangegaan het om dit te doen nie.	",
		
"	12 Toe sê RaguEl: Neem haar onmiddellik volgens die Verordening; sy is jou verwant en behoort aan jou; en mag die barmhartige Elohim julle baie voorspoedig maak.	",
"	13 Toe het hy sy dogter Sarah binne geroep, haar hand geneem, en haar as vrou aan Tobias gegee en gesê: Hier is sy, neem haar volgens die Wet van Moshè en keer met haar na jou vader terug.	",
"	14 En hy het hulle sy seën gegee. En hy het sy vrou Edna binne geroep, ‘n rol papier geneem en daarop ‘n ooreenkoms geskryf, en hulle het hul seëls daarop geplaas.	",
"	15 Toe het hulle begin eet.	",
"	16 RaguEl roep toe sy vrou Edna opsy en sê vir haar: My suster, bring die ander slaapkamer in gereedheid en neem haar daarheen.	",
"	17 En sy doen soos hy gesê het en bring haar daar in en sy het gehuil. En sy laat haar dogter op haar skouer huil en sê vir haar:	",
"	18 Hou moed, my kind! JaHWeH van die Hemele en die Aarde betoon Guns aan jou in plaas van jou droefheid. Hou moed, my dogter!	",

]
},
{
book: 'Tobias',
chapter: '8',
content: [
		
"	1 TOE hulle klaar was met die aandete, neem hulle Tobias na haar toe.	",
"	2 En terwyl hy daarheen gaan, onthou hy wat RafaEl gesê het en hy neem die as van wierook en plaas die hart en die lewer van die vis daarop en maak rook.	",
"	3 En toe die demoon die ruik van die rook kry, vlug hy na die verste dele van Bo-Egipte, en die Boodskapper het hom daar gebind.	",
"	4 Toe hulle albei saam ingesluit is, staan Tobias van die bed af op en sê: Staan op, my suster, en laat ons saam bid dat JaHWeH ons barmhartig mag wees.	",
"	5 En hy begin om te sê: Geseënd is U, Elohim van ons vaders, en geseënd is U verhewe en glansryke Naam in ewigheid. Laat die Hemele en U hele skepping U prys.	",
"	6 U het Adam gemaak en hom sy vrou Gawwah tot hulp en steun gegee, en van hulle stam die adamitiese geslag. U het gesê: Dit is nie goed dat die adamiet alleen is nie; laat Ons vir hom ‘n hulp maak wat by hom pas.	",
"	7 En nou, JaHWeH, is dit nie weens vleeslike begeerte dat ek my suster hier neem nie, maar in Waarheid. Wees my dan barmhartig en laat ek oud word by haar.	",
"	8 En sy het saam met hom 'amein' gesê.	",
"	9 En hulle het albei die hele nag deur geslaap. Maar RaguEl het opgestaan en heengegaan en ‘n graf gegrawe, want hy het gesê:	",
"	10 Miskien sal hy ook sterwe.	",
"	11 Toe kom RaguEl in die huis en sê vir sy vrou Edna;	",
"	12 Stuur een van die diensmeisies om te sien of hy nog lewe, en as dit nie die geval is nie, laat ons hom dan begrawe sonder dat enigiemand dit weet.	",
"	13 En die diensmeisie het die deur oopgemaak en ingegaan en hulle albei aan die slaap gevind,	",
"	14 Toe het sy uitgekom en hulle vertel dat hy lewe.	",
"	15 Daarop prys RaguEl Elohim en sê:	",
"	16 Geseënd is U, o JaHWeH, met elke suiwer en verhewe seëning! Laat U apartes en U hele skepping U loof, en laat al U Boodskappers en U uitverkore volk U vir ewig prys.	",
"	17 U word geloof omdat U Barmhartigheid aan twee enigste kinders betoon het; o JaHWeH, wees hulle barmhartig; gee dat hulle tot die einde toe in goeie gesondheid, met Vreugde en in Guns mag lewe.	",
"	18 Toe beveel hy sy diensknegte om die graf toe te gooi.	",
"	19 En hy het vir hulle ‘n huweliksfees aangerig wat veertien dae lank geduur het.	",
"	20 En voor die dae van die huweliksfees verby was, het RaguEl hom besweer dat hy nie sal vertrek voor aan die einde van die veertiendaagse huweliksfees nie,	",
"	21 en dat hy dan die helfte van RaguEl se besittings moet neem en so veilig na sy vader terugkeer. Die wat oorbly, het hy gesê, sal julle s’n wees as ek en my vrou te sterwe kom.	",

]
},
{
book: 'Tobias',
chapter: '9',
content: [
		
"	1 EN Tobias het RafaEl geroep en vir hom gesê:	",
"	2 Broer AzarJaH, neem ‘n kneg saam met jou en twee kamele en gaan asseblief na GabaEl te Ragae in Medië en kry vir my die geld en bring hom saam na die huweliksfees.	",
"	3 Want RaguEl het my besweer dat ek nie moet vertrek nie,	",
"	4 en my vader tel reeds die dae, en as ek te lank vertoef, sal hy baie bedroef wees.	",
"	5 Toe het RafaEl gegaan en die nag by GabaEl deurgebring; en hy het hom die bewys gegee, en hy het die sakke met ongebroke seëls uitgebring en dit aan hom gegee.	",
"	6 En hulle het vroeg die môre saam opgestaan en by die huweliksfees aangekom; en Tobias het sy vrou geseën.	",

]
},
{
book: 'Tobias',
chapter: '10',
content: [
		
"	1 EN nou het dit gebeur dat sy vader Tobias elke dag getel het. En toe die dae wat vir die reis nodig was, verbygegaan het en hulle nog nie teruggekeer het nie,	",
"	2 sê hy: Is dit moontlik dat hulle teleurgestel is? Of is GabaEl miskien dood sodat daar niemand is om hulle die geld te gee nie?	",
"	3 En hy was baie bedroef.	",
"	4 En sy vrou se vir hom: Die kind het omgekom; dit is die rede waarom hy so lank neem. en sy begin om hom te beween en sê:	",
"	5 Het ek nie omgegee nie, my kind, dat ek jou, die lig van my oë, laat gaan het?	",
"	6 En Tobias sê vir haar: Wees stil, moenie besorg wees nie; dit is wel met hom.	",
"	7 Maar sy antwoord hom: Bly stil, moenie my bedrieg nie; my kind het omgekom.  En elke dag het sy gegaan langs die pad waarmee hy afgereis het, en bedags het sy geweier om te eet en gedurende die nag het sy haar seun Tobias ononderbroke beween, totdat die veertien dae van die huweliksfees, wat RaguEl hom besweer het om daar te bly, verby was. Toe sê Tobias aan RaguEl: Laat my nou gaan, want my vader en moeder het al alle hoop laat vaar om my ooit weer te sien.	",
		
		
"	8 Maar sy skoonvader sê vir hom: Bly by my, en ek sal na jou vader toe stuur, en hulle sal in verband met jou aan hom verduidelik.	",
"	9 En Tobias sê: Nee, laat my liewer na my vader toe gaan.	",
"	10 Toe staan RaguEl op en gee hom Sarah, sy vrou, benewens die helfte van sy besittings aan slawe en vee en geld.	",
"	11 En toe hy hulle laat gaan, seën hy hulle en sê: My kinders, die Elohey van die Hemele sal julle voor my dood voorspoedig maak.	",
"	12 En aan sy dogter sê hy: Jy moet eerbied hê vir jou skoonvader en skoonmoeder, want hulle is nou jou ouers. Laat ek ‘n goeie getuienis in verband met jou verneem.  Toe soen hy haar. En Edna sê vir Tobias: Mag JaHWeH van die Hemele jou veilig terug begelei, liewe broer, en gee dat ek jou kinders by my dogter Sarah mag sien, sodat ek my voor die Aangesig van JaHWeH mag verbly. Hier vertrou ek my dogter plegtig aan jou toe; moenie haar gevoelens seermaak nie.	",

]
},
{
book: 'Tobias',
chapter: '11',
content: [
		
"	1 DAARNA vertrek Tobias, terwyl hy Elohim loof omdat Hy sy weg voorspoedig gemaak het, en hy het RaguEl en sy vrou Edna geseën.	",
"	2 Hy het voort getrek totdat hulle naby Ninevé gekom het. Toe sê RafaEl aan Tobias: Onthou jy nie, broer, hoe jy jou vader verlaat het nie?	",
"	3 Laat ons vooruit hardloop, voor jou vrou uit, en eers die huis in gereedheid bring.	",
"	4 Maar neem die gal van die vis in jou hand. Hulle gaan toe, met die hond op hulle hakke.	",
"	5 En Hanna het gesit en die pad vir haar seun dopgehou.	",
"	6 Toe sy hom sien aankom, sê sy vir sy vader: Hier kom jou seun aan en die man wat hom vergesel het!	",
"	7 En RafaEl sê:	",
"	8 Ek weet dat jou vader sy oë sal oopmaak; vryf dan die gal in sy oë, en as hy die brand voel sal hy dit vrywe en so die wit vliese verwyder en in staat wees om jou te sien.	",
"	9 En Hanna het hulle tegemoet gehardloop en haar seun omhels en vir hom gesê: Nou dat ek jou gesien het, my kind, is ek bereid om te sterwe!	",
"	10 En hulle het albei gehuil. En Tobias kom ook na die deur toe en struikel,	",
"	11 en sy seun hardloop na hom toe en hou sy vader vas en sprinkel die gal op die oë van sy vader en sê: Hou moed, vader?	",
"	12 En toe sy oë begin pyn, vrywe hy hulle,	",
"	13 en die wit vliese het vanuit die hoeke van sy oë begin afval.	",
"	14 En toe hy sy seun sien, omhels hy hom en ween en sê: Geseënd is U, o Elohim, en geseënd is U Naam in ewigheid, en geseënd is al U Boodskappers van Apartheid.	",
"	15 Want alhoewel U my getugtig het, het U U oor my ontferm; kyk, ek kan my seun Tobias sien!  En sy seun het met blydskap ingegaan terwyl hy sy vader vertel van die wonderbare dinge wat met hom in Medië gebeur het.	",
		
"	16 Daarop het Tobias met vreugde uitgegaan om sy skoondogter by die poort van Ninevé te ontmoet. En hulle wat hom sien gaan, was verbaas omdat hy die gesig van sy oë teruggekry het.	",
"	17 En Tobias het in hulle teenwoordigheid dank betuig, omdat Elohim hom barmhartig was. En toe Tobias by sy skoondogter Sarah kom, seën hy haar en sê: Welkom dogter. Geseënd is Elohim wat jou na ons toe gebring het, en geseënd is jou vader en jou moeder.  En daar was groot vreugde onder al sy broers in Ninevé,	",
		
"	18 En Achikar en sy neef Nasbas het gekom,	",
"	19 en Tobias se huweliksfees is gedurende sewe dae met groot blydskap gevier.	",

]
},
{
book: 'Tobias',
chapter: '12',
content: [
		
"	1 TOE roep Tobias sy seun Tobias en sê vir hom: My seun, bepaal die loon van die man wat saam met jou gereis het, want ons moet hom meer gee.	",
"	2 En hy sê vir hom: Vader, ek kan bekostig om hom die helfte te gee van wat ek teruggebring het,	",
"	3 want hy het my veilig en wel aan u terugbesorg, my vrou genees en die geld vir my gaan haal, en daarby het hy ook u gesond gemaak.	",
"	4 En die ou man sê: Ons is dit aan hom verskuldig.	",
"	5 En hy roep die Boodskapper en sê vir hom: Neem die helfte van alles wat jy teruggebring het.	",
"	6 toe roep hy [die Boodskapper] hul albei opsy en sê vir hulle: Loof JaHWeH en betuig dank aan Hom. Maak Hom groot en getuig in die teenwoordigheid van al wat lewe van wat Hy teenoor julle gedoen het. Dit is goed om JaHWeH te loof en om Sy Naam groot te maak en om die dade van Elohim eerbiedig te vermeld; moet dus nie traag wees om Hom te dank nie.	",
"	7 Dit is wys om die geheim van ‘n koning te bewaar, maar die werke van Elohim moet in Glansrykheid openbaar gemaak word. Doen goed, en die kwaad sal nie oor julle kom nie.	",
"	8 Gebed is goed as dit gepaard gaan met vas, liefdadigheid en opregtheid. ‘n Weinig met opregtheid is beter as baie met besoedeling. Dit is beter om liefdadigheid te bewys as om goud op te hoop.	",
"	9 Want liefdadigheid sal ‘n man van die Dood red; dit sal alle oortreding versoen. Hulle wat liefdadigheid bewys en opreg handel, sal met die lewe versadig word;	",
"	10 maar hulle wat oortree, is die vyande van hulle eie lewe.	",
"	11 Ek sal niks vir julle verberg nie; soos ek gesê het, is dit wys om die geheim van ‘n koning te bewaar, maar die werke van Elohim moet in Glansrykheid openbaar gemaak word.	",
"	12 Daarom, toe jy en jou skoondogter Sarah gebid het, het ek die herinnering van julle gebed voor die Aparte Een gebring. En toe jy die dooies begrawe het, was ek steeds by jou.	",
"	13 En toe jy nie teruggedeins het om op te staan en jou feesmaal te verlaat en die lyk te versorg nie, het jou goeie daad my aandag nie ontsnap nie, maar ek was by jou.	",
"	14 Daarom het JaHWeH my gestuur om jou en jou skoondogter Sarah te genees.	",
"	15 Want ek is RafaEl, een van die sewe Boodskappers van Apartheid, wat die gebede van die volk naderbring en wat ingaan in die Glansrykheid van die Aparte Een!	",
"	16 En hulle was albei verstom en het op hulle aangesigte geval, want hulle was bevrees.	",
"	17 Maar hy sê vir hulle: Moenie bang wees nie; Vrede vir julle! Loof JaHWeH in ewigheid.	",
"	18 Want dit is nie deur my guns dat ek na julle toe gekom het nie, maar deur die wil van JaHWeH. Daarom loof Hom tot in ewigheid!	",
"	19 Gedurende al die dae wat ek aan julle verskyn het, het ek nie geëet of gedrink nie, maar julle het ‘n gesig gesien.	",
"	20 Daarom betuig dank aan Elohim, want ek moet heengaan na Hom wat my gestuur het, en julle moet alles wat gebeur het in ‘n Boekrol skryf.	",
"	21 En toe hulle opstaan, sien hulle hom nie meer nie.	",
"	22 En hulle het die groot en wonderbare dade van Elohim verkondig en vertel van hoe die Boodskapper van JaHWeH aan hulle verskyn het.	",

]
},
{
book: 'Tobias',
chapter: '13',
content: [
		
"	1 TOE het Tobias ‘n lofgebed neer geskryf en [daarin] gesê: Loof JaHWeH wat vir ewig lewe, en geseënd is Sy koninkryk,	",
"	2 want Hy tugtig en Hy betoon Barmhartigheid, Hy laat mense in die Doderyk/Sheol afdaal en Hy bring hulle uit haar weer op, en daar is niemand wat Sy Hand kan ontvlug nie.	",
"	3 Dank Hom, JisraEliete, in die teenwoordigheid van die nasies, want Hy het julle onder hulle verstrooi.	",
"	4 Toon dáár Sy Glansrykheid; verhef Hom in die aangesig van al wat leef, want Hy is ons Meester en ons Elohey, Hy is onse Vader tot in ewigheid.	",
"	5 Hy sal ons tugtig weens ons oortredinge, en Hy sal Hom weer ontferm en ons vergader te midde van al die nasies waarheen julle verstrooi is. [JeshaJaHuW 11:12]	",
"	6 As julle jul met julle hele hart tot Hom bekeer, en met julle hele siel in Waarheid voor Hom wil wandel, dan sal Hy Hom tot julle wend; Hy sal Sy Aangesig vir julle nie verberg nie. Bemerk hoe Hy met julle wil handel en dank Hom uit volle bors. Loof JaHWeH van Geregtigheid en verhef die Koning van die eeue. In die Aarde van my gevangeskap dank ek Hom, en ek openbaar Sy Mag en Sy Majesteit aan ‘n nasie van wetsoortreders: wend julle tot Hom, o wetsoortreders, en doen wat Reg is in Sy Oë; miskien sal Hy Hom oor julle ontferm en julle Barmhartigheid bewys.	",
"	7 Ek verhef my Elohey, my siel verhef die Koning van die Hemele en jubel in Sy Glansrykheid.	",
"	8 Laat alle mense spreek en Hom in Jerusalem dank betuig.	",
"	9 O Jerusalem, Stad van Apartheid, Hy sal jou tugtig weens die dade van jou kinders. Maar dan sal Hy Hom meer ontferm oor die seuns van die opregte.	",
"	10 Dank JaHWeH in alle Suiwerheid en loof die Koning van die eeue dat Sy Tent met Vreugde in jou herbou mag word. Mag Hy hulle wat gevangenes is in jou bly maak, en mag Hy die ellendige in jou liefhê vir alle geslagte tot in ewigheid.	",
"	11 Baie nasies sal van ver af na die Naam van JaHWeH onse Elohey toe kom met geskenke in hulle hande, geskenke vir die Koning van die Hemele. Geslagte van geslagte sal U lof verhef.	",
"	12 Vervloek is almal wat U haat! Almal wat U liefhet, sal vir ewig geseënd wees.	",
"	13 Verbly en verheug julle in die seuns van die opregte, want hulle sal saam vergader word en hulle sal JaHWeH van die opregte prys.	",
"	14 Geseënd is hulle wat U liefhet! Hulle sal hulle verbly in U Vrede. Geseënd is hulle wat bedroef is oor al U kastydinge, want hulle sal hul oor U verbly as hulle U Glansrykheid aanskou, en hulle sal ewige Vreugde bedryf.	",
"	15 Laat my siel JaHWeH, die groot Koning, loof,	",
"	16 want Jerusalem sal gebou word met saffiere en smaragde, en haar mure met kosbare stene, en haar torings en vestings van suiwer goud.	",
"	17 En die strate van Jerusalem sal geplavei wees met berille en robyne en klippe van Ofir,	",
"	18 En al haar pleine sal sê: Halalu-JaHH/Prys jul JaHH’, en sal lof verhef en sê: Loof JaHWeH wat jou verhoog het tot in ewigheid!	",
		

]
},
{
book: 'Tobias',
chapter: '14',
content: [
		
"	1 SO het Tobias sy danksegging beëindig.	",
"	2 Hy was agt-en-vyftig jaar oud toe hy die gesig van sy oë verloor het, en agt jaar later het hy weer siende geword; en hy het liefdadigheid bewys en het voortgegaan om JaHWeH sy Elohey te vrees en om Hom te dank.	",
"	3 En toe hy baie oud geword het, het hy sy seun, en die seuns van sy seun, na hom toe geroep en vir hom gesê: My kind, neem jou seuns. Ek het oud geword en sal spoedig uit hierdie lewe heengaan.	",
"	4 Vertrek na Medië, my seun, want ek glo vas wat die profeet Jona aangaande Ninevé gesê het, dat sy verwoes sal word, maar in Medië sal daar anders as hier nog ‘n rukkie vrede wees; en dat ons broers uit die gesuiwerde Adamah [die adamiet se Aarde] oor die Aarde verstrooi sal word, en dat Jerusalem verlate sal wees en die Huis van Elohim wat in haar is, verbrand sal word en ‘n tyd lank verwoes sal wees.	",
"	5 Dan sal JaHWeH Hom weer oor hulle ontferm en hulle na hul Adamah [die adamiet se Aarde] terugbring. En hulle sal die Tempel herbou, maar nie soos sy vantevore was nie, totdat die tyd van daardie geslag verbygegaan het. En daarna sal hulle van die plekke van hulle gevangeskap terugkeer om Jerusalem in glansrykheid te herbou, en die Huis van JaHWeH sal in haar in al sy prag herbou word vir al die geslagte tot in ewigheid, soos die profete daaromtrent gespreek het.	",
"	6 En al die nasies sal hulle bekeer om JaHWeH hulle Elohey in Waarheid te Vrees, en hulle sal hulle idole begrawe,	",
"	7 en al die nasies sal JaHWeH loof. En Sy volk sal hulle Elohey dank, en JaHWeH sal Sy volk verhoog, en almal wat JaHWeH hulle Elohey in Waarheid en opregtheid liefhet, sal hulle verbly en sal Barmhartigheid aan ons broers betoon.	",
"	8 En nou, my kind, verlaat Ninevé; wat die profeet Jona gesê, sal sekerlik gebeur.	",
"	9 Maar hou die Wet en die Insettinge en wees barmhartig en opreg, sodat jy voorspoed mag hê.	",
"	10 Begrawe my behoorlik en my vrou langs my. En moenie langer in Ninevé vertoef nie. Let op, my kind, na wat Haman aan Achikar, wat hom opgevoed het, gedoen het, hoe hy hom uit die lig in die duisternis gestort en hoe hy hom vergeld het! Tog is Achikar gered, en die ander een het sy vergelding ontvang en het self in die duisternis verdwyn. Mórdegai het liefdadigheid bewys en hy het aan die noodlottige strik wat Haman vir hom gespan het, ontkom, maar Haman is self in die strik gevang en het sy lewe verloor.	",
"	11 Sien dus, my kinders, wat liefdadigheid kan doen, en hoe Geregtigheid kan verlos!   En nadat hy dit gesê het, het hy sy laaste asem daar in sy bed uitgeblaas. Hy was honderd-agt-en-vyftig jaar oud, en hulle het hom ‘n eervolle begrafnis gegee.	",
		
"	12 Toe Hanna sterf, het hy [die seun Tobias] haar langs sy vader begrawe. Daarna het Tobias met sy vrou en sy seuns na Ekbatana teruggegaan, na sy skoonvader RaguEl.	",
"	13 En hy het ‘n hoe ouderdom bereik en het sy skoonvader en sy skoonmoeder eervol begrawe en hulle besittings sowel as die van sy vader Tobias geërf.	",
"	14 En in die ouderdom van honderd-sewe-en-twintig jaar het hy in Ekbatana in Medië gesterwe.	",

]
}

];
