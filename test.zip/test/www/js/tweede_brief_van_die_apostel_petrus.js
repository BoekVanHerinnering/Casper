const tweede_brief_van_die_apostel_petrusChapters = [

{
book: 'Tweede_Brief_Van_Die_Apostel_Petrus',
chapter: '1',
content: [
	
"	1 SIMEON Petrus, ’n dienskneg en Apostel van JaHWèshua die Gesalfde, aan die wat net so ’n kosbare Geloof as ons verkry het deur die Geregtigheid van onse Elohey en Verlosser, JaHWèshua die Gesalfde:	",
"	2 Mag Barmhartigheid en Vrede vir julle vermeerder word deur die Kennis van Elohim en JaHWèshua, onse Meester!	",
"	3 IMMERS, SY Krag van BO het ons alles geskenk wat tot die lewe en eerbaarheid dien, deur die Kennis van Hom wat ons geroep het deur Sy Majesteit en Deug,	",
"	4 waardeur Hy ons die grootste en kosbare Beloftes geskenk het, sodat julle deur Hulle saamgevoeg kan word vanuit die Elohim, nadat julle die verdorwenheid ontvlug het wat deur begeerlikheid in die wêreld is.",
"	5 En juis daarom ook moet julle met aanwending van alle ywer by julle Geloof voeg die Deug, en by die Deug die Kennis,	",
"	6 en by die kennis die selfbeheersing, en by die selfbeheersing die lydsaamheid, en by die lydsaamheid die eerbaarheid,	",
"	7 en by die eerbaarheid die broederliefde, en by die broederliefde die liefdadigheid.	",
"	8 Want as hierdie dinge by julle aanwesig is en toeneem, dan laat Sy julle nie ledig of onvrugbaar tot die Kennis van onse Meester JaHWèshua die Gesalfde nie;	",
"	9 want hy by wie hierdie dinge nie aanwesig is nie, is blind en kortsigtig, en het die wassing/doop van sy vorige oortredinge vergeet.	",
"	10 Daarom, broers, moet julle jul des te meer beywer om julle roeping en verkiesing vas te maak; want as julle dit doen, sal julle nooit struikel nie.	",
"	11 Want so sal ryklik aan julle verleen word die ingang in die ewige Koninkryk van onse Meester en Verlosser, JaHWèshua die Gesalfde.	",
"	12 Daarom sal ek nie nalaat om julle altyd hieraan te herinner nie, alhoewel julle [Haar] ken en vasstaan in die Waarheid wat by julle is.	",
"	13 En ek beskou dit regverdig, so lank as ek in hierdie tentwoning is, om julle deur herinnering op te wek,	",
"	14 omdat ek weet dat die aflegging van my tentwoning op hande is, soos onse Meester JaHWèshua die Gesalfde dit ook aan my bekend gemaak het.	",
"	15 En ek sal my beywer, dat julle ook gedurig ná my heengaan hierdie dinge in gedagtenis kan hou.	",
"	16 Want ons het nie kunstig verdigte fabels nagevolg toe ons julle die Krag en koms van onse Meester JaHWèshua die Gesalfde bekend gemaak het nie, maar ons was ooggetuies van Sy Majesteit;	",
"	17 want Hy het van die Elohim die VADER Eer en Majesteit ontvang toe hierdie Stem uit die luisterryke Glansrykheid tot Hom gekom het: DIT IS MY GELIEFDE SEUN IN WIE EK ‘N WELBEHAE HET.	",
"	18 En hierdie Stem het ons uit die Hemele hoor kom toe ons saam met Hom op die berg van Apartheid was.	",
"	19 En ons het die profetiese Woord wat baie vas is, waarop julle tog moet ag gee soos op ’n lamp wat in ’n donker plek skyn, totdat die dag aanbreek en die Môrester opgaan in julle harte;	",
"	20 terwyl julle veral dit moet weet, dat geen profesie van die Skrif ’n saak van eie uitlegging is nie;	",
"	21 want geen profesie is ooit deur die wil van ’n adamiet voortgebring nie, maar, deur die Gees van die Apartheid gedrywe, het die Apartes van die Elohim gespreek.	",

]
},
{
book: 'Tweede_Brief_Van_Die_Apostel_Petrus',
chapter: '2',
content: [
		
"	1 MAAR daar was ook valse profete onder die volk, net soos daar onder julle valse leraars sal wees wat verderflike ketterye heimlik sal invoer, en ook teen die Meester wat hulle gekoop het, getuig en ’n vinnige verderf oor hulleself bring;	",
"	2 en baie sal hulle verderflikhede navolg, en om hulle ontwil sal die Weg van die Waarheid gelaster word;	",
"	3 en uit hebsug sal hulle met verdigte woorde voordeel uit julle trek. Oor hulle is die oordeel van lankal af nie werkeloos nie, en hulle verderf sluimer nie.	",
"	4 Want as Elohim die Boodskappers wat oortree het, nie gespaar het nie, maar hulle in die hel gewerp en aan kettings van Duisternis oorgegee het, om vir die oordeel in bewaring gehou te word; [Boekrol van Henog 19:2; 69:28]	",
"	5 en die ou wêreld nie gespaar het nie, maar Noag, die prediker van Geregtigheid, met sewe ander bewaar het toe Hy die vloed oor die wêreld van die verbasterdes gebring het;	",
"	6 en deur die stede van Sodom en Gomorra tot as te verbrand, hulle tot ondergang veroordeel het en as ’n voorbeeld gestel het vir die wat in die toekoms sou wou verbaster;	",
"	7 en die regverdige Lot gered het, wat hom baie gekwel het oor die ontugtige lewe van die besoedelde mense;	",
"	8 want deur wat hy gesien en gehoor het, het dié regverdige man, wat onder hulle gewoon het, dag vir dag sy regverdige siel gepynig oor hulle wettelose werke -	",
"	9 Die Hoogste El weet om die toegewydes uit versoeking te verlos en die wetsverbrekers te bewaar vir die dag van oordeel om gestraf te word;	",
"	10 en veral die wat die vlees in vuile begeerlikheid agternaloop en die koningskap verag. Vermetel en aanmatigend, skroom hulle nie om die koningskinders te belaster nie,	",
"	11 terwyl die Boodskappers, hoewel groter in sterkte en Krag, geen lasterlike oordeel teen hulle by JaHWeH voortbring nie.	",
"	12 Maar hulle, hierdie brute gediertes vanuit die natuur, gebore om gevang en vernietig te word, uiter besoedelde en lasterlike spraak teen dit wat hulle nie ken nie en sal totaal vernietig word in hul eie korrupsie.	",
"	13 en sal die loon van die Ongeregtigheid ontvang. Hulle ag dit weelderig om oordag oproer te maak; hulle is gebrekkig en walglik, swelgend in hul valsheid as hulle met julle saamsmul;	",
"	14 met oë vol verbastering, wat nie ophou om te oortree nie; hulle verlei onvaste siele, hulle het ’n hart geoefen in hebsug, hulle is kinders van die vervloeking.	",
"	15 Hulle het die regte pad verlaat en verdwaal, en die weg gevolg van Bíleam, die seun van Beor, wat die loon van Ongeregtigheid liefgehad het,	",
"	16 maar die bestraffing van sy eie oortreding ontvang het: die stom lasdier het met die stem van ’n adamiet gepraat en die waansinnigheid van die waarsêer verhinder.	",
"	17 Hulle is waterlose fonteine, miswolke voortgedrywe deur ’n stormwind, vir wie die donkerheid van die Duisternis vir ewig bewaar word.	",
"	18 Want deur trotse woorde vol onsin uit te spreek, verlok hulle deur begeerlikhede van die vlees en ontugtigheid, dié wat waarlik die mense ontvlug het wat in dwaling wandel.	",
"	19 Hulle belowe liberalisme aan hulle, terwyl hulle self slawe van korrupsie is; want waardeur ’n mens minderwaardig word, daarvan het hy ook ’n slaaf geword.	",
"	20 Want as hulle, nadat hulle deur die Kennis van die Meester en Verlosser, JaHWèshua die Gesalfde, die besmettinge van die wêreld ontvlug het, hulle tog weer deur hierdie dinge laat verstrik en oorwin word, dan het vir hulle die laaste erger geword as die eerste.	",
"	21 Want dit sou vir hulle beter gewees het, as hulle die Weg van Geregtigheid nie geken het nie, as dat hulle, nadat hulle Haar leer ken het, hulle hul gedistansieer het van die Gebod van Apartheid wat aan hulle oorgelewer is.	",
"	22 Maar oor hulle het gekom wat die ware spreekwoord sê: Die hond het omgedraai na sy eie uitbraaksel, en die gewaste sog om in die modder te rol. [Spreuke 26:11; JeshaJaH 28:8]	",

]
},
{
book: 'Tweede_Brief_Van_Die_Apostel_Petrus',
chapter: '3',
content: [
	
"	1 DIT is reeds die tweede brief, geliefdes, wat ek aan julle skrywe. In albei wil ek deur herinnering julle suiwere gesindheid opwek,	",
"	2 sodat julle die woorde kan onthou wat deur die Profete van Apartheid tevore gespreek is, en die gebod van ons, Apostels van die Meester en Verlosser.	",
"	3 Dit moet julle veral weet, dat daar aan die einde van die dae spotters sal kom wat volgens hulle eie begeerlikhede wandel	",
"	4 en sê: Waar is die belofte van Sy wederkoms? Want vandat die vaders ontslaap het, bly alles soos dit was van die begin van die skepping af. [Exodus 32:1]	",
"	5 Want moedswillig vergeet hulle dat daar van lankal af Hemele was en ’n Aarde wat uit water en deur water ontstaan het deur die Woord van Elohim,	",
"	6 waardeur die toenmalige wêreld met water oorstroom is en vergaan het.	",
"	7 Maar die teenswoordige Hemele en die Aarde is deur dieselfde Woord as ’n skat weggelê en word vir die vuur bewaar teen die dag van die oordeel en die verderf van die verbasterde adamiete.	",
"	8 Maar laat hierdie een ding julle nie ontgaan nie, geliefdes, dat een dag by JaHWeH soos duisend jaar is en duisend jaar soos een dag.	",
"	9 JaHWeH vertraag nie die belofte soos sommige dit vertraging ag nie, maar HY is lankmoedig oor ons en wil nie hê dat sommige moet vergaan nie, maar dat almal tot bekering moet kom.	",
"	10 Maar die Dag van JaHWeH sal kom soos ’n dief in die nag, waarin die Hemele met gedruis sal verbygaan en die elemente sal brand en vergaan, en die Aarde en die werke wat daarop is, sal verbrand. [Boekrol van Henog 91:16; Openbaring 21:1]	",
"	11 Terwyl al hierdie dinge dan vergaan, hoedanig moet julle nie wees deur in Apartheid en eerbaarheid te wandel nie? -	",
"	12 julle wat die koms van die Dag van JaHWeH verwag en verhaas, waardeur die Hemele deur vuur sal vergaan en die elemente sal brand en versmelt.	",
"	13 Maar ons verwag volgens Sy belofte nuwe Hemele en ’n nuwe Aarde waarin Geregtigheid woon. [Boekrol van Henog 91:16; Openbaring 21:1]	",
"	14 Daarom, geliefdes, terwyl julle hierdie dinge verwag, beywer julle dat julle rassuiwer en onberispelik voor Hom bevind mag word in Vrede.	",
"	15 EN ag die Lankmoedigheid van onse Meester as Verlossing, soos ons geliefde broeder Paulus ook met die wysheid wat aan hom gegee is, aan julle geskryf het, [Jakobus 3:13-18]	",
"	16 net soos in al die briewe. Hy spreek daarin oor hierdie dinge, waarvan sommige swaar is om te verstaan, wat die ongeleerde en onvaste mense verdraai, net soos die ander Skrifte, tot hul eie verderf.	",
"	17 Noudat julle dit dan vooruit weet, geliefdes, moet julle op jul hoede wees dat julle nie miskien meegesleep word deur die dwaling van besoedelde mense en wegval uit jul eie vastigheid nie.	",
"	18 Maar julle moet toeneem in die Barmhartigheid en Kennis van onse Meester en Verlosser, JaHWèshua die Gesalfde. Aan Hom kom die Majesteit toe, nou en in ewigheid. Amein.	",

]
}

];
