const openbaring_van_petrusChapters = [

{
book: 'Openbaring_Van_Petrus',
chapter: '1',
content: [

"	1 BAIE van hulle sal valse profete wees en sal allerlei verderflike weë en insettinge leer.	",
"	2 Hulle sal egter kinders van die verderf word.	",
"	3 En dan sal JaHWeH kom tot my getroues wat honger en dors en verdrukking ly en in hierdie lewe hul siele op die proef stel, en die kinders van Ongeregtigheid sal Hy oordeel.	",
"	4 En die Meester het voortgegaan en gesê: Kom, laat ons op die berg gaan bid.	",
"	5 En toe ons, die twaalf studente, met Hom gaan, vra ons Hom dat Hy ons een van ons regverdige broers moet toon wat uit hierdie wêreld heengegaan het, sodat ons kan sien hoe hulle in gedaante nou daar uitsien en moed kan skep en ook hulle wat na ons luister, kan bemoedig.	",
"	6 En terwyl ons dit vra, verskyn daar ineens twee manne wat voor die Meester staan en wat ons nie in staat was om aan te kyk nie.	",
"	7 Want van hul aangesig het daar ‘n straling soos van die son uitgegaan, en hul gewaad was skitterend, die gelyke waarvan ‘n adamitiese oog nog nooit aanskou het nie, want geen mond is in staat om te beskrywe en geen hart om te bedink die Glansrykheid waarmee hulle beklee was en die skoonheid van hul aangesig nie.	",
"	8 Toe ons hulle sien, het ons verbaas gestaan, want hul liggame was witter as enige sneeu en rooier as enige roos.	",
"	9 En die rooi by hulle was vermeng met die wit, ek kan eenvoudig nie hul skoonheid beskrywe nie.	",
"	10 Want hul hare was vol krulle en aanvallig en het sierlik om hul gesig en skouers gehang soos ‘n krans uit nardusbloeisels en allerlei blomme gevleg, of soos ‘n reënboog in die lug. Sodanig was hul lieflike voorkoms.	",
"	11 Toe ons so hul skoonheid aanskou, was ons met verbasing vervul, want hulle het plotseling verskyn.	",
"	12 En ek het my Meester genader en gesê: Wie is dit?	",
"	13 Hy antwoord my: Dit is julle regverdige broers, van wie julle begeer het om te aanskou hoe hulle daar uitsien.	",
"	14 Toe sê ek vir Hom: En waar bevind al die regverdiges hulle? En hoe lyk die wêreld waarin hulle leef wat so ‘n Glansrykheid besit?	",
"	15 En my Meester het my ‘n baie groot ruimte buitekant hierdie wêreld getoon, gebaai in skittering van lig, en die lug van haar deur sonnestrale verlig, en die grond self oortrek van onverwelklike blomme, vervul met geurige speserye en met lieflik bloeiende en onverganklike plante wat geurige vrugte dra.	",
"	16 En hulle het in so ‘n volle bloei gestaan dat die geure daarvan selfs daarvandaan tot by ons oorgedra is.	",
"	17 En die bewoners van daardie plek was met die gewaad van Boodskappers van die Lig beklee, en hul gewaad was net [so mooi] soos hul adamah [die Adamiet se Aarde].	",
"	18 En Boodskappers het daar tussen hulle beweeg.	",
"	19 En die Glansrykheid van hulle wat daar gewoon het, was by almal eenders, en op daardie plek het hulle met een stem JaHWeH hulle Elohey geloof en gejubel.	",
"	20 Toe sê JaHWeH vir my: Sy is die Plek van julle voorvaders, die regverdige adamiete.	",
"	21 Ek sien toe ook ‘n ander plek, reg teenoor die eerste, duister en vuil. Sy was die Plek van straf. En die wat daar gestraf is en die Boodskappers wat hulle gestraf het, het ‘n donker gewaad gedra, in ooreenstemming met die lug van die plek.	",
"	22 En daar was sommige wat aan hul tonge gehang het. Dit was hulle wat dieWeg van Geregtigheid bespot het. En onder hulle was vuur aangelê wat gebrand en hulle gepynig het.	",
"	23 En daar was ‘n groot meer, gevul met vlammende slyk. En in haar het sekere adamiete verkeer wat hul rug op die Geregtigheid gedraai het, en pynigende Boodskappers was oor hulle gestel.	",
"	24 En daar was ook ander, vroue, aan hul hare opgehang bo die opborrelende slyk. Dit was hulle wat hulself vir hoerery versier het. En die manne wat hulself met hulle verenig het in die besoedeling van vermenging, was aan hul voete opgehang met hul hoofde bedek in die slyk, en hulle het gesê: Ons het nie geglo dat ons na hierdie plek sou kom nie!	",
"	25 Ook die moordenaars en hul medepligtiges het ek gesien, gewerp in ‘n kloof vol giftige, kruipende dinge, en deur hierdie gediertes gekwel, het hulle hulle daar in pyn rondgewring. En hulle was oortrek van wurms, soos donker wolke. En die siele van die wat vermoor is, het daarby gestaan en die foltering van die moordenaars aanskou en gesê: O Elohim, regverdig is U oordeel!	",
"	26 Naby hierdie plek het ek ‘n ander nou kloof gesien waarin die ontlasting en die stink afval van die wat gestraf is, afgevloei en as ‘t ware ‘n meer gevorm het. En daar het vroue tot by hul nekke in die pappery gesit, en teenoor hulle het baie ontydig gebore kinders gesit en ween. En van hulle het vuurstrale uitgegaan wat die vroue in die oë getref het. Want dit was hulle wat verbaster het en vrugafdrywing gepleeg het. [Wysheid van Salomo 4:6]	",
"	27 En ander manne en vroue was tot aan die middel van hul liggaam aan die brand, en was op ‘n duistere plek neergewerp en deur geeste van besoedeling gegesel terwyl hulle aan hul ingewande deur nimmer rustende wurms gevreet is. Dit was hulle wat die regverdiges vervolg en verraai het. [Boekrol van Henog 22:12; Openbaring 6:9]	",
"	28 En naby hulle was daar weer vroue en manne wat hul lippe gebyt en in pyn verkeer het, en teen wie se oë gloeiend hete ysters gedruk is. Dit is hulle wat gelaster en kwaadgespreek het van die Weg van Geregtigheid.	",
"	29 En teenoor hulle was daar weer vroue en manne wat hul tonge gekou en vlammende vuur in hul mond gehad het. Dit was die valse getuies.	",
"	30 En op ‘n ander plek was gruisklippe, skerper as swaarde of enige rooiwarm braaispit, en manne en vroue in vuil vodde geklee, het in pyn daarop rondgerol. Dit was hulle wat ryk was en op hul rykdomme vertrou het en hulle nie oor wese en weduwees ontferm het nie, maar die Gebooie van Elohim verontagsaam het.	",
"	31 En in ‘n ander groot meer, met etter en bloed en opkokende slyk gevul, het manne en vroue kniediep gestaan. Dit was hulle wat geld uitgeleen en woekerrente op rente gevorder het.	",
"	32 Ander manne en vroue is van ‘n hoë krans afgegooi en as hulle onder kom, is hulle weer deur die pynigers wat oor hulle gestel was, aangedryf om die rots na bo uit te klim en dan weer na onder afgegooi, en so het hulle geen rus gehad van hierdie strafpyniging nie. Dit was hulle wat hul liggame besoedel het deur hulle as vroue aan mekaar oor te gee, en die vroue wat met hulle was, dit was hulle wat met mekaar saam gelê het soos man en vrou.	",
"	33 En naas daardie krans was daar ‘n plek vol van ‘n groot vuur, en daar het manne gestaan wat met hul eie hande vir hulle idoolafbeeldings gemaak het in plaas van om Elohim te vereer, en naas hulle ander manne en vroue wat stawe van vuur gehad en mekaar daarmee geslaan het en nooit opgehou het met hierdie manier van pyniging nie...	",
"	34 En daar was nog ander naby hulle, manne en vroue, wat gebrand en rondgerol het en soos op ‘n pan gerooster is. Dit was hulle wat die Weg van Elohim verlaat het. Dit is hulle wat die Gebooie van Elohim verlaat het en leringe van duiwels nagevolg het.	",

]
}

];
