const obadjaChapters = [

{
book: 'Obadja',
chapter: '1',
content: [

"	1 DIE gesig van ObadJaH. So sê my Meester JaHWeH aangaande Edom: Ons het ’n tyding van JaHWeH gehoor, en ’n boodskapper is uitgestuur onder die nasies [om te sê]: Staan op, en laat ons klaarmaak om teen haar te veg!	",
"	2 Kyk, Ek het jou klein gemaak onder die nasies, jy is baie verag.	",
"	3 Die hoogmoedigheid van jou hart het jou bedrieg, o jy wat woon in die rotsklowe, op hoë plekke bly, [en] in jou hart sê: Wie sal my op die Aarde neerwerp?	",
"	4 Al woon jy so hoog soos die arend en al was jou nes tussen die Sterre/Prinse gestel - daarvandaan sal Ek jou neerwerp, spreek JaHWeH.	",
"	5 As daar diewe, as daar nagrowers na jou gekom het - hoe is jy vernietig! - sou hulle nie net soveel gesteel het as wat vir hulle genoeg was nie? As daar druiwesnyers na jou gekom het, sou hulle nie die na-oes laat oorbly het nie?	",
"	6 Hoe is Esau se verborgenhede bevraagteken (deursoek)!	",
"	7 Al jou bondgenote het jou tot by die grens gestuur; die manne met wie jy vriendskap gehou het, het jou bedrieg, jou oorweldig; hulle lê ’n strik onder jou as jou brood. Daar is geen verstand in hom nie!	",
"	8 Sal Ek nie in dié dag, spreek JaHWeH, die wyse manne uit Edom verdelg nie en die verkreë wysheid uit die gebergte van Esau?	",
"	9 En jou dapperes sal verskrik wees, o Teman, sodat elkeen deur moord uit die gebergte van Esau uitgeroei sal word.	",
"	10 Weens die geweld teen jou broer Jakob gepleeg, sal skande jou bedek, en jy sal uitgeroei word vir ewig.	",
"	11 Die dag toe jy daarby gestaan het, die dag toe verbasterdes sy rykdom weggevoer en uitlanders deur sy Poorte gedring en die lot oor Jerusalem gewerp het - toe was jy ook soos een van hulle!	",
"	12 En tog moes jy nie met genot die dag van jou broer aanskou het nie, die dag van sy teëspoed, en jou nie verheug het oor die kinders van JeHûWdah op die dag van hulle ondergang nie en nie gespog het op die dag van benoudheid nie!	",
"	13 Tog moes jy nie die Poort van My volk binnegegaan het in die tyd van hulle verdrukking nie, in die tyd van sy verdrukking moes jy nie sy besoedeling aanskou het nie, in die tyd van sy verdrukking nie [die hand] uitgesteek het na sy rykdom nie!	",
"	14 En jy moes nie gestaan het op die kruispad om sy vlugtelinge uit te roei nie en nie sy oorblyfsel uitgelewer het op die dag van benoudheid nie.	",
"	15 Want die Dag van JaHWeH is naby oor al die nasies; soos jy gedoen het, sal aan jou gedoen word, jou daad sal op jou hoof neerkom.	",
"	16 Want net soos julle gedrink het op [die] Berg van My Apartheid, sal al die nasies voortdurend drink, ja, hulle sal drink en swelg en word asof hulle nooit bestaan het nie.	",
"	17 Maar op die Berg van Sion sal die oorblyfsel vrykom, en daar sal Apartheid wees; en die huis van Jakob sal sy besittings in besit neem.	",
"	18 Dan sal die huis van Jakob ’n vuur wees en die huis van JôWsef ’n vlam, maar die huis van Esau ’n stoppel; en dié sal hulle aan die brand steek en hulle verteer, sodat daar geen oorblyfsel vir die huis van Esau sal wees nie, want JaHWeH het dit gespreek.	",
"	19 En die Suidland sal die gebergte van Esau in besit neem, en die van die laeland: die Filistyne, en hulle sal die veld van Efraim in besit neem en die veld van Samaría, Benjamin en Gílead.	",
"	20 Die ballinge van hierdie leërmag van die kinders van JisraEl sal die wat Kanaäniete is, tot by Sarfat [verower]; en die ballinge van Jerusalem, wat in Sefárad is, sal die stede van die Suidland in besit neem.	",
"	21 Dan sal daar verlossers die Berg van Sion opgaan om die gebergte van Esau te oordeel, en die Koninkryk sal aan JaHWeH toebehoort.	",

]
}
];
