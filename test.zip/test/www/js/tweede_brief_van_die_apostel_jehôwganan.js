const tweede_brief_van_die_apostel_jehôwgananChapters = [

{
book: 'Tweede_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '1',
content: [

"	1 DIE oudste aan die Uitverkore Vrou en aan Haar kinders - wat ek in Waarheid liefhet, en nie ek alleen nie, maar ook almal wat die Waarheid leer ken het;	",
"	2 ter wille van die Waarheid wat in ons bly en by ons vir ewig sal wees -	",
"	3 Guns, Barmhartigheid, Vrede sal met julle wees van die Elohim; die VADER en van onse Meester JaHWèshua die Gesalfde, die Seun van die VADER, in Waarheid en Liefde.	",
"	4 EK was baie bly dat ek van U kinders gevind het wat in die Waarheid wandel, soos ons ’n Gebod van die VADER ontvang het.	",
"	5 En nou bid ek U, Uitverkore Vrou, nie asof ek U ’n nuwe Gebod skryf nie, maar een wat ons van die begin af gehad het: dat ons mekaar moet liefhê.	",
"	6 En Sy is die Liefde, as ons wandel volgens Haar Gebooie. Sy is die Gebod soos julle van die begin af gehoor het dat julle in Haar moet wandel. [Sirah 24:18-20]	",
"	7 Want baie verleiers het in die wêreld ingekom: die wat getuig dat JaHWèshua die Gesalfde nie in die vlees gekom het nie. Hy is ’n verleier en ‘n vals gesalfde.	",
"	8 Wees op julle hoede, dat ons nie verloor wat ons deur arbeid verkry het nie, maar ’n volle loon ontvang.	",
"	9 Elkeen wat ’n oortreder is en nie bly in die Leer van die Gesalfde nie, hy het Elohim nie. Wie in die Leer van die Gesalfde bly, hy het die VADER sowel as die Seun.	",
"	10 As iemand na julle kom en hierdie Leer nie bring nie, ontvang hom nie in die huis nie en groet hom nie.	",
"	11 Want die een wat hom groet, raak ’n deelgenoot van sy besoedelde dade.	",
"	12 Alhoewel ek baie het om aan julle te skrywe, wou ek dit nie met papier en ink doen nie, maar ek hoop om na julle te kom en van mond tot mond te spreek, sodat ons blydskap volkome kan wees.	",
"	13 Die kinders van U Uitverkore Suster groet u. Amein.	",

]
}

];
