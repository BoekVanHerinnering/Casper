const hoséaChapters = [

{
book: 'Hoséa',
chapter: '1',
content: [

"	1 DIE Woord van JaHWeH wat gekom het tot Hoséa, die seun van Beëri, in die dae van UzziJaH, JôWtham, Agas, JegizkiJaH, konings van JeHûWdah, en in die dae van Jeróbeam, die seun van JôWash, koning van JisraEl.	",
"	2 Die begin van die Woord van JaHWeH aan Hoséa; JaHWeH het aan Hoséa gesê: Gaan heen, neem vir jou ’n hoervrou en hoerkinders; want die Aarde het grootliks vermeng deur van JaHWeH afvallig te word.	",
"	3 Toe het hy gegaan en Gomer, die dogter van Diblaim, geneem; en sy het swanger geword en vir hom ’n seun gebaar.	",
"	4 En JaHWeH het vir hom gesê: Noem hom JizreEl, want nog ’n klein tydjie, dan sal Ek die bloedskuld van JizreEl aan die huis van JyHûW besoek en ’n einde maak aan die koninkryk van die huis van JisraEl.	",
"	5 Ja, in dié dag sal Ek die boog van JisraEl verbreek in die vallei van JizreEl.	",
"	6 Toe het sy weer swanger geword en ’n dogter gebaar; en Hy het vir hom gesê: Noem haar Lo-Rugáma/Geen Medelye, want Ek sal My verder nie meer oor die huis van JisraEl ontferm deur hulle vergifnis te skenk nie.	",
"	7 Maar oor die huis van JeHûWdah sal Ek My ontferm en hulle verlos deur JaHWeH hulle Elohey, en Ek sal hulle nie deur boog of swaard of oorlog, deur perde of ruiters verlos nie.	",
"	8 Nadat sy Lo-Rugáma gespeen het, het sy [weer] swanger geword en ’n seun gebaar.	",
"	9 En Hy het gesê: Noem hom Lo-Ammi/Nie My volk, want julle is nie My volk nie, en Ek sal nie julle s’n wees nie.	",
"	10 Nogtans sal die getal van die kinders van JisraEl wees soos die sand van die see, wat nie gemeet en nie getel kan word nie; en in die plek waar dit aan hulle gesê word: ”Nie My volk nie', daar sal aan hulle gesê word: 'julle is die volk van die lewende El'.	",
"	11 Dan sal die kinders van JeHûWdah en die kinders van JisraEl almal saam vergader en vir hulle een hoof aanstel en uit die Aarde optrek; want groot is die dag van JizreEl!	",

]
},
{
book: 'Hoséa',
chapter: '2',
content: [
		
"	1 SÊ aan julle broers: Ammi, en aan julle susters: Rugáma.	",
"	2 Beywer jul met julle moeder, beywer julle; want sy is nie My vrou nie, en Ek is nie haar man nie, en laat sy haar hoerery van haar aangesig verwyder en haar vermenging van haar borste af weg. [Spreuke 9:13; Hooglied 7:3; 7:8; Boekrol van Henog 42:3]	",
"	3 Anders sal Ek haar naak uittrek en haar neersit soos op die dag van haar geboorte en haar maak soos ’n wildernis, ja, haar stel soos ’n dor Aarde en haar van dors laat sterwe.	",
"	4 En Ek sal My oor haar kinders nie ontferm nie, want hulle is kinders uit hoerery gebore.	",
"	5 Want hulle moeder het vermeng, sy wat met hulle swanger was, het skandelike dinge gedoen; want sy het gesê: Ek wil my minnaars agternaloop wat my brood en my water, my wol en my vlas, my olie en my drank gee.	",
"	6 Daarom, kyk, Ek sal jou weg met dorings omhein en om haar ’n muur bou, sodat sy haar paaie nie sal vind nie.	",
"	7 En sy sal haar minnaars agternaloop, maar hulle nie inhaal nie; en sy sal hulle soek, maar nie vind nie. Dan sal sy sê: Ek wil heengaan en terugkeer na my vorige man, want toe het ek dit beter gehad as nou.	",
"	8 Ja, sy het nie erken dat Ek aan haar die koring en die vars wyn en die olie gegee het nie, ook silwer vir haar vermenigvuldig het en goud, wat hulle vir die Here (Baäl) gebruik het.	",
"	9 Daarom sal Ek My koring terugneem in die oestyd en My vars wyn op die bepaalde tyd, en wegneem My wol en My vlas wat dien om haar geslagsdele te bedek.	",
"	10 Ek sal dan nou haar skaamte ontbloot voor die oë van haar minnaars, en niemand sal haar uit My hand red nie.	",
"	11 En Ek maak ’n einde aan al haar vreugde, haar feeste, haar vernuwings en haar sabbatte, ja, aan al haar feestye.	",
"	12 En Ek sal haar Wingerdstok en haar Vyeboom verwoes waarvan sy gesê het: Hierdie dinge is my hoereloon wat my minnaars my gegee het; en Ek sal haar tot ’n bos maak, en die wilde wesens van die veld sal dit verslind.	",
"	13 So besoek Ek dan teen haar die dae van die Baäls toe sy vir hulle reukwerk berei het en haar met haar neusring en haar halssierade versier en haar minnaars agternageloop het; maar My het sy vergeet, spreek JaHWeH.	",
"	14 Daarom, kyk, Ek sal haar lok en haar in die wildernis lei en na haar hart spreek.	",
"	15 Dan sal Ek haar daarvandaan haar Wingerde gee en die dal Agor tot ’n deur van hoop, en daar sal sy antwoord gee soos in die dae van haar jeug en soos die dag toe sy uit die Aarde van Egipte opgetrek het.	",
"	16 En in dié dag, spreek JaHWeH, sal jy [My] noem: My Man; en jy sal My nie meer noem: My Baäl[My Here] nie.	",
"	17 Dan verwyder Ek die name van die Baäls uit haar mond, sodat hulle by hul naam nie meer genoem sal word nie.	",
"	18 Verder sluit Ek in dié dag vir hulle ’n Verbond met die wilde diere van die veld en met die voëls van die Hemele en die kruipende diere van die Adamah[adamiet se Aarde]; ja, boog en swaard en oorlog sal Ek verbreek uit die Aarde, en Ek sal hulle neerlê in veiligheid. [Openbaring 6:1-4]	",
"	19 En Ek sal My met jou verloof tot in ewigheid en My met jou verloof in Geregtigheid en in Reg en in Medelye en in Guns.	",
"	20 En Ek sal My met jou verloof in Getrouheid; dan sal jy JaHWeH ken.	",
"	21 En in dié dag sal Ek antwoord, spreek JaHWeH, Ek sal die Hemele antwoord en hulle sal die Aarde antwoord,	",
"	22 en die Aarde sal die koring antwoord en die vars wyn en die olie, en hulle sal JizreEl antwoord.	",
"	23 En Ek sal haar vir My saai in die Aarde en My oor Lo-Rugáma ontferm, en aan Lo-Ammi sê: Jy is My volk; en hulle sal sê: My Elohey!	",

]
},
{
book: 'Hoséa',
chapter: '3',
content: [
		
"	1 EN JaHWeH het vir my gesê: Gaan nog ’n keer, bemin ’n vrou wat bemin word deur [haar] vriend, maar wat vermenging pleeg, net soos JaHWeH die kinders van JisraEl liefhet, terwyl hulle hul tot die gode van andere wend en versot is op rosynekoeke met wyn.	",
"	2 Toe het ek haar vir my gekoop vir vyftien [sikkels] silwer en anderhalf homer gars.	",
"	3 En ek het aan haar gesê: Jy sal ’n lang tyd moet stilsit vir my, nie vermeng nie en aan geen man behoort nie; en so ook ek teenoor jou.	",
"	4 Want die kinders van JisraEl sal ’n lang tyd bly sit sonder koning en sonder vors en sonder slagdier en sonder kliptorings en sonder skouerkleed en huisidole.	",
"	5 Daarna sal die kinders van JisraEl hulle bekeer en JaHWeH hulle Elohey soek en Dawid hulle koning, en met siddering aankom na JaHWeH en na Sy Suiwerheid in die laaste van die dae.	",

]
},
{
book: 'Hoséa',
chapter: '4',
content: [
		
"	1 LUISTER na die Woord van JaHWeH o kinders van JisraEl! Want JaHWeH het ’n regsaak met die inwoners van die Aarde, omdat daar geen Waarheid en geen Medelye en geen Kennis van Elohim in die Aarde is nie.	",
"	2 Hulle sweer en lieg en moor en steel en vermeng; hulle breek uit, sodat bloed aan bloed raak.	",
"	3 Daarom treur die Aarde, en alles wat in haar woon, kwyn weg: die wilde diere van die veld en die voëls van die Hemele, ja, ook die visse van die see kom om.	",
"	4 Laat net niemand [met ons] twis of [ons] berispe nie! Nogtans is jou volk soos die wat met die priester twis!	",
"	5 Daarom sal jy struikel bedags, en ook die profeet saam met jou struikel in die nag, en Ek sal jou moeder te gronde laat gaan.	",
"	6 My volk gaan te gronde weens gebrek aan Kennis; omdat jy die Kennis verwerp het, sal Ek jou verwerp, sodat jy vir My die priesteramp nie sal bedien nie; omdat jy die Wet van jou Elohey vergeet het, sal Ek ook jou kinders vergeet.	",
"	7 Hoe meer hulle vermenigvuldig het, des te meer het hulle teen My oortree. Ek sal hulle glansrykheid in skande verander.	",
"	8 Hulle verslind die oortreding van My volk, en hulle rig die skandelikheid van hulle siel op.	",
"	9 Daarom sal dit met die priester gaan soos met die volk - Ek sal by hom besoeking doen oor sy weë en hom vergeld na sy dade.	",
"	10 Dan sal hulle eet, maar nie versadig word nie; hulle sal vermeng, maar nie uitbreek in menigte nie; want hulle het nagelaat om JaHWeH te vereer.	",
"	11 Hoerery en wyn en vars wyn neem die hart weg.	",
"	12 My volk raadpleeg sy hout, en sy staf moet hom die inligting gee; want ’n gees van hoerery het [hulle] verlei, en deur hulle hoerery het hulle van hulle Elohey afvallig geword.	",
"	13 Hulle slag op die bergtoppe en laat rook opgaan op die heuwels, onder die eike en populiere en terpentynbome, omdat haar skaduwee goed is. Daarom pleeg julle dogters hoerery, en julle skoondogters vermeng.	",
"	14 Ek sal oor julle dogters geen besoeking doen omdat hulle hoereer nie, en ook nie oor julle bruide omdat hulle vermenging bedryf nie; want hulle deel hulself met die hoer en slag saam met die tempelhoere. So kom dan die volk wat geen Verstand het nie, tot ’n val.	",
"	15 As jy hoereer, o JisraEl, laat JeHûWdah hom tog nie skuldig maak nie! Kom dan nie na Gilgal nie, en gaan nie op na Bet-Awen nie, en sweer nie: So waar as JaHWeH leef!	",
"	16 Want JisraEl is wederstrewig soos ’n wederstrewige koei; nou sal JaHWeH hulle laat wei soos ’n lam in die oop veld.	",
"	17 Efraim is gekoppel aan sy gode: laat hom staan!	",
"	18 As hulle drinkery verby is, dan hoereer hulle te meer. Hulle vorste is versot op skande.	",
"	19 Die [besoedelde] gees bind hulle in sy vleuels, sodat hulle oor hulle altare beskaamd sal staan.	",

]
},
{
book: 'Hoséa',
chapter: '5',
content: [
		
"	1 HOOR dit, o priesters, en let op, o huis van JisraEl, en gee gehoor, o huis van die koning! Want die Regspraak raak julle, omdat julle vir Mispa ’n vangnet geword het en ’n -uitgespreide net op Tabor.	",
"	2 Ja, in doodbloei verdiep die opstandiges hulle, maar Ek sal hulle almal tot Tugtiging wees.	",
"	3 Ek ken Efraim, en JisraEl is vir My nie verborge nie; want nou het jy hoerery gepleeg, o Efraim! JisraEl is besoedel.	",
"	4 Hulle dade gedoog geen terugkeer tot hulle Elohey nie, want daar is ’n gees van hoerery in hulle binneste, en hulle ken JaHWeH nie.	",
"	5 En die trotsheid van JisraEl getuig openlik teen hom; en JisraEl en Efraim sal struikel deur hulle ongeregtigheid, ook JeHûWdah sal saam met hulle struikel.	",
"	6 Met hulle kleinvee en hulle beeste sal hulle heengaan om JaHWeH te soek, maar [Hom] nie vind nie. Hy het Hom aan hulle onttrek.	",
"	7 Hulle het verraad gepleeg teen JaHWeH, want hulle het verbasterde kinders verwek; nou sal die maand hulle met hul velde verteer.	",
"	8 Blaas die ramshoring in Gíbea, die trompet in Rama! Hef aan die krygsgeskreeu in Bet-Awen1. Agter jou kom dit, Benjamin!	",
"	9 Efraim sal verslaan word op die dag van straf; onder die stamme van JisraEl maak Ek bekend wat seker is.	",
"	10 Die vorste van JeHûWdah is soos hulle wat die grenslyne verlê. Ek sal My Grimmigheid oor hulle uitgiet soos water.	",
"	11 Efraim is verdruk, verbreek deur die oordeel; want dit het hom behaag om na die regspraak [van mense] te wandel.	",
"	12 Daarom is Ek vir Efraim soos ’n mot en vir die huis van JeHûWdah soos ’n verrotting in die gebeente.	",
"	13 Toe Efraim sy krankheid sien en JeHûWdah sy sweer, het Efraim na Assur gegaan en na koning Jareb gestuur; maar hý kan julle nie genees en julle van die sweer nie gesond maak nie.	",
"	14 Want Ek is soos ’n leeu vir Efraim, en soos ’n jong leeu vir die huis van JeHûWdah; Ek, Ek verskeur en gaan heen, Ek dra weg sonder dat iemand red.	",
"	15 Dan gaan Ek heen, Ek keer na My woonplek terug, totdat hulle skuld beken en My Aangesig soek. In hulle nood sal hulle My soek.	",

]
},
{
book: 'Hoséa',
chapter: '6',
content: [
		
"	1 KOM en laat Ons terugkeer tot JaHWeH; want Hy het verskeur en sal Ons genees, Hy het geslaan en sal Ons verbind.	",
"	2 Hy sal Ons ná twee dae lewend maak, op die derde dag Ons laat opstaan, sodat Ons voor Sy Aangesig kan lewe.	",
"	3 En laat Ons ken - laat Ons dit najaag om JaHWeH te ken; Sy opgang is so seker soos die dagbreek, en Hy sal tot Ons kom soos die reën, soos die laat reëns wat die Aarde besproei.	",
"	4 Wat sal Ek met jou doen, o Efraim; wat sal Ek met jou doen, o JeHûWdah? aangesien julle suiwerheid is soos die Wolkkolom en soos ’n dou wat vroeg weer verdwyn.	",
"	5 Daarom het Ek [hulle] neergekap deur die profete, hulle gedood deur die woorde van My Mond, en die Regsprake oor jou kom te voorskyn soos ’n Ligstraal.	",
"	6 Want Ek het ’n behae in Medelye en nie in n slagdier nie, en in Kennis van Elohim meer as in brandoffers.	",
"	7 Maar hulle het soos Adam die Verbond oortree, daar het hulle verraad gepleeg teen My.	",
"	8 Gílead is ’n stad van verderflikheid, vol besoedelde bloed.	",
"	9 En soos ’n bende rowers lê en wag op ‘n man, so vermoor die priesterbendes, hulle sweer saam om te vermoor deur bloedvermenging.	",
"	10 In die huis van JisraEl het Ek ’n afskuwelike ding gesien: Efraim het daar tot hoerery verval, JisraEl is besoedel.	",
"	11 Ook vir jou, o JeHûWdah, is daar ’n oes beskik as Ek die lot van My volk verander.	",
		

]
},
{
book: 'Hoséa',
chapter: '7',
content: [
		
"	1 TERWYL Ek JisraEl genees, word die ongeregtigheid van Efraim openbaar en die besoedeling van Samaría; want hulle pleeg bedrog en die dief breek in en ’n rowerbende plunder op die straat.	",
"	2 En hulle sê nie in hulle hart dat Ek aan al hulle besoedeling dink nie; nou omsingel hulle dade hulle, dit lê oop voor My Aangesig.	",
"	3 Met hulle besoedeling verbly hulle die koning en met hulle leuens die vorste.	",
"	4 Hulle almal pleeg vermenging; hulle is soos ’n oond wat bly brand, ook al het die bakker opgehou met stook, vandat die deeg geknie word totdat dit deursuur is.	",
"	5 Op die dag van Ons Koning is die vorste siek van verhitting deur wyn; Hy steek Sy Hand uit na die spotters.	",
"	6 Ja, hulle het hul hart gemaak soos ’n oond in hul arglistigheid; die ganse nag deur slaap hulle bakker, in die môre vroeg brand dit soos ’n vuurvlam.	",
"	7 Hulle almal gloei soos ’n oond en verteer hul regeerders, al hulle konings val; daar is niemand onder hulle wat My aanroep nie.	",
"	8 Efraim - hy verbaster hom met die volke; Efraim is ’n roosterkoek wat nie omgekeer is nie.	",
"	9 Verbasterdes verteer sy krag, en hy bemerk dit nie; ja grysheid is op hom versprei, nog weet hy dit nie.	",
"	10 Ja, die trotsheid van JisraEl getuig openlik teen hom; en tog bekeer hulle hul nie tot JaHWeH hulle Elohey nie, en ondanks dit alles soek hulle Hom nie.	",
"	11 So het Efraim dan geword soos ’n onnosele duif sonder Verstand; hulle roep na Egipte, hulle gaan na Assur.	",
"	12 Wanneer hulle gaan, sal Ek My net oor hulle uitsprei; soos die voëls van die Hemele trek Ek hulle neer; Ek tugtig hulle soos in hulle samekoms aangekondig is.	",
"	13 Wee hulle, omdat hulle van My weggevlieg het! Verwoesting oor hulle, omdat hulle teen My oortree het! Ék tog wou hulle verlos, maar hulle het leuens teen My gespreek.	",
"	14 Ook roep hulle nie van harte na My nie, maar jammer op hulle bedde; ter wille van koring en wyn kerwe hulle hulself stukkend; hulle is opstandig teen My.	",
"	15 Alhoewel Ek hulle arms geoefen, versterk het, het hulle besoedeling teen My beraam.	",
"	16 Hulle keer terug, [maar] nie na Bo nie; hulle is soos ’n bedrieglike boog; hulle vorste sal val deur die swaard weens die skeldwoorde van hulle tong. Dit is hulle bespotting in die Aarde van Egipte. [JirmeJaH 9:3]	",

]
},
{
book: 'Hoséa',
chapter: '8',
content: [
		
"	1 DIE ramshoring teen jou mond is soos ’n arend teen die Huis van JaHWeH! Omdat hulle My Verbond nie onderhou het nie, en teen My Wet oortree het.	",
"	2 JisraEl sal tot My roep: Ons ken U, ons Elohey,	",
"	3 maar JisraEl het die suiwerheid verwerp - die vyand sal hom agtervolg!	",
"	4 Húlle het konings aangestel, maar nie uit My nie; hulle het vorste gekies, maar sonder My wete; van hul silwer en goud het hulle vir hul idole gemaak tot hulle verderf.	",
"	5 Jou kalf, o Samaría, is afskuwelik; My Toorn is teen hulle ontvlam. Hoe lank sal hulle onbekwaam bly ten opsigte van hul suiwerheid?	",
"	6 Want hy is ook uit JisraEl: ’n smid het hom gemaak, en hy is geen El nie; maar tot splinters sal hy word - die kalf van Samaría.	",
"	7 Want hulle saai wind, maar hulle sal storm maai; hy het geen halm nie; wat uitspruit, lewer geen meel op nie; selfs as hy iets oplewer, sou verbasterdes hy verslind.	",
"	8 JisraEl is verslind; alreeds is hulle onder die volke soos iets wat waardeloos is.	",
"	9 Want húlle het opgetrek na Assur - ’n wilde-esel wat eiesinnig rondloop, is Efraim! - hulle het onwettige bondgenootskappe gewerf.	",
"	10 Ook al werf hulle onder die nasies, Ek sal hulle nou saamraap, en hulle sal begin minder word weens die laste deur die koning van die vorste opgelê.	",
"	11 Want Efraim het die altare vermenigvuldig om te oortree - die altare het vir hom ’n oortreding geword.	",
"	12 Ek het hom ‘n menigte groot dinge van My Wet voorgeskrywe, [maar] sy is versin en verbaster.	",
"	13 My slagdiere, My aanbiedings, slag hulle - vleis is dit, en hulle eet; JaHWeH het geen behae daarin nie. Nou sal HY aan hulle ongeregtigheid dink en oor hulle oortredinge besoeking doen; hulle sal teruggaan na Egipte.	",
"	14 Omdat JisraEl sy MAKER vergeet en paleise gebou het, en JeHûWda ‘n menigte versterkte stede geword het, daarom sal Ek ’n Vuur in sy stede slinger wat haar paleise sal verteer.	",

]
},
{
book: 'Hoséa',
chapter: '9',
content: [
		
"	1 WEES nie bly met gejuig, o JisraEl, soos die volke nie, want jy het gehoereer van jou Elohey af weg; jy het hoereloon liefgehad op al die koring -dorsvloere.	",
"	2 Dorsvloer en parskuip sal hulle nie voed nie, en die wyn in haar sal hulle in die steek laat.	",
"	3 Hulle sal in die Aarde van JaHWeH nie bly nie; maar Efraim sal na Egipte teruggaan, en in Assur sal hulle eet wat besoedel is.	",
"	4 Hulle sal vir JaHWeH geen wyn uitgiet nie, en hulle slagdiere sal vir Hom nie welgevallig wees nie; soos tranebrood sal [hulle spys] vir hulle wees. Almal wat van hom eet, word besoedel; want hulle brood is vir hulle siel: hy sal nie in die Huis van JaHWeH kom nie.	",
"	5 Wat sal julle dan doen op die Feestyd en op die Feesdag van JaHWeH?	",
"	6 Want kyk, hulle gaan heen weens die verwoesting: Egipte sal hulle versamel, Memfis hulle begrawe; onkruid sal hulle skat van silwergoed in besit neem, dorings sal in hulle tente wees. [Psalm 12:6]	",
"	7 Die dae van straf het gekom, die dae van vergelding het gekom; JisraEl sal dit ervaar! Die profeet word ’n dwaas, die man van die gees ’n waansinnige, weens die grootheid van jou ongeregtigheid, en omdat die vyandskap groot is.	",
"	8 Efraim is ’n spioen teenoor My Elohey; wat die profeet aangaan, die net van ’n voëlvanger is op al sy weë [gesprei], vyandskap in die Huis van sy Elohey.	",
"	9 Hulle het baie, baie verkeerd gehandel soos in die dae van Gíbea. Hy sal dink aan hulle ongeregtigheid, besoeking doen oor hulle oortredinge.	",
"	10 Ek het JisraEl gevind soos druiwe in die wildernis; Ek het julle vaders gesien soos voorvye aan die Vyeboom in Haar eerste groei; maar húlle het na Baäl-Peor gekom en hulle aan daardie skand-idool afgesonder en ’n verfoeisel geword net soos die voorwerp van hulle liefde.	",
"	11 Efraim - Sy Glansrykheid sal wegvlieg soos ’n voël. Geen geboorte, geen moederskap, geen ontvangenis meer nie!	",
"	12 Ja, al sou hulle hul kinders grootmaak, Ek maak julle kinderloos, sonder adamiet; ja, wee hulleself ook as Ek van hulle wyk.	",
"	13 Efraim, soos Ek dit sien na Tirus heen, is geplant in ’n mooi omgewing, maar Efraim sal sy seuns na die moordenaar moet uitbring.	",
"	14 Gee hulle, o JaHWeH - wat sal U gee? - gee hulle ’n kinderlose moederskoot en uitgedroogde borste.	",
"	15 Al hulle besoedeldes is [byeen] in Gilgal, want daar het Ek hulle begin haat weens die besoedeling van hulle handelinge; Ek sal hulle uit My Huis uitdrywe, hulle nie meer liefhê nie. Al hulle vorste is opstandig.	",
"	16 Efraim is getref, hulle wortel het verdor, hulle dra geen vrug [meer] nie; ook wanneer hulle kinders baar, sal Ek nogtans die lieflinge van hulle skoot ombring.	",
"	17 My Elohey sal hulle verwerp, omdat hulle na HOM nie geluister het nie, en hulle sal rondswerwe onder die nasies.	",

]
},
{
book: 'Hoséa',
chapter: '10',
content: [
		
"	1 JISRAEL was ’n weelderig uitbottende wynstok wat sy vrug voortgebring het; hoe meer vrug hy gedra het, des te meer altare het hy gebou; hoe beter dit met sy deel van die Aarde gesteld was, des te beter het hy die kliptorings gemaak.	",
"	2 Vals is hulle hart, nou sal hulle daarvoor boet; Hy sal hulle altare stukkend breek, hulle kliptorings verwoes.	",
"	3 Ja, nou sal hulle sê: Ons het geen koning nie, want ons het JaHWeH nie gevrees nie; en die Koning - wat sou Hy vir ons kan doen?	",
"	4 Hulle het [groot] woorde gespreek, vals gesweer, verbonde gesluit - en soos ’n gifplant spruit die regspraak uit in die vore van die landerye.	",
"	5 Oor die kalf van Bet-Awen sal die inwoners van Samaría besorg wees; want sy volk sal oor hom treur en sy idolepriesters oor hom sidder, oor sy Glansrykheid, omdat hy van hom weggevoer is.	",
"	6 Hy sal ook self na Assur weggevoer word as ’n geskenk aan koning Jareb; skaamte sal Efraim aangryp, en JisraEl sal beskaamd staan oor sy eie raadsbesluit.	",
"	7 Samaría word vernietig, haar koning is soos ’n spaander op die water.	",
"	8 En die Hoogtes van Awen, JisraEl se oortreding, word verdelg, dorings en distels sal opskiet op hulle altare; en hulle sal tot die berge sê: Bedek ons! en tot die heuwels: Val op ons!	",
"	9 Sedert die dae van Gíbea het jy oortree, o JisraEl! Daar staan hulle - moet die stryd teen die kwaaddoeners hulle nie oorval in Gíbea nie?	",
"	10 Dit is My begeerte om hulle te tugtig, en volke sal teen hulle versamel word as hulle gebind word aan hulle twee se ongeregtigheid.	",
"	11 Maar Efraim is ’n geleerde jong koei wat gewillig dors; nogtans sal Ek self oor haar mooi nek gaan: Ek sal Efraim laat trek; JeHûWdah sal die ploeg trek, Jakob sal die eg sleep.	",
"	12 Saai vir julle volgens die eis van Geregtigheid, maai in ooreenstemming met die Medelye; braak vir julle ’n braakland, want dit is tyd om JaHWeH te soek, totdat Hy kom en Geregtigheid oor julle laat reën.	",
"	13 Julle het besoedeling ingeploeë, julle het ongeregtigheid gemaai, die vrug van leuens geëet, omdat jy op jou weg vertrou het, op die menigte van jou dapperes.	",
"	14 Daarom sal daar oorlogsrumoer onder jou volke ontstaan en al jou vestings verwoes word net soos Salman Bet-Arbel verwoes het in die dag van oorlog: moeders is met kinders en al verpletter.	",
"	15 Net so sal BetEl aan julle doen in [die] aangesig van besoedeling, julle besoedeling; by dagbreek, [deur die] koning van JisraEl te vernietig.	",

]
},
{
book: 'Hoséa',
chapter: '11',
content: [
		
"	1 TOE JisraEl ’n kind was, het Ek hom liefgehad, en uit Egipte het Ek My seun geroep. [Deuteronómium 26:16 - 18]	",
"	2 Hoe meer hulle geroep het, des te meer het hulle van húlle af weggeloop; hulle het aan die Here (Baäl) geslag en vir die gesnede afbeeldings rook laat opgaan.	",
"	3 En Ek self het Efraim leer loop. Hy het hulle op sy arms geneem, maar hulle het nie erken dat Ek hulle genees het nie. [Exodus 15:26]	",
"	4 Met koorde van adamiete, met bande van liefde het Ek hulle getrek; en Ek was vir hulle soos diegene wat die juk van hulle kakebeen af oplig; en Ek het My na hom neergebuig, Ek het hom voedsel gegee.	",
"	5 Hy sal na die Aarde van Egipte nie terugkeer nie, maar Assur - dié sal sy koning wees; omdat hulle geweier het om hulle te bekeer.	",
"	6 En die swaard sal geswaai word in sy stede en sy grendels vernietig en verteer weens hulle planne.	",
"	7 Want My volk neig om van My afvallig te word; maar tog roep hulle die Hoogste, en Hy word glad nie verhoog nie.	",
"	8 Hoe kan Ek jou oorgee, o Efraim, jou prysgee, o JisraEl? Hoe kan Ek jou maak soos Adma, jou gelykstel met Seboïm: My hart is omgekeer in My, tegelykertyd is My Medelye opgewek.	",
"	9 Ek sal My brandende Woede nie laat geld nie, Ek sal Efraim nie weer te gronde rig nie; want Ek is El en nie ’n man nie, die Aparte Een in jou midde. En Ek sal nie kom in Grimmigheid nie.	",
"	10 Hulle sal agter JaHWeH aan trek; Hy sal brul soos ’n leeu. Want Hy sal brul, en die kinders sal sidderende van die seekant aankom.	",
"	11 Hulle sal sidderende aankom soos ’n voëltjie uit Egipte en soos ’n duif uit die Aarde van Assur; en Ek sal hulle laat woon in hulle huise, spreek JaHWeH.	",
"	12 Efraim het My omsingel met leuens, en die huis van JisraEl met bedrog; terwyl JeHûWdah nog altyd bandeloos is teenoor El, ja, teenoor die Aparte Een, die Getroue.	",

]
},
{
book: 'Hoséa',
chapter: '12',
content: [
		
"	1 EFRAIM wei op wind, en hy agtervolg die oostewind; die hele dag vermeerder hy leuens en geweld, en hulle sluit ’n verbond met Assur, terwyl olie na Egipte gevoer word.	",
"	2 JaHWeH het ook ’n twis met JeHûWdah, en Hy sal oor Jakob besoeking doen volgens sy weë, hom vergelde na sy dade.	",
"	3 In die moederskoot het hy sy broer by die hakskeen gehou, en in sy [manlike] krag het hy met Elohim geworstel.	",
"	4 Ja, hy het met die Boodskapper geworstel en die oorhand gekry, hy het geween en Hom gesmeek. By BetEl het hy Hom gevind, en daar het hy met Ons gespreek.	",
"	5 En JaHWeH Elohey van die skeppings-leërmag, JaHWeH is Sy herinnering.	",
"	6 En jy, tot jou Elohey moet jy terugkeer, beoefen Medelye en Reg, en hoop voortdurend op jou Elohey.	",
"	7 Kanaän - in sy hand is daar ’n valse weegskaal, hy hou daarvan om af te pers.	",
"	8 Maar Efraim sê: Tog het ek ryk geword, ek het vir my ’n vermoë verwerf. Alles wat ek verwerf het, is nie genoeg om op my enige skuld van ongeregtigheid te lê nie.	",
"	9 Maar Ek - JaHWeH jou Elohey van die Aarde van Egipte af, Ek sal jou weer in tente laat woon soos in die dae van die vasgestelde tye.	",
"	10 Ek het ook tot die profete gespreek, en Ek het gesigte vermenigvuldig en deur middel van die profete gelykenisse voorgedra.	",
"	11 Is Gílead besoedel - hulle het louter nietigheid geword. In Gilgal het hulle beeste geslag; so sal dan hulle altare wees soos kliphope op die vore van die landerye.	",
"	12 En Jakob het gevlug na die veld van Aram, en JisraEl was diensbaar vir ’n vrou [as loon], en vir ’n vrou het hy vee opgepas.	",
"	13 Maar deur ’n profeet het JaHWeH JisraEl uit Egipte laat optrek, en deur ’n profeet is hulle opgepas.	",
"	14 Efraim het Hom bitterlik getart; daarom sal Hy sy bloedskulde op hom laat neerkom, ja, sy Majesteit sal hom vir die aangedane smaad vergelde.	",

]
},
{
book: 'Hoséa',
chapter: '13',
content: [
		
"	1 AS Efraim [net] gespreek het, was daar siddering; hoog het hy ge- staan in JisraEl. Maar hy het hom skuldig gemaak deur die Here (Baäl) en gesterwe.	",
"	2 En nou gaan hulle voort om te oortree en het vir hulle ’n gegote afbeelding van hulle silwer gemaak, idole volgens hulle insig, geheel en al smidswerk; van hulle word gesê: Laat die adamiet wat slag, die kalwers soen!	",
"	3 Daarom sal hulle vir die Wolkkolom wees soos Dou wat vroeg weer verdwyn, soos kaf wat wegvlieg van die dorsvloer en soos rook uit die venster.	",
"	4 Tog was Ek - JaHWeH, jou Elohey van die Aarde van Egipte af, en buiten My het jy geen Elohim geken nie, ja, behalwe My is daar geen Verlosser nie.	",
"	5 Ek het jou in die wildernis geken, in die Aarde van droogtes.	",
"	6 Ooreenkomstig hulle weiveld het hulle versadig geword; toe hulle versadig was, het hulle hart hoogmoedig geword; daarom het hulle My vergeet.	",
"	7 Toe het Ek vir hulle soos ’n leeu geword, soos ’n luiperd lê Ek by die pad en loer.	",
"	8 Ek val hulle aan soos ’n berin wat van kleintjies beroof is, en Ek skeur hulle borskas oop; en soos ’n leeuin verslind Ek hulle daar, die wilde diere van die veld sal hulle verskeur.	",
"	9 Dit is jou verderf, o JisraEl, dat jy teen My, jou Helper, is.	",
"	10 Waar is nou jou koning, dat hy jou kan verlos in al jou stede, en jou regters van wie jy gesê het: Gee my ’n koning en vorste?	",
"	11 Ek gee jou ’n koning in My Toorn, en Ek neem hom weg in My Grimmigheid.	",
"	12 Saamgebind is die ongeregtigheid van Efraim, weggebêre is sy oortredinge.	",
"	13 Barensweë sal hom oorval, hy is ’n onverstandige kind; want as die tyd daar is, stel hy hom nie in die kindergeboorte nie.	",
"	14 Uit die mag van die Doderyk/Sheol sal Ek hulle loskoop, Ek sal hulle verlos van die Dood. Dood, waar is jou pestilensies? Doderyk/Sheol, waar is jou verderf? Berou bly vir My oë verborge.	",
"	15 Wanneer hy vrug dra onder die broers, kom ’n oostewind, ’n Gees van JaHWeH, wat uit die wildernis opkom; dan droog sy fontein op en sy bron dor uit. Dié sal ’n skat van allerhande kosbare voorwerpe roof.	",
"	16 Samaria sal daarvoor boet, omdat sy teen haar Elohey gerebelleer het; hulle sal val deur die swaard, hulle kinders sal verpletter en hulle swanger vroue oopgesny word.	",

]
},
{
book: 'Hoséa',
chapter: '14',
content: [
		
"	1 BEKEER jou, JisraEl, tot JaHWeH jou Elohey, want jy het gestruikel deur jou ongeregtigheid.	",
"	2 Neem woorde met julle, en bekeer julle tot JaHWeH; sê aan HOM: Vergeef alle ongeregtigheid, en neem aan wat suiwer is; dan sal ons lippe as kalwers aanbied.	",
"	3 Assur kan ons nie red nie, op perde wil ons nie ry nie en tot die werk van ons hande nie meer sê: onse gode nie! Want by U vind die wees Ontferming.	",
"	4 Ek sal hulle afkerigheid genees, hulle vrywillig liefhê, want My Toorn is van hulle afgewend.	",
"	5 Ek sal vir JisraEl wees soos die Dou, hy sal bot soos ’n lelie en sy wortels uitslaan soos die Líbanon.	",
"	6 Sy lote sal uitsprei, en sy prag wees soos dié van ’n Olyfboom en sy geur soos die Líbanon.	",
"	7 Die wat onder sy skaduwee sit, sal weer koring laat groei; en hulle self sal bot soos die Wingerdstok; die nagedagtenis sal wees soos die wyn van die Líbanon.	",
"	8 Efraim, wat het Ek nog met die idole te doen? Ek het hom verhoor en hou My Oog oor hom. Ek is soos ’n groen sipres; uit My word jou vrug gevind.	",
"	9 Wie wys is, laat hom op hierdie dinge let! Wie verstandig is, laat hom dit erken! Want die Weë van JaHWeH is Reg; en die regverdiges sal daarop wandel, maar die oortreders daarop struikel!	",

]
}
];
