const judasChapters = [

{
book: 'Judas',
chapter: '1',
content: [

"	1 JUDAS, ’n dienskneg van JaHWèshua die Gesalfde en broer van Jakobus, aan die wat geroep, in JaHWeH die VADER Apartgestel en vir JaHWèshua die Gesalfde bewaar is:	",
"	2 Mag Barmhartigheid en Vrede en Liefde vir julle vermenigvuldig word!	",
"	3 GELIEFDES, terwyl ek alle ywer aanwend om aan julle oor ons gemeenskaplike Verlossing te skrywe, het ek die noodsaaklikheid gevoel om julle deur my skrywe te vermaan om kragtig te stry vir die Geloof wat eenmaal aan die Apartes oorgelewer is.	",
"	4 Want sekere mense het ingesluip wat lank tevore al opgeskryf is vir hierdie oordeel, verbasterdes wat die Barmhartigheid van onse Elohey verander in ontugtigheid, en teen die enigste Vors, El, onse Meester JaHWèshua die Gesalfde getuig. [Psalm 18:23; Boekrol van Henog 16:3]	",
"	5 Maar ek wil julle daaraan herinner, al weet julle dit nou eenmaal, dat JaHWeH, nadat Hy die volk uit die Aarde van Egipte gered het, daarna die wat nie wou glo nie, omgebring het.	",
"	6 En die Boodskappers wat hul eie beginsel nie bewaar het nie, maar hul eie woning verlaat het, het Hy vir die oordeel van die groot dag met ewige boeie onder die Duisternis bewaar; [Génesis 6:1-6; Boekrol van Henog 14:5; 86:3; Openbaring van Henog 11:34]	",
"	7 soos Sodom en Gomorra en die stede rondom hulle, wat op dieselfde manier as hierdie [Boodskappers] gehoereer en agter vreemde vlees aangeloop het, as ’n voorbeeld gestel is, terwyl hulle die straf van die ewige vuur ondergaan.	",
"	8 Hierdie [smerige] dromers verkleur die vlees, en verag en laster die Koningskap van die adamietiese Skeppingswesens.	",
"	9 Maar toe MikaEl, die Hoofboodskapper, met die Satan in woordestryd was oor die liggaam van Moshè, het hy geen oordeel van lastering durf uitspreek nie, maar het gesê: JaHWeH bestraf jou!	",
"	10 Maar hierdie [smerige dromers] belaster alles wat hulle nie ken nie; maar alles wat in hulle natuur is, wat soos die natuur van die wilde wesens is, daardeur word hulle besmet.	",
"	11 Wee hulle, want hulle het die weg van Kain bewandel en oortree deurdat hulle hulleself in die verleiding van Bíleam [verbastering] gestort het, en sal vernietig word in die verset van Korag.	",
"	12 Hulle is vleesbesoedeldes van julle seksuele feeste, wat vreesloos saam fees hou en hulleself voer, waterlose wolke deur winde rondgedrywe, bome in die na-somer, wat sonder vrugte is, twee maal gestorwe, ontworteld;	",
"	13 hartstogtelik aangedryf deur hul eie skandelike en bruisende begeertes, dwaalsterre vir wie die donkerheid van die Duisternis vir ewig bewaar word.	",
"	14 En Henog, die sewende van Adam af, het ook teen hulle geprofeteer en gesê: Kyk, JaHWeH het gekom met Sy tienduisende Apartes, [Henog 1:9, Deuteronómium 33:2,3]	",
"	15 om gerig te hou oor almal en al die verbasterdes onder hulle te straf oor al hulle basterdade wat hulle in hul verbastering gepleeg het, en oor al die harde woorde wat die verbasterde oortreders teen Hom gespreek het.	",
"	16 Hulle is murmureerders wat oor hul lot kla, en volgens hulle wellus wandel; en hulle mond spreek onbeskaamde woorde, terwyl hulle mense vlei ter wille van [hul eie] voordeel.	",
"	17 MAAR julle, geliefdes, moet die woorde onthou wat tevore gespreek is deur die Apostels van onse Meester JaHWèshua die Gesalfde,	",
"	18 dat hulle vir julle gesê het: In die laaste tyd sal daar koggelaars wees wat volgens hul eie verbasteringswellus sal wandel.	",
"	19 Dit is hulle wat skeuring maak, wellustige mense wat die Gees nie het nie.	",
"	20 Maar julle, geliefdes, moet julleself opbou in jul Geloof van Apartheid en in die Gees van die Apartheid bid	",
"	21 en julleself in die Liefde van Elohim bewaar, terwyl julle die Barmhartigheid van onse Meester JaHWèshua die Gesalfde tot die Ewige Lewe verwag.	",
"	22 En aan sommige wat twyfel, moet julle barmhartigheid bewys;	",
"	23 maar ander moet julle met Vrees red deur hulle uit die vuur te ruk; en ook moet julle die kleed van gekleurde vlees haat.	",
"	24 Aan Hom nou wat magtig is om julle van struikeling te bewaar en julle as rasegtes voor Sy Majesteit te stel met gejuig,	",
"	25 aan die alleenwyse Elohim, ons Verlosser, kom toe Glansrykheid en Majesteit, Krag en Mag, nou en tot in alle ewigheid! Amein.	",


]
}

];
