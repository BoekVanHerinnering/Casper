const lukasChapters = [

{
book: 'Lukas',
chapter: '1',
content: [
	
"	1 AANGESIEN baie onderneem het om ’n verhaal op te stel oor die dinge wat onder ons al vervul is,	",
"	2 soos hulle wat van die begin af ooggetuies en dienaars van die Woord was, dit aan ons oorgelewer het,	",
"	3 het ek ook dit goedgedink, hooggeagte Theófilus, nadat ek van voor af alles noukeurig ondersoek het, om dit in volgorde aan u te skrywe,	",
"	4 sodat u met volle sekerheid kan weet die dinge waaromtrent u onderrig is.	",
		
		
"	5 DAAR was in die dae van Herodes, koning van JeHûWdah, ’n sekere priester met die naam van ZekarJaH, uit die afdeling van AbiJaH; en sy vrou was uit die dogters van Aäron, en haar naam was EliSheba.	",
"	6 En hulle was altwee regverdiges voor die Aangesig van die Elohim en het in al die Gebooie en regte van JaHWeH onberispelik gewandel.	",
"	7 En hulle het geen kind gehad nie, omdat EliSheba onvrugbaar was en albei op ver gevorderde leeftyd.	",
"	8 En terwyl hy besig was om die priesteramp voor die aangesig van die Elohim te bedien in die beurt van sy afdeling,	",
"	9 het die lot volgens priesterlike gewoonte op hom geval om in te gaan in die Huis van JaHWeH en reukwerk te brand.	",
"	10 En die hele menigte van die volk was buite, besig om te bid op die uur van die reukwerk.	",
"	11 Toe verskyn daar aan hom ’n Boodskapper van JaHWeH, wat aan die regterkant van die altaar vir die reukwerk, staan.	",
"	12 En toe ZekarJaH hom sien, was hy ontsteld, en Vrees het hom oorval.	",
"	13 Maar die Boodskapper sê vir hom: Moenie vrees nie, ZekarJaH, want jou gebed is verhoor, en jou vrou EliSheba sal vir jou ’n seun baar, en jy moet hom JeHôWganan noem.	",
"	14 En hy sal blydskap en verheuging vir jou wees, en baie sal oor sy geboorte bly wees;	",
"	15 want hy sal groot wees voor die Aangesig van JaHWeH. En wyn en sterk drank sal hy nooit drink nie, en hy sal vervul word met die Gees van die Apartheid reeds van die skoot van sy moeder af.	",
"	16 En hy sal baie van die kinders van JisraEl bekeer tot JaHWeH hulle Elohey.	",
"	17 En hy sal voor Hom uit gaan in die Gees en die Krag van EliJaHûW, om die harte van die vaders terug te bring tot die kinders en die ongehoorsames tot die gesindheid van die regverdiges, om vir JaHWeH ’n toegeruste volk te berei. [Maleági 4:5,6]	",
"	18 Toe sê ZekarJaH vir die Boodskapper: Waaraan sal ek dit weet? Want ek is ’n ou man, en my vrou is op ver gevorderde leeftyd.	",
"	19 En die Boodskapper antwoord en sê vir hom: Ek is GabriEl wat voor die aangesig van die Elohim staan, en ek is gestuur om met jou te spreek en jou hierdie goeie nuus te bring. [Boekrol van Henog 20:7]	",
"	20 En kyk? jy sal swyg en nie kan praat nie tot op die dag dat hierdie dinge gebeur, omdat jy my woorde wat op hulle tyd vervul sal word, nie geglo het nie.	",
"	21 En die volk het op ZekarJaH bly wag en was verwonderd dat hy so lank in die Tempel vertoef.	",
"	22 Maar toe hy uitkom, kon hy met hulle nie praat nie; hulle bemerk toe dat hy ’n visioen in die Tempel gesien het. En hy het aanhoudend vir hulle beduie en stom gebly.	",
"	23 En toe die dae van sy diens vervul was, het hy huis toe gegaan.	",
"	24 En na hierdie dae het EliSheba, sy vrou, ontvang en haar vyf maande lank verberg en gesê:	",
"	25 So het JaHWeH met my gedoen in die dae toe Hy my aangesien het om my smaad onder die mense weg te neem.	",
		
		
"	26 EN in die sesde maand is die Boodskapper, GabriEl deur JaHWeH gestuur na ’n stad in Galiléa met die naam van Násaret,	",
"	27 na ’n maagd wat verloof was aan ’n man met die naam van JôWsef, uit die huis van Dawid; en die naam van die maagd was Mirjam.	",
"	28 En die Boodskapper het by haar binnegekom en gesê: Wees gegroet, barmhartige! JaHWeH is met jou; geseënd is jy onder die vroue.	",
"	29 En toe sy Hom sien, was sy baie ontsteld oor Sy woord, en sy het daaroor nagedink wat hierdie groet tog kon beteken.	",
"	30 En die Boodskapper sê vir haar: Moenie vrees nie, Mirjam, want jy het Barmhartigheid by JaHWeH gevind.	",
"	31 En kyk, jy sal swanger word en ’n Seun baar, en jy moet Hom JaHWèshua noem.	",
"	32 Hy sal groot wees en die Seun van die Hoogste El genoem word; en JaHWeH Elohim sal aan Hom die Troon van Sy vader Dawid gee,	",
"	33 en Hy sal koning wees oor die huis van Jakob tot in ewigheid, en aan Sy Koninkryk sal daar geen einde wees nie. [Boekrol van Henog 25:3; DaniEl 7:13-14]	",
"	34 Toe sê Mirjam vir die Boodskapper: Hoe kan dit wees aangesien ek geen man het nie?	",
"	35 En die Boodskapper antwoord en sê vir haar: Die Gees van die Apartheid sal oor jou kom en die Krag van die Hoogste El sal jou oorskadu. Daarom ook sal die Aparte Een wat gebore word, Seun van Elohim genoem word.	",
"	36 En kyk, EliSheba, jou bloedverwant, het self ook ’n seun ontvang in haar ouderdom, en hierdie maand is die sesde vir haar wat onvrugbaar genoem is.	",
"	37 Want geen ding sal by Elohim onmoontlik wees nie.	",
"	38 En Mirjam sê: Hier is die diensmaagd van JaHWeH. Laat dit met my gaan volgens u Woord. En die Boodskapper het van haar weggegaan.	",
		
		
"	39 EN in daardie dae het Mirjam opgestaan en haastig na die bergstreek gegaan, na ’n stad van JeHûWdah;	",
"	40 en sy het in die huis van ZekarJaH gekom en EliSheba gegroet.	",
"	41 En toe EliSheba die groet van Mirjam hoor, het die kindjie in haar moederskoot opgespring; en EliSheba is vervul met die Gees van die Apartheid	",
"	42 en het met ’n groot stem uitgeroep en gesê: Geseënd is jy onder die vroue, en geseënd is die vrug van jou moederskoot!	",
"	43 En wat het my oorgekom dat die moeder van my Meester na my toe kom?	",
"	44 Want kyk, toe die geluid van jou groet in my ore klink, het die kindjie in my moederskoot van vreugde opgespring.	",
"	45 En geseënd is sy wat geglo het, want die dinge wat deur JaHWeH aan haar gesê is, sal vervul word.	",
		
		
"	46 EN Mirjam het gesê: My siel maak JaHWeH groot,	",
"	47 en my gees is verheug in Elohey, my Verlosser;	",
"	48 omdat Hy die nederige toestand van Sy diensmaagd aangesien het; want kyk, van nou af sal al die geslagte my geseënd noem.	",
"	49 Want Hy wat magtig is, het groot dinge aan my gedoen, en apartgestel is Sy Naam.	",
"	50 En Sy Barmhartigheid is van geslag tot geslag vir die wat Hom vrees.	",
"	51 Hy het deur Sy Arm kragtige dade gedoen. Hoogmoediges in die gedagtes van hulle hart het Hy verstrooi.	",
"	52 Maghebbers het Hy van trone afgeruk en nederiges verhoog.	",
"	53 Hongeriges het Hy met suiwer dinge vervul en rykes met leë hande weggestuur.	",
"	54 Hy het Sy kneg JisraEl bygestaan, sodat Hy aan Sy Barmhartigheid sou dink -	",
"	55 soos Hy tot ons vaders gespreek het - aan Abraham en sy saad tot in ewigheid.	",
"	56 En Mirjam het by haar omtrent drie maande gebly; en sy het teruggegaan na haar huis toe.	",
"	Geboorte van JeHôWganan die Wasser/Doper.	",
"	57 EN die tyd dat sy moeder moes word, is vir EliSheba vervul, en sy het ’n seun gebaar.	",
"	58 En toe haar bure en bloedverwante hoor dat JaHWeH SY Barmhartigheid aan haar groot gemaak het, was hulle saam met haar bly.	",
"	59 En op die agtste dag het hulle gekom om die kindjie te besny, en hulle wou hom ZekarJaH noem, na die naam van sy vader.	",
"	60 Toe antwoord sy moeder en sê: Nee, maar hy moet JeHôWganan genoem word.	",
"	61 En hulle sê vir haar: Daar is niemand in jou familie wat dié naam het nie.	",
"	62 En hulle beduie vir sy vader hoe hy wou hê dat hy genoem moes word.	",
"	63 Hy vra toe ’n skryfbordjie en skryf: JeHôWganan is sy naam. En almal was verwonderd.	",
"	64 En onmiddellik is sy mond geopen en het sy tong losgeraak, en hy het gepraat en die Elohim geloof.	",
"	65 En daar het Vrees gekom oor almal wat rondom hulle gewoon het, en daar is baie gepraat oor al hierdie dinge in die hele bergstreek van JeHûWdah.	",
"	66 En almal wat dit gehoor het, het dit ter harte geneem en gesê: Wat sal tog van hierdie kindjie word? En die Hand van JaHWeH was met hom.	",
"	67 EN ZekarJaH, sy vader, is vervul met die Gees van die Apartheid en het geprofeteer en gesê:	",
"	68 Geloofd sy JaHWeH die Elohey van JisraEl, omdat Hy Sy volk besoek het en vir hulle Lossing teweeggebring het, [2 ShemuEl 22:3 ; Psalm 18:2 ; Henog 90:16 ; JeségiEl 29:21]	",
"	69 en ’n Horing van Lossing vir Ons opgerig het in die huis van Dawid, Sy kneg -	",
"	70 soos Hy gespreek het deur die Mond van Sy Profete, die Apartes van begin van tyd af -	",
"	71 Lossing van Ons vyande en uit die hand van almal wat Ons haat,	",
"	72 om Barmhartigheid te bewys aan Ons vaders en aan SY Verbond van die Apartheid te dink,	",
"	73 aan die Eed wat HY gesweer het vir Abraham, Ons vader, om aan Ons te gee	",
"	74 dat Ons, verlos uit die hand van Ons vyande, HOM sonder vrees kan dien,	",
"	75 deur Apartheid en Geregtigheid voor HOM, al die dae van Ons lewe.	",
"	76 En jy, kindjie, sal ’n profeet van die Hoogste El genoem word, want jy sal voor die Aangesig van JaHWeH uitgaan om Sy Weë reg te maak; [Maleagi 3]	",
"	77 om Kennis van Verlossing aan Sy volk te gee in die vergifnis van hulle oortredinge,	",
"	78 deur die innige Barmhartigheid van onse Elohey waarmee die opgaande Lig uit die hoogte ons besoek het,	",
"	79 om te skyn oor die wat in Duisternis en doodskaduwee sit, om ons voete na die Weg van Vrede te rig. [JeshaJaH 9:6]	",
"	80 En die kindjie het gegroei en sterk geword in die Gees; en hy was in die wildernisse tot op die dag van sy vertoning aan JisraEl.	",

]
},
{
book: 'Lukas',
chapter: '2',
content: [
		
"	1 EN in daardie dae het daar ’n bevel uitgegaan van keiser Augustus dat die hele wêreld ingeskryf moes word.	",
"	2 Hierdie eerste inskrywing het plaasgevind toe Cirénius goewerneur van Sírië was.	",
"	3 En almal het gegaan om ingeskryf te word, elkeen na sy eie stad.	",
"	4 En JôWsef het ook opgegaan van Galiléa, uit die stad Násaret, na JeHûWdah, na die Stad van Dawid, wat Betlehem genoem word, omdat hy uit die huis en saadlyn van Dawid was,	",
"	5 om hom te laat inskrywe saam met Mirjam, die vrou aan wie hy hom verloof het, wat swanger was.	",
"	6 En terwyl hulle daar was, is die dae vervul dat sy moes baar; [Boodskap van Jakobus 17-19]	",
"	7 en sy het haar eersgebore Seun gebaar en Hom toegedraai in doeke en Hom in die krip neergelê, omdat daar vir hulle geen plek in die herberg was nie.	",
		
		
"	8 EN daar was herders in dieselfde landstreek, wat in die oop veld gebly en in die nag oor hulle skape wag gehou het.	",
"	9 En meteens staan daar ’n Boodskapper van die Meester by hulle, en die Glansrykheid van JaHWeH het rondom hulle geskyn en groot Vrees het hulle oorweldig.	",
"	10 En die Boodskapper sê vir hulle: Moenie vrees nie, want kyk, ek bring julle ’n goeie nuus van groot blydskap wat vir die hele volk sal wees,	",
"	11 dat vir julle vandag in die Stad van Dawid gebore is die Verlosser wat die Gesalfde, die Koning, is.	",
"	12 En dit is vir julle die Teken: julle sal ’n Kindjie vind wat in doeke toegedraai is en wat in die krip lê.	",
"	13 En skielik was daar saam met die Boodskapper ’n menigte van die Skeppings-leërmagte wat Elohim prys en sê:	",
"	14 Eer aan Elohim in die hoogste en Vrede op Aarde, in die adamiete ’n welbehae!	",
"	15 En toe die Boodskappers van hulle weggegaan het na die Hemele, sê die herders vir mekaar: Laat ons dan na Betlehem gaan en hierdie ding sien wat gebeur het, wat JaHWeH aan ons bekend gemaak het.	",
"	16 En hulle het met haas gegaan en Mirjam en JôWsef gevind en die Kindjie wat in die krip lê.	",
"	17 En toe hulle Hom gesien het, het hulle oral die woord bekend gemaak wat aan hulle van dié Kindjie vertel is.	",
"	18 En almal wat dit gehoor het, was verwonderd oor wat deur die herders aan hulle vertel is;	",
"	19 maar Mirjam het al hierdie woorde bewaar en in haar hart oordink.	",
"	20 En die herders het teruggegaan en Elohim vereer en geprys oor alles wat hulle gehoor en gesien het, net soos aan hulle gesê is.	",
"	21 En toe agt dae vervul was, en die Kindjie besny is, het hulle Hom JaHWèshua genoem, die Naam wat deur die Boodskapper gegee is voor Sy ontvangenis in die moederskoot. [Odes van Salomo 19:4]	",
"	22 En nadat die dae van haar besoedeling volgens die Wet van Moshè vervul was, het hulle Hom na Jerusalem gebring om Hom aan JaHWeH voor te stel,	",
"	23 soos geskrywe is in die Wet van JaHWeH: Elke manlike kind wat die moederskoot open, sal aan JaHWeH afgegee word; [Exodus 13:12; Levítikus 12]	",
"	24 en om die slagdier te gee volgens wat gesê is in die Wet van JaHWeH: ’n paar tortelduiwe of twee jong duiwe.	",
		
		
"	25 EN daar was ’n man in Jerusalem met die naam van Símeon; en hierdie man was regverdig en opreg en het die Vertroosting van JisraEl verwag, en die Gees van die Apartheid was op hom. [2 Nikodémus 1:1a]	",
"	26 En aan hom was dit deur die Gees van die Apartheid geopenbaar dat hy die dood nie sou sien voordat hy die Gesalfde van JaHWeH gesien het nie.	",
"	27 En hy het deur die Gees in die Tempel gekom; en toe die ouers die Kindjie JaHWèshua inbring om met Hom te handel volgens die gebruik van die Wet,	",
"	28 het hy Hom in sy arms geneem en die Elohim geloof en gesê:	",
"	29 Nou laat U, Hoogste El, U dienskneg gaan in Vrede volgens U Woord,	",
"	30 omdat my oë U Oorwinning gesien het,	",
"	31 wat U berei het voor die oë van al die volke -	",
"	32 ’n Lig tot Verligting van die nasies en tot Glansrykheid van U volk JisraEl.	",
"	33 En JôWsef en sy moeder het hulle verwonder oor die dinge wat van Hom gesê is.	",
"	34 En Símeon het hulle geseën en aan Mirjam, Sy moeder, gesê: Kyk, hierdie Kind is bestemd tot ’n val en ’n opstanding van baie in JisraEl en tot ’n Teken wat weerspreek sal word - [Psalm 86:17]	",
"	35 ja, ’n swaard sal deur jou eie siel gaan - sodat die gedagtes uit baie harte openbaar kan word.	",
"	36 En daar was Anna, ’n profetes, die dogter van PeniEl, uit die stam van Aser. Sy was op baie ver gevorderde leeftyd en het van haar maagdelikheid af sewe jaar lank met haar man saamgelewe; [Boodskap van Jakobus 4:1]	",
"	37 en sy was ’n weduwee van omtrent vier-en-tagtig jaar. Sy het nie weggebly van die Tempel nie, en met vas en gebed die Elohim gedien, nag en dag. [Boodskap van Jakobus 4:1a]	",
"	38 En sy het in dieselfde uur daar gekom en die Meester geprys en van Hom gespreek met almal in Jerusalem wat die Verlossing verwag het.	",
"	39 En toe hulle alles volbring het wat volgens die Wet van JaHWeH was, het hulle teruggegaan na Galiléa, na hulle stad Násaret.	",
"	40 En die Kindjie het gegroei en sterk geword in die Gees en vol van Wysheid. En die Barmhartigheid van Elohim was op Hom.	",
		
		
"	41 EN Sy ouers was gewoond om elke jaar met die fees van die Pasga na Jerusalem te gaan.	",
"	42 En toe Hy twaalf jaar oud was, het hulle, volgens die gebruik van die Fees, na Jerusalem opgegaan.	",
"	43 En nadat die Feesdae vir hulle voltooi was, en terwyl hulle teruggaan, het die Kind JaHWèshua in Jerusalem agtergebly; en JôWsef en Sy moeder het dit nie geweet nie.	",
"	44 Maar omdat hulle gedink het dat Hy by die reisgeselskap was, het hulle ’n dagreis ver gegaan en Hom onder die familie en onder die bekendes gesoek.	",
"	45 En toe hulle Hom nie vind nie, het hulle teruggegaan na Jerusalem en Hom gesoek.	",
"	46 En ná drie dae het hulle Hom in die Tempel gevind, terwyl Hy in die midde van die leraars sit en na hulle luister en hulle uitvra.	",
"	47 En almal wat Hom gehoor het, was verbaas oor Sy verstand en Sy antwoorde.	",
"	48 En toe hulle Hom sien, was hulle verslae. En Sy moeder sê vir Hom: Kind, waarom het Jy so met ons gemaak? Kyk, Jou vader en ek het Jou met angs gesoek.	",
"	49 En Hy sê vir hulle: Waarom het u My gesoek? Het u nie geweet dat Ek in die dinge van My VADER moet wees nie?	",
"	50 En hulle het die Woord wat Hy aan hulle gesê het, nie verstaan nie.	",
"	51 En Hy het saam met hulle gegaan en in Násaret gekom, en Hy was hulle onderdanig. En Sy moeder het al hierdie dinge in haar hart bewaar.	",
"	52 En JaHWèshua het toegeneem in Wysheid en Grootheid en in Guns by Elohim en die adamiete.	",

]
},
{
book: 'Lukas',
chapter: '3',
content: [
		
"	1 EN in die vyftiende jaar van die regering van keiser Tiberius, toe Pontius Pilatus goewerneur was van JeHûWdah en Herodes viervors van Galiléa, en Filippus, sy broer, viervors van Ituréa en die Aarde Trachonítus, en Lisánias viervors van Abiléne,	",
"	2 tydens die hoëpriesterskap van Annas en Kájafas, het die Woord van Elohim gekom tot JeHôWganan, die seun van ZekarJaH, in die wildernis.	",
"	3 En hy het gekom in die hele omtrek van die Jordaan en die wassing/doop van bekering tot vergifnis van oortredinge verkondig;	",
"	4 soos geskrywe is in die boek van die woorde van JeshaJaHûW, die Profeet, waar hy sê: ’n Stem van een wat roep in die wildernis. Berei die Weg van JaHWeH; maak gelyk in die woestyn ’n grootpad vir onse Elohey! [JeshaJaHûW 40:3, Maleági 3:1].	",
"	5 Elke dal moet opgevul word en elke berg en heuwel wegsak; en die verdraaide weg sal ’n reguit pad word en die skurwe plekke gelyk Weë.	",
"	6 En die Glansrykheid van JaHWeH sal geopenbaar word, en alle vlees tesame sal hom sien: [want die Mond van JaHWeH het dit gespreek]. [JeshaJaHûW 40:3-5]	",
"	7 Toe sê hy vir die skare wat uitgegaan het om deur hom gewas/gedoop te word: Genetiese nageslag van Nagash/slang, wie het julle aangewys om te vlug vir die toorn wat aan kom is?	",
"	8 Dra dan vrugte wat by die bekering pas, en moenie by julleself begin sê: Ons het Abraham as vader nie; want ek sê vir julle dat Elohim mag het om uit hierdie klippe kinders vir Abraham te verwek.	",
"	9 Maar die byl lê ook al teen die wortel van die bome. Elke Boom dan wat geen suiwer vrugte dra nie, word uitgekap en in die vuur gegooi.	",
"	10 En die skare het hom gevra en gesê: Wat moet ons dan doen?	",
"	11 En hy antwoord en sê vir hulle: Wie twee kledingstukke het, moet uitdeel aan hom wat nie het nie; en wie voedsel het, moet dieselfde doen.	",
"	12 En tollenaars het ook gekom om gewas/gedoop te word, en vir hom gesê: Meester, wat moet ons doen?	",
"	13 En hy antwoord hulle: Moenie meer invorder as wat julle voorgeskrywe is nie.	",
"	14 En die soldate het hom ook gevra en gesê: En ons, wat moet ons doen? En hy sê vir hulle: Julle moet niemand geweld aandoen of iets afpers nie; en wees tevrede met julle soldy.	",
"	15 En terwyl die volk in verwagting was, en almal in hulle hart oorweeg het aangaande JeHôWganan of hy nie miskien die Gesalfde was nie,	",
"	16 antwoord JeHôWganan almal en sê: Ek was/doop julle wel in water, maar Hy kom wat sterker is as ek, wie se skoenriem ek nie waardig is om los te maak nie - Hy sal julle was/doop met die Gees van die Apartheid en met Vuur. [Boekrol van Henog 2:3; JeHôWganan 21:22]	",
"	17 Sy skop is in Sy Hand, en Hy sal Sy dorsvloer deur en deur skoonmaak en Sy koring saambring in Sy skuur, maar die kaf met onuitbluslike vuur verbrand. [Thomas 12]	",
"	18 Hy het dan ook met baie ander vermaninge die goeie nuus aan die volk verkondig.	",
"	19 Maar toe Herodes, die viervors, deur hom bestraf is oor Heródias, die vrou van Filippus, sy broer, en oor al die besoedelde dinge wat Herodes gedoen het,	",
"	20 het hy by alles nog dit gevoeg, dat hy JeHôWganan in die gevangenis opgesluit het.	",
		
		
"	21 EN nadat Jahwèshua en hulle wat teenwoordig was, gewas/gedoop is, het die Hemele oopgegaan terwyl Hy besig was om te bid;	",
"	22 en die Gees van die Apartheid het in liggaamlike gedaante soos ’n Duif op Hom neergedaal; en ’n Stem het uit die Hemele gekom wat sê: U IS MY GELIEFDE SEUN; IN U HET EK ‘N WELBEHAE. [Odes van Salomo 24:1-2]	",
		
		
"	23 EN Hy, JaHWèshua, was omtrent dertig jaar oud toe Hy begin leer het; en Hy was, soos hulle gemeen het, die seun van JôWsef, die seun van Eli,	",
"	24 die seun van Mattat, die seun van Levi, die seun van Melgi, die seun van Janna, die seun van JôWsef,	",
"	25 die seun van MattithJaH, die seun van Amos, die seun van Nahum, die seun van ElJôWeynay, die seun van Noga,	",
"	26 die seun van Maät, die seun van MattithJaH, die seun van Símeï, die seun van JôWsef, die seun van JeHûWdah,	",
"	27 die seun van GanánJaH, die seun van Rafa-JaH, die seun van Serubbábel, die seun van ShealtiEl, die seun van NearJaH, [1Kronieke 3:17-22]	",
"	28 die seun van Meleg, die seun van Addi, die seun van Kosam, die seun van Almódad, die seun van Er,	",
"	29 die seun van Joses, die seun van EliEzer, die seun van Jorim, die seun van Mattat, die seun van Levi,	",
"	30 die seun van Símeon, die seun van JeHûWdah, die seun van JôWsef, die seun van Jonan, die seun van El-Jakim,	",
"	31 die seun van Meléas, die seun van Mainan, die seun van Máttata, die seun van Natan, die seun van Dawid,	",
"	32 die seun van Isai, die seun van Obed, die seun van Boas, die seun van Salmon, die seun van Nagson, [JeshaJaH 11:1, 2]	",
"	33 die seun van Ammínadab, die seun van Ram, die seun van Hesron, die seun van Peres, die seun van JeHûWdah,	",
"	34 die seun van Jakob, die seun van Isak, die seun van Abraham, die seun van Tera, die seun van Nahor,	",
"	35 die seun van Serug, die seun van Rehu, die seun van Peleg, die seun van Heber, die seun van Selag,	",
"	36 die seun van Kainan, die seun van Arpágsad, die seun van Sem, die seun van Noag, die seun van Lameg,	",
"	37 die seun van Metúsalag, die seun van Henog, die seun van Jered, die seun van MahalalEl, die seun van Kenan,	",
"	38 die seun van Enos, die seun van Set, die seun van Adam, die seun van Elohim.	",

]
},
{
book: 'Lukas',
chapter: '4',
content: [
		
"	1 EN JaHWèshua het vol van die Gees van die Apartheid teruggekeer van die Jordaan af, en is deur die Gees in die wildernis gelei,	",
"	2 waar Hy veertig dae lank deur die Satan versoek is; en Hy het niks geëet in dié dae nie; en toe hulle verby was, het Hy naderhand honger geword.	",
"	3 Toe sê die Satan vir Hom: As U die Seun van Elohim is, sê vir hierdie klip dat hy brood moet word.	",
"	4 Maar JaHWèshua antwoord en sê vir hom: Daar is geskrywe: dat die adamiet nie van brood alleen lewe nie, maar dat die adamiet lewe van alles wat uit die Mond van JaHWeH uitgaan. [Deuteronómium 8:3]	",
"	5 Toe bring die Satan Hom op ’n hoë berg en wys Hom al die koninkryke van die wêreld in ’n oomblik se tyd.	",
"	6 En die Satan sê vir Hom: Ek sal U al hierdie mag gee en hulle glansrykheid, want sy is aan my oorgegee, en ek gee haar aan wie ek wil.	",
"	7 As U neerval voor my, dan sal alles aan U behoort.	",
"	8 En JaHWèshua antwoord en sê vir hom: Gaan weg agter My, Satan, want daar is geskrywe: Jy moet JaHWeH jou Elohey vrees en Hom dien; en by Sy Naam moet jy sweer. [Deuteronómium 6:13, 10:20]	",
"	9 Toe bring hy Hom na Jerusalem en stel Hom op die dak van die Tempel en sê vir Hom: As U die Seun van Elohim is, werp Uself hiervandaan neer.	",
"	10 Want daar is geskrywe: want HY sal SY Boodskappers aangaande U bevel gee om U te bewaar op al U Weë. [Psalm 91:11; MattithJaHûW 4:6]	",
"	11 Hulle sal U op die handpalms dra, sodat U U voet teen geen klip stamp nie. [Psalm 91:11,12]	",
"	12 En JaHWèshua antwoord en sê vir hom: Daar is gesê: Julle mag JaHWeH julle Elohey nie versoek nie. [Deuteronómium 6:16]	",
"	13 En toe die Satan elke versoeking geëindig het, het hy ’n tyd lank van Hom gewyk.	",
		
		
"	14 EN JaHWèshua het in die Krag van die Gees na Galiléa teruggekeer, en daar het ’n gerug aangaande Hom deur die hele omtrek uitgegaan;	",
"	15 en Hy het in hulle vergaderings geleer en is deur almal geprys.	",
"	16 Toe kom Hy in Násaret waar Hy opgevoed was; en soos Hy gewoond was, gaan Hy op die Sabbatdag in die vergadering en staan op om te lees.	",
"	17 En die Boekrol van die Profeet JeshaJaHûW is aan Hom oorhandig; en toe Hy die Boekrol oopmaak, kry Hy die plek waar geskrywe is:	",
"	18 Die Gees van JaHWeH is op My, omdat HY My gesalf het om die blye boodskap te bring aan die neergedruktes. HY het My gestuur om te verbind die gebrokenes van hart, om in die gevangenis ‘n vrylating uit te roep en vir die geboeides opening van die gevangenis;	",
"	19 om uit te roep ‘n jaar van Vreugde van JaHWeH en ‘n dag van wraak van Onse Elohey; om al die treurendes te troos; [JeshaJaH 61:1, 2]	",
"	20 En Hy het die Boekrol toegerol en aan die dienaar teruggegee, en Hy het gaan sit, en die oë van almal in die vergadering was op Hom gevestig.	",
"	21 Toe begin Hy vir hulle te sê: Vandag is hierdie Skrif in julle ore vervul.	",
"	22 En almal het vir Hom getuienis gegee en was verwonderd oor die aangename woorde uit Sy mond; en hulle sê: Is Hy nie die seun van JôWsef nie? [JeshaJaH 50:4]	",
"	23 En Hy antwoord hulle: Julle sal My ongetwyfeld hierdie spreekwoord toevoeg: Geneesheer, genees uself! Alles wat ons hoor wat in Kapérnaüm gebeur het, doen dit hier in U vaderstad ook.	",
"	24 En Hy sê: Voorwaar Ek sê vir julle, geen Profeet is aangenaam in sy vaderland nie.	",
"	25 Maar Ek sê vir julle met Waarheid, daar was baie weduwees in JisraEl in die dae van EliJaHûW toe die Hemele toegesluit was drie jaar en ses maande lank, toe daar ’n groot hongersnood gekom het in die hele Aarde, [1 Konings 17:1]	",
"	26 en na nie een van hulle is EliJaHûW gestuur nie, behalwe na Sarfat in Sidon, na ’n weduwee.	",
"	27 En daar was baie melaatses in JisraEl in die tyd van Elíshua, die Profeet, en nie een van hulle is gesuiwer nie, behalwe Naäman, die Síriër. [2 Konings 5]	",
"	28 En almal in die vergadering is met woede vervul toe hulle dit hoor;	",
"	29 en hulle het opgestaan en Hom uit die stad uitgedryf en Hom gebring tot op die rand van die berg waarop hulle stad gebou was om Hom van die krans af te gooi.	",
"	30 Maar Hy het tussen hulle deur geloop en weggegaan.	",
"	31 En Hy het afgekom na Kapérnaüm, ’n stad van Galiléa, en hulle op die Sabbat geleer.	",
"	32 En hulle was verslae oor Sy leer, want Sy Woord was met gesag.	",
		
		
"	33 EN in die vergadering was daar ’n man met die gees van besoedeling van ‘n demoon, en hy het met ’n groot stem uitgeskreeu	",
"	34 en gesê: Ha! wat het ons met U te doen, JaHWèshua, Nasaréner? Het U gekom om ons te verdelg? Ek ken U, wie U is: die Aparte Een van JaHWeH!	",
"	35 En JaHWèshua het hom bestraf en gesê: Bly stil, en gaan uit hom uit! En die demoon het hom tussen hulle neergegooi en uit hom uitgegaan sonder om hom seer te maak.	",
"	36 Toe kom daar verbaasdheid oor almal, en hulle praat met mekaar en sê: Wat vir ’n Woord is dit, dat Hy met gesag en mag die geeste van besoedeling gebied, en hulle gaan uit!	",
"	37 En daar het ’n gerug aangaande Hom uitgegaan na elke plek van die omgewing.	",
		
		
"	38 EN Hy het opgestaan uit die vergadering en in die huis van Simon gekom. En Simon se skoonmoeder was aangetas deur ’n hewige koors, en hulle het Hom geraadpleeg oor haar.	",
"	39 Toe gaan Hy oor haar staan en bestraf die koors, en dit het haar verlaat, en sy het onmiddellik opgestaan en hulle bedien.	",
"	40 En toe die son ondergaan, het almal hulle siekes, mense met allerhande kwale, na Hom gebring, en Hy het een vir een van hulle die hande opgelê en hulle gesond gemaak.	",
"	41 En demone het ook uit baie uitgegaan en geskreeu en gesê: U is die Gesalfde, die Seun van Elohim! En Hy het hulle bestraf en nie toegelaat om te praat nie, omdat hulle geweet het dat Hy die Gesalfde was.	",
"	42 En toe dit dag geword het, het Hy uitgegaan en na ’n verlate plek vertrek; en die skare het Hom gesoek en by Hom gekom en Hom teëgehou, dat Hy nie van hulle sou weggaan nie.	",
"	43 Maar Hy het vir hulle gesê: Ek moet aan die ander stede ook die goeie nuus van die Koninkryk van Elohim bring, want Ek is daarvoor gestuur.	",
"	44 En Hy het verder in die vergaderings van Galiléa verkondig.	",

]
},
{
book: 'Lukas',
chapter: '5',
content: [
	
"	1 EN toe die skare by Hom aandring om die Woord van die Elohim te hoor, gaan Hy by die meer Gennésaret staan	",
"	2 en sien twee skuite aan die kant van die meer lê; maar die vissers het van hulle af weggegaan en was besig om die nette uit te spoel.	",
"	3 Toe klim Hy in een van die skuite wat aan Simon behoort het, en vra hom om ’n entjie van die land af weg te vaar, en Hy het gaan sit en die skare vanuit die skuit geleer.	",
"	4 En toe Hy ophou met spreek, sê Hy vir Simon: Vaar uit na die diep water en laat julle nette sak om te vang.	",
"	5 En Simon antwoord en sê vir Hom: Meester, ons het die hele nag deur hard gewerk en niks gevang nie; maar op U woord sal ek die net laat sak.	",
"	6 En toe hulle dit gedoen het, het hulle ’n groot menigte visse ingesluit; en hulle net wou skeur.	",
"	7 Daarop wink hulle vir hul maats in die ander skuit om hulle te kom help. En hulle het gekom en altwee die skuite vol gemaak, sodat hulle amper gesink het.	",
"	8 En toe Simon Petrus dit sien, val hy neer aan die knieë van JaHWèshua en sê: Gaan weg van my, Meester, want ek is ’n man wat oortree!	",
"	9 Want verbaasdheid het hom aangegryp en almal wat by hom was, oor die vangs van visse wat hulle gemaak het;	",
"	10 en net so ook vir Jakobus en JeHôWganan, die seuns van Sebedéüs, wat Simon se maats was. En JaHWèshua sê vir Simon: Moenie vrees nie; van nou af sal jy adamiete vang.	",
"	11 En nadat hulle die skuite aan land gebring het, het hulle alles verlaat en Hom gevolg.	",
		
		
"	12 EN terwyl Hy in een van die stede was, kom daar ’n man vol van melaatsheid; en toe hy JaHWèshua sien, val hy op sy aangesig en smeek Hom en sê: Meester, as U wil en U die mag het om te suiwer, kan U my suiwer maak.	",
"	13 Daarop steek Hy die hand uit en raak hom aan en sê: Ek wil, word gesuiwer! En dadelik het die melaatsheid hom verlaat.	",
"	14 Toe gee Hy hom bevel om dit aan niemand te vertel nie; maar, sê Hy, gaan vertoon jou aan die priester en bring [‘n aanbieding] nader vir jou suiwering, soos Moshè voorgeskrywe het, vir hulle tot ’n getuienis.	",
"	15 Maar die gerug aangaande Hom is nog meer versprei, en groot menigtes het bymekaargekom om te luister en deur Hom van hulle siektes genees te word.	",
"	16 Maar Hy het Hom in verlate plekke teruggetrek en gebid.	",
		
		
"	17 EN op een van dié dae was Hy besig om te leer; en Fariseërs en wetsvertolkers wat gekom het uit elke dorp van Galiléa en JeHûWdah en uit Jerusalem, het daar gesit, en daar was Krag van die Meester om hulle te genees.	",
"	18 En daar het manne ’n adamiet wat verlam was, op ’n bed gebring, en hulle het probeer om hom in te bring en voor Hom neer te sit.	",
"	19 En toe hulle vanweë die skare geen kans sien om hom in te bring nie, klim hulle op die dak en laat hom met die bed afsak deur die panne tussen die mense in en voor JaHWèshua.	",
"	20 En toe Hy hulle geloof sien, sê Hy vir hom: Adamiet, jou oortredinge is jou vergewe.	",
"	21 En die skrywers en die Fariseërs het begin redeneer en sê: Wie is Hy wat so lasterlik praat? Wie kan oortredinge vergewe behalwe die Elohim alleen?	",
"	22 Maar JaHWèshua het hulle redeneringe gemerk, en Hy antwoord en sê vir hulle: Wat redeneer julle in jul harte?	",
"	23 Wat is makliker, om te sê: Jou oortredinge is jou vergewe; of om te sê: Staan op en loop?	",
"	24 Maar dat julle kan weet dat die Seun van die Adam mag het om op Aarde oortredinge te vergewe - sê Hy vir die verlamde man: Ek sê vir jou, staan op, neem jou bed op en gaan na jou huis toe.	",
"	25 Hy staan toe onmiddellik voor hulle op, neem die bed op waar hy op gelê het, en gaan na sy huis, terwyl hy Elohim vereer.	",
"	26 En verbasing het almal aangegryp, en hulle het Elohim vereer en is met Vrees vervul en het gesê: Ons het vandag ongelooflike dinge gesien.	",
		
		
"	27 EN ná hierdie dinge het Hy uitgegaan en ’n tollenaar met die naam van Levi by die tolhuis sien sit en vir hom gesê: VOLG MY.	",
"	28 En hy het alles verlaat en opgestaan en Hom gevolg.	",
"	29 En Levi het ’n groot feesmaal vir Hom in sy huis gegee; en daar was ’n groot menigte van tollenaars en ander wat saam met hulle aan tafel was.	",
"	30 En hulle skrywers en die Fariseërs het by Sy studente gemurmureer en gesê: Waarom eet en drink julle saam met die tollenaars en oortreders?	",
"	31 En JaHWèshua antwoord en sê vir hulle: Die wat gesond is, het die geneesheer nie nodig nie, maar die wat ongesteld is.	",
"	32 Ek het nie gekom om regverdiges te roep nie, maar oortreders tot bekering.	",
		
		
"	33 TOE sê hulle vir Hom: Waarom vas die studente van JeHôWganan dikwels en doen gebede; so ook dié van die Fariseërs; maar U studente eet en drink?	",
"	34 En Hy sê vir hulle: Kan julle die seuns wat die Bruidskamer voorberei dan laat vas solank as die Bruidegom by hulle is?	",
"	35 Maar daar sal dae kom wanneer die Bruidegom van hulle weggeneem word; dan sal hulle vas, in daardie dae.	",
"	36 En Hy het ook aan hulle ’n gelykenis vertel: Niemand sit ’n lap van ’n nuwe kleed op ’n ou kleed nie; anders skeur hy die nuwe ook, en die lap wat van die nuwe af kom, pas nie by die oue nie.	",
"	37 En niemand gooi nuwe wyn in ou leersakke nie; anders sal die nuwe wyn die sakke skeur, en hy sal uitloop, en die sakke sal vergaan.	",
"	38 Maar nuwe wyn moet in nuwe sakke gegooi word, en altwee word saam behou.	",
"	39 En niemand wat ou wyn gedrink het, wil dadelik nuwe hê nie; want hy sê: Die oue is beter.	",
		
		
"	6 EN op die tweede Sabbat na die Pasga het Hy deur die gesaaides geloop, en Sy studente het die are gepluk en met hulle hande uitgevrywe en geëet.	",
"	2 Toe sê sommige van die Fariseërs vir hulle: Waarom doen julle wat nie ge-oorloof is om op die Sabbat te doen nie?	",
"	3 En JaHWèshua antwoord en sê vir hulle: Het julle dan nie gelees wat Dawid gedoen het nie - toe hy honger gehad het, hy en die wat by hom was -	",
"	4 hoe hy in die Huis van Elohim gegaan en die toonbrode geneem en geëet het, en ook aan die wat by hom was, gegee het, wat hulle nie geoorloof was om te eet nie, maar net vir die priesters alleen? [1 ShemuEl 21:6]	",
"	5 Toe sê Hy vir hulle: Die Seun van die Adam is Meester óók van die Sabbat.	",

]
},
{
book: 'Lukas',
chapter: '6',
content: [
	
"	1 EN op ’n ander Sabbat het Hy in die vergadering gegaan en geleer. En daar was ’n man, en sy regterhand was uitgedor.	",
"	7 En die skrywers en die Fariseërs het Hom in die oog gehou, of Hy op die Sabbat gesond maak, sodat hulle ’n aanklag teen Hom kon vind.	",
"	8 Maar Hy het hulle gedagtes geken en vir die man met die verdorde hand gesê: Staan op hier in hul midde. En hy het opgestaan.	",
"	9 Toe sê JaHWèshua vir hulle: Ek sal aan julle ’n vraag stel: wat is geoorloof op die Sabbat - om goed te doen of kwaad te doen; om ’n siel te red of óm te bring?	",
"	10 En nadat Hy almal rondom aangekyk het, sê Hy vir die man: Steek jou hand uit! En hy het dit gedoen; en sy hand is herstel, gesond soos die ander een.	",
"	11 En hulle is met woede vervul en het met mekaar gepraat wat hulle aan JaHWèshua sou doen.	",
		
		
"	12 EN Hy het in daardie dae uitgegaan na die berg om te bid en die nag in die gebed tot Elohim deurgebring.	",
"	13 En toe dit dag geword het, het Hy Sy studente na Hom geroep en twaalf van hulle uitgekies, wat Hy Apostels genoem het:	",
"	14 Simon wat Hy Petrus genoem het, en Andréas, sy broer; Jakobus en JeHôWganan; Filippus en Bartholoméüs;	",
"	15 MattithJaHûW en Thomas; Jakobus, die seun van Alféüs, en Simon wat Yweraar genoem word;	",
"	16 Judas, die seun van Jakobus, en Judas Iskáriot, wat die verraaier geword het.	",
		
		
"	17 EN Hy het met hulle afgeklim en op ’n gelyk plek gaan staan, en daar was ’n skare van Sy studente en ’n groot menigte van die volk van die hele JeHûWdah en Jerusalem en die kusstreek van Tirus en Sidon af,	",
"	18 wat gekom het om Hom te hoor en van hulle kwale genees te word; en die wat gekwel was deur geeste van besoedeling , is ook genees.	",
"	19 En die hele skare het probeer om Hom aan te raak, omdat Krag van Hom uitgegaan het, en Hy het almal gesond gemaak.	",
"	20 Toe slaan Hy Sy oë op oor Sy studente en sê: Geseënd is julle, armes, want aan julle behoort die Koninkryk van die Elohim.	",
"	21 Geseënd is julle wat nou honger het, want julle sal versadig word. Geseënd is julle wat nou ween, want julle sal lag.	",
"	22 Geseënd is julle wanneer die mense julle haat, en wanneer hulle julle verstoot en beledig en jul naam weggooi soos iets wat besoedel is, ter wille van die Seun van die Adam.	",
"	23 Wees bly in daardie dag en spring op, want kyk, julle loon is groot in die Hemele, want hiervolgens het hulle vaders aan die Profete gedoen.	",
"	24 Maar wee julle, rykes, want julle het jul troos weg.	",
"	25 Wee julle wat vol is, want julle sal honger ly. Wee julle wat nou lag, want julle sal treur en ween.	",
"	26 Wee julle wanneer al die mense goed van julle praat, want hiervolgens het hulle vaders aan die valse profete gedoen.	",
"	27 Maar Ek sê vir julle wat luister: Julle moet jul teëstanders liefhê en goed doen aan die wat vir julle haat.	",
"	28 Seën die wat vir julle vervloek, en bid vir die wat julle beledig.	",
"	29 Aan hom wat jou op die wang slaan, moet jy ook die ander een aanbied; en aan hom wat jou bo-kleed neem, moet jy ook die onderkleed nie weier nie.	",
"	30 Maar gee aan elkeen wat jou iets vra, en eis jou goed nie terug van hom wat dit neem nie.	",
"	31 En soos julle wil hê dat die adamiete aan julle moet doen, so moet julle ook aan hulle doen.	",
"	32 En as julle dié liefhêt wat vir julle liefhet, watter dank het julle? Want die oortreders het ook dié lief wat vir hulle liefhet.	",
"	33 En as julle goed doen aan die wat aan julle goed doen, watter dank het julle? Want die oortreders doen ook dieselfde.	",
"	34 En as julle leen aan dié van wie julle hoop om terug te ontvang, watter dank het julle? Want die oortreders leen ook aan die oortreders, om net soveel terug te ontvang.	",
"	35 Maar julle moet jul teëstanders liefhê en goed doen en leen sonder om iets terug te verwag, en julle loon sal groot wees; en julle sal kinders van die Hoogste El wees; want HY self is hard op die ondankbares en besoedeldes.	",
"	36 Wees dan barmhartig, soos julle VADER ook barmhartig is.	",
"	37 En julle moet nie oordeel nie, dan sal julle nooit geoordeel word nie. Julle moet nie veroordeel nie, dan sal julle nooit veroordeel word nie. Spreek vry, en julle sal vrygespreek word. [Spreuke 17:9]	",
"	38 Gee, en aan julle sal gegee word. ’n Goeie maat wat ingedruk en geskud en oorlopend is, sal hulle in jul skoot gee, want met dieselfde maat waarmee julle meet, sal weer vir julle gemeet word.	",
"	39 En Hy het vir hulle ’n gelykenis uitgespreek: ’n Blinde kan tog nie ’n blinde lei nie! Sal hulle nie altwee in die sloot val nie?	",
"	40 ’n Leerling is nie bo sy meester nie; maar elkeen wat volleerd is, sal soos sy meester wees.	",
"	41 En waarom sien jy die splinter in die oog van jou broeder, maar die balk wat in jou eie oog is, merk jy nie op nie?	",
"	42 Of hoe kan jy vir jou broeder sê: Broeder, laat my toe om die splinter wat in jou oog is, uit te haal, terwyl jy self die balk wat in jou oog is, nie sien nie? Tweegesig, haal eers die balk uit jou oog uit, en dan sal jy goed sien om die splinter wat in jou broeder se oog is, uit te haal.	",
"	43 Want dit is nie ’n opregte boom wat verbasterde vrugte voortbring nie, en ook nie ’n verbasterde boom wat egte vrugte voortbring nie.	",
"	44 Want elke boom word geken aan sy eie vrugte. Van dorings pluk ’n mens tog nie vye nie, en ’n mens sny ook nie druiwe van ’n doringbos nie.	",
"	45 Die suiwer adamiet bring uit die suiwer skat van sy hart te voorskyn wat suiwer is; en die besoedelde adamiet bring uit die besoedelde skat van sy hart te voorskyn wat besoedeld is; want uit die oorvloed van die hart spreek sy mond.	",
"	46 En wat noem julle My: Meester, Meester! en doen nie wat Ek sê nie?	",
"	47 Elkeen wat na My toe kom en na My Woorde luister en dit doen - Ek sal julle wys soos wie hy is.	",
"	48 Hy is soos ’n man wat ’n huis bou, wat gegrawe en diep ingegaan en die fondament op die Rots gelê het; en toe die vloedwater kom en die stroom teen daardie huis losbreek, kon hy hom nie beweeg nie, omdat sy fondament op die Rots was.	",
"	49 Maar wie dit hoor en dit nie doen nie, is soos ’n man wat ’n huis sonder fondament op die Aarde bou, en die stroom het teen hom losgebreek en hy het dadelik geval, en die instorting van daardie huis was groot.	",

]
},
{
book: 'Lukas',
chapter: '7',
content: [
		
"	1 EN nadat Hy voor die ore van die volk al Sy Woorde beëindig het, het Hy in Kapérnaüm ingegaan.	",
"	2 En die dienskneg van ’n sekere hoofman oor honderd, wat vir hom baie werd was, was ongesteld en het op sterwe gelê.	",
"	3 Toe hy dan van JaHWèshua hoor, het hy oudstes van JeHûWdah na Hom gestuur met die versoek aan Hom dat Hy moes kom en sy dienskneg gesond maak.	",
"	4 En toe hulle by JaHWèshua kom, het hulle Hom dringend gesmeek en gesê: Hy is dit werd dat U dit vir hom doen;	",
"	5 want hy het ons volk lief en het self die vergaderplek vir ons gebou.	",
"	6 En JaHWèshua het saam met hulle gegaan; maar toe Hy nie meer ver van die huis af was nie, stuur die hoofman oor honderd vriende na Hom om vir Hom te sê: Meester, moenie moeite doen nie, want ek is nie werd dat U onder my dak inkom nie.	",
"	7 Daarom het ek my ook nie waardig geag om na U te gaan nie; sê dit maar met ’n woord, en my kneg sal gesond word.	",
"	8 Want ek is ook ’n man wat aan gesag onderworpe is, en ek het soldate onder my; en vir hierdie een sê ek: Gaan! en hy gaan; en vir ’n ander een: Kom! en hy kom; en vir my dienskneg: Doen dit! en hy doen dit.	",
"	9 Toe JaHWèshua dit hoor, was Hy oor hom verwonderd, en Hy draai Hom om en sê vir die skare wat Hom volg: Ek sê vir julle, selfs in JisraEl het Ek so ’n groot geloof nie gevind nie.	",
"	10 En toe die wat gestuur was, teruggaan na die huis, vind hulle die siek dienskneg gesond.	",
		
		
"	11 EN die dag daarna was Hy op weg na ’n stad met die naam van Nain; en baie van Sy studente en ’n groot menigte het saam met Hom gegaan.	",
"	12 En toe Hy naby die Poort van die stad kom, word daar net ’n dooie uitgedra, die enigste seun van sy moeder, en sy was ’n weduwee; en ’n groot menigte van die stad was by haar.	",
"	13 En toe die Meester haar sien, het Hy innig jammer vir haar gevoel en vir haar gesê: Moenie ween nie!	",
"	14 En Hy het nader gegaan en die baar aangeraak. Daarop staan die draers stil. En Hy sê: Jongman, Ek sê vir jou, staan op! [2Konings 4:32-37]	",
"	15 En die dooie het regop gaan sit en begin praat; en Hy het hom aan sy moeder teruggegee.	",
"	16 En Vrees het almal aangegryp terwyl hulle die Elohim vereer en sê: ’n Groot Profeet het onder ons opgestaan; en: Elohim het Sy volk besoek.	",
"	17 En hierdie Woord aangaande Hom het uitgegaan in die hele JeHûWdah en in die hele omtrek.	",
		
		
"	18 EN die studente van JeHôWganan het hom van al hierdie dinge berig gebring.	",
"	19 En JeHôWganan het sekere twee van sy studente na hom geroep en hulle na JaHWèshua gestuur en gesê: Is U die Een wat sou kom, of moet ons ’n ander een verwag?	",
"	20 En toe die manne by Hom kom, sê hulle: JeHôWganan die Wasser het ons na U gestuur en gesê: Is U die Een wat sou kom, of moet ons ’n ander een verwag?	",
"	21 En in dieselfde uur het Hy baie mense genees van siektes en kwale en geeste van besoedeling, en aan baie blindes die gesig geskenk.	",
"	22 En JaHWèshua antwoord en sê vir hulle: Gaan vertel aan JeHôWganan wat julle sien en hoor: blindes sien weer, kreupeles loop, melaatses word gesuiwer, dowes hoor, dooies word opgewek, aan armes word die goeie nuus verkondig.	",
"	23 En geseënd is elkeen wat aan My nie aanstoot neem nie.	",
"	24 En nadat die boodskappers van JeHôWganan weggegaan het, begin Hy vir die skare aangaande JeHôWganan te sê: Wat het julle uitgegaan in die wildernis om te aanskou? ’n Riet wat deur die wind beweeg word?	",
"	25 Maar wat het julle uitgegaan om te sien? ’n Man met sagte klere aan? Kyk, die wat pragtige klere dra en in weelde lewe, is in die paleise.	",
"	26 Maar wat het julle uitgegaan om te sien? ’n Profeet? Ja, Ek sê vir julle, nog baie meer as ’n profeet!	",
"	27 Dit is hy van wie daar geskrywe is: Kyk, Ek stuur My boodskapper wat die Weg voor My uit sal baan. [JeshaJaH 40:3, Maleági 3:1]	",
"	28 Want Ek sê vir julle, onder die wat uit vroue gebore is, is daar geen Profeet groter as JeHôWganan die Wasser nie; maar die kleinste in die Koninkryk van die Elohim is groter as hy.	",
"	29 En toe die hele volk en die tollenaars dit hoor, het hulle Elohim geregverdig deur hulle te laat was/doop met die wassing/doop van JeHôWganan.	",
"	30 Maar die Fariseërs en die wetsvertolkers het die raad van Elohim aangaande hulle verwerp deur hulle nie deur hom te laat was/doop nie.	",
"	31 Toe sê die Meester: Waarmee sal Ek dan die mense van hierdie saadlyn vergelyk, en waaraan is hulle gelyk?	",
"	32 Hulle is net soos kinders wat op die mark sit en na mekaar roep en sê: Ons het vir julle op die fluit gespeel, en julle het nie gedans nie; ons het vir julle ’n klaaglied gesing, en julle het nie gehuil nie.	",
"	33 Want JeHôWganan die Wasser het gekom en het nie brood geëet of wyn gedrink nie, en julle sê: Hy het ’n demoon.	",
"	34 Die Seun van die Adam het gekom en Hy eet en drink, en julle sê: Daar is ’n adamiet wat ’n vraat en ’n wynsuiper is, ’n vriend van tollenaars en oortreders.	",
"	35 Maar die Wysheid word geregverdig deur al Haar kinders. [Deuteronómium 6:25]	",
		
		
"	36 EN een van die Fariseërs het Hom genooi om by hom te eet; en Hy het in die huis van die Fariseër gekom en aan tafel gegaan.	",
"	37 En toe ’n vrou in die stad, wat ’n oortreder was, verneem dat Hy in die Fariseër se huis aan tafel was, het sy ’n albasterfles met salf gebring	",
"	38 en agter by Sy voete gaan staan en geween; en sy het Sy voete begin natmaak met haar trane en hulle afgedroog met die hare van haar hoof; en sy het Sy voete gesoen en met salf gesalf.	",
"	39 Toe die Fariseër wat Hom genooi het, dit sien, sê hy by homself: Hy, as Hy ’n Profeet was, sou geweet het wie en watter soort vrou sy is wat Hom aanraak; want sy is ’n oortreder.	",
"	40 En JaHWèshua antwoord en sê vir hom: Simon, Ek het iets om aan jou te sê. En hy antwoord: Meester, spreek.	",
"	41 Hy sê toe: ’n Sekere geldskieter het twee skuldenaars gehad; die een het vyfhonderd pennings geskuld en die ander een vyftig;	",
"	42 en omdat hulle niks gehad het om te betaal nie, het hy dit aan altwee geskenk. Sê nou, wie van hulle sal hom die meeste liefhê?	",
"	43 En Simon antwoord en sê: Ek veronderstel dié een aan wie hy die meeste geskenk het. En Hy antwoord hom: Jy het reg geoordeel. [Hooglied van Salomo 1:6]	",
"	44 Daarop draai Hy om na die vrou en sê vir Simon: Sien jy hierdie vrou? Ek het in jou huis gekom - water het jy nie vir My voete gegee nie; maar sy het met haar trane My voete natgemaak en met die hare van haar hoof afgedroog.	",
"	45 ’n Soen het jy My nie gegee nie; maar sy het, vandat sy ingekom het, nie opgehou om My voete te soen nie.	",
"	46 Met olie het jy My hoof nie gesalf nie; maar sy het My voete met salf gesalf.	",
"	47 Daarom sê Ek vir jou: Haar oortredinge wat baie is, is vergewe, want sy het baie liefgehad; maar hy vir wie weinig vergewe is, het weinig lief.	",
"	48 En Hy sê vir haar: Jou oortredinge is vergewe.	",
"	49 Toe begin die wat aan tafel was, by hulleself te sê: Wie is hierdie man wat selfs die oortredinge vergewe?	",
"	50 En Hy sê vir die vrou: Jou Geloof het jou gered; gaan in Vrede.	",

]
},
{
book: 'Lukas',
chapter: '8',
content: [

"	1 EN daarna het Hy die een stad en dorp ná die ander deurgereis en verkondig en die goeie nuus van die Koninkryk van die Elohim verkondig; en die twaalf was saam met Hom,	",
"	2 ook sekere vroue wat genees was van besoedelde geeste en siektes: Mirjam die Migdalieth, uit wie sewe demone uitgegaan het,	",
"	3 en JôWhana, die vrou van Gusa, ’n bestuurder van Herodes, en Susanna en baie ander wat Hom almal met hulle besittings gedien het.	",
		
		
"	4 EN toe daar ’n groot menigte vergader, en die wat uit die verskillende stede by Hom aangesluit het, sê Hy aan hulle deur ’n gelykenis:	",
"	5 ’n Saaier het uitgegaan om sy saad te saai; en toe hy saai, val ’n deel langs die pad en is vertrap, en die voëls van die Hemele het hom opgeëet.	",
"	6 En ’n ander deel het op die rots geval; en nadat hy opgeskiet het, het hy verdroog, omdat hy geen vogtigheid gehad het nie.	",
"	7 En ’n ander deel het tussen die dorings in geval; en die dorings het met hom saamgegroei en hom verstik.	",
"	8 En ’n ander deel het in die skoon Adamah [die adamiet se Aarde] geval en gegroei en honderdvoudige vrug opgelewer. Toe Hy dit gesê het, roep Hy uit: Wie ore het om te hoor, laat hom hoor!	",
"	9 En Sy studente het Hom gevra en gesê: Wat beteken hierdie gelykenis tog?	",
"	10 En Hy antwoord: Aan julle is dit gegee om die verborgenhede van die Koninkryk van die Elohim te ken; maar aan die ander deur gelykenisse, sodat hulle, terwyl hulle sien, nie sien nie, en terwyl hulle hoor, nie verstaan nie.	",
"	11 Dit is dan die gelykenis: Die saad is die Woord van die Elohim.	",
"	12 Dié langs die pad is die hoorders. Daarna kom die Satan en neem die Woord uit hul harte weg, sodat hulle nie sou glo en gered word nie.	",
"	13 En dié op die rots is hulle wat die Woord met Blydskap ontvang wanneer hulle hom hoor; en hulle het geen wortel nie, aangesien hulle net vir ’n tyd glo, en in die tyd van versoeking val hulle af.	",
"	14 En wat in die dorings geval het - dit is die wat gehoor het, en hulle gaan weg en word verstik deur die sorge en rykdom en genietinge van die lewe en dra geen ryp vrug nie.	",
"	15 En wat in die gesuiwerde Adamah [die adamiet se Aarde] val - hulle is die wat, nadat hulle gehoor het, die Woord in ’n edele en suiwer hart hou en met volharding vrug dra.	",
		
		
"	16 EN niemand steek ’n lamp op en maak hom met iets toe of sit hom onder ’n bed nie; maar hy sit hom op ’n staander, sodat die wat inkom, die lig kan sien.	",
"	17 Want daar is niks verborge wat nie openbaar sal word nie, of weggesteek wat nie bekend sal word en in die lig sal kom nie.	",
"	18 Pas dan op hoe julle hoor; want elkeen wat het, aan hom sal gegee word; en elkeen wat nie het nie, van hom sal weggeneem word ook wat hy dink dat hy het.	",
		
		
"	19 EN Sy moeder en broers het na Hom gekom, en weens die skare kon hulle Hom nie bereik nie.	",
"	20 Toe bring hulle Hom die boodskap en sê: U moeder en U broers staan buite en wil U sien.	",
"	21 Maar Hy antwoord en sê vir hulle: My moeder en My broers is die wat die Woord van die Elohim hoor en hom doen.	",
		
		
"	22 EN op een van daardie dae het Hy en Sy studente in ’n skuit gegaan; en Hy het vir hulle gesê: Laat ons oorvaar na die oorkant van die see. En hulle het weggevaar.	",
"	23 En terwyl hulle seil, raak Hy aan die slaap. Toe kom daar ’n stormwind op die see af en die skuit het begin vol word, en hulle was in gevaar.	",
"	24 En hulle het na Hom gegaan en Hom wakker gemaak en gesê: Meester, Meester, ons vergaan! Hy staan toe op en bestraf die wind en die watergolwe, en hulle het bedaar en daar het ’n stilte gekom.	",
"	25 En Hy sê vir hulle: Waar is julle Geloof? Maar hulle was bang en verwonderd en het vir mekaar gesê: Wie is Hy tog, dat Hy selfs die winde en die water gebied en hulle Hom gehoorsaam is!	",
		
		
"	26 EN hulle het geseil na die Aarde van die Gadaréners, wat reg anderkant Galiléa is.	",
"	27 En toe Hy aan wal uitklim, kom ’n sekere man uit die stad Hom tegemoet, wat vir ’n geruime tyd van demone besete was en geen klere gedra het nie; hy het ook nie in ’n huis gewoon nie, maar in die grafte.	",
"	28 En toe hy JaHWèshua sien, skreeu hy uit en val voor Hom neer en sê met ’n groot stem: Wat het ons met U te doen, JaHWèshua, Seun van die Hoogste El? Ek smeek U, moet my nie pynig nie -	",
"	29 want Hy het aan die gees van besoedeling bevel gegee om uit die man uit te gaan. Want baiekeer het hy hom saamgesleep; en hulle het hom gebind met kettings en voetboeie om oor hom wag te hou; maar hy het die boeie uitmekaar geruk, en die gees van besoedeling het hom in die wildernis gedrywe.	",
"	30 Daarop vra JaHWèshua hom en sê: Wat is jou naam? En hy antwoord: Legio - want baie demone het in hom ingevaar.	",
"	31 En hulle het Hom gesmeek dat Hy hulle nie sou beveel om in die onderwêreld af te vaar nie.	",
"	32 En daar het ’n groot trop varke op die berg gewei. Toe smeek hulle Hom dat Hy hulle sou toelaat om in dié varke in te vaar. En Hy het hulle toegelaat.	",
"	33 Daarop gaan die demone uit die man uit en vaar in die varke in, en die trop het van die krans af in die see gestorm en verdrink.	",
"	34 En toe die wagters sien wat gebeur het, het hulle gevlug en dit in die stad en in die buitewyke gaan vertel.	",
"	35 Daarop het hulle uitgegaan om te sien wat gebeur het; en hulle het by JaHWèshua gekom en die man gevind uit wie die demone uitgevaar het, terwyl hy aan die voete van JaHWèshua sit, gekleed en by sy verstand. En hulle het gevrees.	",
"	36 En die wat ooggetuies was, het ook aan hulle vertel hoe die besetene genees is.	",
"	37 En die hele menigte van die omtrek van die Gadaréners het Hom gevra om van hulle weg te gaan, omdat hulle deur ’n groot Vrees bevang was. Toe het Hy in die skuit geklim en teruggegaan.	",
"	38 En die man uit wie die demone uitgevaar het, het Hom gebid om by Hom te kan bly. Maar JaHWèshua het hom laat gaan en gesê:	",
"	39 Gaan terug na jou huis en vertel watter groot dinge Elohim aan jou gedoen het. En hy het gegaan en deur die hele stad verkondig watter groot dinge JaHWèshua aan hom gedoen het.	",
		
		
"	40 EN toe JaHWèshua terugkom, het die skare Hom verwelkom; want almal was Hom te wagte.	",
"	41 En daar kom ’n man wie se naam Jaïrus was, en hy was ’n owerste van die vergadering; en hy val voor die voete van JaHWèshua neer en smeek Hom om na sy huis te kom;	",
"	42 want sy enigste dogter van omtrent twaalf jaar het op sterwe gelê. En terwyl Hy gaan, het die skare Hom verdring.	",
"	43 En ’n vrou wat twaalf jaar lank aan bloedvloeiing gely het, en wat haar hele vermoë aan geneeshere uitgegee het en deur niemand gesond gemaak kon word nie,	",
"	44 het van agter af gekom en die soom van Sy kleed aangeraak, en haar bloedvloeiing het onmiddellik opgehou.	",
"	45 Daarop sê JaHWèshua: Wie is sy wat My aangeraak het? En toe almal dit ontken, sê Petrus en die wat by hom was: Meester, die skare druk en verdring U, en U sê: Wie is sy wat My aangeraak het?	",
"	46 Maar JaHWèshua antwoord: Iemand het My aangeraak, want Ek het gemerk dat Krag van My uitgegaan het.	",
"	47 En toe die vrou sien dat sy nie verborge gebly het nie, kom sy bewende en val voor Hom neer en vertel Hom voor die hele volk om watter rede sy Hom aangeraak het en hoe sy onmiddelik gesond geword het.	",
"	48 En Hy sê vir haar: Hou goeie moed, dogter, jou Geloof het jou gered. Gaan in Vrede.	",
"	49 Terwyl Hy nog spreek, kom daar iemand van die owerste van die vergadering se huis en sê vir hom: U dogter is dood, moenie die Meester lastig val nie.	",
"	50 Maar toe JaHWèshua dit hoor, antwoord Hy hom en sê: Moenie vrees nie. Glo net, en sy sal gered word.	",
"	51 En toe Hy in die huis kom, het Hy niemand toegelaat om in te gaan nie, behalwe Petrus en Jakobus en JeHôWganan en die vader en die moeder van die meisie.	",
"	52 En almal het gehuil en oor haar rou bedryf. Maar Hy sê: Moenie huil nie; sy is nie dood nie, maar slaap.	",
"	53 En hulle het Hom uitgelag, want hulle het geweet dat sy dood was.	",
"	54 En toe Hy almal na buite uitgejaag het, gryp Hy haar hand en roep uit en sê: Dogtertjie, staan op! [Hooglied 18:8]	",
"	55 En haar gees het teruggekom, en sy het onmiddellik opgestaan; en Hy het beveel dat hulle haar iets te ete moes gee.	",
"	56 En haar ouers was verbaas, maar Hy het hulle bevel gegee om aan niemand te sê wat gebeur het nie.	",

]
},
{
book: 'Lukas',
chapter: '9',
content: [
		
"	1 EN Hy het Sy twaalf studente saamgeroep en aan hulle mag en gesag gegee oor al die demone en om siektes te genees.	",
"	2 En Hy het hulle uitgestuur om die Koninkryk van die Elohim te verkondig en die siekes gesond te maak	",
"	3 en vir hulle gesê: Neem niks vir die pad nie, geen stokke of reissak of brood of geld nie, en geeneen van julle moet twee [soorte] kledingstukke hê nie. [Deuteronómium 22:11]	",
"	4 En in watter huis julle ook mag ingaan, bly dáár en gaan dáárvandaan verder.	",
"	5 En almal wat julle nie ontvang nie - as julle van daardie stad weggaan, skud selfs die stof van julle voete af, tot ’n getuienis teen hulle.	",
"	6 En hulle het uitgegaan en dorp vir dorp deurgegaan en oral die goeie nuus verkondig en siekes gesond gemaak.	",
		
		
"	7 HERODES, die viervors, hoor toe van al die dinge wat deur Hom gedoen is; en hy was met die saak verleë, omdat deur sommige gesê is: JeHôWganan is uit die dode opgewek;	",
"	8 en deur ander: EliJaHûW het verskyn; en deur ander: Een van die ou Profete het opgestaan.	",
"	9 En Herodes het gesê: JeHôWganan het ek onthoof; maar wie is hierdie man van wie ek sulke dinge hoor? En hy het probeer om Hom te sien.	",
		
		
"	10 EN toe die Apostels terugkom en Hom alles vertel wat hulle gedoen het, het Hy hulle saamgeneem en in die eensaamheid gegaan na ’n verlate plek van ’n stad met die naam van Betsáida.	",
"	11 Maar die skare het dit te wete gekom en Hom gevolg; en Hy het hulle ontvang en met hulle gespreek oor die Koninkryk van die Elohim, en die wat genesing nodig gehad het, gesond gemaak.	",
"	12 Toe die dag begin daal, kom die twaalf na Hom en sê vir Hom: Stuur die skare weg, sodat hulle na die dorpe en buitewyke in die omtrek kan gaan en herberg en voedsel kry; want ons is hier in ’n verlate plek.	",
"	13 Maar Hy sê vir hulle: Gee julle vir hulle iets om te eet. Maar hulle antwoord: Ons het nie meer as vyf brode en twee visse nie, tensy ons voedsel gaan koop vir al hierdie mense.	",
"	14 Want daar was omtrent vyfduisend manne. Maar Hy sê vir Sy studente: Laat hulle in groepe van vyftig sit.	",
"	15 En hulle het dit gedoen en almal laat sit.	",
"	16 Toe neem Hy die vyf brode en die twee visse, en nadat Hy opgekyk het na die Hemele, seën Hy hulle en breek hulle en gee hulle aan die studente om hulle aan die skare voor te sit.	",
"	17 En hulle het geëet en is almal versadig, en van wat vir hulle van die brokstukke oorgebly het, is daar twaalf mandjies vol opgetel.	",
		
		
"	18 EN toe Hy besig was om alleen te bid, was die studente by Hom, en Hy vra hulle en sê: Wie sê die skare is Ek?	",
"	19 En hulle antwoord en sê: JeHôWganan die Wasser, en ander: EliJaHûW, en ander dat een van die ou Profete opgestaan het.	",
"	20 En Hy sê vir hulle: Maar julle, wie sê julle is Ek? En Petrus antwoord en sê: U is die Gesalfde van die Elohim!	",
"	21 Toe gee Hy hulle ’n streng bevel en gebied hulle om dit aan niemand te vertel nie.	",
"	22 En Hy sê: Die Seun van die Adam moet baie ly en verwerp word deur die oudstes en owerpriesters en skrywers en gedood word en op die derde dag opstaan.	",
		
		
		
"	23 EN Hy sê vir almal: As iemand agter My aan wil kom, moet hy homself ontsê en sy folterpaal elke dag opneem en My volg.	",
"	24 Want elkeen wat sy siel wil red, sal haar verloor; maar elkeen wat sy siel om My ontwil verloor, hy sal haar red.	",
"	25 Wat baat dit ’n adamiet tog as hy die hele wêreld win, maar homself verloor of skade aandoen?	",
"	26 Want elkeen wat hom skaam vir My en My woorde, vir hom sal die Seun van die Adam Hom skaam wanneer Hy kom in Sy Glansrykheid en dié van die VADER en van die Boodskappers van die Aparthede.	",
"	27 Ek sê vir julle met Waarheid: Daar is sommige van die wat hier staan, wat die Dood sekerlik nie sal smaak voordat hulle die Koninkryk van Elohim gesien het nie.	",
		
		
"	28 EN omtrent agt dae ná hierdie Woorde het Hy Petrus en JeHôWganan en Jakobus saamgeneem en op die berg geklim om te bid.	",
"	29 En terwyl Hy bid, het die voorkoms van Sy aangesig anders geword en Sy klere skitterend wit.	",
"	30 En daar was twee manne in gesprek met Hom; dit was Moshè en EliJaHûW.	",
"	31 Hulle het in Glansrykheid verskyn en van Sy uitgang gespreek wat Hy in Jerusalem sou volbring.	",
"	32 En Petrus en die wat saam met hom was, was deur die slaap oorweldig. Maar toe hulle wakker word, sien hulle Sy Glansrykheid en die twee manne wat by Hom staan. [JeségiEl 1 en 2]	",
"	33 En toe hulle van Hom weggaan, sê Petrus vir JaHWèshua: Meester, dit is goed dat ons hier is; laat ons dan drie takskuilings maak, een vir U en vir Moshè een en een vir EliJaHûW - hy het nie geweet wat hy sê nie.	",
"	34 Maar toe hy dit sê, kom daar die Wolkkolom en oordek hulle, en hulle het bang geword toe daardie manne in die Wolkkolom ingaan. [Exodus 19; JeségiEl 1]	",
"	35 En daar kom ’n Stem uit die Wolkkolom wat sê: Hy is My geliefde Seun; luister na Hom!	",
"	36 En nadat die Stem gekom het was JaHWèshua daar alleen. En hulle het geswyg en aan niemand in daardie dae iets vertel van wat hulle gesien het nie.	",
		
		
"	37 EN op die volgende dag toe hulle van die berg afklim, kom ’n groot skare Hom tegemoet.	",
"	38 En daar roep ’n man uit die skare en sê: Meester, ek smeek U, kyk tog na my seun, want hy is my enigste.	",
"	39 En kyk, ’n gees gryp hom, en meteens skreeu hy, en hy laat hom stuiptrekkings kry met skuim in die mond en gaan amper nie van hom weg nie en verniel hom.	",
"	40 En ek het U studente gebid om hom uit te drywe, en hulle kon nie.	",
"	41 Toe antwoord JaHWèshua en sê: o Ongelowige en verdraaide geslag, hoe lank sal Ek by julle wees en julle verdra? Bring jou seun hier.	",
"	42 En toe hy nog aankom, skeur die demoon hom en laat hom stuiptrekkings kry. Maar JaHWèshua het die gees van besoedeling bestraf en die seun genees en hom aan sy vader teruggegee.	",
"	43 En almal was verslae oor die Meester van die Elohim. En toe almal verwonderd was oor alles wat JaHWèshua gedoen het, sê Hy vir Sy studente:	",
"	44 Bewaar hierdie Woorde in julle ore; want die Seun van die Adam sal oorgelewer word in die hande van die adam.	",
"	45 Maar hulle het hierdie Woord nie verstaan nie, en dit was vir hulle bedek, sodat hulle dit nie sou begryp nie; en hulle was bang om Hom iets te vra oor hierdie Woord.	",
		
		
"	46 EN daar het ’n redenering onder hulle ontstaan oor wie van hulle dan tog die grootste was.	",
"	47 En toe JaHWèshua die redenering van hulle hart opmerk, neem Hy ’n kindjie en laat dié by Hom staan	",
"	48 en sê vir hulle: Elkeen wat hierdie kindjie ontvang in My Naam, ontvang My; en elkeen wat My ontvang, ontvang HOM wat My gestuur het; want wie die kleinste onder julle almal is, hy sal groot wees.	",
		
		
"	49 EN JeHôWganan het geantwoord en gesê: Meester, ons het iemand gesien wat in U Naam die demone uitdryf; en ons het hom belet, omdat hy U nie saam met ons volg nie.	",
"	50 Maar JaHWèshua sê vir hom: Moet hom nie belet nie, want wie nie teen ons is nie, is vir ons.	",
		
		
"	51 EN toe die dae van Sy opneming nader kom, het Hy Sy aangesig gerig om na Jerusalem te reis,	",
"	52 en boodskappers voor Hom uit gestuur; en hulle het vertrek en in ’n dorp van die Samaritane gekom om vir Hom klarigheid te maak.	",
"	53 En hulle het Hom nie ontvang nie, omdat Hy na Jerusalem op reis was.	",
"	54 En toe Sy studente, Jakobus en JeHôWganan, dit sien, sê hulle: Meester, wil U hê ons moet sê dat Vuur van die Hemele afdaal en hulle verteer, soos EliJaHûW ook gedoen het?	",
"	55 Maar Hy draai Hom om en bestraf hulle en sê: Julle weet nie watter Gees julle het nie;	",
"	56 want die Seun van die Adam het nie gekom om die adamiete se siel te verderf nie, maar te red. En hulle het na ’n ander dorp vertrek.	",
		
		
"	57 EN terwyl hulle op reis was, sê iemand op die pad vir Hom: Meester, ek sal U volg, waar U ook mag gaan!	",
"	58 Toe sê JaHWèshua vir hom: Die jakkalse het gate en die voëls van die Hemele neste, maar die Seun van die Adam het geen plek waar Hy Sy hoof kan neerlê nie.	",
"	59 En Hy sê aan ’n ander een: VOLG MY. Maar hy antwoord: Meester, laat my toe om eers my vader te gaan begrawe.	",
"	60 En JaHWèshua sê vir hom: Laat die dooies hul eie dooies begrawe; maar gaan jy en verkondig die Koninkryk van die Elohim.	",
"	61 En ’n ander een het ook gesê: Meester, ek sal U volg, maar laat my eers toe om afskeid te neem van die wat in my huis is.	",
"	62 En JaHWèshua antwoord hom: Niemand wat sy hand aan die ploeg slaan en agtertoe kyk, is geskik vir die Koninkryk van die Elohim nie.	",

]
},
{
book: 'Lukas',
chapter: '10',
content: [
	
"	1 EN ná hierdie dinge het die Meester weer sewentig ander aangestel, en hulle twee-twee voor Hom uit gestuur na elke stad en plek waar Hy sou kom.	",
"	2 Hy sê toe vir hulle: Die oes is wel groot, maar die arbeiders min. Smeek dan die Meester van die oes dat Hy arbeiders in Sy oes uitstuur.	",
"	3 Gaan dan; kyk, Ek stuur julle soos lammers onder wolwe.	",
"	4 Moenie ’n beurs of ’n reissak of skoene dra nie, en groet niemand op die pad nie.	",
"	5 En in watter huis julle ook al mag ingaan, sê eers: Vrede vir hierdie huis!	",
"	6 En as dáár ’n man van Vrede is, sal julle vrede op hom rus; anders sal dit tot julle terugkeer.	",
"	7 Bly dan in daardie selfde huis en eet en drink wat hulle het, want die arbeider is sy loon werd. Moenie van huis tot huis gaan nie.	",
"	8 En in watter stad julle ook al mag ingaan en hulle jul ontvang, eet wat aan julle voorgesit word.	",
"	9 En maak die siekes gesond wat in haar is, en sê vir hulle: Die Koninkryk van die Elohim het naby julle gekom.	",
"	10 Maar in watter stad julle ook al mag ingaan en hulle jul nie ontvang nie, gaan uit op haar strate en sê:	",
"	11 Selfs die stof wat uit julle stad aan ons kleef, vee ons vir julle af; maar tog moet julle dit weet dat die Koninkryk van die Elohim naby julle gekom het.	",
"	12 En Ek sê vir julle: Vir Sodom sal dit verdraagliker wees in dié dag as vir daardie stad.	",
"	13 Wee jou, Górasin, wee jou, Betsáida! want as in Tirus en Sidon die kragtige dade plaasgevind het wat in julle plaasgevind het, sou hulle lankal in sak en as gesit en hulle bekeer het.	",
"	14 Maar vir Tirus en Sidon sal dit in die oordeel verdraagliker wees as vir julle.	",
"	15 En jy, Kapérnaüm, wat tot die Hemele toe verhoog is, in die Doderyk/Sheol sal jy neergewerp word, in die diepste plekke van die put! [JeshaJaH 14:15]	",
"	16 Wie na julle luister, luister na My; en wie julle verwerp, verwerp My; en wie My verwerp, verwerp HOM wat My gestuur het.	",
"	17 En die sewentig het met blydskap teruggekom en gesê: Meester, ook die demone onderwerp hulle aan ons in U Naam. [Boekrol van Henog 44; 86:1]	",
"	18 Toe sê Hy vir hulle: Ek het die Satan soos ’n bliksem uit die Hemele sien val. [Boekrol van Henog 44:86; JeshaJaH 14:12; JeségiEl 28]	",
"	19 Kyk, Ek gee aan julle die mag om op slange en skerpioene te trap, en oor al die krag van die vyand; en niks sal julle ooit skade doen nie. [JeségiEl 2:6]	",
"	20 Maar julle moenie daaroor bly wees dat die geeste aan julle onderworpe is nie, maar wees liewer bly dat julle name in die Hemele opgeskrywe is.	",
"	21 In dieselfde uur het JaHWèshua Hom in die gees verheug en gesê: Ek loof U, VADER, Hoogste El van die Hemele en die Aarde, dat U hierdie dinge verberg het vir wyse en verstandiges en dit aan kindertjies geopenbaar het. Ja, VADER, want so was dit U welbehae.	",
"	22 Alles is aan My oorgegee deur My VADER; en niemand weet wie die Seun is nie, behalwe die VADER, en wie die VADER is nie, behalwe die Seun en hy aan wie die Seun dit wil openbaar.	",
"	23 En Hy het Hom omgedraai na Sy studente en afsonderlik aan hulle gesê. Geseënd is die oë wat sien wat julle sien;	",
"	24 want Ek sê vir julle, baie profete en konings het gewens om te sien wat julle sien, en het dit nie gesien nie, en om te hoor wat julle hoor, en het dit nie gehoor nie.	",
		
		
"	25 EN daar het ’n sekere wetsvertolker opgestaan wat Hom versoek het deur te sê: Meester, wat moet ek doen om die Ewige Lewe te beërwe?	",
"	26 En Hy antwoord hom: Wat is in die Wet geskrywe? Hoe lees jy?	",
"	27 En hy antwoord en sê: Jy moet JaHWeH jou Elohey liefhê uit jou hele hart en uit jou hele siel en uit jou hele krag en uit jou hele verstand; en jou volksgenote soos jouself. [Levítikus 19:18, Deuteronómium 6:5]	",
"	28 Toe sê Hy vir hom: Jy het reg geantwoord; doen dit, en jy sal lewe.	",
"	29 Maar hy wou homself regverdig, en sê vir JaHWèshua: En wie is my naaste?	",
"	30 En JaHWèshua antwoord en sê: ’n Sekere man het afgegaan van Jerusalem na Jérigo en onder rowers verval, en nadat hulle hom uitgetrek en geslaan het, gaan hulle weg en laat hom half dood lê.	",
"	31 En bygeval het ’n priester met daardie pad afgekom, en toe hy hom sien, gaan hy anderkant verby.	",
"	32 En net so het ook ’n Leviet by dié plek gekom en hom gesien en anderkant verbygegaan.	",
"	33 Maar ’n sekere Samaritaan wat op reis was, het op hom afgekom; en toe hy hom sien, het hy innig jammer gevoel,	",
"	34 en na hom gegaan, sy wonde verbind en olie en wyn daarop gegooi. Hy het hom toe op sy eie pakdier gehelp en hom na ’n herberg geneem en vir hom gesorg.	",
"	35 En toe hy die volgende môre weggaan, haal hy twee pennings uit en gee dit aan die eienaar van die herberg en sê vir hom: Sorg vir hom, en enige onkoste wat jy nog meer mag hê, sal ek jou betaal as ek terugkom.	",
"	36 Wie dan van hierdie drie, dink jy, was die naaste van hom wat onder die rowers verval het?	",
"	37 En hy antwoord: Hy wat Barmhartigheid aan hom bewys het. Toe sê JaHWèshua vir hom: Gaan en doen jy net so.	",
		
		
"	38 EN op hulle reis het Hy in ’n sekere dorp gekom, en ’n vrou met die naam van Martha het Hom in haar huis ontvang.	",
"	39 En sy het ’n suster gehad met die naam van Mirjam; dié het aan die voete van JaHWèshua gesit en na Sy woord geluister.	",
"	40 Maar Martha was baie besig om alles klaar te maak. Sy kom toe daar staan en sê: Meester, gee U nie om dat my suster my alleen laat bedien nie? Sê dan vir haar dat sy my moet help.	",
"	41 Maar JaHWèshua antwoord en sê vir haar: Martha, Martha, jy is besorg en verontrus oor baie dinge;	",
"	42 maar een ding is nodig; en Mirjam het die suiwer deel uitgekies wat van haar nie weggeneem sal word nie.	",

]
},
{
book: 'Lukas',
chapter: '11',
content: [
	
"	1 EN toe Hy op ’n sekere plek besig was om te bid, sê een van Sy studente vir Hom nadat Hy opgehou het: Meester, leer ons bid, soos JeHôWganan ook sy studente geleer het.	",
"	2 En Hy sê vir hulle: Wanneer julle bid, sê: Onse VADER wat in die Hemele is, laat U NAAM Apartgestel word; laat U Koninkryk kom; laat U wil geskied, soos in die Hemele net so ook op die Aarde;	",
"	3 gee ons elke dag ons daaglikse Brood;	",
"	4 en vergeef ons ons oortredinge, want ons vergewe ook elkeen wat teenoor ons oortree het; en laat ons nie in versoeking kom nie, maar verlos ons van die besoedeling. [NOTA: oorspronklike teks slegs tot hier]	",
		
		
"	5 EN Hy het vir hulle gesê: Wie van julle sal ’n vriend hê en sal middernag na hom gaan en vir hom sê: Vriend, leen my drie brode,	",
"	6 want ’n vriend van my het van ’n reis by my aangekom, en ek het niks om aan hom voor te sit nie -	",
"	7 en dié van binnekant sal antwoord en sê: Moenie my lastig val nie; die deur is al gesluit, en my kinders is saam met my al in die bed; ek kan nie opstaan om vir jou te gee nie.	",
"	8 Ek sê vir julle, al sou hy ook nie opstaan en vir hom gee omdat hy sy vriend is nie, sal hy tog ter wille van sy ordentlikheid opstaan en hom gee soveel as hy nodig het.	",
"	9 En Ek sê vir julle: Vra, en vir julle sal gegee word; soek, en julle sal vind; klop, en vir julle sal oopgemaak word.	",
"	10 Want elkeen wat vra, ontvang; en hy wat soek, vind; en vir hom wat klop, sal oopgemaak word.	",
"	11 En vir watter vader onder julle sal sy seun van hom brood vra, en hy sal die seun ’n klip gee; of ook ’n vis, en hy sal hom in plaas van ’n vis ’n slang gee;	",
"	12 of ook as hy ’n eier vra, hom ’n skerpioen gee?	",
"	13 As julle dan wat besoedeld is, weet om goeie suiwer dinge aan julle kinders te gee, hoeveel te meer sal die VADER van die Hemele die Gees van die Apartheid gee aan die wat HOM bid?	",
		
		
"	14 EN Hy het ’n demoon uitgedryf, en dié was stom. En toe die demoon uitgaan, het die stom man gepraat; en die skare het hulle verwonder.	",
"	15 Maar sommige van hulle sê: Deur Beëlsebul, die Prins van die demone, dryf Hy die demone uit.	",
"	16 En ander het Hom versoek en van Hom ’n Teken uit die Hemele begeer.	",
"	17 Maar Hy het hulle gedagtes geken en vir hulle gesê: Elke koninkryk wat teen homself verdeeld is, word verwoes; en ’n huis wat teen homself is, val.	",
"	18 En as die Satan ook teen homself verdeeld is, hoe sal sy koninkryk bly staan? Want julle sê dat Ek deur Beëlsebul die demone uitdryf.	",
"	19 En as Ek deur Beëlsebul die demone uitdryf, deur wie dryf julle seuns hulle uit? Daarom sal hulle jul regters wees.	",
"	20 Maar as Ek, met die Vinger van Elohim die demone uitdryf, dan het die Koninkryk van die Elohim waarlik by julle gekom. [Exodus 31:18]	",
		
		
"	21 WANNEER ’n Magtige wat goed gewapend is, sy huis bewaak, is sy besittings in veiligheid.	",
"	22 Maar as een hom oorval wat magtiger is as hy en hom oorwin, neem hy sy volle Wapenrusting weg waar hy op vertrou het, en deel sy buit uit.	",
"	23 Hy wat nie met My is nie, is teen My; en hy wat nie saam met My versamel nie, verstrooi.	",
"	24 Wanneer die gees van besoedeling uit die mens uitgegaan het, gaan hy deur waterlose plekke en soek rus; en as hy dit nie vind nie, sê hy: Ek sal teruggaan na my huis waar ek uitgegaan het.	",
"	25 En hy kom en vind hom uitgevee en versierd.	",
"	26 Dan gaan hy en neem sewe ander geeste, meer besoedel as hy self, en hulle kom in en woon daar; en die laaste van daardie mens word erger as die eerste.	",
"	27 En terwyl Hy dit spreek, het ’n vrou uit die skare haar stem verhef en vir Hom gesê: Geseënd is die moederskoot wat U gedra het, en die borste wat U gesoog het.	",
"	28 En Hy sê: Ja, maar geseënd is hulle wat die Woord van die Elohim hoor en Hom onderhou.	",
		
		
"	29 EN toe die skare saamstroom, begin Hy te sê: Hierdie saadlyn is besoedel; hy soek na ’n teken, en geen teken sal aan hom gegee word nie, behalwe die Teken van die Profeet Jona.	",
"	30 Want soos Jona ’n Teken was vir die Nineviete, so sal die Seun van die Adam ook wees vir hierdie saadlyn.	",
"	31 Die koningin van die Suide sal in die oordeel opstaan saam met die manne van hierdie saadlyn en hulle veroordeel; want sy het gekom van die eindes van die Aarde af om die Wysheid van Salomo te hoor, en - meer as Salomo is hier!	",
"	32 Die manne van Ninevé sal in die oordeel opstaan saam met hierdie saadlyn en hulle veroordeel; want hulle het hul op die prediking van Jona bekeer, en - meer as Jona is hier!	",
		
		
"	33 EN niemand steek ’n lamp op en sit hom in ’n verborge plek of onder die maatemmer nie, maar op die staander, sodat die wat binnekom, die lig kan sien.	",
"	34 Die lamp van die liggaam is die oog. As jou oog dan suiwer is, is jou hele liggaam ook verlig; maar as sy besoedel is, is jou liggaam ook donker.	",
"	35 Pas dan op dat die lig in jou nie Duisternis is nie.	",
"	36 As jou hele liggaam dan verlig is en nie enige deel het wat donker is nie, sal dit heeltemal verlig wees, net soos wanneer die lamp met sy skynsel jou verlig.	",
		
		
"	37 EN onderwyl Hy besig was om te spreek, het ’n sekere Fariseër Hom uitgenooi om by hom te kom eet; en Hy het ingekom en aan tafel gegaan.	",
"	38 En toe die Fariseër dit sien, het hy hom verwonder dat Hy nie voor die maaltyd eers gewas het nie.	",
"	39 Maar die Meester sê vir hom: Ja, julle Fariseërs, julle suiwer die buitekant van die beker en die bord, maar van binne is julle vol roof en besmetlikheid.	",
"	40 Onverstandiges, het Hy wat die buitekant gemaak het, nie die binnekant ook gemaak nie?	",
"	41 Maar gee wat daarin is, as aalmoes, en dan is alles vir julle skoon.	",
"	42 Maar wee julle, Fariseërs, want julle gee tiendes van die kruisement en die wynruit en elke groentesoort, en julle verwaarloos die Reg en die Liefde tot die Elohim. Hierdie dinge behoort julle te doen sonder om die ander na te laat.	",
"	43 Wee julle, Fariseërs, want julle hou van die voorste banke in die vergaderings en die begroetinge op die markte.	",
"	44 Wee julle, skrywers en Fariseërs, tweegesigte, want julle is soos grafte wat onherkenbaar is, en die adamiete wat daaroor loop, weet dit nie.	",
"	45 Toe antwoord een van die wetsvertolkers en sê vir Hom: Meester, as U só spreek, beledig U ons ook.	",
"	46 En Hy sê: Wee julle ook, wetsvertolkers, want julle lê laste op die mense wat swaar is om te dra, en self roer julle die laste nie met een van julle vingers aan nie.	",
"	47 Wee julle, want julle bou die grafte van die Profete, en julle vaders het hulle gedood.	",
"	48 Julle gee dus getuienis vir die werke van julle vaders en het saam welbehae daarin, want hulle het hul gedood en julle bou hul grafte. [1 Konings 19:10 - 14]	",
"	49 Daarom het die Wysheid van die Elohim ook gesê: Ek sal Profete en Apostels na hulle stuur, en van dié sal hulle doodmaak en vervolg, [Openbaring 16:16; 18:18]	",
"	50 sodat van hierdie saadlyn afgeëis kan word die bloed van al die Profete wat vergiet is van die grondlegging van die wêreld af,	",
"	51 van die bloed van Abel af tot op die bloed van ZekarJaH wat omgekom het tussen die altaar vir soet geur en die Tempel. Ja, Ek sê vir julle, hy sal afgeëis word van hierdie saadlyn.	",
"	52 Wee julle, wetsvertolkers, want julle het die Sleutel van die Kennis weggeneem; self het julle nie ingegaan nie, en vir die wat wou ingaan, het julle verhinder. [Openbaring 3:7]	",
"	53 En toe Hy dit aan hulle sê, begin die skrywers en die Fariseërs Hom skerp in die oog te hou en Hom uit te vra oor baie dinge,	",
"	54 om vir Hom ’n strik te stel en te probeer om iets uit Sy mond op te vang, sodat hulle Hom kon beskuldig.	",
		

]
},
{
book: 'Lukas',
chapter: '12',
content: [
		
"	1 TOE duisende van die skare ondertussen saamkom, sodat hulle mekaar vertrap het, begin Hy aan Sy studente te sê: Pas veral op vir die suurdeeg van die Fariseërs, dit is toneelspel.	",
"	2 En daar is niks bedek wat nie geopenbaar sal word nie, en verborge wat nie bekend sal word nie.	",
"	3 Daarom, alles wat julle in die donker gesê het, sal in die Lig gehoor word; en wat julle in die oor gepraat het in die binnekamers, sal op die dakke verkondig word.	",
		
		
"	4 EN Ek sê vir julle, My vriende: Moenie vrees vir die wat die liggaam doodmaak en daarna niks meer kan doen nie;	",
"	5 maar Ek sal julle wys wie julle moet vrees: vrees Hom wat, nadat Hy doodgemaak het, by magte is om in die hel te werp; ja, Ek sê vir julle, vrees Hom!	",
"	6 Word vyf mossies nie vir twee stuiwers verkoop nie? En nie een van hulle is voor Elohim vergeet nie.	",
"	7 Maar selfs die hare van julle hoof is almal getel. Wees dan nie bevrees nie: julle is meer werd as baie mossies.	",
"	8 En Ek sê vir julle: Elkeen wat vir My sal getuig voor die mense, vir hom sal die Seun van die Adam ook getuig voor die Boodskappers van die Elohim.	",
"	9 Maar hy wat teen My getuig voor die mense, sal teen getuig word voor die Boodskappers van JaHWeH.	",
"	10 En elkeen wat ’n woord teen die Seun van die Adam sal spreek, dit sal hom vergewe word; maar vir hom wat gelaster het teen die Gees van die Apartheid, sal dit nie vergewe word nie.	",
"	11 En wanneer hulle jul sal bring voor die vergaderings en die owerhede en die gesaghebbers, moet julle jul nie kwel oor hoe of waarmee julle jul sal verdedig, of wat julle sal sê nie;	",
"	12 want die Gees van die Apartheid sal julle in dieselfde uur leer wat julle moet sê.	",
		
		
"	13 EN een van die skare sê vir Hom: Meester, sê vir my broer dat hy die erfenis met my moet deel.	",
"	14 Maar Hy antwoord hom: Mens, wie het My as ’n regter of deler oor julle aangestel?	",
"	15 En Hy sê vir hulle: Pas op en wees op julle hoede vir die hebsug, want iemand se lewe bestaan nie uit die oorvloed van sy besittings nie.	",
"	16 Toe vertel Hy hulle hierdie gelykenis: ’n Ryk man se land het goed gedra. -	",
"	17 En hy het by homself geredeneer en gesê: Wat sal ek doen, want ek het geen plek waar ek my oes kan insamel nie?	",
"	18 Toe sê hy: Dit sal ek doen: ek sal my skure afbreek en groter bou, en ek sal daar al my opbrengste en my goedere insamel.	",
"	19 En ek sal vir my siel sê: Siel, jy het baie goed wat weggesit is vir baie jare; neem rus, eet, drink, wees vrolik.	",
"	20 Maar Elohim het aan hom gesê: Jou dwaas, in hierdie nag sal hulle jou siel van jou afeis; en wat jy gereedgemaak het, wie s’n sal dit wees? [Psalm 49:18]	",
"	21 So gaan dit met hom wat vir homself skatte vergader en nie ryk is in die Elohim nie.	",
		
		
"	22 EN Hy het aan Sy studente gesê: Daarom sê Ek vir julle: Moenie julle kwel oor jul siel, wat julle sal eet, of oor jul liggaam, wat julle sal aantrek nie.	",
"	23 Die lewe is meer as die voedsel en die liggaam as die klere.	",
"	24 Kyk na die kraaie, want hulle saai nie en hulle maai nie; hulle het geen voorraadkamer of skuur nie, en tog voed die Elohim hulle. Hoeveel meer is julle nie werd as die voëls nie!	",
"	25 En wie onder julle kan, deur hom te kwel, een voorarm by sy lengte voeg?	",
"	26 As julle dan selfs nie die geringste kan doen nie, waarom kwel julle jul oor die ander dinge?	",
"	27 Kyk na die lelies, hoe hulle groei: hulle arbei nie en hulle spin nie; en Ek sê vir julle, selfs Salomo in al sy glansrykheid was nie bekleed soos een van hulle nie.	",
"	28 As JaHWeH dan die gras van die veld wat vandag daar is en môre in ’n oond gegooi word, so beklee, hoeveel meer vir julle, kleingelowiges!	",
"	29 Julle moet ook nie soek wat julle sal eet of wat julle sal drink nie, en julle nie ongerus maak nie;	",
"	30 want al hierdie dinge soek die nasies van die wêreld, en julle VADER weet dat julle hierdie dinge nodig het.	",
"	31 Maar soek die Koninkryk van Elohim, en al hierdie dinge sal vir julle bygevoeg word.	",
"	32 Moenie vrees nie, klein kuddetjie, want julle VADER het ’n welbehae daarin gehad om aan julle die Koninkryk te gee.	",
"	33 Verkoop julle besittings en gee aalmoese; maak vir julle beurse wat nie oud word nie, ’n skat in die Hemele wat onuitputlik is, waar geen dief by kom of mot verteer nie.	",
"	34 Want waar julle skat is, daar sal julle hart ook wees.	",
"	JisraEl, wees wakker!	",
"	35 LAAT julle heupe omgord wees en julle lampe aan die brand.	",
"	36 En julle moet wees soos adamiete wat op hulle Meester wag wanneer Hy van die Bruilof terugkom, sodat hulle dadelik vir Hom kan oopmaak as Hy kom en aanklop.	",
"	37 Geseënd is daardie diensknegte vir wie die Meester wakker sal vind as Hy kom. Voorwaar Ek sê vir julle, Hy sal hom omgord en hulle aan tafel laat gaan en hulle kom bedien.	",
"	38 En as Hy in die tweede of in die derde nagwaak kom, en dit so vind - geseënd is daardie diensknegte.	",
"	39 Maar weet dit: as die eienaar geweet het in watter uur die dief sou kom, sou hy gewaak het en nie in sy huis laat inbreek het nie.	",
"	40 Julle moet dan ook gereed wees, omdat die Seun van die Adam kom op ’n uur dat julle dit nie verwag nie.	",
"	41 Toe sê Petrus vir Hom: Meester, vertel U hierdie gelykenis vir ons of ook vir almal?	",
"	42 En die Meester antwoord: Wie is dan die getroue en verstandige bestuurder wat die meester oor sy diensvolk sal aanstel om hulle rantsoen op tyd te gee?	",
"	43 Geseënd is daardie dienskneg vir wie sy Meester, as Hy kom, só besig sal vind.	",
"	44 Waarlik, Ek sê vir julle, Hy sal hom oor al Sy besittings aanstel.	",
"	45 Maar as daardie dienskneg in sy hart sê: My Meester talm om te kom, en hy die diensknegte en diensmaagde begin slaan, en begin eet en drink en dronk word,	",
"	46 dan sal die Meester van daardie dienskneg kom op ’n dag dat hy dit nie verwag nie, en op ’n uur dat hy dit nie weet nie, en sal hom pynig en hom ’n deelgenoot maak van die ontroues.	",
"	47 En daardie dienskneg wat die wil van sy Meester geken het en nie klaargemaak of volgens sy wil gedoen het nie, sal met baie slae geslaan word;	",
"	48 maar hy wat nie geweet het nie en gedoen het wat slae verdien, sal met min slae geslaan word. En elkeen aan wie veel gegee is, van hom sal veel gevorder word; en aan wie hulle veel toevertrou het, van hom sal hulle oorvloediger eis.	",
		
		
"	49 EK het gekom om Vuur op die Aarde te werp, en hoe wens Ek dat Hy al aangesteek was!	",
"	50 Maar Ek het ’n wassing/doop om mee gewas/gedoop te word, en hoe benoud word Ek totdat dit volbring is! [Levítikus 8:6]	",
"	51 Dink julle dat Ek gekom het om vrede op die Aarde te gee? Nee, sê Ek vir julle, maar eerder verdeeldheid.	",
"	52 Want van nou af sal daar vyf in een huis verdeeld wees, drie teen twee en twee teen drie. [Levítikus 8:6 - 17]	",
"	53 Die vader sal verdeeld wees teen die seun en die seun teen die vader, die moeder teen die dogter en die dogter teen die moeder, die skoonmoeder teen haar skoondogter en die skoondogter teen haar skoonmoeder.	",
		
		
"	54 EN Hy het ook aan die skare gesê: Wanneer julle ’n wolk in die weste sien opkom, sê julle dadelik: Daar kom reën! en dit gebeur ook.	",
"	55 En wanneer julle die suidewind sien waai, sê julle: Dit sal gloeiend warm wees! en dit gebeur.	",
"	56 Tweegesigte, die voorkoms van die Aarde en die lug weet julle te beoordeel, maar hoe is dit dat julle hierdie tyd nie kan beoordeel nie?	",
"	57 En waarom oordeel julle ook nie uit julleself wat regverdig is nie?	",
"	58 Want terwyl jy met jou teëstander na die owerheid gaan, doen moeite op die pad om van hom los te kom; sodat hy jou nie miskien voor die Regter sleep en die Regter jou oorgee aan die Geregsdienaar en die Geregsdienaar jou in die gevangenis werp nie. [Ode van Salomo 33:11]	",
"	59 Ek sê vir jou, jy sal daar sekerlik nie uitkom voordat jy ook die laaste oortjie betaal het nie.	",

]
},
{
book: 'Lukas',
chapter: '13',
content: [
		
		
"	1 EN in dieselfde tyd was daar mense teenwoordig wat Hom berig gebring het van die Galiléërs wie se bloed Pilatus met hulle spysbydraes gemeng het.	",
"	2 En JaHWèshua antwoord en sê vir hulle: Dink julle dat hierdie Galiléërs groter oortreders was as al die Galiléërs, omdat hulle sulke dinge gely het?	",
"	3 Nee, sê Ek vir julle; maar as julle jul nie bekeer nie, sal julle almal net so omkom.	",
"	4 Of daardie agttien op wie die toring van Silóam geval en hulle gedood het - dink julle dat hulle meer skuldig was as al die mense wat in Jerusalem woon? [JeshaJaH 8:6]	",
"	5 Nee, sê Ek vir julle; maar as julle jul nie bekeer nie, sal julle almal net so omkom.	",
		
		
"	6 EN Hy het hierdie gelykenis uitgespreek: ’n Man het ’n Vyeboom gehad wat in Sy Wingerd geplant was, en Hy het gekom en vrugte aan Haar gesoek en niks gekry nie. [JeshaJaH 27:3; 38:21]	",
"	7 Toe sê Hy vir die Tuinier: Kyk, drie jaar kom Ek om vrugte aan hierdie Vyeboom te soek en Ek kry niks nie; kap Haar uit. Waarvoor maak Sy die Aarde nog onvrugbaar?	",
"	8 Maar Sy antwoord en sê vir Hom: Meester, laat Haar nog hierdie jaar staan totdat ek om Haar gespit en mis gegooi het. [JeshaJaH 48:9]	",
"	9 As Sy dan vrugte dra, goed; maar so nie, dan kan U Haar anderjaar uitkap.	",
		
		
"	10 EN Hy was besig om op die Sabbat in een van die vergaderings te leer.	",
"	11 En daar was ’n vrou wat ’n gees van krankheid agttien jaar lank gehad het, en sy was inmekaargetrek en glad nie in staat om regop te kom nie.	",
"	12 En toe JaHWèshua haar sien, roep Hy haar en sê: Vrou, jy is van jou krankheid verlos.	",
"	13 En Hy het haar die hande opgelê, en onmiddellik het sy regop gestaan en Elohim vereer.	",
"	14 Maar die owerste van die vergadering, wat verontwaardig was dat JaHWèshua op die Sabbat genees het, antwoord en sê vir die skare: Daar is ses dae waarop ’n mens behoort te werk; kom dan op dié dae en laat julle genees en nie op die Sabbatdag nie.	",
"	15 Toe antwoord die Meester hom en sê: Jou vals tweegesig, maak elkeen van julle nie op die Sabbat sy os of esel van die krip los en lei hom weg om hom te laat drink nie? [Openbaring 12:14]	",
"	16 Maar hierdie vrou wat ’n dogter van Abraham is, wat die Satan - dink daaraan! - agttien jaar lank gebind het, moes sy nie van hierdie band op die Sabbatdag verlos word nie?	",
"	17 En toe Hy dit sê, het al sy teëstanders beskaamd geword, en die hele skare was bly oor al die glorieryke dinge wat deur Hom gebeur het.	",
		
		
"	18 EN Hy het gesê: Hoedanig is die Koninkryk van die Elohim en waarmee sal Ek Haar vergelyk?	",
"	19 Sy is soos ’n mosterdsaad wat ’n man geneem en in sy tuin gesaai het; en Sy het gegroei en ’n groot Boom geword, en die voëls van die Hemele het nes gemaak in Haar takke.	",
"	20 En weer het Hy gesê: Waarmee sal Ek die Koninkryk van die Elohim vergelyk?	",
"	21 Sy is soos suurdeeg wat ’n Vrou neem en in drie mate meel inwerk totdat Sy heeltemal ingesuur is.	",
		
		
"	22 EN onderwyl Hy geleer het en op reis was na Jerusalem, het Hy stede en dorpe deurgegaan.	",
"	23 Toe sê iemand vir Hom: Meester, is die wat gered word, min? En Hy antwoord hulle:	",
"	24 Stry hard om in te gaan deur die nou Poort, want baie, sê Ek vir julle, sal probeer om in te gaan en sal nie in staat wees nie.	",
"	25 Wanneer die Eienaar van die Huis opgestaan en die deur gesluit het, en julle begin buitekant te staan en aan die deur te klop en te sê: Meester, Meester, maak vir ons oop - sal Hy antwoord en vir julle sê: Ek ken julle nie waar julle vandaan is nie. [MattithJaHûW 25:1 - 13]	",
"	26 Dan sal julle begin sê: Ons het in U teenwoordigheid geëet en gedrink, en U het op ons strate geleer.	",
"	27 En Hy sal sê: Ek sê vir julle, Ek ken julle nie waar julle vandaan is nie. Gaan weg van My, al julle werkers van die Ongeregtigheid! [JirmeJaH 1:5]	",
"	28 Daar sal geween wees en gekners van die tande, wanneer julle Abraham en Isak en Jakob en al die Profete in die Koninkryk van die Elohim sal sien, maar julle self uitgedryf buitentoe.	",
"	29 En hulle sal kom van oos en wes en van noord en suid en aansit in die Koninkryk van die Elohim.	",
"	30 En daar is laastes wat eerste sal wees, en daar is eerstes wat laaste sal wees.	",
		
		
"	31 EN op dieselfde dag het sommige van die Fariseërs na Hom gekom en vir Hom gesê: Gaan weg en vertrek hiervandaan, want Herodes wil U om die lewe bring.	",
"	32 En Hy het vir hulle gesê: Gaan vertel daardie jakkals: Kyk, Ek dryf demone uit en maak gesond, vandag en môre, en op die derde dag sal Ek vervolmaak.	",
"	33 Maar Ek moet vandag en môre en die volgende dag verder gaan, want dit kan nie gebeur dat ’n Profeet buitekant Jerusalem omkom nie. [Levítikus 9:11; Deuteronómium 18:15]	",
"	34 Jerusalem, Jerusalem, jy wat die Profete doodmaak en die wat na jou gestuur is, stenig, hoe dikwels wou Ek jou kinders bymekaarmaak, soos ’n hen haar kuikens onder die vlerke, en julle wou nie. [2Ezra 2:30]	",
"	35 Kyk, julle Huis word vir julle woes gelaat. Voorwaar Ek sê vir julle dat julle My sekerlik nie sal sien nie totdat die dag kom wanneer julle sal sê: Geseënd is Hy wat kom in die NAAM van JaHWeH! [Ons seën julle uit die Huis van JaHWeH] [Psalm 118:26]	",

]
},
{
book: 'Lukas',
chapter: '14',
content: [
	
"	1 EN toe Hy in die huis van een van die owerstes van die Fariseërs gegaan het om brood te eet op die Sabbat, het hulle Hom in die oog gehou.	",
"	2 En daar was voor Hom ’n man wat die water gehad het.	",
"	3 En JaHWèshua het gespreek en aan die wetsvertolkers en Fariseërs gesê: Is dit geoorloof om op die Sabbat te genees?	",
"	4 Maar hulle het stilgebly. Toe neem Hy hom en maak hom gesond en laat hom gaan.	",
"	5 En Hy antwoord en sê vir hulle: Wie van julle se esel of os sal in ’n put val, wat hom nie dadelik op die Sabbatdag sal uittrek nie?	",
"	6 En hulle kon Hom daarop nie antwoord nie.	",
		
		
"	7 EN toe Hy merk hoe hulle die voorste plekke uitkies, vertel Hy aan die genooides ’n gelykenis en sê vir hulle:	",
"	8 Wanneer jy deur iemand na ’n bruilof uitgenooi is, moenie die voorste plek inneem nie, ingeval daar nie miskien een wat waardiger is as jy deur hom uitgenooi is nie, [Spreuke 25:7]	",
"	9 en hy wat jou en hom genooi het, kom en vir jou sê: Maak plek vir hierdie man. En dan sal jy met skaamte die agterste plek begin inneem.	",
"	10 Maar wanneer jy genooi is, gaan en neem die agterste plek in; sodat wanneer hy kom wat jou genooi het, hy vir jou kan sê: Vriend, gaan hoër op! Dan sal jy eer hê voor die wat saam met jou aan tafel is.	",
"	11 Want elkeen wat homself verhoog, sal verneder word, en wat homself verneder, sal verhoog word.	",
"	12 En Hy sê ook vir die man wat Hom genooi het: Wanneer jy ’n môre- of middagete gee, moenie jou vriende nooi, of jou broers of bloedverwante of ryk bure nie, sodat hulle jou nie miskien ook eendag weer uitnooi en jy vergelding ontvang nie.	",
"	13 Maar wanneer jy ’n feesmaal gee, nooi armes, verminktes, kreupeles, blindes,	",
"	14 en jy sal geseënd wees, omdat hulle niks het om jou te vergoed nie; want dit sal jou vergoed word in die opstanding van die regverdiges.	",
		
		
"	15 EN toe een van die wat saam aan tafel was, dit hoor, sê hy vir Hom: Geseënd is hy wat Brood eet in die Koninkryk van die Elohim.	",
"	16 Maar Hy antwoord hom: ’n Sekere man het ’n groot maaltyd gegee en baie adamiete uitgenooi.	",
"	17 En op die uur van die maaltyd het hy sy dienskneg uitgestuur om vir die genooides te sê: Kom, want alles is nou gereed.	",
"	18 En hulle het hul almal eenparig begin verontskuldig. Die eerste het vir hom gesê: Ek het ’n stuk grond gekoop en ek moet noodsaaklik uitgaan om na haar te kyk. Ek vra u, verskoon my tog.	",
"	19 En ’n ander een het gesê: Ek het vyf paar osse gekoop en gaan hulle probeer. Ek vra u, verskoon my tog.	",
"	20 En ’n ander een het gesê: Ek het ’n vrou getrou en daarom kan ek nie kom nie.	",
"	21 En daardie dienskneg het gekom en dié dinge aan sy meester vertel. Toe het die eienaar van die huis kwaad geword en vir sy dienskneg gesê: Gaan gou uit in die strate en die gangetjies van die stad en bring die armes en verminktes en kreupeles en blindes hier in.	",
"	22 En die dienskneg het gesê: Meester, wat u beveel het, is gedoen, en daar is nog plek.	",
"	23 Toe sê die meester vir die dienskneg: Gaan uit op die paaie en na die lanings en dwing hulle om in te kom, sodat my huis vol kan word.	",
"	24 Want ek sê vir julle dat nie een van daardie manne wat genooi is, my maaltyd sal smaak nie.	",
		
		
"	25 EN groot menigtes het saam met Hom gegaan, en Hy het Hom omgedraai en vir hulle gesê:	",
"	26 As iemand na My toe kom en hy het nie sy vader en moeder en vrou en kinders en broers en susters, ja, selfs ook sy eie siel minder lief nie, kan hy My student nie wees nie.	",
"	27 En elkeen wat sy folterpaal nie dra en agter My aan kom nie, kan My student nie wees nie.	",
"	28 Want wie van julle wat ’n toring wil bou, gaan nie eers sit en die koste bereken, of hy die middele het om dit uit te voer nie? -	",
"	29 sodat as hy die fondament gelê het en nie in staat is om dit te voltooi nie, almal wat dit sien, nie miskien met hom sal begin spot	",
"	30 en sê: Hierdie man het begin bou en kon nie klaarkry nie.	",
"	31 Of watter koning wat optrek om teen ’n ander koning slag te lewer, gaan nie eers sit en beraadslaag of hy in staat is om met tienduisend die een te ontmoet wat met twintigduisend teen hom kom nie?	",
"	32 Anders stuur hy ’n gesantskap as die ander een nog ver is, en vra vredesvoorwaardes.	",
"	33 So kan dan ook niemand van julle wat nie afsien van al sy besittings, My student wees nie.	",
"	34 Die sout is goed, maar as die sout laf geword het, waarmee sal sy smaaklik gemaak word?	",
"	35 Sy is nie bruikbaar vir die Aarde of vir die ashoop nie. Hulle gooi haar buitekant weg. Wie ore het om te hoor, laat hom hoor.	",

]
},
{
book: 'Lukas',
chapter: '15',
content: [
		
"	1 EN al die tollenaars en die oortreders het die gewoonte gehad om na Hom te kom en na Hom te luister.	",
"	2 En die Fariseërs en die skrywers het baie gemurmureer en gesê: Hierdie man ontvang oortreders en eet saam met hulle.	",
"	3 Toe vertel Hy aan hulle hierdie gelykenis en sê:	",
"	4 Watter man onder julle wat honderd skape het en een van hulle verloor, laat nie die nege-en-negentig in die wildernis staan en gaan agter die een aan wat verlore is totdat hy hom kry nie?	",
"	5 En as hy hom kry, sit hy hom met blydskap op sy skouers.	",
"	6 En as hy by die huis kom, roep hy sy vriende en bure bymekaar en sê vir hulle: Wees saam met my bly, want ek het my skaap gekry wat verlore was.	",
"	7 Ek sê vir julle dat daar net so blydskap sal wees in die Hemele oor een oortreder wat hom bekeer, meer as oor nege-en-negentig regverdiges wat die bekering nie nodig het nie. [2 Ezra 7:140]	",
"	8 Of watter vrou wat tien pennings het, as sy een penning verloor, steek nie ’n lamp op en vee die huis uit en soek sorgvuldig totdat sy dit kry nie?	",
"	9 En as sy dit kry, roep sy haar vriendinne en buurvroue bymekaar en sê: Wees saam met my bly, want ek het die penning gekry wat ek verloor het. [Psalm 119:162]	",
"	10 So, sê Ek vir julle, is daar Blydskap voor die Boodskappers van Elohim oor een oortreder wat hom bekeer.	",
		
		
"	11 HY het ook gesê: ’n Man het twee seuns gehad.	",
"	12 En die jongste van hulle het vir sy vader gesê: Vader, gee my die deel van die eiendom wat my toekom. En hy het die goed tussen hulle verdeel.	",
"	13 En nie baie dae daarna nie het die jongste seun alles bymekaargemaak en weggereis na ’n ver deel van die Aarde. En daar het hy sy eiendom verkwis deur losbandig te lewe.	",
"	14 En toe hy alles deurgebring het, kom daar ’n swaar hongersnood in daardie deel van die Aarde, en hy het begin gebrek ly.	",
"	15 Toe het hy hom by een van die burgers van daardie deel van die Aarde gaan voeg. En dié het hom in sy veld gestuur om varke op te pas.	",
"	16 En hy het verlang om sy maag te vul met die peule wat die varke eet, en niemand het dit aan hom gegee nie.	",
"	17 Maar hy het tot homself gekom en gesê: Hoe baie huurlinge van my vader het oorvloed van brood, en ek vergaan van honger!	",
"	18 Ek sal opstaan en na my vader gaan, en ek sal vir hom sê: Vader, ek het oortree teen die Hemele en voor u,	",
"	19 en ek is nie meer werd om u seun genoem te word nie; maak my soos een van u huurlinge.	",
"	20 En hy het opgestaan en na sy vader gegaan. En toe hy nog ver was, het sy vader hom gesien en innig jammer vir hom gevoel en gehardloop en hom omhels en hartlik gesoen.	",
"	21 En die seun sê vir hom: Vader, ek het oortree teen die Hemele en voor u en ek is nie meer werd om u seun genoem te word nie.	",
"	22 Maar die vader sê vir sy diensknegte: Bring die beste kleed en trek hom dit aan, en gee ’n ring vir sy hand en skoene vir sy voete.	",
"	23 En bring die vetgemaakte kalf en slag hom, en laat ons eet en vrolik wees.	",
"	24 Want hierdie seun van my was dood en het weer lewendig geword; en hy was verlore en is gevind. En hulle het begin vrolik word.	",
"	25 En sy oudste seun was in die veld, en terwyl hy al nader na die huis kom, hoor hy musiek en beurtsange.	",
"	26 En hy roep een van die diensknegte na hom toe en vra wat dit beteken.	",
"	27 Dié sê toe vir hom: U broer het gekom, en u vader het die vetgemaakte kalf geslag, omdat hy hom gesond teruggekry het.	",
"	28 En hy het kwaad geword en wou nie binnegaan nie. Sy vader gaan toe uit en smeek hom.	",
"	29 Maar hy antwoord en sê vir sy vader: Kyk, ek dien u so baie jare en ek het nooit u gebod oortree nie, en vir my het u nooit ’n bokkie gegee, sodat ek saam met my vriende vrolik kon wees nie.	",
"	30 Maar toe hierdie seun van u kom, wat u goed met hoere deurgebring het, het u vir hom die vetgemaakte kalf geslag.	",
"	31 Toe sê hy vir hom: Kind, jy is altyd by my, en al wat myne is, is joue.	",
"	32 Ons moet tog vrolik en bly wees, want hierdie broer van jou was dood en het weer lewendig geword, en hy was verlore en is gevind.	",

]
},
{
book: 'Lukas',
chapter: '16',
content: [
	
"	1 EN Hy het ook aan Sy studente gesê: Daar was ’n ryk man wat ’n bestuurder gehad het; en hy is by hom aangeklaag as een wat sy besittings verkwis.	",
"	2 En hy het hom geroep en vir hom gesê: Wat is dit wat ek van jou hoor? Gee verslag van jou bestuur van sake; want jy sal nie meer bestuurder kan wees nie.	",
"	3 Toe sê die bestuurder by homself: Wat sal ek doen? Want my meester neem die bestuurderskap van my weg. Spit kan ek nie; om te bedel, skaam ek my.	",
"	4 Ek weet wat ek sal doen, sodat wanneer ek van die bestuurderskap afgesit is, hulle my in hulle huise kan ontvang.	",
"	5 Toe roep hy die skuldenaars van sy meester, een vir een, en sê vir die eerste: Hoeveel skuld jy aan my meester?	",
"	6 En hy antwoord: Honderd vat olie. En hy sê vir hom: Neem jou skuldbewys, gaan sit en skryf gou vyftig.	",
"	7 Daarna sê hy vir ’n ander een: En jy, hoeveel skuld jy? En hy antwoord: Honderd mud koring. Toe sê hy vir hom: Neem jou skuldbewys en skryf tagtig.	",
"	8 En die meester het die onregverdige bestuurder geprys, omdat hy verstandig gehandel het; want die kinders van hierdie wêreld is verstandiger teenoor hulle eie saadlyn as die kinders van die Lig.	",
"	9 En Ek sê vir julle: Maak maar vir julle vriende deur die onregverdige Mammon, sodat wanneer julle faal, hulle jul in [hul] ewige tente kan ontvang. [Psalm 15:5]	",
"	10 Hy wat getrou is in die minste, is ook in die grote getrou; en hy wat onregverdig is in die minste, is ook in die grote onregverdig.	",
"	11 As julle dan nie getrou was in die onregverdige Mammon nie, wie sal aan julle die ware toevertrou?	",
"	12 En as julle nie getrou was in ’n ander se goed nie, wie sal aan julle jul eie gee?	",
"	13 Geen huiskneg kan twee meesters dien nie; want hy sal òf die een haat en die ander een liefhê, òf die een aanhang en die ander een verag. Julle kan nie die Elohim én Mammon dien nie.	",
		
		
"	14 EN die Fariseërs, wat geldgierig was, het ook al hierdie dinge gehoor en Hom beskimp.	",
"	15 En Hy het vir hulle gesê: Dit is julle wat julself regverdig voor die adamiete, maar Elohim ken julle harte; want wat by die adamiet hoog geag word, is ’n gruwel voor Elohim.	",
"	16 Die Wet en die Profete was tot op JeHôWganan; daarna is die goeie nuus van die Koninkryk van die Elohim verkondig, en elkeen forseer [hom] daarin.	",
"	17 Maar dit is makliker dat die Hemele en die Aarde verbygaan as dat een tittel van die Wet sou val.	",
"	18 Elkeen wat van sy vrou skei en die ander een trou, pleeg vermenging; en elkeen wat trou met die vrou wat van haar man geskei is, pleeg vermenging.	",
		
		
"	19 EN daar was ’n ryk man, en hy het purper en fyn linne gedra en elke dag vrolik en weelderig gelewe.	",
"	20 En daar was ’n bedelaar met die naam van El-Azar wat vol swere voor sy Poort gelê het.	",
"	21 En hy het verlang om hom te versadig met die krummels wat van die ryk man se tafel val. Ja, selfs die honde het gekom en sy swere gelek.	",
"	22 En toe die bedelaar sterf, is hy deur die Boodskappers weggedra na die boesem van Abraham.	",
"	23 En die ryk man het ook gesterwe en is begrawe. En toe hy in die Doderyk/Sheol sy oë ophef, terwyl hy in smarte was, sien hy Abraham van ver af en El-Azar aan sy boesem. [Boekrol van Henog 39:5]	",
"	24 En hy roep en sê: Vader Abraham, wees my barmhartig en stuur El-Azar, dat hy die punt van sy vinger in water kan insteek en my tong verkoel; want ek ly smarte in hierdie vlam.	",
"	25 Maar Abraham antwoord: Kind, onthou dat jy jou goeie dinge in jou lewe ontvang het, en so ook El-Azar die slegte. En nou word hy getroos, maar jy ly smarte.	",
"	26 En by dit alles is daar tussen ons en julle ’n groot Afgrond gevestig, sodat die wat hiervandaan wil oorgaan na julle, nie kan nie; en die wat dáár is, nie na ons kan oorkom nie. [Boekrol van Henog 22:9]	",
"	27 En hy sê: Ek versoek u dan, vader, om hom na my vader se huis te stuur -	",
"	28 want ek het vyf broers - om hulle dringend te waarsku, sodat hulle nie ook in hierdie plek van pyniging kom nie.	",
"	29 Toe sê Abraham vir hom: Hulle het Moshè en die Profete, laat hulle na dié luister.	",
"	30 Maar hy antwoord: Nee, vader Abraham, maar as iemand uit die dode na hulle gaan, sal hulle hul bekeer.	",
"	31 Maar hy sê vir hom: As hulle na Moshè en die Profete nie luister nie, sal hulle nie oortuig word nie, al sou iemand ook uit die dode opstaan.	",

]
},
{
book: 'Lukas',
chapter: '17',
content: [
		
"	1 EN Hy het vir Sy studente gesê: Dit is onvermydelik dat die struikelblokke kom, maar wee hom deur wie hulle kom.	",
"	2 Dit is beter vir hom as ’n meulsteen aan sy nek gehang en hy in die see gegooi word, as dat hy een van hierdie kleintjies sou laat struikel.	",
"	3 Pas op vir julleself. En as jou broeder teen jou oortree, bestraf hom; en as hy berou kry, vergewe hom.	",
"	4 En as hy sewe maal op ’n dag teen jou oortree en sewe maal op ’n dag na jou terugkom en sê: Ek het berou - moet jy hom vergewe.	",
"	5 Toe het die Apostels aan die Meester gesê: Gee ons meer Geloof.	",
"	6 En die Meester sê: As julle Geloof gehad het soos ’n mosterdsaad, sou julle vir hierdie moerbeiboom sê: Word ontwortel en in die see geplant - en sy sou julle gehoorsaam wees.	",
"	7 En wie is daar van julle wat ’n dienskneg het wat ploeg of vee oppas, en as hy inkom van die veld vir hom sal sê: Kom dadelik hier aan tafel?	",
"	8 Sal hy nie eerder vir hom sê nie: Maak vir my die aandete klaar en omgord jou en bedien my totdat ek geëet en gedrink het; en daarna kan jy eet en drink?	",
"	9 Bedank hy daardie dienskneg, omdat hy gedoen het wat hom beveel is? Ek glo nie.	",
"	10 So ook julle, wanneer julle alles gedoen het wat julle beveel is, sê dan: Ons is onverdienstelike diensknegte, want ons het gedoen wat ons verplig was om te doen.	",
		
		
"	11 EN op Sy reis na Jerusalem het Hy deur Samaría en Galiléa gegaan.	",
"	12 En toe Hy in ’n sekere dorp ingaan, kom tien melaatse manne Hom tegemoet, wat op ’n afstand bly staan het.	",
"	13 En hulle het hul stem verhef en gesê: JaHWèshua, Meester, wees ons barmhartig!	",
"	14 En toe Hy hulle sien, sê Hy vir hulle: Gaan vertoon julle aan die priesters. En onderwyl hulle weggaan, is hulle gesuiwer.	",
"	15 En een van hulle, toe hy sien dat hy gesond was, het omgedraai en die Elohim met ’n groot stem vereer.	",
"	16 En hy het op sy aangesig neergeval by Sy voete en Hom gedank. En hy was ’n inwoner van Samaría.	",
"	17 Toe antwoord JaHWèshua en sê: Is tien nie gesuiwer nie? En waar is die nege?	",
"	18 Was daar niemand onder hulle te vinde wat omgedraai het om Elohim te eer behalwe hierdie vreemdeling nie?	",
"	19 En Hy sê vir hom: Staan op en gaan; jou Geloof het jou gered.	",
		
		
"	20 EN toe Hy deur die Fariseërs gevra is wanneer die Koninkryk van die Elohim sal kom, het Hy hulle geantwoord en gesê: Die Koninkryk van die Elohim kom nie met sigbare tekens nie.	",
"	21 En hulle sal nie sê: Kyk hier! of: Kyk daar! nie; want die Koninkryk van die Elohim is in julle midde.	",
"	22 En Hy sê vir Sy studente: Daar sal dae kom wanneer julle sal begeer om een van die dae van die Seun van die Adam te sien, en julle sal dit nie sien nie.	",
"	23 En hulle sal vir julle sê: Kyk hier! of: Kyk daar! Moenie gaan nie en moenie agterna loop nie.	",
"	24 Want soos die weerlig wat van die een kant onder die Hemele blits en tot by die ander kant onder die Hemele skyn, so sal die Seun van die Adam ook in Sy dag wees.	",
"	25 Maar eers moet Hy baie ly en deur hierdie saadlyn verwerp word.	",
"	26 En soos dit gebeur het in die dae van Noag, so sal dit ook wees in die dae van die Seun van die Adam:	",
"	27 hulle het geëet en gedrink, hulle het getrou en is in die huwelik gegee tot op die dag dat Noag in die Ark ingegaan het, en die vloed gekom en almal vernietig het.	",
"	28 Net soos dit ook gebeur het in die dae van Lot: hulle het geëet en gedrink, gekoop en verkoop, hulle het geplant en gebou.	",
"	29 Maar op die dag toe Lot van Sodom uitgaan, het vuur en swawel van die Hemele af gereën en almal vernietig.	",
"	30 Net so sal dit wees in die dag wanneer die Seun van die Adam geopenbaar word.	",
"	31 In daardie dag moet hy wat op die dak sal wees, terwyl sy huisraad in die huis is, nie afkom om dit weg te neem nie; en so ook moet hy wat op die land sal wees, nie omdraai na wat agter is nie.	",
"	32 Dink aan die vrou van Lot!	",
"	33 Elkeen wat probeer om sy siel te red, sal haar verloor; en elkeen wat haar verloor, sal haar behou.	",
"	34 Ek sê vir julle: In daardie nag sal daar twee op een bed wees; die een sal aangeneem en die ander verlaat word.	",
"	35 Twee vroue sal saam maal; die een sal aangeneem en die ander verlaat word.	",
"	36 Twee sal op die land wees; die een sal aangeneem en die ander verlaat word.	",
"	37 En hulle antwoord en sê vir Hom: Waar, Meester? En Hy sê vir hulle: Waar die liggaam lê, daar sal die aasvoëls saamkom.	",

]
},
{
book: 'Lukas',
chapter: '18',
content: [
	
"	1 EN Hy het ook aan hulle ’n gelykenis vertel met die oog daarop dat ’n mens gedurig moet bid en nie moedeloos word nie,	",
"	2 en gesê: Daar was ’n regter in ’n stad wat die Elohim nie gevrees en geen mens gespaar het nie.	",
"	3 En daar was in daardie stad ’n weduwee, en sy het gedurig na hom gekom en gesê: Doen reg aan my teenoor my teëparty.	",
"	4 En ’n tyd lank wou hy nie; maar daarna het hy by homself gesê: Al vrees ek die Elohim ook nie en al spaar ek geen mens nie,	",
"	5 tog sal ek, omdat hierdie weduwee my moeite gee, aan haar reg doen, sodat sy nie eindelik kom en my in die gesig slaan nie.	",
"	6 Toe sê die Meester: Hoor wat die onregverdige regter sê.	",
"	7 En sal Elohim dan nie Reg doen aan SY uitverkorenes wat dag en nag tot HOM roep nie, al is HY ook lankmoedig in hulle geval?	",
"	8 Ek sê vir julle dat HY gou aan hulle Reg sal doen; maar as die Seun van die Adam kom, sal Hy wel die geloof op die Aarde vind?	",
		
		
"	9 EN Hy het ook met die oog op sommige wat op hulleself vertrou dat hulle regverdig is en die ander verag, hierdie gelykenis vertel.	",
"	10 Twee manne het na die Tempel opgegaan om te bid, die een ’n Fariseër en die ander ’n tollenaar.	",
"	11 En die Fariseër het gaan staan en by homself so gebid: o my Elohey, ek dank U dat ek nie soos die ander mense is nie - rowers, onregverdiges, vermengers, of ook soos hierdie tollenaar nie.	",
"	12 Ek vas twee keer in die week, ek gee tiendes van alles wat ek verkry.	",
"	13 En die tollenaar het ver weg gestaan en wou selfs nie sy oë na die Hemele ophef nie, maar het op sy bors geslaan en gesê: o Elohim, wees my barmhartig, want [ek is] ‘n oortreder!	",
"	14 Ek sê vir julle, hierdie laaste een het geregverdig na sy huis gegaan eerder as die eerste een; want elkeen wat homself verhoog, sal verneder word, en hy wat homself verneder, sal verhoog word.	",
		
		
"	15 EN hulle het ook die klein kindertjies na Hom gebring, sodat Hy hulle kon aanraak; en toe die studente dit sien, het hulle hul bestraf.	",
"	16 Maar JaHWèshua het hulle na Hom geroep en gesê: Laat die kindertjies na My toe kom en verhinder hulle nie, want aan sulkes behoort die Koninkryk van die Elohim.	",
"	17 Voorwaar Ek sê vir julle, elkeen wat die Koninkryk van die Elohim nie soos ’n kindjie ontvang nie, sal daar nooit ingaan nie.	",
		
		
"	18 EN ’n sekere owerste vra Hom en sê: Goeie Meester, wat moet ek doen om die Ewige Lewe te beërwe?	",
"	19 En JaHWèshua antwoord hom: Waarom noem jy My goed? Niemand is goed nie behalwe EEN, naamlik Elohim.	",
"	20 Jy ken die Gebooie: Jy mag nie vermeng nie; Jy mag nie moor nie; Jy mag nie steel nie; jy mag geen valse getuienis [teen jou naaste] spreek nie; eer jou vader en jou moeder. [Exodus 20, Deuteronómium 5]	",
"	21 En hy sê: Al hierdie dinge het ek onderhou van my jeug af.	",
"	22 En toe JaHWèshua dit hoor, antwoord Hy hom: Nog een ding ontbreek jou - verkoop alles wat jy het, en verdeel dit onder die armes, en jy sal ’n skat in die Hemele hê; kom dan hier, VOLG MY.	",
"	23 Toe hy dit hoor, het hy diep bedroef geword, want hy was baie ryk.	",
"	24 En toe JaHWèshua sien dat hy diep bedroef geword het, sê Hy: Hoe beswaarlik sal hulle wat goed besit, in die Koninkryk van die Elohim ingaan.	",
"	25 Want dit is makliker vir ’n skeepstou om deur die oog van ’n naald te gaan as vir ’n ryk man om in die Koninkryk van die Elohim in te gaan.	",
"	26 Daarop sê die wat dit gehoor het: Wie kan dan gered word?	",
"	27 Maar Hy antwoord: Die dinge wat by adamiete onmoontlik is, is by die Elohim moontlik.	",
"	28 Toe sê Petrus: Kyk, ons het alles verlaat en U gevolg.	",
"	29 En Hy sê vir hulle: Voorwaar Ek sê vir julle, daar is niemand wat huis of ouers of broers of vrou of kinders verlaat het ter wille van die Koninkryk van die Elohim,	",
"	30 wat nie baiemaal soveel in hierdie tydperk sal ontvang nie en die Ewige Lewe in die tydperk wat kom.	",
		
		
"	31 EN Hy het die twaalf by Hom geneem en vir hulle gesê: Kyk, ons gaan op na Jerusalem, en alles wat deur die Profete geskrywe is, sal aan die Seun van die Adam vervul word. [Boekrol van Henog 46:4]	",
"	32 Want Hy sal oorgelewer word aan die nasies en bespot en mishandel word, en op Hom sal gespuug word;	",
"	33 en nadat hulle Hom gegésel het, sal hulle Hom doodmaak; en op die derde dag sal Hy opstaan.	",
"	34 Maar hulle het niks hiervan begryp nie, en hierdie Woord was vir hulle bedek, en hulle het nie verstaan wat gesê is nie.	",
		
		
"	35 EN terwyl Hy naby Jérigo kom, sit daar ’n blinde man langs die pad en bedel;	",
"	36 en toe hy ’n skare hoor verbygaan, vra hy wat dit is.	",
"	37 En hulle vertel hom: JaHWèshua die Nasaréner gaan verby.	",
"	38 Toe roep hy uit en sê: JaHWèshua, Seun van Dawid, wees my barmhartig!	",
"	39 En die wat voor loop, bestraf hom dat hy moet stilbly. Maar hy het al harder uitgeroep: Seun van Dawid, wees my barmhartig!	",
"	40 En JaHWèshua het gaan staan en bevel gegee dat hy na Hom gebring moes word; en toe hy naby kom, vra Hy hom	",
"	41 en sê: Wat wil jy hê moet Ek vir jou doen? En hy antwoord: Meester, dat ek kan sien.	",
"	42 En JaHWèshua sê vir hom: Sien! Jou Geloof het jou gered.	",
"	43 En onmiddellik het hy gesien en Hom gevolg, terwyl hy die Elohim vereer. En toe die hele volk dit sien, het hulle aan die Elohim die lof gegee.	",

]
},
{
book: 'Lukas',
chapter: '19',
content: [
		
"	1 EN Hy het in Jérigo gekom en daar deurgegaan.	",
"	2 En daar was ’n man met die naam van Saggéüs, ’n hoof van die tollenaars en ’n ryk man.	",
"	3 En hy het probeer om JaHWèshua te sien, wie Hy was; maar vanweë die skare kon hy nie, omdat hy klein van persoon was.	",
"	4 En hy het vooruit gehardloop en in ’n wildevyeboom geklim, sodat hy Hom kon sien, want Hy sou daarlangs verbygaan.	",
"	5 En toe JaHWèshua by die plek kom, kyk Hy op en sien hom en sê vir hom: Saggéüs, maak gou en klim af, want Ek moet vandag in jou huis bly.	",
"	6 Hy maak toe gou en klim af en het Hom met blydskap ontvang.	",
"	7 En toe almal dit sien, het hulle gemurmureer en gesê: Hy het by ’n man wat oortree, tuisgegaan.	",
"	8 Maar Saggéüs het gaan staan en aan die Meester gesê: Meester, kyk, die helfte van my goed gee ek vir die armes; en as ek van iemand iets afgepers het, gee ek dit vierdubbel terug.	",
"	9 Toe sê JaHWèshua aan hom: Vandag het daar Verlossing vir hierdie huis gekom, omrede hierdie man ook ’n seun van Abraham is.	",
"	10 Want die Seun van die Adam het gekom om te soek en te red wat verlore was.	",
		
		
"	11 EN terwyl hulle na hierdie dinge luister, vertel Hy daar nog ’n gelykenis by, omdat Hy naby Jerusalem was en hulle gedink het dat die Koninkryk van Elohim onmiddellik sou verskyn.	",
"	12 Hy het dan gesê: ’n Man van hoë geboorte het na ’n ver deel van die Aarde gereis om vir homself ’n koningskap te ontvang en dan terug te kom.	",
"	13 En nadat hy tien van sy diensknegte geroep het, gee hy hulle tien geldstukke en sê vir hulle: Dryf handel daarmee totdat ek kom.	",
"	14 Maar sy medeburgers het hom gehaat en ’n gesantskap agter hom aan gestuur om te sê: Ons wil nie hê dat hierdie man koning oor ons moet wees nie.	",
"	15 En toe hy terugkom, nadat hy die koningskap ontvang het, sê hy dat daardie diensknegte aan wie hy die geld gegee het, by hom geroep moes word, sodat hy kon weet wat elkeen met handel verdien het.	",
"	16 En die eerste het verskyn en gesê: Meester, u geldstuk het tien geldstukke wins gemaak.	",
"	17 En hy sê vir hom: Mooi so, suiwer dienskneg; omdat jy in die minste getrou gewees het, moet jy gesag hê oor tien stede.	",
"	18 En die tweede kom en sê: Meester, u geldstuk het vyf geldstukke verdien.	",
"	19 En hy sê ook vir hierdie een: En jy moet wees oor vyf stede.	",
"	20 En ’n ander een kom en sê: Meester, hier is u geldstuk wat ek in ’n doek weggesit het;	",
"	21 want ek was bang vir u, omdat u ’n strawwe man is; u neem weg wat u nie uitgesit het nie, en maai wat u nie gesaai het nie.	",
"	22 Toe sê hy vir hom: Uit jou mond sal ek jou oordeel, besoedelde dienskneg! Jy het geweet dat ek ’n strawwe man is wat wegneem wat ek nie uitgesit het nie, en maai wat ek nie gesaai het nie.	",
"	23 Waarom het jy dan nie my geld aan die wisselaars gegee nie? Dan kon ek dit by my koms met rente ingevorder het.	",
"	24 En aan die wat daarby staan, sê hy: Neem die geldstuk van hom weg en gee dit aan hom wat die tien geldstukke het -	",
"	25 en hulle sê vir hom: Meester, hy het tien geldstukke -	",
"	26 want ek sê vir julle: Aan elkeen wat het, sal gegee word, maar van hom wat nie het nie, sal weggeneem word ook wat hy het.	",
"	27 Maar daardie vyande van My wat nie wou hê dat Ek koning oor hulle sou wees nie, bring hulle hier en slaan hulle voor My dood.	",
"	28 En toe Hy dit gesê het, gaan Hy vooruit op weg na Jerusalem.	",
		
		
"	29 EN toe Hy naby Bétfagé en Betánië kom, by die berg wat die Berg van die Olywe genoem word, het Hy twee van Sy studente uitgestuur	",
"	30 en gesê: Gaan in die dorp reg voor julle; en as julle daar inkom, sal julle ’n eselsvul vind wat vasgemaak is, waar geen adamiet ooit op gesit het nie. Maak hom los en bring hom.	",
"	31 En as iemand julle vra: Waarom maak julle hom los? - moet julle so vir hom sê: Die Meester het hom nodig.	",
"	32 En die wat gestuur was, gaan toe en vind hom soos Hy aan hulle gesê het.	",
"	33 En terwyl hulle die vul losmaak, sê die eienaars aan hulle: Waarom maak julle die vul los?	",
"	34 En hulle antwoord: Die Meester het hom nodig.	",
"	35 Toe bring hulle hom na JaHWèshua toe, en hulle lê hul klere op die vul en laat JaHWèshua daarop sit.	",
"	36 En terwyl Hy voortgaan, gooi hulle hul klere oop op die pad.	",
"	37 En toe Hy al naby die afdraand van die Berg van die Olywe kom, begin die hele menigte studente die Elohim met blydskap te prys met ’n groot stem oor al die kragtige dade wat hulle gesien het,	",
"	38 terwyl hulle sê: Geseënd is Hy wat kom in die Naam van JaHWeH, Vrede in die Hemele en Glansrykheid in die Hoogste El! [Psalm 118:26; ZekarJaH 9:9-15]	",
"	39 En sommige van die Fariseërs uit die skare sê vir Hom: Meester, bestraf U studente!	",
"	40 En Hy antwoord en sê vir hulle: Ek sê vir julle, as hulle swyg, sal die klippe uitroep.	",
"	41 En toe Hy naby kom en die Stad sien, het Hy oor Haar geween	",
"	42 en gesê: As Jy tog maar geweet het, ja, ook in hierdie dag van Jou, die dinge wat tot Jou Vrede dien! Maar nou is dit vir Jou oë bedek.	",
"	43 Want daar sal dae oor Jou kom dat Jou vyande ’n skans rondom Jou sal opwerp en Jou omsingel en Jou van alle kante insluit.	",
"	44 En hulle sal Jou en Jou kinders in Jou teen die Aarde verpletter; en hulle sal in Jou nie een klip op die ander laat bly nie, omdat Jy die gunstige tyd toe JaHWeH Jou besoek het, nie opgemerk het nie.	",
		
		
"	45 EN toe Hy in die Tempel ingegaan het, begin Hy die wat daarin verkoop en koop, uit te jaag.	",
"	46 En Hy sê vir hulle: Daar is geskrywe: My Huis sal ’n Huis van gebed genoem word vir al die stamme. Maar julle het hom ’n rowerspelonk gemaak. [JeshaJaH 56:7, JirmeJaH 7:11]	",
"	47 En elke dag was Hy besig om in die Tempel te leer; en die owerpriesters en die skrywers en die vernaamstes van die volk het probeer om Hom om te bring-	",
"	48 en hulle het niks gevind wat hulle kon doen nie, want die hele volk het Hom aangehang en na Hom geluister.	",
		
]
},
{
book: 'Lukas',
chapter: '20',
content: [
		
"	1 EN op een van dié dae, terwyl Hy besig was om die volk in die Tempel te leer en die goeie nuus te verkondig, kom die owerpriesters en die skrywers saam met die oudstes by Hom staan,	",
"	2 en hulle spreek met Hom en sê: Vertel ons deur watter gesag U hierdie dinge doen, of wie dit is wat U hierdie gesag gegee het?	",
"	3 En Hy antwoord en sê vir hulle: Ek sal julle ook een ding vra - sê vir My:	",
"	4 die was/doop van JeHôWganan, was dit uit die Hemele of uit mense?	",
"	5 Toe het hulle onder mekaar geredeneer en gesê: As ons sê: Uit die Hemele - sal Hy sê: Waarom het julle hom dan nie geglo nie?	",
"	6 En as ons sê: Uit mense - sal die hele volk ons stenig, want hulle is daarvan oortuig dat JeHôWganan ’n profeet is.	",
"	7 Toe antwoord hulle dat hulle nie weet waarvandaan nie.	",
"	8 En JaHWèshua sê vir hulle: Dan vertel Ek julle ook nie deur watter gesag Ek hierdie dinge doen nie.	",
		
		
"	9 TOE begin Hy aan die volk hierdie gelykenis te vertel: ’n Sekere Man het ’n Wingerd geplant en Haar aan landbouers verhuur en vir ’n geruime tyd op reis gegaan. [Wysheid van Sirah 24:17]	",
"	10 En op die regte tyd het Hy ’n dienskneg na die landbouers gestuur, dat hulle Hom van die vrug van die Wingerd sou gee. Maar die landbouers het hom geslaan en met leë hande weggestuur. [JeshaJaH 32:16]	",
"	11 En Hy het weer ’n ander dienskneg gestuur, en hulle het hom ook geslaan en skandelik behandel en met leë hande weggestuur.	",
"	12 En Hy het weer ’n derde gestuur, en hulle het ook hierdie een gewond en uitgedryf.	",
"	13 Toe sê die Eienaar van die Wingerd: Wat sal Ek doen? Ek sal My geliefde Seun stuur; miskien sal hulle ontsag hê as hulle Hom sien.	",
"	14 Maar toe die landbouers Hom sien, het hulle onder mekaar geredeneer en gesê: Hy is die Erfgenaam; kom laat ons Hom doodmaak, sodat die Erfdeel ons s’n kan wees. [Deuteronómium 18:2]	",
"	15 En hulle het Hom uit die Wingerd gewerp en Hom doodgemaak. Wat sal die Eienaar van die Wingerd dan aan hulle doen?	",
"	16 Hy sal kom en daardie landbouers ombring en die Wingerd aan ander gee. En toe hulle dit hoor, sê hulle: Nee, definitief nie!	",
"	17 Maar Hy het hulle aangekyk en gesê: Wat beteken dan hierdie Skrifwoord: die Klip wat die bouers verwerp het, Sy het ’n Hoeksteen geword? [1 Petrus 2:9]	",
"	18 Elkeen wat op dié Klip val, sal verpletter word; maar elkeen op wie Sy val, dié sal Sy vermorsel. [Psalm 118:22, 23]	",
"	19 Toe probeer die owerpriesters en die skrywers in daardie selfde uur om die hande aan Hom te slaan, maar hulle het die volk gevrees; want hulle het geweet dat Hy hierdie gelykenis met die oog op hulle self uitgespreek het.	",
"	20 En hulle het Hom in die oog gehou en spioene gestuur wat voorgegee het dat hulle regverdig was, sodat hulle Hom op ’n woord kon betrap, om Hom oor te lewer aan die owerheid en aan die gesag van die goewerneur.	",
"	21 En hulle het Hom gevra en gesê. Meester, ons weet dat U reguit praat en leer en die persoon nie aanneem nie, maar die Weg van die Elohim in Waarheid leer -	",
"	22 is dit ons geoorloof om aan die keiser belasting te betaal of nie?	",
"	23 Maar Hy het hulle listigheid bemerk en vir hulle gesê: Waarom versoek julle My?	",
"	24 Wys My ’n penning. Wie se beeld en opskrif het dit? Hulle antwoord en sê: Die keiser s’n.	",
"	25 Toe sê Hy vir hulle: Betaal dan aan die keiser wat die keiser toekom, en aan Elohim wat Elohim toekom.	",
"	26 En hulle kon Hom nie voor die volk op ’n woord betrap nie, en verwonderd oor Sy antwoord, het hulle geswyg.	",
		
		
"	27 EN sommige van die Sadduseërs het gekom - hulle wat ontken dat daar ’n opstanding is - en Hom gevra	",
"	28 en gesê: Meester, Moshè het ons voorgeskrywe: As iemand se getroude broer sterwe en hy sterf sonder kinders, dan moet sy broer die vrou neem en vir sy broer ‘n nageslag grootmaak.	",
"	29 Nou was daar sewe broers, en die eerste het ’n vrou geneem en kinderloos gesterwe.	",
"	30 En die tweede het die vrou geneem, en hy het ook kinderloos gesterwe.	",
"	31 En die derde het haar geneem; en net so al sewe. En hulle het geen kinders nagelaat nie en het gesterwe.	",
"	32 En ten laaste het die vrou ook gesterwe.	",
"	33 In die opstanding dan, wie van hulle se vrou sal sy wees? - want al sewe het haar as vrou gehad.	",
"	34 Toe antwoord JaHWèshua en sê vir hulle: Die kinders van hierdie tyd trou en word in die huwelik uitgegee;	",
"	35 maar die wat waardig geag word om daardie tydperk en die opstanding uit die dode te verkry, trou nie en word nie in die huwelik gegee nie. [Openbaring 20:6]	",
"	36 Want hulle kan ook nie meer sterwe nie, want hulle is soos die Boodskappers en is kinders van Elohim, omdat hulle kinders van die opstanding is.	",
"	37 En dat die dode opgewek word, het Moshè ook in die gedeelte oor die doringbos aangedui, waar hy JaHWeH noem die Elohey van Abraham en die Elohey van Isak en die Elohey van Jakob. [Exodus 3:1-6]	",
"	38 En die Elohim is nie ’n Elohey van die dooies nie, maar ’n Elohey van die lewendes, want almal leef vir Hom.	",
"	39 En sommige van die skrywers antwoord en sê: Meester, U het goed gespreek.	",
"	40 En hulle het Hom nie meer iets durf vra nie.	",
		
		
"	41 TOE sê Hy vir hulle: Hoe is dit dat hulle sê dat die Gesalfde die seun van Dawid is?	",
"	42 En Dawid self sê in die boek van die Psalms: JaHWeH het tot My Meester gespreek: Sit aan My regterkant [Openbaring 5:6]	",
"	43 totdat Ek U vyande maak maak ’n Voetbank vir U voete. [Psalm 110:1]	",
"	44 Dawid noem Hom dan Meester, en hoe is Hy sy seun?	",
		
		
"	45 EN terwyl die hele volk luister, sê Hy vir Sy studente:	",
"	46 Pas op vir die skrywers wat graag in lang klere rondloop en van die begroetinge op die markte hou en van die voorste banke in die vergaderings en die voorste plekke by die maaltye.	",
"	47 Hulle eet die huise van die weduwees op en doen vir die skyn lang gebede. Hulle sal ’n swaarder oordeel ontvang.	",
		

]
},
{
book: 'Lukas',
chapter: '21',
content: [
		
"	1 EN toe Hy opkyk, sien Hy die rykes wat hulle gawes in die skatkis gooi.	",
"	2 En Hy het ook ’n arm weduwee daar twee geldstukkies sien ingooi.	",
"	3 En Hy sê: Waarlik, Ek sê vir julle dat hierdie arm weduwee meer as almal ingegooi het. [2 Konings 4:1-7]	",
"	4 Want hulle almal het uit hul oorvloed by die gawes van die Elohim ingegooi, maar sy het uit haar gebrek ingegooi alles wat sy gehad het om van te lewe.	",
		
		
"	5 EN toe sommige oor die Tempel praat, dat hy met mooi klippe en gewyde geskenke versierd was, sê Hy:	",
"	6 Hierdie dinge wat julle sien - daar sal dae kom wanneer daar nie een klip op die ander gelaat sal word wat nie afgebreek sal word nie.	",
"	7 En hulle vra Hom en sê: Meester, wanneer sal dit dan wees, en wat is die Teken wanneer dit gaan gebeur?	",
"	8 En Hy antwoord: Pas op dat julle nie mislei word nie; want baie sal onder My Naam kom en dit sê: Ek Is! en: Die tyd is naby! Gaan dan nie agter hulle aan nie.	",
"	9 En wanneer julle hoor van oorloë en opstande, moenie skrik nie; want dié dinge moet eers plaasvind, maar dit is nie dadelik die einde nie.	",
"	10 Toe sê Hy vir hulle: Die een nasie sal teen die ander opstaan en die een koninkryk teen die ander. [2 Ezra 13:31]	",
"	11 En daar sal groot aardbewings op verskillende plekke wees en hongersnode en pessiektes; en daar sal verskriklike dinge en groot tekens van die Hemele kom.	",
"	12 Maar voor al hierdie dinge sal hulle die hande aan julle slaan en julle vervolg en oorlewer in vergaderings en gevangenisse en julle voor konings en goewerneurs bring ter wille van My Naam.	",
"	13 En dit sal vir julle uitloop op ‘n getuienis.	",
"	14 Neem julle dan in jul harte voor om nie vooraf oor julle verdediging te dink nie.	",
"	15 Want Ek sal aan julle woorde en Wysheid gee wat al julle teëstanders nie sal kan teëspreek of weerstaan nie.	",
"	16 Maar julle sal oorgelewer word ook deur ouers en broers en bloedverwante en vriende, en hulle sal van julle doodmaak.	",
"	17 En julle sal gehaat wees deur almal ter wille van My Naam.	",
"	18 En geen haar van julle hoof sal ooit verlore gaan nie.	",
"	19 Deur geduldigheid moet julle jul siel in besit kry.	",
		
		
"	20 EN wanneer julle Jerusalem deur leërs omsingeld sien, dan moet julle weet dat haar verwoesting naby is.	",
"	21 Dan moet die wat in JeHûWdah is, na die berge vlug; en die wat in die Stad is, moet uitgaan; en die wat in die buitewyke is, moet nie daar inkom nie.	",
"	22 Want dit sal ‘n dag van wraak wees, sodat alles wat geskrywe is, vervul kan word. [JeshaJaHûW 34:8, 61:2]	",
"	23 Maar wee die vroue wat swanger is en die wat nog soog in daardie dae; want daar sal ’n groot nood op die Aarde wees en toorn oor hierdie volk.	",
"	24 En hulle sal deur die skerpte van die swaard val en as krygsgevangenes geneem word na al die nasies, en Jerusalem sal vertrap word deur die nasies totdat die tye van die nasies vervul is.	",
		
		
"	25 EN daar sal tekens wees aan son en maan en Sterre, en op die Aarde benoudheid van nasies in hulle radeloosheid, wanneer see en branders dreun,	",
"	26 en mense se harte beswyk van vrees en verwagting van die dinge wat oor die wêreld kom. Want die kragte van die Hemele sal geskud word. [JeshaJaHûW 13:9-13]	",
"	27 En dan sal hulle die Seun van die Adam sien kom in die Wolkkolom, met groot Krag en Glansrykheid.	",
"	28 En as hierdie dinge begin gebeur, kyk dan na bo en hef julle hoofde op, omdat julle Verlossing naby is.	",
"	29 Toe vertel Hy hulle ’n gelykenis: Let op die Vyeboom en al die bome.	",
"	30 Net soos hulle bot, weet julle vanself, as julle haar sien, dat die somer al naby is.	",
"	31 So moet julle ook weet dat die Koninkryk van die Elohim naby is wanneer julle hierdie dinge sien gebeur.	",
"	32 Voorwaar Ek sê vir julle, hierdie saadlyn sal sekerlik nie tot niet gaan voordat alles gebeur het nie.	",
"	33 Die Hemele en die Aarde sal verbygaan, maar My woorde sal nooit verbygaan nie.	",
		
		
"	34 MAAR pas op vir julleself, dat julle harte nie miskien beswaar word deur swelgery en dronkenskap en sorge van die lewe nie, en dié Dag julle nie skielik oorval nie.	",
"	35 Want soos ’n strik sal Hy kom oor almal wat op die hele Aarde woon.	",
"	36 Waak dan en smeek altyddeur, sodat julle waardig geag mag word om al hierdie dinge wat kom, te ontvlug en voor die Seun van die Adam te staan.	",
		
		
"	37 EN Hy was oordag in die Tempel besig om te leer, en snags het Hy uitgegaan en vernag op die berg wat die Berg van die Olywe genoem word.	",
"	38 En die hele volk het vroeg in die môre na Hom in die Tempel gekom om na Hom te luister.	",
	
]
},
{
book: 'Lukas',
chapter: '22',
content: [
	
"	1 EN die Fees van die Ongesuurde Brode, wat Pasga genoem word, was naby.	",
"	2 En die owerpriesters en die skrywers het gesoek hoe hulle Hom kon ombring, want hulle het die volk gevrees.	",
"	3 En die Satan het in Judas gevaar, wat Iskáriot genoem word en wat uit die getal van die twaalf was.	",
"	4 Toe het hy gegaan en met die owerpriesters en hoofde beraadslaag hoe hy Hom aan hulle kon oorlewer.	",
"	5 En hulle was bly en het met hom ooreengekom om hom geld te gee.	",
"	6 En hy het toegestem en na ’n goeie geleentheid gesoek om Hom sonder oproer aan hulle oor te lewer.	",
		
		
"	7 EN die dag voor die Ongesuurde Brode het gekom waarop die Pasga doodgebloei moes word.	",
"	8 Toe stuur Hy Petrus en JeHôWganan en sê: Gaan berei die Pasga vir ons, dat ons hom kan eet.	",
"	9 En hulle sê vir Hom: Waar wil U hê moet ons hom berei?	",
"	10 En Hy antwoord hulle: Kyk, as julle in die Stad ingaan, sal ’n man julle ontmoet wat ’n kruik water dra; volg hom na die huis waar hy ingaan.	",
"	11 En julle moet vir die eienaar van die huis sê: Die Meester vra u - waar is die kamer waar Ek die Pasga met My studente kan eet?	",
"	12 En hy sal julle ’n groot bovertrek wys wat reggemaak is; daar moet julle hom berei.	",
"	13 En hulle het gegaan en dit gevind soos Hy vir hulle gesê het, en die Pasga berei.	",
"	14 En toe die uur kom, het Hy aan tafel gegaan en die twaalf Apostels saam met Hom.	",
"	15 En Hy sê vir hulle: Ek het baie sterk daarna verlang om hierdie Pasga met julle te eet voordat Ek ly.	",
"	16 Want Ek sê vir julle: Ek sal sekerlik nie meer van hom eet voordat hy in die Koninkryk van die Elohim vervul is nie.	",
"	17 En toe Hy ’n Beker geneem het, dank Hy en sê: Neem Haar en deel Haar onder julle.	",
"	18 Want Ek sê vir julle: Ek sal sekerlik nie drink van die vrug van die Wingerdstok voordat die Koninkryk van die Elohim gekom het nie.	",
"	19 Daarop neem Hy Brood, en nadat Hy gedank het, breek Hy Hom en gee Hom aan hulle en sê: Hy is My liggaam wat vir julle gegee word; doen dit [eet] tot My gedagtenis.	",
"	20 Net so neem Hy ook die Beker ná die maaltyd en sê: Hierdie Beker is die Nuwe Verbond in My Bloed wat vir julle uitgestort word.	",
"	21 Maar kyk, die hand van hom wat My verraai, is by My aan tafel.	",
"	22 Die Seun van die Adam gaan wel heen volgens wat bepaal is, maar wee daardie man deur wie Hy verraai word!	",
"	23 Toe begin hulle onder mekaar te vra wie van hulle dit tog kon wees wat dit sou doen.	",
		
		
"	24 EN daar het ook twis onder hulle ontstaan oor wie van hulle die grootste geag moet wees.	",
"	25 En Hy het vir hulle gesê: Die konings van die nasies heers oor hulle, en die wat gesag voer oor hulle, word weldoeners genoem.	",
"	26 Maar so moet julle nie wees nie; maar die oudste onder julle moet word soos die jongste, en wie ’n leier is, soos een wat dien.	",
"	27 Want wie is groter: die een wat aan tafel is, of die een wat dien? Is dit nie hy wat aan tafel is nie? Maar Ek is onder julle soos een wat dien.	",
"	28 En dit is julle wat altyddeur by My gebly het in My versoekinge.	",
"	29 En Ek beskik vir julle ’n Koninkryk soos My VADER haar vir My beskik het,	",
"	30 sodat julle kan eet en drink aan My tafel in My Koninkryk en op trone sit om die twaalf stamme van JisraEl te oordeel.	",
		
		
"	31 EN die Meester sê: Simon, Simon, kyk, die Satan het vurig begeer om julle soos koring te sif.	",
"	32 Maar Ek het vir jou gebid, dat jou Geloof nie ophou nie; en as jy eendag terugkom, moet jy jou broers versterk.	",
"	33 En hy het vir Hom gesê: Meester, ek is gereed om saam met U selfs in die gevangenis en in die dood te gaan.	",
"	34 Maar Hy antwoord: Ek sê vir jou, Petrus, die haan sal vannag nie kraai voordat jy drie maal getuig het dat jy My nie ken nie.	",
		
		
"	35 EN Hy sê vir hulle: Toe Ek julle uitgestuur het sonder beurs en reissak en skoene, het julle iets kortgekom? En hulle antwoord: Niks nie.	",
"	36 Toe sê Hy vir hulle: Maar nou, wie ’n beurs het, laat hom dit neem en so ook die reissak; en wie dit nie het nie, moet sy kleed verkoop en ’n swaard koop.	",
"	37 Want Ek sê vir julle dat dit wat geskrywe is, nog aan My vervul moet word: Omdat Hy Sy siel uitgestort het in die Dood en saam met die opstandiges gereken was. Want ook aan die dinge wat betrekking het op My, kom daar ’n einde. [JeshaJaH 53:12]	",
"	38 Hulle sê vir Hom: Meester, kyk hier is twee swaarde. En Hy antwoord hulle: Dit is genoeg.	",
		
		
"	39 EN Hy het vertrek en volgens gewoonte na die Berg van die Olywe gegaan. En ook Sy studente het Hom gevolg.	",
"	40 En toe Hy op die plek kom, sê Hy vir hulle: Bid dat julle nie in versoeking kom nie.	",
"	41 En Hy het Hom van hulle afgesonder omtrent so ver as ’n mens met ’n klip kan gooi, en neergekniel en gebid	",
"	42 en gesê: VADER, as U tog maar hierdie Beker van My wil wegneem! Laat nogtans nie My wil nie, maar U wil geskied!	",
"	43 En ’n Boodskapper uit die Hemele het aan Hom verskyn en Hom versterk.	",
"	44 En toe Hy in ’n sware stryd kom, het Hy met groter inspanning gebid, en Sy sweet het geword soos bloeddruppels wat op die Aarde val.	",
"	45 Toe staan Hy van die gebed op en kom by Sy studente en vind hulle aan die slaap van droefheid.	",
"	46 En Hy sê vir hulle: Wat slaap julle? Staan op en bid, dat julle nie in versoeking kom nie.	",
		
		
"	47 EN terwyl Hy nog spreek, kom daar ’n skare; en hy wat Judas genoem word, een van die twaalf, het voor hulle uit geloop en nader gekom na JaHWèshua om Hom te soen.	",
"	48 En JaHWèshua sê vir hom: Judas, verraai jy die Seun van die Adam met ’n kus?	",
"	49 En toe die wat rondom Hom was, sien wat gaan gebeur, sê hulle vir Hom: Meester, moet ons met die swaard slaan?	",
"	50 En een van hulle het die dienskneg van die hoëpriester getref en sy regteroor afgekap.	",
"	51 Maar JaHWèshua het geantwoord en gesê: Hou op, dit is genoeg! En Hy het sy oor aangeraak en hom gesond gemaak.	",
"	52 Toe sê JaHWèshua vir die owerpriesters en hoofde van die Tempel en oudstes wat teen Hom gekom het: Het julle uitgetrek soos teen ’n rower met swaarde en stokke?	",
"	53 Dag vir dag was Ek saam met julle in die Tempel, en julle het nie die hande teen My uitgesteek nie. Maar dit is julle uur en die mag van die Duisternis.	",
		
		
"	54 EN hulle het Hom gevange geneem en weggelei en Hom gebring in die huis van die hoëpriester. En Petrus het van ver af gevolg.	",
"	55 En toe hulle ’n vuur in die middel van die binneplaas van die paleis gemaak en bymekaar gaan sit het, het Petrus onder hulle gesit.	",
"	56 En ’n diensmeisie het hom daar by die vuur sien sit; en nadat sy hom vas aangekyk het, sê sy: Hierdie man was ook saam met Hom.	",
"	57 Maar hy het teen Hom getuig en gesê: Vrou, ek ken Hom nie. [Psalm 69:8]	",
"	58 En kort daarna sien iemand anders hom en sê: Jy is ook een van hulle. Maar Petrus sê: Man, ek is nie.	",
"	59 En ná verloop van omtrent een uur het ’n ander een dit verseker en gesê: Sowaar, hierdie man was ook saam met Hom, want hy is ook ’n Galiléër.	",
"	60 Maar Petrus antwoord: Man, ek weet nie wat jy sê nie. En onmiddellik, terwyl hy nog praat, het die haan gekraai.	",
"	61 En die Meester het Hom omgedraai en Petrus aangekyk, en Petrus het die Woord van die Meester onthou wat Hy vir hom gesê het: Voordat die haan kraai, sal jy drie maal teen My getuig.	",
"	62 En Petrus het buitentoe gegaan en bitterlik geween.	",
		
		
"	63 EN die manne wat JaHWèshua gevange gehou het, het Hom bespot en geslaan.	",
"	64 En hulle het Hom geblinddoek en Hom in die aangesig geslaan en Hom gevra en gesê: Profeteer wie dit is wat U geslaan het.	",
"	65 En baie ander dinge het hulle lasterlik teen Hom gespreek.	",
"	66 En toe dit dag word, het die oudstes van die volk - die owerpriesters en skrywers - vergader en Hom voor hulle Raad gebring	",
"	67 en gesê: As U die Gesalfde is, sê vir ons. En Hy antwoord hulle: As Ek vir u sê, sal u tog nie glo nie.	",
"	68 En as Ek vra, sal u My tog nie antwoord of loslaat nie.	",
"	69 Van nou af sal die Seun van die Adam sit aan die regterkant van die Krag van die Elohim.	",
"	70 En hulle sê almal: Is U dan die Seun van die Elohim? En Hy antwoord hulle: Julle sê dat [dit] Ek Is.	",
"	71 Daarop sê hulle: Wat het ons nog getuienis nodig! Want ons het dit self uit Sy mond gehoor.	",

]
},
{
book: 'Lukas',
chapter: '23',
content: [
	
"	1 EN die hele menigte van hulle het opgestaan en Hom na Pilatus gelei.	",
"	2 En hulle het Hom begin beskuldig en sê: Ons het gevind dat hierdie man die volk verlei en verbied om aan die keiser belasting te betaal, terwyl Hy sê dat Hy self die Gesalfde, die Koning, is.	",
"	3 Toe vra Pilatus Hom en sê: Is U die Koning van die manne van JeHûWdah? En Hy antwoord hom en sê: U sê dit.	",
"	4 En Pilatus sê vir die owerpriesters en die skare: Ek vind geen skuld in hierdie man nie.	",
"	5 Maar hulle het aangehou en gesê: Hy maak die volk oproerig met Sy leer die hele JeHûWdah deur, vandat Hy in Galiléa begin het tot hiertoe.	",
"	6 En toe Pilatus van Galiléa hoor, vra hy of die man ’n Galiléër is.	",
"	7 En nadat hy verneem het dat Hy uit die magsgebied van Herodes was, stuur hy Hom na Herodes wat self ook in daardie dae in Jerusalem was.	",
"	8 En toe Herodes JaHWèshua sien, was hy baie bly, want hy was al geruime tyd begerig om Hom te sien, omdat hy veel van Hom gehoor het; en hy het gehoop om een of ander Teken te sien wat deur Hom gedoen sou word.	",
"	9 En hy het Hom met baie woorde uitgevra, maar Hy het hom niks geantwoord nie.	",
"	10 En die owerpriesters en die skrywers het Hom heftig staan en beskuldig.	",
"	11 En nadat Herodes saam met sy soldate Hom met veragting behandel en bespot het, werp hy Hom ’n blink kleed om en stuur Hom terug na Pilatus.	",
"	12 En Pilatus en Herodes het op daardie dag goeie vriende geword, want hulle was vantevore in vyandskap teenoor mekaar.	",
"	13 Toe roep Pilatus die owerpriesters en die owerstes en die volk bymekaar en sê vir hulle:	",
"	14 Julle het hierdie man na my gebring as een wat die volk afvallig maak. En nou het ek in julle teenwoordigheid ondersoek ingestel en in hierdie man geen skuld gevind aan die dinge waarvan julle Hom beskuldig nie;	",
"	15 ja, ook Herodes nie, want ek het julle na hom gestuur; en daar is deur Hom niks gedoen wat die dood verdien nie.	",
"	16 Nadat ek Hom dan gekasty het, sal ek Hom loslaat.	",
"	17 En hy was verplig om vir hulle op die Fees een los te laat.	",
"	18 Maar die hele menigte skreeu en sê: Weg met Hom, en laat vir ons Barábbas los!	",
"	19 Dié was oor ’n sekere opstand wat in die Stad plaasgevind het, en oor ’n moord in die gevangenis gewerp.	",
"	20 Daarop spreek Pilatus hulle weer toe, omdat hy JaHWèshua wou loslaat;	",
"	21 maar hulle het aangehou roep en sê: Folter, folter Hom! [Deuteronómium 21:22]	",
"	22 En vir die derde keer sê hy vir hulle: Watter kwaad het Hy dan gedoen? Ek het in Hom niks gevind wat die dood verdien nie. Ek sal Hom dan kasty en loslaat.	",
"	23 Maar hulle het aangehou met ’n harde geroep en geëis dat Hy gefolter moes word; en hulle geroep en die van die owerpriesters het die oorhand gekry.	",
"	24 Toe gee Pilatus uitspraak dat aan hulle eis voldoen moet word.	",
"	25 En hy het die een vir hulle losgelaat wat oor opstand en moord in die gevangenis gewerp was, die een wat hulle geëis het. Maar JaHWèshua het hy aan hulle wil oorgelewer.	",
		
		
"	26 EN toe hulle Hom weglei, neem hulle ’n sekere Simon van Ciréne wat van die veld af gekom het, en sit die folterpaal op hom om hom agter JaHWèshua aan te dra.	",
"	27 En ’n groot menigte van die volk het Hom gevolg, en vroue wat rou bedryf en Hom beklaag het.	",
"	28 Maar JaHWèshua het Hom omgedraai en vir hulle gesê: Dogters van Jerusalem, moenie oor My ween nie, maar ween oor julleself en oor julle kinders;	",
"	29 want daar kom dae waarin hulle sal sê: Geseënd is die onvrugbares en die moederskote wat nie gebaar en die borste wat nie gesoog het nie.	",
"	30 Dan sal hulle vir die berge begin sê: Val op ons! en vir die heuwels: Bedek ons!	",
"	31 Want as hulle dit doen aan die groen hout, wat sal met die droë gebeur!	",
"	32 En daar is nog twee ander, kriminele, weggelei om saam met Hom tereggestel te word.	",
		
		
"	33 EN toe hulle op die plek kom wat Hoofskedel genoem word, het hulle Hom daar gefolter, en die kriminele, een aan die regter en een aan die linkerkant.	",
"	34 En JaHWèshua sê: VADER, vergeef hulle nie, want hulle weet wat hulle doen. En hulle het Sy klere verdeel en die lot daaroor gewerp. [Psalm 22:18, Psalm 69:21-28 Klaagl van JirmeJaH 3:63-66]]	",
"	35 En die volk het dit staan en aanskou. En die owerstes het saam met hulle ook geskimp en gesê: Ander het Hy verlos; laat Hy Homself verlos as Hy die Gesalfde, die uitverkorene van die Elohim, is. [Psalm 22:16]	",
"	36 En die soldate het Hom ook bespot en gekom en vir Hom asyn gebring [Psalm 69:21; JeHôWganan 19:29]	",
"	37 en gesê: As U die Koning van die manne van JeHûWdah is, verlos Uself.	",
"	38 En daar was ook ’n opskrif bokant Hom geskrywe in Griekse en Romeinse en Hebreeuse letters: !ydiWhyÒh’ &l,m, aWh hz ² - HY IS DIE KONING VAN DIE MANNE VAN JEHûWDAH.	",
		
"	39 En een van die kriminele wat opgehang is, het Hom gesmaad en gesê: As U die Gesalfde is, verlos Uself en ons.	",
"	40 Maar die ander een antwoord en bestraf hom en sê: Vrees jy nie ook die Elohim nie, terwyl jy in dieselfde oordeel is? -	",
"	41 ons tog regverdiglik, want ons ontvang die verdiende loon vir ons dade, maar Hy het niks verkeerds gedoen nie.	",
"	42 En hy sê vir JaHWèshua: Dink aan my, Meester, wanneer U in U Koninkryk kom.	",
"	43 En JaHWèshua antwoord hom: Voorwaar Ek sê vir jou, vandag sal jy saam met My in die Paradys wees. [Nikodemus 10]	",
"	44 En dit was omtrent die sesde uur, en daar het duisternis oor die hele Aarde gekom tot die negende uur toe;	",
"	45 en die son is verduister; en die voorhangsel van die Tempel het middeldeur geskeur. [Exodus 26:31; Boodskap van Jakobus 10:1]	",
"	46 En JaHWèshua het met ’n groot stem uitgeroep en gesê: VADER, in U Hande gee Ek My Gees oor! En toe Hy dit gesê het, blaas Hy die laaste asem uit.	",
"	47 En toe die hoofman oor honderd sien wat daar gebeur, het hy die Elohim vereer en gesê: Waarlik, hierdie man was regverdig.	",
"	48 En die hele skare wat vir hierdie skouspel bymekaar was, het op hulle borste geslaan toe hulle sien wat gebeur het, en hulle het teruggegaan.	",
"	49 En al Sy bekendes het ver weg gestaan; ook die vroue wat Hom van Galiléa gevolg het, het hierdie dinge gesien.	",
		
		
"	50 EN daar was ’n man met die naam van JôWsef, ’n lid van die Raad, ’n suiwer en regverdige man	",
"	51 - hy het nie met hulle raad en handelwyse saamgestem nie - van Arimathéa, ’n stad van JeHûWdah, [Hy het] ook self die Koninkryk van die Elohim verwag.	",
"	52 Hy het na Pilatus gegaan en die Liggaam van JaHWèshua gevra	",
"	53 en Hom afgehaal en in linne toegedraai en Hom neergelê in ’n graf wat uit ’n rots gekap was, waar nog nooit iemand in gelê het nie.	",
"	54 En dit was die dag van voorbereiding, en die Sabbat het nader gekom.	",
"	55 En die vroue wat saam met Hom van Galiléa gekom het, het ook gevolg en die graf gesien en hoe Sy liggaam neergelê was.	",
"	56 Daarop het hulle teruggegaan en speserye en salf berei om op die Sabbat te rus volgens die Gebod.	",
	
]
},
{
book: 'Lukas',
chapter: '24',
content: [
		
"	1 EN baie vroeg in die môre, op die eerste dag van die week, het hulle en ander saam met hulle by die graf gekom en die speserye gebring wat deur hulle berei was.	",
"	2 En hulle het die steen van die graf afgerol gevind.	",
"	3 En toe hulle ingaan, het hulle nie die Liggaam van die Meester JaHWèshua gekry nie.	",
"	4 En terwyl hulle hieroor in verleentheid was, staan daar twee Manne by hulle in glansende klere.	",
"	5 En toe hulle baie bevrees word en met hulle aangesigte na die Aarde buig, sê die Manne vir hulle: Waarom soek julle die Lewende by die dooies?	",
"	6 Hy is nie hier nie, maar Hy het opgestaan. Onthou hoe Hy vir julle gesê het toe Hy nog in Galiléa was:	",
"	7 Die Seun van die Adam moet oorgelewer word in die hande van sterflinge [en] die oortreders en gefolter word en op die derde dag opstaan.	",
"	8 En hulle het Sy woorde onthou.	",
"	9 Hulle gaan toe terug van die graf en vertel dit alles aan die elf en aan al die ander.	",
"	10 En dit was Mirjam die Migdalieth en JôWhana en Mirjam, [die moeder] van Jakobus, [en die ander vroue] saam met hulle wat dit aan die Apostels vertel het.	",
"	11 En hul woorde het vir hulle na onsinnige praatjies gelyk, en hulle het hul nie geglo nie.	",
"	12 Maar Petrus het opgestaan en na die graf gehardloop; en toe hy neerbuk, sien hy die doeke alleen lê. En hy het weggegaan huis toe, vol verwondering oor wat gebeur het.	",
		
		
"	13 EN twee van hulle was dieselfde dag op pad na ’n dorp wat agt myl van Jerusalem af was, met die naam van Émmaüs.	",
"	14 En hulle was in gesprek met mekaar oor al hierdie dinge wat voorgeval het.	",
"	15 En terwyl hulle praat en mekaar ondervra, kom JaHWèshua self nader en loop met hulle saam.	",
"	16 Maar hulle oë is weerhou, sodat hulle Hom nie kon herken nie.	",
"	17 En Hy sê vir hulle: Watter woorde is dit wat julle met mekaar loop en wissel, en waarom is julle bedroef?	",
"	18 En die een wie se naam Kléopas was, antwoord en sê vir Hom: Is U alleen ’n vreemdeling in Jerusalem en weet U nie van die dinge wat in hierdie dae in haar gebeur het nie?	",
"	19 En Hy sê vir hulle: Watter dinge? En hulle antwoord Hom: Die dinge aangaande JaHWèshua, die Nasaréner, wat ’n Profeet was, kragtig in werk en Woord voor die Aangesig van JaHWeH en die hele volk;	",
"	20 en hoe ons owerpriesters en owerstes Hom oorgelewer het tot die doodstraf en Hom gefolter het.	",
"	21 En ons het gehoop dat dit Hy was wat JisraEl sou verlos; maar nou is dit vandag, reeds al drie dae vandat dit plaasgevind het.	",
"	22 Maar sommige vroue uit ons het ons ook ontstel nadat hulle vroeër by die graf was;	",
"	23 en toe hulle Sy Liggaam nie kry nie, het hulle gekom en gesê dat hulle ook ’n gesig gesien het van Boodskappers wat sê dat Hy lewe.	",
"	24 En sommige van die wat saam met ons was, het na die graf gegaan en dit net so gevind soos die vroue ook gesê het; maar Hom het hulle nie gesien nie.	",
"	25 En Hy sê vir hulle: o Onverstandiges, met harte wat traag is om te glo alles wat die Profete gespreek het!	",
"	26 Moes die Gesalfde nie hierdie dinge ly en in Sy Glansrykheid ingaan nie?	",
"	27 En Hy het begin van Moshè en al die Profete af en vir hulle uitgelê in al die Skrifte die dinge wat op Hom betrekking het.	",
"	28 Daarop kom hulle naby die dorp waarheen hulle op reis was, en Hy het gemaak of Hy verder wou gaan;	",
"	29 maar hulle het by Hom aangedring en gesê: Bly by ons, want dit is amper aand en die dag het gedaal; en Hy het ingegaan om by hulle te bly.	",
"	30 En toe Hy met hulle aan tafel was, neem Hy die Brood en dank; en Hy breek Hom en gee Hom aan hulle.	",
"	31 Toe is hulle oë geopen en hulle het Hom herken, en Hy het uit hulle gesig verdwyn.	",
"	32 En hulle sê vir mekaar: Was ons hart nie brandende in ons toe Hy met ons op die pad gepraat en vir ons die Skrifte uitgelê het nie?	",
"	33 Toe staan hulle in dieselfde uur op en gaan na Jerusalem terug en vind die elf en die wat saam met hulle bymekaar was,	",
"	34 wat sê: die Meester het waarlik opgestaan en het aan Simon verskyn.	",
"	35 Toe vertel hulle wat op die pad gebeur het en hoe Hy aan hulle bekend geword het by die breking van die Brood.	",
		
		
"	36 EN terwyl hulle hieroor praat, staan JaHWèshua self in hul midde en sê vir hulle: Vrede vir julle!	",
"	37 Toe het hulle verskrik en baie bang geword en gemeen dat hulle ’n gees sien.	",
"	38 En Hy sê vir hulle: Waarom is julle ontsteld en waarom kom daar twyfel in julle hart op?	",
"	39 Kyk na My hande en My voete, want Ek Is. Voel aan My en kyk; want ’n gees het nie vlees en bene soos julle sien dat Ek het nie.	",
"	40 En terwyl Hy dit sê, wys Hy hulle Sy hande en Sy voete.	",
"	41 En toe hulle van blydskap nog nie kon glo nie en hulle verwonder, sê Hy vir hulle: Het julle hier iets om te eet?	",
"	42 Daarop gee hulle Hom ’n stuk gebraaide vis en ’n stuk heuningkoek.	",
"	43 En Hy het dit geneem en voor hulle oë geëet.	",
"	44 En Hy sê vir hulle: Dit is die Woorde wat Ek met julle gespreek het toe Ek nog by julle was, dat alles wat oor My geskrywe is in die Wet van Moshè en die Profete en die Psalms, vervul moet word. [Deuteronómium 18:15]	",
"	45 Toe open Hy hulle verstand om die Skrifte te verstaan.	",
"	46 En Hy sê vir hulle: So is dit geskrywe, en so moes die Gesalfde ly en op die derde dag uit die dode opstaan,	",
"	47 en bekering en vergewing van oortredinge in Sy Naam verkondig word aan al die nasies, van Jerusalem af en verder.	",
"	48 En julle is getuies van hierdie dinge.	",
"	49 En kyk, Ek stuur die Belofte van My VADER op julle. Maar julle moet in die Stad Jerusalem bly totdat julle toegerus is met Krag uit die hoogte.	",
"	50 En Hy het hulle uitgelei tot by Betánië. En Hy het Sy hande opgehef en hulle geseën.	",
"	51 En terwyl Hy hulle seën, het Hy van hulle geskei en is in die Hemele opgeneem.	",
"	52 En hulle het Hom vereer en na Jerusalem teruggegaan met groot blydskap.	",
"	53 En hulle was gedurig in die Tempel en het die Elohim geprys en gedank. Amein.	",

]
}

];
