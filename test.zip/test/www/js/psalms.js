const psalmsChapters = [

{
book: 'Psalms',
chapter: '1',
content: [

"	1 GESEËND is die man wat nie wandel in die raad van die besoedelde en nie staan op die weg van die oortreders en nie sit in die kring van die spotters nie;	",
"	2 maar sy behae is in die Wet van JaHWeH, en hy oordink Sy Wet dag en nag.	",
"	3 En hy sal wees soos ’n Boom wat geplant is by waterstrome, wat sy vrugte gee op sy tyd en waarvan die blare nie verwelk nie; en alles wat hy doen, voer hy voorspoedig uit.	",
"	4 So is die besoedelde mense nie, maar soos kaf wat die wind verstrooi.	",
"	5 Daarom sal die besoedeldes nie standhou in die Reg en die oortreders in die vergadering van die regverdiges nie.	",
"	6 Want JaHWeH ken die Weg van die regverdiges, maar die weg van die besoedeldes sal vergaan.	",
	
]
},
{
book: 'Psalms',
chapter: '2',
content: [
		
"	1 WAAROM woel die nasies en bedink die gemeenskappe nietige dinge?	",
"	2 Die konings van die Aarde staan gereed, en die vorste hou saam raad teen JaHWeH en teen Sy Gesalfde [en sê]:	",
"	3 Laat ons Hulle bande stukkend ruk en Hulle toue van ons afwerp!	",
"	4 Hy wat in die Hemele woon, lag; My Meester spot met hulle.	",
"	5 Dan sal Hy hulle aanspreek in Sy Toorn, en Sy brandende Woede sal hulle verskrik:	",
"	6 Ek tog het My Koning gesalf oor Sion, [die] Berg van My Apartheid.	",
"	7 Ek wil vertel van die besluit: JaHWeH het aan My gesê: U is MY Seun, vandag het EK U gegenereer.	",
"	8 Eis van My, en Ek wil nasies gee as U Erfdeel en die eindes van die Aarde as U besitting.	",
"	9 U sal hulle verpletter met ’n Septer van Yster, U sal hulle stukkend slaan soos ’n erdepot.	",
"	10 Wees dan nou verstandig, o konings; laat julle waarsku, o regters van die Aarde!	",
"	11 Dien JaHWeH met vrees, en juig met bewing.	",
"	12 Bewapen jou met die Seun, dat Hy nie toornig word en julle op die Weg vergaan nie; want gou kan Sy Toorn ontvlam. Geseënd is almal wat by Hom skuil!	",

]
},
{
book: 'Psalms',
chapter: '3',
content: [
		
"	1 O JaHWeH, hoe het my teëstanders vermenigvuldig! Baie staan teen my op.	",
"	2 Baie sê van my: Daar is geen Verlossing vir hom by Elohim nie.Sela.	",
"	3 Maar U, JaHWeH, is ’n Skild wat my beskut, my eer en die Een wat my hoof ophef.	",
"	4 Luid roep ek JaHWeH aan, en Hy verhoor my uit die Berg van Sy Apartheid.Sela.	",
"	5 Ek het gaan lê en aan die slaap geraak; ek het wakker geword, want JaHWeH ondersteun my.	",
"	6 Ek sal nie vrees vir tienduisende van mense wat rondom teen my gereed staan nie.	",
"	7 Staan op, JaHWeH; verlos my, my Elohey! Want U het al my vyande op die kakebeen geslaan; U het die tande van die besoedelde stukkend gebreek.	",
"	8 Die Verlossing behoort aan JaHWeH; laat U seën wees oor U volk!	",

]
},
{
book: 'Psalms',
chapter: '4',
content: [
		
"	1 AS Ek roep, verhoor My, o Elohey van Geregtigheid! In benoudheid het U vir My ruimte gemaak; wees My barmhartig, en hoor My Gebed!	",
"	2 o Manne, hoe lank sal My Eer tot skande wees? [Hoe lank] sal julle die nietigheid liefhê, die leuen soek?Sela.	",
"	3 Weet tog dat JaHWeH vir Hom ’n Toegewyde afgesonder het; JaHWeH hoor as Ek Hom aanroep.	",
"	4 Sidder, en moenie oortree nie; spreek in julle hart op julle bed, en wees stil.Sela.	",
"	5 Slag ‘n Slagdier vir Geregtigheid en vertrou op JaHWeH.	",
"	6 Baie sê: Wie sal ons die suiwere laat sien? Verhef oor ons die Lig van U Aangesig, o JaHWeH!	",
"	7 Groter vreugde het U in My Hart gegee as wanneer hulle koring en hulle wyn oorvloedig is.	",
"	8 Ek wil in Vrede gaan lê en meteens aan die slaap raak; want U, o JaHWeH, alleen laat My in veiligheid woon.	",

]
},
{
book: 'Psalms',
chapter: '5',
content: [
		
"	1 O JaHWeH, luister na My woorde, let op My versugting.	",
"	2 Gee ag op die Stem van My hulpgeroep, My Koning en My Elohey, want tot U bid Ek.	",
"	3 In die môre, JaHWeH, sal U My Stem hoor; in die môre sal Ek dit aan U voorlê en afwag.	",
"	4 Want U is nie ’n El wat behae het in besoedeling nie; die besoedelde sal by U nie vertoef nie.	",
"	5 Die onsinniges sal voor U Oë nie standhou nie; U haat al die bewerkers van Ongeregtigheid.	",
"	6 U sal die leuensprekers laat omkom; van die man van bloed en bedrog het JaHWeH ’n afsku.	",
"	7 Maar Ek, deur die grootheid van U Barmhartigheid mag Ek in U Huis ingaan, My buig na die Tempel van U Apartheid, in U Vrees.	",
"	8 JaHWeH, lei My in U Geregtigheid om My vyande ontwil; maak U Weg voor My Reg. [Psalm 18:30; Odes van Salomo 39:13]	",
"	9 Want in hulle mond is niks betroubaars nie; hulle binneste bring bedrieglikheid; hulle keel is ’n oop graf; hulle maak hul tong glad.	",
"	10 Verklaar hulle skuldig, o Elohim! Laat hulle val deur hul planne; dryf hulle weg oor die menigte van hul oortredinge, want hulle het gerebelleer teen U.	",
"	11 Maar laat húlle almal bly wees wat by U skuil; laat hulle vir ewig jubel, en beskut U hulle; en laat in U juig die wat U Naam liefhet.	",
"	12 Want U seën die regverdige, o JaHWeH, U omring hom met Vreugde soos met ’n Skild.	",

]
},
{
book: 'Psalms',
chapter: '6',
content: [
	
"	1 O JaHWeH, straf My nie in U Toorn nie, en kasty My nie in U Grimmigheid nie.	",
"	2 Wees My barmhartig, JaHWeH, want Ek is verswak; maak My gesond, JaHWeH, want My gebeente is verskrik.	",
"	3 Ja, My Siel is baie verskrik; en U, JaHWeH, tot hoe lank?	",
"	4 Keer terug, JaHWeH, red My Siel; verlos My om U Barmhartigheid ontwil.	",
"	5 Want in die Dood word aan U nie gedink nie; wie sal U loof in die Doderyk/Sheol?	",
"	6 Ek is moeg van My gesug; elke nag laat Ek My bed swem; Ek deurweek My bed met My trane.	",
"	7 My oog het dof geword van verdriet; dit het swak geword vanweë al My teëstanders.	",
"	8 Gaan weg van My, al julle bewerkers van Ongeregtigheid, want JaHWeH het die stem van My geween gehoor.	",
"	9 JaHWeH het My smeking gehoor; JaHWeH neem My gebed aan.	",
"	10 Al My vyande sal beskaamd staan en baie verskrik word; hulle sal in ’n oomblik beskaamd omdraai.	",

]
},
{
book: 'Psalms',
chapter: '7',
content: [
	
"	1 JaHWeH, my Elohey, by U skuil ek; verlos my van al my vervolgers en red my;	",
"	2 sodat hy nie my siel soos ’n leeu verskeur en wegruk sonder dat iemand red nie.	",
"	3 JaHWeH, my Elohey, as ek dit gedoen het, as daar onreg in my handpalms is,	",
"	4 as ek hóm kwaad aangedoen het wat in vrede met my geleef het (ja, ek het hom gered wat my sonder oorsaak vyandig was),	",
"	5 mag die vyand my dan vervolg en inhaal en my siel teen die Aarde vertrap en my eer in die stof laat woon.Sela.	",
"	6 Staan op, JaHWeH, in U Toorn, verhef U teen die grimmigheid van my teëstanders en ontwaak vir my, U wat die Reg beveel het!	",
"	7 En laat die vergadering van die gemeenskappe U omring; keer dan bo hulle terug in die hoogte!	",
"	8 JaHWeH oordeel die volke. Doen aan my Reg, JaHWeH, na my Geregtigheid en na my egtheid in my.	",
"	9 Laat tog die besoedeling van die besoedeldes tot ’n einde kom, maar bevestig U die regverdige, ja, U wat harte en niere toets, o regverdige Elohim!	",
"	10 My Skild is by Elohim wat die opregtes van hart verlos.	",
"	11 Elohim is ’n regverdige Regter, en ’n El wat elke dag toornig is.	",
"	12 As hy hom nie bekeer nie, maak Hy Sy Swaard skerp; Hy span Sy Boog en maak haar gereed	",
"	13 en berei vir hom dodelike Werktuie; Hy maak Sy Pyle bran-dende wapens.	",
"	14 Kyk, hy is in barensweë van onreg en is swanger van moeite; hy baar leuens.	",
"	15 Hy het ’n put gegrawe en dit uitgehol; maar hy het geval in die gat wat hy gemaak het.	",
"	16 Die onenigheid wat hy gestig het, keer op sy hoof terug, en sy geweld kom op sy kroontjie neer.	",
"	17 Ek wil JaHWeH loof na Sy getrouheid en musiek maak vir die Naam van JaHWeH, die Hoogste El.	",
	
]
},
{
book: 'Psalms',
chapter: '8',
content: [
	
"	1 O JaHWeH, Onse Meester, hoe uitnemend is U Naam op die ganse Aarde! Wie het U Majesteit gelê op die Hemele?	",
"	2 Uit die mond van kinders en suigelinge het U sterkte gegrondves, om U teëstanders ontwil, om die vyand en wraakgierige stil te maak. [2 Ezra 6:21]	",
"	3 As Ek U Hemele aanskou, die werk van U Vingers, die maan en die Sterre wat U toeberei het -	",
"	4 wat is die adamiet dat U aan hom dink, en die Seun van Adam dat U hom besoek?	",
"	5 U het Hom weinig tekort laat kom van die Elohim en Hom met Grootsheid en Glansrykheid gekroon.	",
"	6 U laat Hom heers oor die werke van U Hande; U het alles onder Sy Voete gestel:	",
"	7 skape en beeste, dié almal, en ook die diere van die veld,	",
"	8 die voëls van die Hemele en die visse van die see, wat trek deur die paaie van die see.	",
"	9 o JaHWeH, Onse Meester, hoe uitnemend is U Naam op die ganse Aarde!	",

]
},
{
book: 'Psalms',
chapter: '9',
content: [
	
"	1 EK wil JaHWeH loof met My hele hart; Ek wil al U wonders vertel.	",
"	2 In U wil Ek bly wees en juig; Ek wil musiek maak tot eer van U Naam, O Hoogste El,	",
"	3 omdat My vyande agteruitwyk, struikel en omkom van voor U Aangesig.	",
"	4 Want U het My Reg en My Regsaak behandel; U het gaan sit op die Troon, o Regter van Geregtigheid!	",
"	5 U het die nasies gedreig, die besoedelde laat omkom, hulle naam uitgedelg vir Ewig tot in Ewigheid.	",
"	6 Die vyande het omgekom - puinhope vir ewig; ook die stede wat U verwoes het; hulle gedagtenis, ja, dié het vergaan.	",
"	7 Maar JaHWeH sit vir ewig; Hy het Sy Troon reggesit vir die Reg.	",
"	8 En Hy self sal die wêreld oordeel met Geregtigheid en die gemeenskappe vonnis met Reg.	",
"	9 So is JaHWeH dan ’n rotsvesting vir die verdrukte, ’n rotsvesting in tye van benoudheid.	",
"	10 En hulle wat U Naam ken, sal op U vertrou, omdat U die wat U soek, nie verlaat nie, o JaHWeH!	",
"	11 Maak musiek tot eer van JaHWeH wat op Sion woon; verkondig onder die volke Sy dade.	",
"	12 Want Hy wat die bloed ondersoek, dink aan hulle; Hy vergeet die geroep van die ellendiges nie.	",
"	13 Begunstig My, JaHWeH, aanskou My ellende vanweë My haters, U wat My verhef uit die poorte van die Dood;	",
"	14 sodat Ek al U roemryke dade kan vertel, in die Poorte van die Dogter van Sion kan juig oor U Verlossing.	",
"	15 Die nasies het gesink in die kuil wat hulle gemaak het; hulle voet is gevang in die net wat hulle gespan het.	",
"	16 JaHWeH het Hom bekend gemaak; Hy het die Reg geoefen; die besoedelde is verstrik in die werk van Sy handpalms.Bepeinsing.Sela.	",
"	17 Die besoedelde sal teruggaan na die Doderyk/Sheol, al die nasies wat Elohim vergeet het.	",
"	18 Want die Behoeftige sal nie vir altyd vergeet word, die Verwagting van die ellendiges nie vir ewig verlore gaan nie. [Hooglied van Salomo 2:9]	",
"	19 Staan op, JaHWeH, laat die mens nie sterk word nie; laat die nasies voor U Aangesig geoordeel word!	",
"	20 o JaHWeH, jaag hulle skrik aan; laat die nasies weet, hulle is sterflinge!Sela.	",
	
]
},
{
book: 'Psalms',
chapter: '10',
content: [
	
"	1 O JaHWeH, waarom staan U so ver weg [en] hou U verborge in tye van besoedeling?	",
"	2 In sy trotsheid vervolg die besoedelde die behoeftige. Laat hulle gegryp word oor die listige planne wat hulle uitgedink het!	",
"	3 Want die besoedelde spog oor die begeerte van sy siel; en hy seën hom wat geplunder het, hy verag JaHWeH.	",
"	4 Die besoedelde, met sy neus in die hoogte, sê: Hy ondersoek nie: daar is geen Elohim nie - dit is al sy gedagtes!	",
"	5 Sy weë is altyd voorspoedig; hoog daarbo is U Reg, weg van hom af; al sy teëstanders - hy blaas op hulle.	",
"	6 Hy sê in sy hart: Ek sal nie wankel nie; van geslag tot geslag [is ek] die een wat nie in die ellende sal wees nie.	",
"	7 Sy mond is vol van vloek en van bedrog en verdrukking; onder sy tong is moeite en onreg.	",
"	8 Hy sit in die hinderlae by die dorpe; in skuilplekke maak hy die onskuldige dood; sy oë loer op die ellendige.	",
"	9 Hy loer in die skuilhoek soos ’n leeu in sy lêplek; hy loer om die ellendige te vang; hy vang die ellendige deur sy net toe te trek;	",
"	10 en verbryseld sink dié terneer, en die ellendiges val in sy mag.	",
"	11 Hy sê in sy hart: El het Haar vergeet; Hy het Sy Aangesig verberg; Hy sal Haar vir ewig nie sien nie.	",
"	12 Staan op, JaHWeH! O El, hef U Hand op; vergeet die ellendiges nie!	",
"	13 Die besoedelde, waarom verag hy Elohim en sê in sy hart: U soek Haar nie?	",
"	14 U het Haar gesien; want U aanskou die moeite en verdriet, sodat ’n mens Haar in U Hand sal gee. Aan U gee die ellendige Haar oor; U was ’n helper van die Wees.	",
"	15 Verbreek die arm van die besoedelde en sy besoedeling; besoek sy besoedeling [totdat] U niks vind nie!	",
"	16 JaHWeH is Koning vir Ewig tot in Ewigheid; nasies is vernietig uit Sy Aarde.	",
"	17 JaHWeH, U het die begeerte van die ootmoediges gehoor; U sal hulle hart versterk, U Oor sal luister	",
"	18 om aan die Wees en Verdrukte Reg te doen. Geen sterfling uit die Aarde sal langer voortgaan om skrik aan te jaag nie.	",
	
]
},
{
book: 'Psalms',
chapter: '11',
content: [
		
"	1 BY JaHWeH skuil Ek. Hoe kan julle dan vir My Siel sê: Vlug na julle berg soos ’n voël!	",
"	2 Want kyk, die besoedelde span die boog; hulle het hul pyl op die snaar reggesit om in die donker te skiet na die opregtes van hart.	",
"	3 As die fondamente omgegooi word, wat kan die regverdige doen?	",
"	4 JaHWeH is in die Tempel van Sy Apartheid; die Troon van JaHWeH is in die Hemele; Sy Oë sien, Sy Ooglede toets die seuns van adam.	",
"	5 JaHWeH toets die regverdige; maar Sy Siel haat die besoedelde en die wat geweld liefhet.	",
"	6 Hy sal op die besoedelde strikke, vuur en swawel laat reën; ’n Gees van Verterende Vuur sal die deel van hulle beker wees.	",
"	7 Want JaHWeH is regverdig; Hy het dade van Geregtigheid lief; die opregtes sal Sy Aangesig sien.	",
	
]
},
{
book: 'Psalms',
chapter: '12',
content: [
	
"	1 RED, o JaHWeH, want daar is geen toegewyde meer nie; want die getroues het verdwyn uit die seuns van adam.	",
"	2 Hulle praat leuens, die een met die ander; met vleiende lippe spreek hulle dubbelhartig.	",
"	3 Mag JaHWeH al die vleiende lippe uitroei, die tong wat grootpraat,	",
"	4 hulle wat sê: Met ons tong is ons sterk; ons lippe is met ons! Wie is meester oor ons?	",
"	5 Oor die verdrukking van die ellendiges, oor die gesug van die behoeftiges sal Ek nou opstaan, sê JaHWeH; Ek sal hom die Lossing gee wat daarna smag.	",
"	6 Die Woorde van JaHWeH is suiwer woorde, Silwer wat gelouter is in ’n smeltkroes in die Aarde, gesuiwer sewe maal. [2 Konings 5:10; Spreuke 10:20; JôWEl 3:5; Hoséa 9:6]	",
"	7 U, o JaHWeH, sal hulle bewaar; U sal Ons bewaar van hierdie geslag vir ewig.	",
"	8 Die besoedeldes draf rond as die nikswerd die oorhand kry by die seuns van adam.	",
	
]
},
{
book: 'Psalms',
chapter: '13',
content: [
	
"	1 HOE lank, JaHWeH, sal U My altyddeur vergeet? Hoe lank sal U vir My U Aangesig verberg?	",
"	2 Hoe lank sal Ek planne beraam in My Siel, [met] kommer in My hart oordag? Hoe lank sal My vyand hom oor My verhef?	",
"	3 Aanskou tog, verhoor My, JaHWeH, My Elohey! Verlig My oë, sodat Ek nie in die Dood vertoef nie;	",
"	4 sodat My vyand nie kan sê: Ek het Hom oorwin nie, [en] My teëstanders nie juig as Ek wankel nie.	",
"	5 Maar Ek - op U Barmhartigheid vertrou Ek; My hart sal juig oor U Verlossing.	",
"	6 Ek wil JaHWeH besing, omdat HY aan My goed gedoen het.	",
	
]
},
{
book: 'Psalms',
chapter: '14',
content: [
	
"	1 DIE dwaas sê in sy hart: Daar is geen Elohim nie. Sleg, afskuwelik maak hulle [hul] dade; daar is niemand wat suiwer optree nie. [2 Ezra 8:58]	",
"	2 JaHWeH het uit die Hemele neergesien op die seuns van adam, om te sien of daar iemand verstandig is, wat na Elohim vra.	",
"	3 Hulle het almal afgewyk, tesame het hulle verkleur; daar is niemand wat suiwer optree nie, ook nie een nie.	",
"	4 Het al die bewerkers van Ongeregtigheid dan geen Kennis nie, die wat My volk opeet [asof] hulle brood eet? Hulle roep JaHWeH nie aan nie.	",
"	5 Dáár het skrik hulle oorweldig, want Elohim is by die regverdige geslag.	",
"	6 Die Raad van die ellendige - julle het Haar tot skande gemaak; waarlik, JaHWeH is sy toevlug.	",
"	7 Ag, mag die Verlossing van JisraEl uit Sion kom! As JaHWeH die lot van Sy volk verander, dan sal Jakob juig, JisraEl sal bly wees.	",

]
},
{
book: 'Psalms',
chapter: '15',
content: [
	
"	1 JaHWeH, wie mag vertoef in U Tent? Wie mag woon in die berg van U Apartheid?	",
"	2 Hy wat rassuiwer wandel en Geregtigheid doen, en wat met sy hart die Waarheid spreek;	",
"	3 wat nie rondgaan met laster op sy tong nie, sy vriend geen kwaad doen en geen besoedeling uitspreek teen sy naaste nie;	",
"	4 in wie se oë die veragtelike veragtelik is, maar hy eer die wat JaHWeH vrees; al het hy gesweer tot sy skade, hy verander nie;	",
"	5 wat sy geld nie gee op woeker en geen omkoopgeskenk aanneem teen die onskuldige nie. Hy wat hierdie dinge doen, sal nie wankel in ewigheid nie. [Lukas 16:9]	",

]
},
{
book: 'Psalms',
chapter: '16',
content: [
		
"	1 BEWAAR My, o El, want by U skuil Ek.	",
"	2 Ek het tot JaHWeH gesê: U is My Meester; vir My is daar geen suiwere bo U nie.	",
"	3 [Maar] aangaande die Apartes wat op die Aarde is, [sê Ek]: Hulle is die heersers in wie al My behae is.	",
"	4 Die smarte van hulle wat ’n ander met gawes vereer, sal menigvuldig wees; Ek sal hulle dranke van bloed nie uitgiet en hulle name op My lippe nie neem nie.	",
"	5 JaHWeH is die deel van My Erfenis en van My Beker; U onderhou My lot.	",
"	6 Die meetsnoere het vir My in lieflike plekke geval, ja, My Erfenis is vir My mooi.	",
"	7 Ek sal JaHWeH loof wat My raad gegee het; selfs in die nag vermaan My niere My.	",
"	8 Ek stel JaHWeH altyddeur voor My; omdat [Hy] aan My regterhand is, sal Ek nie wankel nie.	",
"	9 Daarom is My hart bly en My eer juig; ook sal My vlees in veiligheid woon;	",
"	10 want U sal My Siel aan die Doderyk/Sheol nie oorgee nie; U sal nie toelaat dat U Toegewyde verderwing sien nie.	",
"	11 U sal My die Pad van die Lewe bekend maak; versadiging van Vreugde is voor U Aangesig, lieflikhede in U Regterhand, vir ewig.	",

]
},
{
book: 'Psalms',
chapter: '17',
content: [
		
"	1 LUISTER na regverdigheid JaHWeH, let op My smeking; luister tog na My gebed met onbedrieglike lippe.	",
"	2 Laat My Reg van U Aangesig uitgaan; laat U Oë regverdig sien.	",
"	3 U het My hart getoets, haar in die nag ondersoek, U het My gekeur, U vind niks nie; wat Ek ook dink, My mond oortree nie.	",
"	4 Aangaande die handelinge van die adamiete, Ek het deur die Woord van U Lippe die paaie van die geweldenaar vermy.	",
"	5 My gange het vasgehou aan U spore, My voetstappe het nie gewankel nie.	",
"	6 Ek roep U aan, want U verhoor My, o El! Neig U oor tot My, luister na My woord!	",
"	7 Maak U gunsbewyse wonderbaar, o Verlosser van die wat by U Regterhand skuil vir teëstanders!	",
"	8 Bewaar My soos ’n Oogappel; verberg My in die skaduwee van U Vleuels	",
"	9 teen die besoedelde wat My geweld aandoen, My Sielsvyande wat My omring.	",
"	10 Hulle het hul gevoel afgesluit; met hul mond spreek hulle hoogmoedig.	",
"	11 Nou het hulle Ons in Ons gang omsingel; hulle rig hul oë daarop om Ons op die Aarde uit te strek.	",
"	12 Hy is soos ’n leeu wat begerig is om te verskeur, en soos ’n jong leeu wat in skuilplekke klaar lê.	",
"	13 Staan op, JaHWeH, gaan hom tegemoet, werp hom neer; red My Siel van die besoedelde met U Swaard;	",
"	14 met manne van U Hand, o JaHWeH, met manne wie se deel in die lewe uit hierdie wêreld is en wie se binneste U vul met U verborgenhede; wie se seuns met Haar vervul word, en wat weer die oorblyfsel aan hulle kinders agterlaat.	",
"	15 Maar Ek sal U Aangesig deur Geregtigheid aanskou; Ek sal tevrede wees wanneer Ek wakker word met U Gestalte.	",

]
},
{
book: 'Psalms',
chapter: '18',
content: [
	
"	1 EN gesê: Ek het U hartlik lief, JaHWeH, My Sterkte.	",
"	2 JaHWeH is My Rots en My Bergvesting en My Redder; My El, My Rots by wie Ek skuil; My Skild en die Horing van My Lossing, My Hoë Toring.	",
"	3 Ek roep JaHWeH aan wat lofwaardig is, en van My vyande word Ek verlos.	",
"	4 Bande van die Dood het My omring, en ‘n stortvloed van Belijaal-mense het My oorval.	",
"	5 Bande van die Doderyk/Sheol was rondom My; strikke van die Dood het My teëgekom.	",
"	6 Toe Ek benoud was, het Ek JaHWeH aangeroep, en Ek het tot My Elohey geroep om hulp; Hy het My Stem uit Sy Tempel gehoor, en My hulpgeroep voor Sy Aangesig het in Sy Ore gekom.	",
"	7 Toe het die Aarde geskud en gebewe; die fondamente van die berge het gesidder en geskud, omdat Hy toornig was.	",
"	8 Rook van Woede het opgegaan, en ’n Vuur uit Sy Mond het verteer; kole uit Hom het gebrand.	",
"	9 En Hy het die Hemele gebuig en neergedaal, en donkerheid was onder Sy voete.	",
"	10 En Hy het op ’n Gérub gery en gevlieg; ja, Hy het gesweef op die Vleuels van die Gees.	",
"	11 Duisternis het Hy in sy skuilplek geplaas, sy takskuiling rondom Hom, die swart waters, donker wolke van mis.	",
"	12 Deur die glans voor Hom het Sy Wolkkolom verbygetrek, hael en gloeiende kole.	",
"	13 En JaHWeH het in die Hemele gedonder, en die Hoogste El het SY Stem laat hoor; hael en gloeiende kole.	",
"	14 En HY het SY Pyle uitgestuur en hulle verstrooi; ja, SY Bliksems in menigte, en HY het hulle verwar.	",
"	15 En die beddings van die waters het sigbaar geword, en die fondamente van die wêreld is blootgelê vanweë U dreiging, o JaHWeH, vanweë die geblaas van die Gees van U Woede.	",
"	16 HY het uit die hoogte uitgestrek, Hy het My gegryp, Hy het My uit groot waters getrek.	",
"	17 Hy het My verlos van My magtige vyand en van My haters, omdat hulle te sterk was vir My. [Hooglied 1:6]	",
"	18 Hulle het My oorval op die dag van My nood; maar JaHWeH was My steun.	",
"	19 En Hy het My uitgelei in die ruimte; Hy het My gered, omdat Hy behae in My gehad het.	",
"	20 JaHWeH het met My gehandel na My Geregtigheid; Hy het My vergelde na die suiwerheid van My hande.	",
"	21 Want Ek het dieWeë van JaHWeH gehou en nie besoedeld afgewyk van My Elohey nie;	",
"	22 want al Sy Verordeninge was voor My, en Sy Insettinge het Ek nie van My verwyder nie.	",
"	23 Maar Ek was rassuiwer voor Hom, en Ek het myself weerhou van ontugtigheid. [Judas 1:4]	",
"	24 So het JaHWeH My dan vergelde na My wetsgehoorsaamheid, na die suiwerheid van My hande, voor Sy Oë.	",
"	25 By die Getroue openbaar U Uself liefderyk, by die rassuiwer man van opregtheid, volkome,	",
"	26 by die Suiwere, openbaar U Uself suiwer; maar by die verdraaide betoon U Uself verdraaid. [JirmeJaH 23:39]	",
"	27 Want U verlos die verdrukte volk; maar U verneder die oë wat hoogmoedig is.	",
"	28 Want U laat My Lamp skyn; JaHWeH My Elohey verlig My Duisternis.	",
"	29 Want met U loop Ek ’n bende storm, en met My Elohey spring Ek oor ’n muur.	",
"	30 Die Weg van die Elohey is rassuiwerheid; die Woord van JaHWeH is gelouter; Hy is ’n Skild vir almal wat by Hom skuil. [Psalm 5:8; 67:2; Odes van Salomo 39:13; Spreuke van Salomo 16:31; 30:5; JeshaJaH 30:21; 35:8;48:17; JirmeJaH 21:8; Profesie van Barug 3:13, 21]	",
"	31 Want wie is Elowahh buiten JaHWeH, en wie is ’n Rots behalwe Onse Elohey?	",
"	32 El is Hy wat My met Krag omgord om My lewenswandel rassuiwer te hou.	",
"	33 Hy maak My voete soos dié van herte en laat My staan op My Hoogtes.	",
"	34 Hy leer My hande om oorlog te voer, sodat My arms ’n koperboog span.	",
"	35 Ook het U My die Skild van U Lossing gegee, en U Regterhand het My ondersteun, en U neerbuigende Suiwerheid het My groot gemaak.	",
"	36 U het My voetstap ruim gemaak onder My, en My enkels het nie gewankel nie.	",
"	37 Ek het My vyande agtervolg en hulle ingehaal, en Ek het nie teruggekom voordat Ek hulle vernietig het nie.	",
"	38 Ek het hulle verbrysel, sodat hulle nie kon opstaan nie; hulle het geval onder My voete.	",
"	39 En U het My met Krag omgord vir die stryd; U het My teëstanders onder My laat buk.	",
"	40 En U het My vyande vir My laat vlug; en My haters, dié het Ek vernietig.	",
"	41 Hulle het geroep om hulp, maar daar was geen verlosser nie - tot JaHWeH, maar Hy het hulle nie geantwoord nie.	",
"	42 Toe het Ek hulle vermaal soos stof voor die wind; Ek het hulle uitgegooi soos modder van die strate.	",
"	43 U het My gered uit die getwis van die volk; U het My ’n Hoof gemaak van nasies; ’n volk wat Ek nie geken het nie, het My gedien.	",
"	44 Sodra hulle van My gehoor het, was hulle My gehoorsaam, seuns van die uitlander het kruipende na My gekom.	",
"	45 Seuns van die uitlander word kragteloos en kom met siddering uit hulle vestings.	",
"	46 JaHWeH leef! En geloofd sy My Rots, en laat verhoog wees die Elohim van My  Lossing!	",
"	47 Die El wat My die wraak gee en volke aan My onderwerp;	",
"	48 wat My red van My vyande; ja, U verhef My bo My teëstanders; U bevry My van die man van geweld.	",
"	49 Daarom wil Ek U loof, o JaHWeH, onder die nasies, en tot eer van U Naam wil Ek musiek maak.	",
"	50 Hy wat Groot Verlossinge gee aan Sy Koning en Medelye betoon aan Sy Gesalfde, aan Dawid en aan Sy saad tot in Ewigheid.	",

]
},
{
book: 'Psalms',
chapter: '19',
content: [
		
"	1 DIE Hemele vertel die Eer van El, en die Koepel verkondig die werk van Sy Hande.	",
"	2 Die een dag stort vir die ander ’n boodskap uit, en die een nag kondig vir die ander kennis aan:	",
"	3 daar is geen spraak en daar is geen woorde nie - onhoorbaar is hulle stem.	",
"	4 Hulle meetsnoer gaan uit oor die hele Aarde, en hulle woorde tot by die einde van die wêreld. Vir die son het Hy in haar ’n Tent gemaak;	",
"	5 Hy is soos ’n Bruidegom wat uitgaan uit Sy slaapkamer; Hy is bly soos ’n dappere om die pad te loop.	",
"	6 Sy uitgang is van die einde van die Hemele af, en Sy omloop tot by die eindes daarvan, en niks is verborge vir Sy hitte nie.	",
"	7 Die Wet van JaHWeH is rasegtheid: sy laat die siel terugkeer; die Getuienis van JaHWeH is betroubaar: Sy gee Wysheid aan die eenvoudige.	",
"	8 Die bevele van JaHWeH is Reg: hulle verbly die hart; die Gebooie van JaHWeH is suiwer: sy verlig die oë.	",
"	9 Die Vrees vir JaHWeH is suiwerheid: Sy bestaan tot in ewigheid; die Verordeninge van JaHWeH is Waarheid - tesame is hulle regverdigheid.	",
"	10 Hulle is begeerliker as goud, ja, as baie fyn goud; en soeter as heuning en heuningstroop.	",
"	11 Ook word U kneg daardeur gewaarsku; in die onderhouding daarvan is groot loon.	",
"	12 Die afdwalinge - wie bemerk hulle? Spreek My vry van die wat verborge is.	",
"	13 Hou U kneg ook terug hoogmoedigheid; laat hy nie oor My heers nie. Dan sal Ek onbestraflik wees en vry van groot oortreding.	",
"	14 Laat die woorde van My mond en die oordenking van My hart welbehaaglik wees voor U Aangesig, o JaHWeH, My Rots en My Verlosser!	",

]
},
{
book: 'Psalms',
chapter: '20',
content: [
		
"	1 MAG JaHWeH U verhoor in die dag van benoudheid! Mag die Naam van die Elohey van Jakob U beskerm!	",
"	2 Mag HY U Hulp stuur uit die Apartheid en U ondersteun uit Sion!	",
"	3 Mag HY dink aan al U spysbydraes en U brandoffer met welgevalle aansien!Sela.	",
"	4 Mag HY U gee na U hart en al U voornemens vervul!	",
"	5 Ons wil juig oor U Verlossing en die vaandels opsteek in die Naam van Onse Elohey. Mag JaHWeH al U begeertes vervul!	",
"	6 Nou weet Ek dat JaHWeH SY Gesalfde verlos; HY sal Hom verhoor uit die Hemele van SY Apartheid, met magtige dade van Lossing van SY Regterhand.	",
"	7 Sommige [roem] op strydwaens en ander op perde, maar Ons sal roem op die Naam van JaHWeH Onse Elohey.	",
"	8 Húlle het inmekaar gesak en geval, maar Ons het opgestaan en Ons weer opgerig.	",
"	9 JaHWeH, verlos die Koning! Mag Hy Ons verhoor op die dag as Ons roep!	",

]
},
{
book: 'Psalms',
chapter: '21',
content: [
		
"	1 O JaHWeH, die Koning is bly oor U Sterkte, en hoe baie juig Hy oor U Verlossing!	",
"	2 U het Hom die wens van Sy Hart gegee en die begeerte van Sy Lippe nie geweier nie.Sela.	",
"	3 Want U kom Hom tegemoet met seëninge van Suiwerheid; op Sy hoof sit U ’n Kroon van fyn goud. [Klaagliedere 4:2]	",
"	4 Die lewe het Hy van U begeer; U het dit vir Hom gegee: lengte van dae, vir Ewig tot in Ewigheid.	",
"	5 Groot is Sy Glansrykheid deur U Verlossing; Majesteit en Eer het U op Hom gelê.	",
"	6 Want U maak Hom baie geseënd vir ewig; U maak Hom bly met Vreugde by U Aangesig.	",
"	7 Want die Koning vertrou op JaHWeH, en deur die Medelye van die Hoogste El sal Hy nie wankel nie.	",
"	8 U Hand sal al U vyande vind; U Regterhand sal U haters vind.	",
"	9 U sal hulle maak soos ’n vurige oond as U verskyn; JaHWeH sal hulle verslind, Sy Toorn en Vuur sal hulle verteer.	",
"	10 U sal hulle vrug van die Aarde af verdelg en hulle saad uit die seuns van Adam af weg.	",
"	11 Want hulle het U met besoedeling bedreig; hulle het ’n listige plan uitgedink sonder om iets uit te rig.	",
"	12 Want U sal hulle dwing om te vlug; met U oorblyfsel sal U mik op hulle gesig.	",
"	13 Verhef U, JaHWeH, in U Sterkte; Ons wil U Sterkte eer met psalmgesang!	",
		

]
},
{
book: 'Psalms',
chapter: '22',
content: [
	
"	1 MY El, My El, waarom het U My verlaat, My Verlossing is ver [van] die woorde van My gebrul? [MattithJaHûW 27:46]	",
"	2 My Elohey, Ek roep bedags, maar U antwoord nie; en snags, en Ek kan nie swyg nie.	",
"	3 Tog is U die Aparte wat woon onder die lofsange van JisraEl!	",
"	4 Op U het Ons vaders vertrou; hulle het vertrou, en U het hulle uitgered. [Wysheid 10;15-21]	",
"	5 Hulle het U aangeroep en het ontvlug; op U het hulle vertrou en nie beskaamd gestaan nie.	",
"	6 Maar Ek is ’n wurm en geen man nie, ’n smaad van die adamiete en verag deur die volk.	",
"	7 Almal wat My sien, spot met My; hulle steek die lip uit, hulle skud die hoof [en sê]:	",
"	8 Laat Hom aan JaHWeH oor! Laat HY Hom red, laat HY Hom bevry: HY het mos behae in Hom! [MattithJaHûW 27:39]	",
"	9 Ja, U is Hy wat My uit die moederskoot uitgetrek het, wat My veilig laat rus het aan My moeder se bors. [Odes van Salomo 19]	",
"	10 Aan U is Ek oorgegee van die geboorte af; van die skoot van My moeder af is U My El.	",
"	11 Wees nie ver van My af nie, want die nood is naby, want daar is geen Helper nie.	",
"	12 Baie stiere het My omsingel, sterkes van Basan het My omring. [Psalm 86:14]	",
"	13 Hulle het hul mond teen My oopgespalk soos ’n leeu wat verskeur en brul. [MattithJaHûW 27:31]	",
"	14 Ek is uitgestort soos water; al My beendere raak los; My hart het soos was geword; sy het gesmelt binne-in My ingewande. [Odes van Salomo 28]	",
"	15 My Krag is verdroog soos ’n potskerf, en My tong kleef aan My verhemelte; en U lê My neer in die stof van Dood. [MattithJaHûW 27:34,48]	",
"	16 Want honde het My omsingel; ’n bende kwaaddoeners het My omring; hulle het My hande en My voete deurboor. [Lukas 23:35]	",
"	17 Al My beendere kan Ek tel; hulle kyk, hulle sien met welgevalle op My neer!	",
"	18 Hulle verdeel My klere onder mekaar en werp die lot oor My gewaad. [Lukas 23:34; MattithJaHûW 27:35; JeHôWganan 19:24]	",
"	19 Maar U, JaHWeH, wees nie ver nie; My Sterkte, maak tog gou om My te help!	",
"	20 Red My Siel van die swaard, My enigste uit die mag van die hond.	",
"	21 Verlos My uit die bek van die leeu, en uit die horings van die eenhorings het U My verhoor!	",
"	22 Ek wil U Naam aan My broers vertel, in die midde van die vergadering sal Ek U prys.	",
		
"	23 Julle wat JaHWeH vrees, prys Hom! Al die saad van Jakob, vereer Hom! Ja, vrees Hom! al die saad van JisraEl!	",
"	24 Want HY het die ellende van die Ellendige nie verag of verfoei en SY Aangesig vir Hom nie verberg nie; maar HY het gehoor toe Hy HOM aangeroep het om hulp.	",
"	25 Van U kom My lof in ’n groot vergadering; Ek sal My Geloftes betaal in die teenwoordigheid van die wat Hom vrees.	",
"	26 Die ootmoediges sal eet en versadig word; húlle sal JaHWeH prys wat na Hom soek; mag julle Hart vir ewig lewe! [TsefánJaH 3:12]	",
"	27 Die Einde van die Aarde sal daaraan dink en hulle tot JaHWeH bekeer, en al die stamme van die nasies sal voor U Aangesig neerval.	",
"	28 Want die Koninkryk behoort aan JaHWeH en Hy heers oor die nasies.	",
"	29 Al die vettes van die Aarde sal eet en neerval; almal wat in die stof neerdaal, sal voor Sy Aangesig kniel, want niemand kan sy siel in die lewe hou nie.	",
"	30 ’n Saadlyn sal Hom dien; dit sal vertel word van My Meester aan die [volgende] geslag.	",
"	31 Hulle sal aankom en Sy Geregtigheid verkondig aan die volk wat gebore word; want Hy het dit gedoen.	",
	
]
},
{
book: 'Psalms',
chapter: '23',
content: [
		
"	1 JaHWeH is my Herder; niks sal my ontbreek nie.	",
"	2 Hy laat my neerlê in groen weivelde; na waters waar rus is, lei Hy my heen.	",
"	3 Hy verkwik my Siel; Hy lei my in die spore van Geregtigheid, om Sy Naam ontwil.	",
"	4 Al gaan ek ook in die dal van Doodskaduwee, ek sal geen besoedeling vrees nie; want U is met my: U Septer en U Staf dié vertroos my.	",
"	5 U berei die tafel voor my Aangesig teenoor my teëstanders; U maak my hoof vet met olie; my Beker loop oor.	",
"	6 Net Suiwerheid en Guns sal my volg al die dae van my lewe; en ek sal in die Huis van JaHWeH bly in lengte van dae.	",

]
},
{
book: 'Psalms',
chapter: '24',
content: [
		
"	1 DIE Aarde behoort aan JaHWeH en die volheid van haar, die wêreld en die wat in haar woon;	",
"	2 want Hy het haar gegrond op die seë en haar vasgestel op die strome.	",
"	3 Wie mag klim op die Berg van JaHWeH? En wie mag in die gebied van Sy Apartheid staan?	",
"	4 Hy wat skoon van handpalms en suiwer van hart is, wat sy siel nie ophef tot leuens en nie vals sweer nie.	",
"	5 Hy sal seën wegdra van JaHWeH en Geregtigheid van die Elohey van Sy Lossing.	",
"	6 Dit is die geslag van hulle wat na Hom vra, wat U Aangesig soek – [dit is] Jakob.Sela.	",
"	7 Hef op julle hoofde, o poorte, ja, verhef julle, ewige deure, dat die Erekoning kan ingaan!	",
"	8 Wie is tog die Erekoning? JaHWeH, sterk en geweldig, JaHWeH geweldig in die stryd.	",
"	9 Hef op julle hoofde, o poorte, ja, hef op, ewige deure, dat die Erekoning kan ingaan! [2 Nikodémus 5:3(b)]	",
"	10 Wie is dan tog die Erekoning? JaHWeH van die skeppings-leërmagte - Hy is die Erekoning! Sela.[2 Nikodémus 5:3]	",

]
},
{
book: 'Psalms',
chapter: '25',
content: [
	
"	1 [a Alef.] Tot U, o JaHWeH, hef ek my siel op.	",
"	2 [B Bet.] my Elohey, op U vertrou ek; laat my nie beskaamd staan nie; laat my vyande oor my nie juig nie.	",
"	3 [G Ghimel.] Ja, almal wat U verwag, sal nie beskaamd staan nie. Hulle sal beskaamd staan wat verraai sonder oorsaak.	",
"	4 [D Dalet.] JaHWeH, maak my U Weë bekend; leer my U Paaie.	",
"	5 [h’ Hé.] Lei my in U Waarheid en leer my, want U is die Elohey van my Lossing. U verwag ek die hele dag.	",
"	6 [z Zajin.] Dink, JaHWeH, aan U Barmhartigheid en U Medelye, want Hulle is van ewigheid af.	",
"	7 [j’ Get.] Dink nie aan die oortredinge van my jonkheid en aan my opstandigheid nie; dink aan my na U Medelye, om U Suiwerheid ontwil, o JaHWeH! [Hooglied 1:6]	",
"	8 [fo Tet.] JaHWeH is Suiwer en Reg; daarom sal HY oortreders leer aangaande die Weg.	",
"	9 [y” Jod.] Hy sal die ootmoediges lei in die Reg en die ootmoediges SY Weg leer.	",
"	10 [K Kaf.] Al die Paaie van JaHWeH is vol Barmhartigheid en Waarheid vir die wat Sy Verbond en Sy Getuienisse bewaar.	",
"	11 [l Lamed.] Om U Naam ontwil, JaHWeH, vergeef my oortreding, want dit is groot.	",
"	12 [m  Mem.] Wie tog is die man wat JaHWeH vrees? HY sal hom leer aangaande die Weg wat hy moet kies.	",
"	13 [n Noen.] Sy siel self sal vernag in Suiwerheid, en sy saad sal die Adamah [die adamiet se Aarde] besit.	",
"	14 [s Samek.] Die verborgenhede van JaHWeH is vir die wat Hom vrees, en Sy Verbond om hulle [dit] bekend te maak.	",
"	15 [[ Ajin.] my oë is voortdurend op JaHWeH, want Hy sal my voete uit die net uitlei.	",
"	16 [P Pé.] Wend U tot my en wees my barmhartig, want ek is eensaam en ellendig.	",
"	17 [x Tzadé.] Die benoudhede van my hart is wyd uitgestrek; lei my uit my angste.	",
"	18 [r Resj.] Aanskou my ellende en my moeite, en vergeef al my oortredinge.	",
"	19 [r Resj.]. Aanskou my vyande, want hulle is talryk, en hulle haat my met ’n gewelddadige haat.	",
"	20 [v Sjin.]Bewaar my siel en red my; laat my nie beskaamd staan nie, want by U skuil ek.	",
"	21 [To Taw.] Laat rassuiwere, opregtheid my bewaar, want U verwag ek.	",
"	22 O Elohim, verlos JisraEl uit al sy benoudhede!	",

]
},
{
book: 'Psalms',
chapter: '26',
content: [
		
"	1 DOEN aan My Reg, o JaHWeH, want Ek wandel raseg en vertrou op JaHWeH sonder om te wankel.	",
"	2 Toets My, JaHWeH, en beproef My, keur My niere en My hart;	",
"	3 want U Medelye is voor My oë, en Ek wandel in U Waarheid.	",
"	4 Ek sit nie by bedrieglike persone nie, en met geheimsinniges gaan Ek nie om nie.	",
"	5 Ek haat die vergadering van besoedeldes, en by die besoedelde sit Ek nie.	",
"	6 Ek was My handpalms in onskuld en wil gaan rondom U altaar, o JaHWeH,	",
"	7 om die stem van dank te laat hoor en om al U wonders te vertel.	",
"	8 JaHWeH, Ek het lief die Woning van U Huis en die  Tabernakel van U Glansrykheid.	",
"	9 Ruk My Siel nie weg saam met die oortreders en My lewe saam met die manne van bloed nie,	",
"	10 in wie se hande bloedvermenging is, en wie se regterhand vol is van omkopery.	",
"	11 Maar Ek wandel raseg; verlos My en wees My barmhartig.	",
"	12 My voet staan op gelyk grond; Ek sal JaHWeH loof in die vergaderings.	",
	
]
},
{
book: 'Psalms',
chapter: '27',
content: [
		
"	1 JaHWeH is My Lig en My Lossing: vir wie sou Ek vrees? JaHWeH is die vesting van My lewe: vir wie sou Ek vervaard wees?	",
"	2 As kwaaddoeners teen My nader kom om My Vlees te eet - My teëstanders en My vyande, ja, Myne - struikel hulle self en val.	",
"	3 Al word ’n laer teen My opgeslaan, My Hart sal nie vrees nie; al staan ’n oorlog teen My op, nogtans vertrou Ek.	",
"	4 Een ding het Ek van JaHWeH begeer, dit sal Ek soek: dat Ek al die dae van My lewe mag woon in die Huis van JaHWeH, om die Lieflikheid van JaHWeH te aanskou en te ondersoek in Sy Tempel.	",
"	5 Want Hy steek My weg in Sy Hut in die dag van besoedeling; Hy verberg My in die skuilplek van Sy Tent; Hy verhef My op die Rots.	",
"	6 En nou sal My hoof hoog wees bo My vyande rondom My, en Ek wil in Sy Tent ‘n slagdier slag saam met krygsgeskreeu; Ek wil sing, ja, musiek maak tot eer van JaHWeH.	",
"	7 Hoor, o JaHWeH, Ek roep luid; en wees My barmhartig en antwoord My.	",
"	8 Van U sê My Hart: Soek My Aangesig! Ek soek U Aangesig, o JaHWeH!	",
"	9 Verberg U Aangesig nie vir My nie, wys U Kneg nie af in toorn nie: U was My hulp! Verstoot en verlaat My nie, o Elohey van My Lossing!	",
"	10 Want My vader en My moeder het My verlaat, maar JaHWeH sal My aanneem.	",
"	11 JaHWeH, leer My U Weg en lei My op ’n gelyk pad, vanweë My vyande.	",
"	12 Gee My nie oor aan die siel van My teëstanders nie, want valse getuies het teen My opgestaan, en hy wat geweld uitblaas. [MattithJaHûW 26:61]	",
"	13 o, As Ek nie geglo het dat Ek die Suiwerheid van JaHWeH sal sien in die Adamah [die adamiet se Aarde] van die lewendes nie.	",
"	14 Wag op JaHWeH! Wees sterk en laat jou hart sterk wees! Ja, wag op JaHWeH!	",
	
]
},
{
book: 'Psalms',
chapter: '28',
content: [
	
"	1 EK roep U aan, o JaHWeH! My Rots, draai nie stilswygend van My af weg nie, sodat Ek nie, as U teenoor My bly swyg, word soos Een wat in die kuil neerdaal nie.	",
"	2 Luister na die Stem van My smekinge as Ek U aanroep om hulp, as Ek My hande ophef na die binneste van U Apartheid	",
"	3 Ruk My nie weg saam met die besoedelde en saam met die bewerkers van Ongeregtigheid nie; wat van vrede spreek met hulle naaste, maar daar is besoedeling in hulle hart.	",
"	4 Gee hulle na hul dade en na die besoedeling van hul handelinge; gee hulle na die werk van hul hande; vergeld hulle na hulle dade.	",
"	5 Omdat hulle nie let op die dade van JaHWeH, of op die werk van Sy Hande nie, sal Hy hulle afbreek en hulle nie bou nie.	",
"	6 Geloofd sy JaHWeH, want Hy het die Stem van My smekinge gehoor.	",
"	7 JaHWeH is My Sterkte en My Skild; op Hom het My Hart vertrou, en Ek is gehelp; daarom jubel My Hart en sal Ek Hom loof met My gesang.	",
"	8 JaHWeH is Sterkte, en Hy is ’n vesting van Verlossing vir Sy Gesalfde.	",
"	9 Verlos U volk en seën U Erfdeel, en wees vir hulle ’n Herder en dra hulle tot in ewigheid.	",

]
},
{
book: 'Psalms',
chapter: '29',
content: [
	
"	1 GEE aan JaHWeH, o seuns van El, gee aan JaHWeH Eer en Sterkte!	",
"	2 Gee aan JaHWeH die Eer van Sy Naam; buig neer vir JaHWeH in die prag van Apartheid!	",
"	3 Die Stem van JaHWeH is op die waters, die El van Eer donder; JaHWeH is op die groot waters.	",
"	4 Die Stem van JaHWeH is met Krag; die Stem van JaHWeH is met Glansrykheid.	",
"	5 Die Stem van JaHWeH breek seders; ja, JaHWeH verbreek die seders van die Líbanon;	",
"	6 en Hy laat hulle spring soos ’n kalf, die Líbanon en Sirjon soos ’n jong eenhoring.	",
"	7 Die Stem van JaHWeH laat vuurvlamme uitslaan.	",
"	8 Die Stem van JaHWeH laat die woestyn bewe; JaHWeH laat die wildernis van Kadesh bewe.	",
"	9 Die Stem van JaHWeH laat die takbokke lam en stroop die bosse; maar in Sy Tempel praat elkeen van Sy Glansrykheid!	",
"	10 JaHWeH het gesit oor die Watervloed; ja, JaHWeH sit as Koning tot in ewigheid.	",
"	11 JaHWeH sal Sy volk Sterkte gee, JaHWeH sal Sy volk seën met Vrede.	",

]
},
{
book: 'Psalms',
chapter: '30',
content: [
	
"	1 EK sal U verhoog, JaHWeH, want U het My opgetrek en My vyande oor My nie laat bly wees nie.	",
"	2 JaHWeH, My Elohey, Ek het U aangeroep om hulp, en U het My gesond gemaak.	",
"	3 JaHWeH, U het My Siel uit die Doderyk/Sheol laat opkom; U het My lewend gemaak uit die wat in die put neergedaal het. [2 Nikodemus 5:1]	",
"	4 Maak musiek tot eer van JaHWeH, o SY Toegewydes, en hef die hande op in dank aan die herinnering van SY Apartheid;	",
"	5 want vir ’n oomblik is Sy Toorn, ’n lewe in Sy goedgunstigheid; saans vernag die geween, maar smôrens is daar Vreugde.	",
"	6 Ek het wel onbevange gesê: Ek sal vir ewig nie wankel nie.	",
"	7 JaHWeH, U het My Berg deur U welbehae sterk laat staan. U het U Aangesig verberg - Ek het verskrik geword!	",
"	8 Ek het U aangeroep, JaHWeH, en Ek het My Meester gesmeek:	",
"	9 Watter voordeel is daar in My Bloed as Ek neerdaal in die kuil? Sal die stof U loof? Sal Sy U Waarheid bekend maak? [JeHôWganan 6:55-56; MattithJaHûW 26:28]	",
"	10 Hoor, JaHWeH, en wees My barmhartig! JaHWeH, wees My ’n Helper!	",
"	11 U het My weeklag vir My verander in ’n koordans, U het My roukleed losgemaak en My met Vreugde omgord; [JirmeJaH 6:26]	",
"	12 sodat [My] Eer U kan besing en nie swyg nie. JaHWeH, My Elohey, vir ewig sal Ek U loof.	",

]
},
{
book: 'Psalms',
chapter: '31',
content: [
		
"	1 BY U, o JaHWeH, skuil Ek; laat My nooit beskaamd staan nie. Bevry My deur U Geregtigheid.	",
"	2 Neig U Oor tot My, red My gou; wees vir My ’n laer om in te vlug, ’n baie vaste Huis om My te verlos.	",
"	3 Want U is My Rots en My Bergvesting; en om U Naam ontwil sal U My lei en My bestuur.	",
"	4 U sal My laat uitgaan uit die net wat hulle vir My gespan het, want U is My laer.	",
"	5 In U Hand gee Ek My Gees oor; U het My verlos, JaHWeH, El van Waarheid.	",
"	6 Ek haat die wat valse nietighede vereer, maar Ek vertrou op JaHWeH.	",
"	7 Ek wil juig en bly wees oor U Medelye, omdat U My ellende aangesien, My Siel in die benoudhede geken het	",
"	8 en My nie oorgelewer het in die hand van die vyand nie; U het My voete op vrye grond laat staan.	",
"	9 Wees My barmhartig, JaHWeH, want Ek is benoud; van verdriet het My oog mat geword, My Siel en My Liggaam.	",
"	10 Want My lewe kwyn weg van kommer en My jare van gesug; My krag struikel deur My ongeregtigheid, en My gebeente teer uit.	",
"	11 Vanweë al My teëstanders het Ek ’n voorwerp van smaad geword, ja, grootliks vir My bure, en ’n voorwerp van skrik vir My bekendes; die wat My op straat sien, vlug weg van My af.	",
"	12 Ek is vergeet uit die hart, soos ’n dooie; Ek het geword soos ’n ding wat lê en vergaan.	",
"	13 Want Ek het die skindertaal van baie gehoor - skrik rondom! - terwyl hulle saam raad hou teen My; hulle is van plan om My Siel te neem.	",
"	14 Maar Ek vertrou op U, o JaHWeH! Ek sê: U is My Elohey.	",
"	15 My tye is in U Hand; red My uit die hand van My vyande en van My vervolgers.	",
"	16 Laat U Aangesig skyn oor U Kneg, verlos My deur U Medelye.	",
"	17 JaHWeH, laat My nie beskaamd staan nie, want Ek roep U aan; laat die besoedelde beskaamd staan, laat hulle stilbly in die Doderyk/Sheol!	",
"	18 Laat die valse lippe stom word wat in trotsheid en veragting, onbeskaamd spreek teen die regverdige.	",
"	19 o, Hoe groot is U Suiwerheid wat U weggelê het vir die wat U vrees, wat U uitgewerk het vir die wat by U skuil, in teenwoordigheid van die seuns van adam!	",
"	20 U verberg hulle in die Skuilplek van U Aangesig vir die samesweringe van mense; U steek hulle weg in ’n Hut vir die twis van die tonge.	",
"	21 Geloofd sy JaHWeH, want HY het SY Medelye aan My wonderbaar gemaak, in ’n beleërde Stad.	",
"	22 Ek tog het in My angs gesê: Ek het verdwyn, weg van U Oë; nogtans het U die stem van My smekinge gehoor toe Ek U aangeroep het om hulp.	",
"	23 Julle moet JaHWeH liefhê, al Sy toegewydes! JaHWeH bewaar die getroues en vergeld hom oorvloedig wat trots handel.	",
"	24 Wees sterk, en laat julle hart sterk wees, almal wat op JaHWeH wag!	",

]
},
{
book: 'Psalms',
chapter: '32',
content: [
		
"	1 GESEËND is hy wie se oortreding vergewe, wie se oortredinge bedek is.	",
"	2 Geseënd is die adamiet aan wie JaHWeH die ongeregtigheid nie toereken nie en in wie se gees geen bedrog is nie.	",
"	3 Toe ek geswyg het, het my gebeente uitgeteer van my gebrul die hele dag;	",
"	4 want U Hand was dag en nag swaar op my; my murg het verander soos deur somergloed.Sela.	",
"	5 My opstandigheid het ek U bekend gemaak, en my ongeregtigheid het ek nie verberg nie. Ek het gesê: Ek wil aan JaHWeH my opstandigheid bely; en U het die skuld van my oortredinge vergewe.Sela.	",
"	6 Daarom sal elke toegewyde U aanbid in ’n tyd as U te vinde is; ja, by ’n oorstroming van groot waters sal hulle nie aan hom raak nie.	",
"	7 U is ’n skuilplek vir my; U bewaar my vir benoudheid; U omring my met vrolike gesange van bevryding.Sela.	",
"	8 Ek wil jou onderrig en jou leer aangaande die Weg wat jy moet gaan; Ek wil raad gee; my oog sal op jou wees.	",
"	9 Wees nie soos ’n perd of soos ’n muil wat geen verstand het nie, wie se bek met toom en teuel gehou word, [anders] gaan hy nie vorentoe nie.	",
"	10 Die besoedelde het baie smarte, maar hy wat op JaHWeH vertrou - met Medelye sal HY hom omring.	",
"	11 Wees bly in JaHWeH en juig, o regverdiges! En jubel, alle opregtes van hart!	",

]
},
{
book: 'Psalms',
chapter: '33',
content: [
		
"	1 O REGVERDIGES, jubel voor JaHWeH! ’n Loflied betaam die opregtes.	",
"	2 Loof JaHWeH met die siter; maak musiek tot Sy Eer met die tiensnarige harp.	",
"	3 Sing tot Sy Eer ’n nuwe lied; speel goed met [trompet]geklank.	",
"	4 Want die Woord van JaHWeH is Reg, en al Sy dade is Getrouheid.	",
"	5 Hy het Geregtigheid en Reg lief; die Aarde is vol van die Medelye van JaHWeH.	",
"	6 Deur die Woord van JaHWeH is die Hemele gemaak en deur die Gees van Sy Mond hulle hele Leër.	",
"	7 Hy versamel die waters van die see soos ’n hoop; Hy bêre die Afgrond weg in ‘n bergplek.	",
"	8 Laat die hele Aarde vir JaHWeH vrees; laat al die bewoners van die wêreld vir Hom bedug wees;	",
"	9 want Hy het gespreek, en sy was; Hy het gebied, en sy staan.	",
"	10 JaHWeH vernietig die raad van die nasies, Hy verydel die gedagtes van die volke.	",
"	11 Die Raad van JaHWeH bestaan vir ewig, die gedagtes van Sy Hart van geslag tot geslag.	",
"	12 Geseënd is die nasie wie se Elohey, JaHWeH is, die volk wat Hy vir Hom as Erfdeel uitgekies het.	",
"	13 JaHWeH kyk van die Hemele af; HY sien al die seuns van adam.	",
"	14 Uit SY woonplek aanskou HY al die bewoners van die Aarde,	",
"	15 HY wat die hart van hulle almal formeer, wat let op al hul werke.	",
"	16 ’n Koning word nie verlos deur ’n groot leër, ’n dappere nie gered deur groot krag nie.	",
"	17 Die perd is ‘n tevergeefse veilige hawe en red nie deur sy groot krag nie.	",
"	18 Kyk, die Oog van JaHWeH is op die wat Hom vrees, op die wat op Sy Medelye wag;	",
"	19 om hulle siel te red van die Dood en hulle in die lewe te hou in hongersnood.	",
"	20 Ons Siel wag op JaHWeH; HY is Ons Hulp en Ons Skild;	",
"	21 want Ons Hart is bly in HOM, omdat Ons in die Naam Sy Apartheid vertrou.	",
"	22 Laat U Medelye, JaHWeH, oor Ons wees net soos Ons op U wag!	",
	
]
},
{
book: 'Psalms',
chapter: '34',
content: [
	
"	1 [a Alef.] Ek wil JaHWeH altyd loof; Sy lof sal voortdurend in My mond wees.	",
"	2 [B Bet.] My Siel sal haar beroem in JaHWeH; die ootmoediges sal haar hoor en bly wees. [Openbaring 6:9]	",
"	3 [G Ghimel.] Maak JaHWeH saam met My groot, en laat ons saam Sy Naam verhef!	",
"	4 [D Dalet.] Ek het JaHWeH gesoek, en Hy het My geantwoord en My uit al My vrees gered.	",
"	5 [hi Hé.] Hulle het Hom aangesien en gestraal van Vreugde, en hulle aangesig hoef nie rooi van skaamte te word nie.	",
"	6 [z² Zajin.] Hierdie ellendige het geroep, en JaHWeH het gehoor, en Hy het hom uit al sy benoudhede verlos.	",
"	7 [jo Get.] Die Boodskapper van JaHWeH trek ’n laer rondom die wat Hom vrees, en red hulle uit.	",
"	8 [f Tet.] Smaak en sien dat JaHWeH suiwer is; Geseënd is die krygsman wat by Hom skuil!	",
"	9 [yÒ Jod.] Vrees JaHWeH, o Sy apartes, want die wat Hom vrees, het geen gebrek nie.	",
"	10 [K Kaf.] Die jong leeus ly armoede en het honger; maar die wat JaHWeH soek, het geen gebrek aan enigiets nie.	",
"	11 [l Lamed.] Kom, kinders, luister na My; Ek wil julle die Vrees van JaHWeH leer.	",
"	12 [mi Mem.] Wie is die man wat lus het in die lewe, wat dae liefhet om die suiwere te sien?	",
"	13 [nÒ Noen.] Bewaar jou tong van besoedeling, en jou lippe dat hulle nie bedrog spreek nie.	",
"	14 [s Samek.] Wyk af van wat besoedel is, en doen wat suiwer is; soek die Vrede en jaag Hom na. [Númeri 25:12]	",
"	15 [[ Ajin.] Die Oë van JaHWeH is op die regverdiges, en Sy Ore tot hulle hulpgeroep.	",
"	16 [P Pé.] Die Aangesig van JaHWeH is teen die wat met die besoedeling te doen het, om hulle nagedagtenis van die Aarde af uit te roei.	",
"	17 [x Tzadé.] Hulle roep, en JaHWeH hoor, en Hy red hulle uit al hul benoudhede.	",
"	18 [q Kof.] JaHWeH is naby die wat gebroke is van hart, en Hy verlos die wat verslae is van gees.	",
"	19[r Resj.] Menigvuldig is die besoedeling teenoor die regverdige, maar uit dié almal red JaHWeH hom.	",
"	20[v Sjin.] Hy bewaar al Sy bene: nie een daarvan word gebreek nie. [Exodus 12:46; JeHôWganan 19:33-36]	",
"	21[T] Taw.] Die besoedeling maak die besoedelde een dood; en die wat die regverdige haat, moet daarvoor boet.	",
"	22 JaHWeH verlos die Siel van Sy knegte; en almal wat by Hom skuil, hoef nie te boet nie.	",
	
]
},
{
book: 'Psalms',
chapter: '35',
content: [
	
"	1 JaHWeH, twis met die wat met My twis; bestry die wat My bestry!	",
"	2 Gryp die klein skild en die grote, en staan op as My Hulp!	",
"	3 En trek die spies uit en stuit My vervolgers! Spreek tot My Siel: Ek is jou Verlossing!	",
"	4 Laat hulle wat My Siel soek, beskaamd staan en in die skande kom; laat hulle wat My teistering beraam, agteruitwyk en rooi van skaamte word!	",
"	5 Laat hulle word soos kaf voor die wind, terwyl die Boodskapper van JaHWeH [hulle] wegstoot.	",
"	6 Laat hulle weg Duisternis en glibberig wees, terwyl die Boodkapper van JaHWeH hulle vervolg!	",
"	7 Want hulle het sonder oorsaak die kuil met hul net vir My verberg, hulle het sonder oorsaak gegrawe teen My Siel.	",
"	8 Laat verwoesting oor hom kom sonder dat hy dit weet, en laat sy net hom vang wat hy gespan het; laat hom in haar [die kuil] val met verwoesting!	",
"	9 Maar My Siel sal juig in JaHWeH, sy sal verheug wees in Sy Verlossing.	",
"	10 Al My beendere sal sê: JaHWeH, wie is soos U? U wat die ellendige red van die wat sterker is as hy; ja, die ellendige en behoeftige van sy berower!	",
"	11 Kwaadwillige getuies staan op; wat Ek nie weet nie, vra hulle vir My.	",
"	12 Hulle vergeld My besoedeling vir suiwerheid: verlatenheid vir My Siel.	",
"	13 En Ek - toe hulle siek was, het Ek ’n roukleed gedra; Ek het My Siel gekwel met vas, en My gebed het teruggekeer in My boesem. [JirmeJaH 50:12]	",
"	14 Ek het rondgegaan asof dit ’n vriend, asof dit ’n broer van My was; Ek het gebuk gegaan in die rou soos een wat oor sy moeder treur.	",
"	15 Maar as Ek struikel, is hulle bly en kom bymekaar; hulle vergader teen My, lae mense en die wat Ek nie ken nie; hulle laster sonder ophou.	",
"	16 Onder die tweegesig hofnarre kners hulle met hul tande teen My.	",
"	17 My Meester, hoe lank sal U dit aansien? Bring My Siel terug van hulle verwoestinge, My enigste van die jong leeus af.	",
"	18 Ek sal U loof in ’n groot vergadering; onder ’n groot skare sal Ek U prys.	",
"	19 Laat hulle oor My nie bly wees wat sonder grond My vyande is nie; laat die wat My sonder oorsaak haat, nie met die oë knip nie!	",
"	20 Want hulle spreek nie van Vrede nie, maar hulle bedink bedrieglike woorde teen die stilles in die Aarde.	",
"	21 En hulle maak hul mond wyd oop teen My, hulle sê: Ha, ha, ons oog het Haar gesien!	",
"	22 JaHWeH U het gesien, swyg nie, My Meester, wees nie ver van My af nie!	",
"	23 Ontwaak en word wakker vir My Reg; My Elohey en My Meester, vir My regsaak.	",
"	24 Doen aan My Reg na U Geregtigheid, JaHWeH My Elohey, en laat hulle oor My nie bly wees nie!	",
"	25 Laat hulle in hul hart nie sê: Ha, ons begeerte! Laat hulle nie sê: Ons het hom verslind nie!	",
"	26 Laat hulle wat bly is oor My teëspoed, beskaamd staan en saam rooi van skaamte word; laat hulle wat hul teen My groot maak, met skaamte en skande beklee word!	",
"	27 Laat húlle jubel en bly wees wat ’n behae het in My Geregtigheid; en laat hulle voortdurend sê: Groot is JaHWeH wat ’n welbehae het in die Vrede van Sy Kneg!	",
"	28 En My tong sal U getrouheid prys, U lof die hele dag deur.	",
	
]
},
{
book: 'Psalms',
chapter: '36',
content: [
		
"	1 DIE opstandigheid van die besoedelde is ‘n openbaring in My Hart dat daar geen Vrees vir Elohim in sy oë is nie.	",
"	2 Want hy vlei homself in sy eie oë net om uit te vind dat sy besoedeling gehaat word.	",
"	3 Die woorde van sy mond is onreg en bedrog; hy laat ná om verstandig te wees, om goed te doen.	",
"	4 Hy bedink onreg op sy bed; hy gaan staan op ’n weg wat nie suiwer is nie; wat besoedel is, verfoei hy nie.	",
"	5 o JaHWeH, U Medelye is tot in die Hemele, U Getrouheid tot in die wolke.	",
"	6 U Geregtigheid is soos die berge van El; U oordele oor die groot Afgrond, JaHWeH, U red adamiete en diere!	",
"	7 Hoe kosbaar is U Medelye, o Elohim! Daarom skuil die seuns van adam onder die skaduwee van U Vleuels.	",
"	8 Hulle verkwik hul aan die vettigheid van U Huis, en U laat hulle drink uit die stroom van U genietinge.	",
"	9 Want by U is die Fontein van die Lewe; in U Lig sien ons die Lig.	",
"	10 Laat U Medelye voortduur vir die wat U ken, en U Geregtigheid vir die opregtes van hart.	",
"	11 Laat die voet van die trotsaard nie oor My kom nie, en laat die hand van die besoedelde mense My nie verdryf nie.	",
"	12 Daar het die bewerkers van Ongeregtigheid geval; hulle is neergestoot en kan nie weer opstaan nie.	",

]
},
{
book: 'Psalms',
chapter: '37',
content: [

"	1 [a’ Alef.] Wees nie toornig op die kwaaddoeners nie, beny hulle nie wat onreg doen nie;	",
"	2 want soos gras sal hulle gou verwelk, en soos groen grasspruitjies sal hulle verdroog.	",
"	3 [B Bet.] Vertrou op JaHWeH, en doen wat suiwer is; bewoon die Aarde en beoefen Getrouheid,	",
"	4 en verlustig jou in JaHWeH; dan sal Hy jou gee die begeertes van jou hart.	",
"	5 [GO Ghimel.] Laat jou weg aan JaHWeH oor en vertrou op Hom, en Hy sal dit uitvoer;	",
"	6 en Hy sal jou Geregtigheid laat voortkom soos die Lig en jou Reg soos die middag.	",
"	7 [Do Dalet.] Swyg voor die Aangesig van JaHWeH en verwag Hom; wees nie toornig op hom wat voorspoedig in sy weg is nie, op die man wat listige planne uitvoer nie. [MattithJaHûW 25:13]	",
"	8 [h Hé.] Laat staan die toorn en verlaat die grimmigheid; wees nie toornig nie: dit is net om kwaad te stig.	",
"	9 Want die besoedelde sal uitgeroei word; maar die wat JaHWeH verwag, hulle sal die Aarde besit.	",
"	10 [wÒ Waw.] En nog ’n klein rukkie en die besoedelde sal daar nie wees nie; ja, jy sal ag gee op sy plek, maar hy sal daar nie wees nie.	",
"	11 Die ootmoediges daarenteen sal die Aarde besit en hulle verlustig oor groot Vrede.	",
"	12 [zœ Zajin.] Die besoedelde bedink listige planne teen die regverdige en kners met sy tande teen hom.	",
"	13 My Meester lag oor hom, want hy sien dat sy dag kom.	",
"	14 [jo Get.] Die besoedelde het die swaard getrek en hulle boog gespan om die ellendige en behoeftige te laat val, om dié te slag wat opreg is van Weg.	",
"	15 Hulle swaard sal in hul hart gaan, en hulle boë sal verbreek word. [Openbaring 1:16; 19:15]	",
"	16 [fo Tet.] ’n Klein bietjie is vir die regverdige beter as die rykdom van baie besoedeldes;	",
"	17 want die arms van die besoedelde sal verbreek word, maar JaHWeH ondersteun die regverdiges.	",
"	18 [y Jod.] JaHWeH ken die leeftyd van die rassuiweres, en hulle Erfdeel sal tot in ewigheid bly.	",
"	19 Hulle sal nie beskaamd staan in die besoedelde tyd nie, en in dae van hongersnood sal hulle versadig word.	",
"	20 [Ki Kaf.] Maar die besoedelde sal omkom en die vyande van JaHWeH soos die prag van die weivelde; hulle verdwyn soos rook, hulle verdwyn.	",
"	21 [l Lamed.] Die besoedelde leen en gee nie terug nie, maar die regverdige ontferm hom en gee;	",
"	22 want die wat deur Hom geseën word, sal die Aarde besit; maar die wat deur Hom vervloek word, sal uitgeroei word. [Deuteronómium 28]	",
"	23 [m Mem.] Deur JaHWeH word die gange van ’n krygsman bevestig, en hy het ’n welbehae in Sy Weg.	",
"	24 As hy val, dan stort hy nie neer nie; want JaHWeH ondersteun sy hand.	",
"	25 [n Noen.] Ek was jonk, ook het Ek oud geword, maar nooit het Ek die regverdige verlate gesien, of dat sy saad brood soek nie.	",
"	26 Die hele dag ontferm hy hom en leen uit, en sy saad is ’n seën.	",
"	27 [s Samek.] Wyk af van wat besoedel is, en doen wat suiwer is, en jy sal vir ewig woon;	",
"	28 want JaHWeH het die Reg lief en sal Sy Toegewyde nie verlaat nie; vir ewig word Hulle bewaar, maar die saad van die besoedelde word uitgeroei.	",
"	29 Die regverdiges sal die Aarde besit en vir ewig op haar woon.	",
"	30 [Pi Pé.] Die mond van die regverdige verkondig Wysheid, en sy tong spreek Reg.	",
"	31 Die Wet van sy Elohey is in sy hart; sy gange sal nie wankel nie.	",
"	32 [xo Tzadé.] Die besoedelde loer op die regverdige en soek om hom dood te maak.	",
"	33 JaHWeH gee hom nie oor in sy hand nie, en Hy veroordeel hom nie as hy gerig word nie.	",
"	34 [q’ Kof.] Wag op JaHWeH en hou Sy Weg, en Hy sal jou verhoog om die Aarde te besit; jy sal met welgevalle neersien op die uitroeiing van die besoedelde mense.	",
"	35 [r Resj.] Ek het die Besoedelde Een gesien, ’n geweldenaar, terwyl hy hom uitbrei soos ’n groen inlandse Boom. [Handelinge 9:22]	",
"	36 Toe gaan iemand verby, en kyk, hy was daar nie; en Ek het hom gesoek, maar hy was nie te vinde nie.	",
"	37 [v Sjin.] Let op die rassuiwere en kyk na die opregte, want daar is ’n toekoms vir die man van Vrede. [Númeri 25]	",
"	38 Maar die oortreders word tesame verdelg; die toekoms van die Besoedelde Een word afgesny.	",
"	39 [T Taw.] Maar die Hulp van die regverdiges is van JaHWeH, Sy is hulle veilige hawe in tyd van benoudheid. [Psalm 107:30]	",
"	40 En JaHWeH help hulle en red hulle; Hy red hulle van die besoedelde mense en verlos hulle, want hulle skuil by Hom.	",

]
},
{
book: 'Psalms',
chapter: '38',
content: [
	
"	1 O JaHWeH, straf my nie in U Toorn nie en kasty my nie in U Grimmigheid nie.	",
"	2 Want U pyle het in my ingedring, en U Hand het op my neergedaal.	",
"	3 Daar is geen heel plek in my vlees vanweë U Grimmigheid nie; daar is niks gesond in my gebeente vanweë my oortredinge nie.	",
"	4 Want my skuld gaan oor my hoof; soos ’n swaar vrag het hulle vir my te swaar geword.	",
"	5 My wonde stink, hulle dra vanweë my dwaasheid.	",
"	6 Ek is krom, heeltemal geboë; die hele dag gaan ek in rou;	",
"	7 want my lendene is vol ontsteking, en daar is geen heel plek in my vlees nie.	",
"	8 Ek is kragteloos en heeltemal verbrysel; ek brul van die gebons van my hart.	",
"	9 My Meester, voor U is al my begeertes, en my gesug is vir U nie verborge nie.	",
"	10 My hart slaan vinnig, my Krag het my verlaat, en die Lig van my Oë, ook Hy is nie by my nie.	",
"	11 Die wat my liefhet en my vriende is, staan opsy vir my kwaal, en my naasbestaandes het ver gaan staan;	",
"	12 en die wat my siel soek, span strikke; en die wat my teistering soek, spreek van ondergang, en hulle bedink die hele dag bedrog.	",
"	13 Maar ek is soos ’n dowe: ek hoor nie, en soos ’n stomme wat sy mond nie oopmaak nie.	",
"	14 Ja, ek is soos ’n man wat nie hoor nie en in wie se mond geen teëspraak is nie;	",
"	15 want op U, JaHWeH, wag ek; U sal verhoor, my Meester my Elohey!	",
"	16 Want ek het gesê: Laat hulle net nie bly wees oor my nie! Hulle wat by die wankeling van my voet hul groot maak teen my!	",
"	17 Want ek is klaar om te val, en my smart is voortdurend voor my.	",
"	18 Ja, my skuld bely ek, ek is bekommerd oor my oortreding.	",
"	19 Maar my vyande lewe, hulle is magtig; en die wat my valslik haat, is groot in aantal.	",
"	20 En die wat besoedel vir suiwer vergeld, behandel my vyandig, omdat ek suiwerheid najaag.	",
"	21 Verlaat my nie, o JaHWeH! My Elohey, wees nie ver van my af nie!	",
"	22 Maak tog gou om my te help, my Meester, bevry my!	",
	
]
},
{
book: 'Psalms',
chapter: '39',
content: [
	
"	1 EK het gesê: Ek wil my weë bewaar, sodat ek nie oortree met my tong nie; ek wil my mond in toom hou solank as die besoedelde nog voor my is.	",
"	2 Ek was stom in stilte, ek het geswyg, ver van suiwerheid af, maar my smart is aangewakker.	",
"	3 My hart het warm geword in my binneste; ’n vuur het ontvlam by my gesug; ek het gespreek met my tong:	",
"	4 JaHWeH, maak my einde aan my bekend en wat die maat van my dae is, laat my weet hoe verganklik ek is.	",
"	5 Kyk, U het my dae ’n paar handbreedtes gemaak, en my leeftyd is soos niks voor U nie; ja, as pure nietigheid staan elke adamiet daar! Sela	",
"	6 Waarlik, ‘n man wandel met ‘n skynbeeld rond; ja, hulle woel verniet; hulle stapel op en weet nie wie dit sal insamel nie.	",
"	7 En nou, wat verwag ek, o my Meester? My hoop is op U.	",
"	8 Red my van al my oortredinge; maak my nie ’n smaad van die dwaas nie.	",
"	9 Ek is stom, ek sal my mond nie oopmaak nie; want U het dit gedoen.	",
"	10 Neem U plaag van my weg; ek vergaan vanweë die bestryding van U Hand.	",
"	11 Tugtig U die adamiet met strawwe vir ongehoorsaamheid, dan laat U sy skoonheid vergaan soos [deur] ’n mot; ja, elke adamiet is ’n asemtog! Sela	",
"	12 Hoor, JaHWeH, my gebed, en luister na my hulpgeroep; swyg nie by my trane nie; want ek is ’n vreemdeling by U, ’n bywoner soos al my vaders.	",
"	13 Wend U Oog van my af, dat ek vrolik kan word voordat ek heengaan en daar nie meer is nie.	",

]
},
{
book: 'Psalms',
chapter: '40',
content: [
		
"	1 EK het JaHWeH lank verwag, en HY het HOM na My toe neergebuig en My hulpgeroep gehoor;	",
"	2 en HY het My uit die put van vernietiging, uit die modderige slyk opgetrek en My voete op ’n Rots gestel; HY het My gange vasgemaak.	",
"	3 En HY het ’n nuwe lied in My Mond gegee, ’n lofsang tot eer van onse Elohey. Baie sal dit sien en vrees en op JaHWeH vertrou.	",
"	4 Geseënd is die krygsman wat sy vertroue in JaHWeH stel en hom nie wend tot hoogmoediges en leuendienaars nie.	",
"	5 Groot dinge het U gedoen, JaHWeH My Elohey - U wonders en gedagtes vir Ons; niemand kan met U vergelyk word nie. Wil Ek dit verkondig en uitspreek, dan is dit te veel om te vertel.	",
"	6 U het geen behae in ‘n slagdier of aanbieding nie; My ore het U vir My geopen; brandoffer vir oortreding het U nie geëis nie. [Hebreërs 10:8]	",
"	7 Toe het Ek gesê: Kyk, Ek kom; in die skrywe van die Boekrol, is dit van My geskryf. [Hebreërs 10:7]	",
"	8 Ek het lus, o My Elohey, om U welbehae te doen, en U Wet is binne-in My binneste. [Hebreërs 10:9]	",
"	9 Ek het ’n blye boodskap van Geregtigheid in die groot vergadering verkondig; kyk, My Lippe bedwing Ek nie. JaHWeH, U weet dit.	",
"	10 U Geregtigheid bedek Ek nie binne-in My Hart nie; van U Getrouheid en U Redding spreek Ek; U Medelye en U Waarheid verberg Ek nie vir die groot vergadering nie.	",
"	11 U, o JaHWeH, sal U dade van Barmhartigheid van My nie terughou nie; laat U Medelye en U Waarheid My voortdurend behoed.	",
"	12 Want onmeetbare besoedeling het My omring; My skuld het My ingehaal, en Ek kan nie sien nie; hulle is meer as die hare van My hoof, en My Hart het My verlaat. [Hebreërs 9:28]	",
"	13 Laat dit U behaag, JaHWeH, om My te red; JaHWeH, maak tog gou om My te help!	",
"	14 Laat hulle wat My lewe soek, om dit weg te ruk, tesame beskaamd staan en rooi van skaamte word; laat hulle wat behae het in My benoudheid, agteruitwyk en in die skande kom.	",
"	15 Laat hulle wat vir My sê: Ha, ha! vanweë hul beskaming verskrik wees!	",
"	16 Laat almal wat U soek, in U vrolik en bly wees; laat die liefhebbers van U uitspraak voortdurend sê: Groot is JaHWeH!	",
"	17 Al is Ek ellendig en behoeftig - my Meester dink aan My; U is My Hulp en My Redder; My Elohey, vertoef tog nie!	",
	
]
},
{
book: 'Psalms',
chapter: '41',
content: [
	
"	1 GESEËND is hy wat ag gee op die arme; JaHWeH sal hom red in die dag van benoudheid.	",
"	2 JaHWeH sal hom bewaar en hom in die lewe hou; hy sal voorspoedig gemaak word op die Aarde. Ja, U kan hom nie oorgee aan die siel van sy vyande nie. [Openbaring van Henog 13:88]	",
"	3 JaHWeH sal hom ondersteun op die siekbed; sy hele slaapplek verander U as hy krank is.	",
"	4 Ek het gesê: o JaHWeH, wees My barmhartig! Genees My siel, want sy het teen U oortree.	",
"	5 My vyande spreek kwaad van My [en sê]: Wanneer sal Hy sterwe en Sy Naam vergaan?	",
"	6 En as iemand kom om [My] te sien, dan praat hy leuens; sy hart vergader besoedeling vir hom; gaan hy uit na buite, dan spreek hy daarvan.	",
"	7 Al My haters tesame fluister onder mekaar teen My; teen My bedink hulle besoedeling [en sê]:	",
"	8 ‘n Woord van Belijaal is op Hom uitgestort; en nou dat Hy lê, sal Hy nie weer opstaan nie.	",
"	9 Selfs die man wat met My in Vrede lewe, op wie Ek vertrou het, wat My Brood eet, het die hakskeen teen My opgelig. [JeHôWganan 13:18]	",
"	10 Maar U, o JaHWeH, wees My barmhartig en rig My op dat Ek hulle dit kan vergelde!	",
"	11 Hieraan weet Ek dat U ’n welbehae in My het: dat My vyand oor My nie juig nie.	",
"	12 My tog, deur My egtheid ondersteun U My, en stel My voor U Aangesig tot in ewigheid.	",
"	13 Geloofd sy JaHWeH, die Elohey van JisraEl, van ewigheid tot in ewigheid! Amein, ja amein.	",

]
},
{
book: 'Psalms',
chapter: '42',
content: [
	
"	1 SOOS ’n hert wat smag na waterstrome, so smag My Siel na U, o Elohim!	",
"	2 My Siel dors na Elohim, na die lewende El; wanneer sal Ek ingaan en voor die Aangesig van Elohim verskyn?	",
"	3 My trane is My spys dag en nag, omdat hulle die hele dag vir My sê: Waar is jou Elohey?	",
"	4 Hieraan wil Ek dink en My Siel uitstort in My: hoe Ek gewoond was om voort te trek met die skare, hulle gelei het na die Huis van Elohim, met die stem van jubel en dank - ’n feesvierende menigte! [Wysheid 10:15-21]	",
"	5 Wat buig jy jou neer, o My Siel, en is onrustig in My? Hoop op Elohim; want Ek sal Hom nog loof - die Verlossing van Sy Aangesig!	",
"	6 o My Elohey, My Siel buig neer in My; daarom dink Ek aan U vanaf die Aarde van die Jordaan en die Hermoniete, van die klein gebergte af.	",
"	7 Die Afgrond roep na die Afgrond by die gedruis van U waterstrome; al U bare en U golwe het oor My heengegaan.	",
"	8 [Maar] JaHWeH sal oordag Sy Medelye gebied, en in die nag sal Sy lied by My wees, ’n gebed tot die El van My lewe.	",
"	9 Ek wil spreek tot El, My Rots, waarom vergeet U My? Waarom gaan Ek in rou deur die vyande se verdrukking?	",
"	10 Met ’n doodsteek in My gebeente, smaad My teëstanders My as hulle die hele dag vir My sê: Waar is jou Elohey?	",
"	11 Wat buig jy jou neer, o My Siel, en wat is jy onrustig in My? Hoop op Elohim, want Ek sal Hom nog loof - die Verlossing van My Aangesig en My Elohey!	",
	
]
},
{
book: 'Psalms',
chapter: '43',
content: [
	
"	1 DOEN aan my Reg, o Elohim, en verdedig my regsaak teen ’n onbarmhartige volk; red my van die man van bedrog en onreg!	",
"	2 Want U is die Elohey van my laer; waarom verstoot U my dan? Waarom moet ek rondgaan in rougewaad deur die vyand se verdrukking?	",
"	3 Stuur U Lig en U Waarheid; laat Hulle my lei; laat Hulle my bring na die berg van U Apartheid en na U Tabernakels ,	",
"	4 dat ek kan ingaan na die altaar van Elohim, na die El van my jubelende blydskap en U kan loof met die siter, o Elohim Elohey!	",
"	5 Wat buig jy jou neer, o my siel, en wat is jy onrustig in my? Hoop op Elohim, Want ek sal Hom nog loof- die Verlossing van my aangesig en my Elohey!	",
	
]
},
{
book: 'Psalms',
chapter: '44',
content: [
		
"	1 O ELOHIM, met ons ore het ons dit gehoor, ons vaders het ons dit vertel: ’n werk het U gedoen in hulle dae, in die dae van die voortyd.	",
"	2 U self het met U Hand nasies verdrywe, maar húlle geplant; U het gemeenskappe kwaad aangedoen, húlle daarenteen laat uitspruit.	",
"	3 Want húlle het die Aarde nie deur hul swaard in besit geneem nie, en hul arm het hulle nie die oorwinning gegee nie, maar U Regterhand en U Arm en die Lig van U Aangesig, omdat U ’n welbehae in hulle gehad het.	",
"	4 U self is my Koning, o Elohim! Gebied die Verlossinge van Jakob.	",
"	5 Deur U sal ons ons teëstanders omstoot; in U Naam sal ons hulle vertrap wat teen ons opstaan.	",
"	6 Want ek vertrou nie op my boog nie en my swaard sal my die oorwinning nie gee nie;	",
"	7 maar U het ons verlos van ons teëstanders en ons haters beskaamd gemaak.	",
"	8 In Elohim roem ons die hele dag en U Naam sal ons loof tot in ewigheid.Sela.	",
"	9 En tog het U ons verstoot en tot skande gemaak, en U trek nie saam met ons leërs uit nie.	",
"	10 U laat ons agteruitwyk vir die teëstander, en ons haters plunder na hartelus.	",
"	11 U gee ons oor soos slagvee, en U het ons onder die nasies verstrooi.	",
"	12 U verkoop U volk vir niks en het nie baie verdien deur hulle koopprys nie.	",
"	13 U maak ons ’n smaad vir ons bure, ’n spot en beskimping vir die wat rondom ons is.	",
"	14 U maak ons ’n spreekwoord onder die nasies, ’n hoofskudding onder die gemeenskappe.	",
"	15 My skande is die hele dag voor my, en die skaamte van my aangesig oordek my;	",
"	16 weens die stem van die smader en lasteraar, weens die blik van die vyand en wraakgierige.	",
"	17 Dit alles het oor ons gekom, en tog het ons U nie vergeet en nie bedrieglik gehandel teen U Verbond nie.	",
"	18 Ons hart het nie agteruit gewyk nie, en ons gange het van U Pad nie afgebuig nie,	",
"	19 alhoewel U ons verbrysel het in die Plek van die Drake en ons met die Doodskaduwee oordek.	",
"	20 As ons die Naam van onse Elohey vergeet het en ons handpalms uitgestrek het na ’n verbasterde heerser-	",
"	21 sou Elohim dit nie naspeur nie? Want Hy ken die geheime van die hart.	",
"	22 Maar om U ontwil word ons die hele dag gedood; ons word gereken as slagskape.	",
"	23 Ontwaak! Waarom slaap U, my Meester? Word tog wakker! Verstoot nie vir ewig nie!	",
"	24 Waarom verberg U U Aangesig, vergeet U ons ellende en ons verdrukking?	",
"	25 Want ons siel is in die stof neergebuig; ons buik kleef aan die Aarde.	",
"	26 Staan op tot ons hulp en verlos ons om U Medelye ontwil!	",

]
},
{
book: 'Psalms',
chapter: '45',
content: [
	
"	1 MY hart word bewoë deur suiwer woorde; Ek dra My gedigte voor aangaande ’n Koning; My Tong is die pen van ’n vaardige skrywer. [Openbaring van Henog 1:1]	",
"	2 U is veel skoner as die uit die seuns van adam; Guns is uitgestort op U Lippe; daarom het Elohim U geseën vir Ewig.	",
"	3 Gord U Swaard aan die heup, o Dappere, U Majesteit en U Grootsheid;	",
"	4 ja, U Grootsheid! Ry voorspoedig ter wille van Waarheid en Ootmoed [en] Regverdigheid; en laat U Regterhand U ontsagwekkende dinge leer!	",
"	5 U pyle is skerp (volke val onder U!); [hulle tref] in die hart van die Koning se vyande.	",
"	6 U Troon, o Elohim, is vir Ewig tot in Ewigheid; die Septer van U Koninkryk is ’n regverdige Septer.	",
"	7 U het Geregtigheid lief en haat besoedeling. Daarom het, o Elohim, U Elohim U gesalf met Vreugde-olie bo U metgeselle. [Hebreërs 1:9]	",
"	8 Al U klere is mirre en alewee [en] kassie; uit ivoorpaleise maak snarespel U bly. [Wysheid van Sirag 24:15]	",
"	9 Dogters van konings is onder U kosbares; die Koningin staan aan U regterhand in goud van Ofir.	",
"	10 Hoor, o Dogter, en kyk en neig U oor, en vergeet U volk en die Huis van U Vader;	",
"	11 en as die Koning U skoonheid begeer - want Hy is U Meester - buig U dan voor Hom neer.	",
"	12 En, o die dogter van Tirus sal met geskenke U guns afsmeek, ja, die rykstes van die volk.	",
"	13 Louter welgesteldheid is die Koning se Dogter daarbinne; van goud[draad] is Haar kleding.	",
"	14 In veelkleurige gewade word Sy na die Koning gelei; maagde agter Haar, Haar vriendinne, word na U gebring. [Hooglied van Salomo 6:9]	",
"	15 Hulle word gelei met Vreugde en gejuig; Hulle gaan in die Koning se paleis in. [MattithJaHûW 25:1]	",
"	16 In die plek van U vaders sal U seuns wees; U sal hulle aanstel as vorste in die hele Aarde.	",
"	17 U Naam wil Ek vermeld van geslag tot geslag; daarom sal die volke U loof vir Ewig tot in Ewigheid.	",
	
]
},
{
book: 'Psalms',
chapter: '46',
content: [
	
"	1 ELOHIM is vir Ons ’n Toevlug en Sterkte; as Hulp in benoudhede is Hy in hoë mate beproef.	",
"	2 Daarom sal Ons nie vrees nie, al waggel die Aarde en al wankel die berge weg in die hart van die see.	",
"	3 Laat haar waters bruis, laat hulle skuim; laat die berge bewe deur haar onstuimigheid!Sela.	",
"	4 [Daar is] ’n rivier en sy spruitjies maak die Stad van Elohim bly, die Aparte  Tabernakels van die Hoogste El.	",
"	5 Elohim is binne-in Haar, Sy wankel nie; Elohim sal Haar beskerm as die dagbreek verskyn.	",
"	6 Nasies het gebruis, koninkryke het gewankel; Hy het Sy Stem verhef; die Aarde bewe.	",
"	7 JaHWeH van die skeppings-Leërmagte is met Ons; die Elohey van Jakob is ’n Rotsvesting vir Ons.Sela.	",
"	8 Kom, aanskou die Dade van JaHWeH, wat verskriklike dinge oor die Aarde bring,	",
"	9 wat die oorloë laat ophou tot by die Einde van die Aarde, die boog verbreek en die spies stukkend slaan, die strydwaens met vuur verbrand.	",
"	10 Laat staan en weet dat Ek Elohim is; Ek sal hoog wees onder die nasies, hoog op die Aarde.	",
"	11 JaHWeH van die skeppings-Leërmagte is met Ons; die Elohey van Jakob is ’n Rotsvesting vir Ons.Sela.	",
	
]
},
{
book: 'Psalms',
chapter: '47',
content: [
		
"	1 ALLE volke, klap met die handpalms; juig tot Eer van Elohim met ’n stem van gejubel!	",
"	2 Want JaHWeH, die Hoogste El, is gedug, ’n groot Koning oor die hele Aarde.	",
"	3 Hy bring volke onder Ons en gemeenskappe onder Ons voete.	",
"	4 Hy kies Ons Erfdeel vir Ons uit, die Trots van Jakob vir wie Hy liefhet.Sela.	",
"	5 Elohim vaar op met gejuig, JaHWeH met ramshoring geklank. [Handelinge 1:9]	",
"	6 Maak musiek tot Eer van Elohim, maak musiek! Maak musiek tot Eer van Ons Koning, maak musiek!	",
"	7 Want Elohim is Koning van die hele Aarde; maak musiek met ’n onderwysing.	",
"	8 Elohim regeer oor die nasies; Elohim sit op die Troon van Sy Apartheid.	",
"	9 Die edeles van die volke het vergader - ’n volk van die Elohey van Abraham; want aan Elohim behoort die skilde van die Aarde. Hoog verhewe is Hy!	",

]
},
{
book: 'Psalms',
chapter: '48',
content: [
	
"	1 JaHWeH is groot en uitnemend lofwaardig in die Stad van onse Elohey, Berg van Sy Apartheid!	",
"	2 Skoon deur Sy verhewenheid, die Vreugde van die hele Aarde is die Berg van Sion, aan die Noordekant, die Stad van die groot Koning!	",
"	3 Elohim word bekend gemaak in Haar paleise as ’n Rotsvesting.	",
"	4 Want kyk, die konings het bymekaar gekom, tesame opgetrek.	",
"	5 Skaars het hulle Haar gesien, of hulle het verstom, verskrik geword, in angs weggevlug.	",
"	6 Bewing het hulle daar aangegryp, smart soos van een wat baar.	",
"	7 Deur die Gees van die Ooste verbreek U die skepe van Tarsis.	",
"	8 Soos ons gehoor het, so het ons gesien in die Stad van JaHWeH van die skeppings-leërmagte, in die Stad van onse Elohey: Elohim sal Haar bevestig tot in ewigheid.Sela.	",
"	9 o Elohim, ons dink aan U Medelye binne-in U Tempel.	",
"	10 Soos U Naam, o Elohim, so is U roem tot die eindes van die Aarde toe; U Regterhand is vol Geregtigheid.	",
"	11 Laat die Berg van Sion bly wees, laat die Dogters van JeHûWdah juig oor U Regsprake.	",
"	12 Gaan rondom Sion, trek om Haar heen, tel Haar torings;	",
"	13 let op Haar skanse, wandel deur Haar paleise, sodat julle van Haar aan die volgende geslag kan vertel,	",
"	14 dat hierdie Elohim, onse Elohey is, vir Ewig tot in Ewigheid; Hy sal ons lei tot die dood toe.	",
	
]
},
{
book: 'Psalms',
chapter: '49',
content: [

		
"	1 HOOR dit, alle volke, luister, alle bewoners van die wêreld.	",
"	2 Beide seuns van die Adamiete sowel as seuns van die groot manne, ryk en arm tesaam!	",
"	3 My Mond sal louter Wysheid spreek, en die oordenking van My Hart is net Verstand.	",
"	4 Ek sal My oor neig tot ’n spreuk; Ek sal My raaisel verklaar by die siter.	",
"	5 Waarom sou Ek vrees in dae van besoedeling, as die ongeregtigheid van My onderkruipers My omring -	",
"	6 die wat vertrou op hulle vermoë en hulle beroem op die grootheid van hulle rykdom?	",
"	7 Niemand kan ooit ’n broer loskoop nie; hy kan aan Elohim sy losprys nie gee nie	",
"	8 (want die losprys van hulle siel is te kosbaar en vir ewig ontoereikend),	",
"	9 dat hy vir ewig sou voortlewe, die vernietiging nie sou sien nie.	",
"	10 Want hy sien: wyse manne sterwe, die dwaas en die onverstandige kom tesame om en laat hulle vermoë aan ander na.	",
"	11 Hulle binneste gedagte is: hul huise sal vir ewig wees, hul tabernakels van geslag tot geslag; hulle noem die  Adamah [die adamiet se Aarde] na hul name.	",
"	12 Maar die adamiet wat in aansien is, hou nie stand nie; hy is soos die wilde wesens wat vergaan.	",
"	13 Dit is die weg van die wat op hulleself vertrou, en van hulle volgelinge wat in hul woorde ’n behae het.Sela.	",
"	14 Soos skape word hulle bestem vir die Doderyk/Sheol; Dood is hulle herder, en die opregtes heers oor hulle in die môre; en hulle gestalte is daar vir die Doderyk/Sheol om te verteer, sodat daarvoor geen woning meer is nie.	",
"	15 Maar Elohim sal My Siel loskoop van die mag van die Doderyk/Sheol, want Hy sal My opneem. Sela. [2 Nikodemus 8:2]	",
"	16 Wees nie bevrees as ’n man ryk word, as die rykdom van sy huis groot word nie;	",
"	17 want wanneer hy doodgaan vat hy niks saam uit alles van hom nie; sy Glansrykheid sal nie neerdaal agter hom aan nie.	",
"	18 Want terwyl hy leef het hy sy siel geseën - en prys hulle jou, omdat jy aan jouself goed doen – [Lukas 12:20]	",
"	19 tog gaan [sy siel] na die geslag van sy vaders; tot in ewigheid sal hulle die Lig nie sien nie.	",
"	20 Die adamiet wat in aansien is en geen verstand het nie, is soos die wilde wesens wat vergaan.	",
		
]
},
{
book: 'Psalms',
chapter: '50',
content: [
	
"	1 DIE El van die Elohim, JaHWeH, spreek en roep die Aarde, van die opgang van die son af tot sy ondergang toe.	",
"	2 Uit Sion, die volkomenheid van skoonheid, verskyn Elohim in Ligglans.	",
"	3 Onse Elohey kom en kan nie swyg nie. Vuur verteer voor Sy Aangesig, en rondom Hom storm dit geweldig.	",
"	4 Hy roep na die Hemele daarbo, en na die Aarde, om Sy volk te oordeel:	",
"	5 Versamel My gunsgenote vir My, hulle wat My Verbond by die Slagdier sluit! [Wysheid van Sirah 24:10]	",
"	6 En - die Hemele verkondig Sy regverdigheid, want Elohim staan gereed om te oordeel!Sela.	",
"	7 Hoor, My volk, dat Ek kan spreek; JisraEl, dat Ek jou dit kan inskerp: Ek is Elohim, jou Elohey!	",
"	8 Oor jou slagdiere bestraf Ek jou nie, en jou brandoffers is voortdurend voor My.	",
"	9 Ek hoef uit jou huis geen stier te neem of bokke uit jou krale nie;	",
"	10 want al die wilde diere van die bos is Myne, die vee op die berge by duisende.	",
"	11 Ek ken al die voëls van die berge, en wat roer op die veld, is van My.	",
"	12 As Ek honger het, sal Ek jou dit nie sê nie; want die wêreld is Myne en haar volheid. [MattithJaHûW 12:6]	",
"	13 Sou Ek vleis van stiere eet, of bloed van bokke drink?	",
"	14 Slag aan Elohim met dank, en betaal jou Geloftes aan die Hoogste El;	",
"	15 en roep My aan in die dag van benoudheid: Ek sal jou uithelp, en jy moet My eer.	",
"	16 Maar aan die besoedelde sê Elohim: Wat vertel jy nog My Insettinge en neem jy My Verbond in jou mond -	",
"	17 terwyl jy die Tug haat en My woorde agter jou werp?	",
"	18 As jy ’n dief sien, dan geval dit jou by hom, en jou deel is met die verbasteraars.	",
"	19 Jou mond laat jy los in besoedeling, en jou tong vleg bedrog.	",
"	20 Jy sit en praat teen jou broer, die seun van jou Moeder beskimp jy.	",
"	21 Hierdie dinge het jy gedoen, en sou Ek swyg? Jy dink Ek is net soos jy! Ek gaan jou straf en jou dit ordelik voor oë stel.	",
"	22 Verstaan dit tog, o julle wat Elowahh vergeet, sodat Ek [julle] nie verskeur sonder dat iemand red nie.	",
"	23 Die een wat slag met dank, eer My; en die een wat op Sy Weg ag gee, hom sal Ek die Lossing van Elohim laat geniet.	",
	
]
},
{
book: 'Psalms',
chapter: '51',
content: [
		
"	1 WEES My barmhartig, o Elohim, na U Medelye; delg My oortredinge uit na die grootheid van U barmhartigheid.	",
"	2 Was My heeltemal van My ongeregtigheid en suiwer My van My opstandigheid. [JeshaJaH 1:16; MattithJaHûW 28:19]	",
"	3 Want Ek ken My opstandigheid, en My oortredinge is voortdurend voor My.	",
"	4 Teen U alleen het Ek oortree en gedoen wat besoedel is in U Oë, sodat U regverdig kan wees as U spreek, suiwer as U gerig hou.	",
"	5 Kyk, in skuld is Ek gebore, en in oortreding het My Moeder My ontvang.	",
"	6 Kyk, U het ’n welgevalle aan Waarheid in die binneste, en in die verborgene maak U aan My Wysheid bekend.	",
"	7 Was My van oortredinge met hisop, dat Ek gesuiwer kan wees; was My, dat Ek witter kan wees as sneeu.	",
"	8 Laat My Vreugde en Blydskap hoor; laat die gebeente juig wat U verbrysel het.	",
"	9 Verberg U Aangesig vir My oortredinge en delg uit al My skuld vir oortredinge.	",
"	10 Skep vir My ’n suiwer hart, o Elohim, en gee opnuut in die binneste van My, ’n standvastige Gees.	",
"	11 Verwerp My nie van U Aangesig nie en neem die Gees van U Apartheid nie van My weg nie.	",
"	12 Gee My weer die Vreugde van U Lossing, en vernuwe My deur ’n standvastige Gees.	",
"	13 Ek wil die opstandiges U Weë leer, dat die oortreders hulle tot U kan bekeer.	",
"	14 Verlos My van die Bloed, o Elohim, Elohey van My bevryding! Laat My Tong U Geregtigheid uitjubel.	",
"	15 My Meester, open My Lippe, dat My Mond U Lof kan verkondig.	",
"	16 Want U het geen behae in ‘n slagdier nie, anders sou Ek hom gee; in brandoffer het U geen behae nie.	",
"	17 Die Slagdier van Elohim is ’n Gebroke Gees; ’n Gebroke en Verslae Hart sal U, o Elohim, nie verag nie!	",
"	18 Doen goed aan Sion na U welbehae; bou die mure van Jerusalem op.	",
"	19 Dan sal U ’n welbehae hê in die Slagdiere van Regverdigheid, in brandoffer en ‘n volledige aan-bieding; dan sal hulle stiere opdra op U altaar.	",
	
]
},
{
book: 'Psalms',
chapter: '52',
content: [
		
"	1 WAT beroem jy jou in die besoedeling, o geweldige? Die Medelye van El duur die hele dag!	",
"	2 Jou tong beraam bedrieglikheid, soos ’n geslypte skeermes, o werker van bedrog!	",
"	3 Jy hou meer van besoedeling as van suiwerheid, van die leuen meer as om die Waarheid te spreek.Sela.	",
"	4 Jy hou net van woorde wat verslind, o bedrieglike tong!	",
"	5 So sal El jou dan ook vir ewig omverwerp, jou wegruk en jou uit die Tent uitsleep; ja, Hy sal jou ontwortel uit die Aarde van die lewendes.Sela.	",
"	6 En die regverdiges sal dit sien en vrees; en hulle sal oor hom lag [en sê]:	",
"	7 Kyk, die sterk man wat Elohim nie tot sy toevlug gemaak het nie, maar vertrou het op die grootheid van sy rykdom, sterk was in sy bedrieg-likheid!	",
"	8 Maar Ek sal wees soos ’n groen Olyfboom in die Huis van Elohim; Ek vertrou op die Medelye van Elohim vir Ewig tot in Ewigheid. [JirmeJaH 11:16]	",
"	9 Vir ewig sal Ek U loof, omdat U dit gedoen het; en Ek sal U Naam verwag, want Hy is suiwer, in teenwoordigheid van U Toegewydes.	",

]
},
{
book: 'Psalms',
chapter: '53',
content: [
		
"	1 DIE dwaas sê in sy hart: Daar is geen Elohim nie! Hulle het sleg gehandel en [hul] onreg afskuwelik gemaak; daar is niemand wat suiwer optree nie.	",
"	2 Elohim het uit die Hemele neergesien op die seuns van adam om te sien of daar iemand verstandig is, wat na Elohim vra.	",
"	3 Hulle het almal afgewyk, tesame het hulle verkleur; daar is niemand wat suiwer optree nie, ook nie een nie.	",
"	4 Het die bewerkers van Ongeregtigheid dan geen Kennis nie, wat My volk opeet [asof] hulle brood eet? Hulle roep Elohim nie aan nie.	",
"	5 Dáár het skrik hulle oorweldig sonder dat daar skrik was; want Elohim het die beendere verstrooi van hom wat jou beleër het; jy het [hulle] beskaamd gemaak, want Elohim het hulle verwerp.	",
"	6 Ag, mag die Verlossing van JisraEl uit Sion kom! As Elohim die lot van Sy volk verander, dan sal Jakob juig, JisraEl sal bly wees.	",

]
},
{
book: 'Psalms',
chapter: '54',
content: [
	
"	1 O ELOHIM, verlos My deur U Naam, en doen aan My Reg deur U Mag!	",
"	2 o Elohim, hoor My gebed, luister na die woorde van My Mond!	",
"	3 Want verbasterdes staan teen My op, en tiranne soek My Siel; hulle stel Elohim nie voor hul oë nie.Sela.	",
"	4 Kyk, Elohim is My Helper, My Meester is met hulle wat My Siel ondersteun.	",
"	5 Hy sal My vyande hul besoedeling vergelde. Vernietig hulle deur U Waarheid!	",
"	6 Ek wil ‘n vrywillige [gawe] aan U slag; Ek wil U Naam, o JaHWeH, loof, want Hy is suiwer;	",
"	7 want Hy het My uit alle benoudheid gered, en My Oog het met welgevalle op My vyande neergesien.	",
	
]
},
{
book: 'Psalms',
chapter: '55',
content: [
	
"	1 O ELOHIM, hoor my gebed en verberg U nie vir my smeking nie.	",
"	2 Luister na my en verhoor my; in my onrus dwaal ek rond en is verward,	",
"	3 weens die geroep van die vyand, weens die geraas van die besoedelde; want hulle stort onreg op my af, en in toorn behandel hulle my as vyand.	",
"	4 My hart krimp inmekaar in my binneste, en verskrikkinge van die Dood het op my geval.	",
"	5 Vrees en bewing kom oor my, en angs oordek my.	",
"	6 Toe het ek gesê: Ag, had ek maar vlerke soos ’n duif, dan sou ek wegvlieg en [weg]bly!	",
"	7 Kyk, ek sou ver wegvlug; ek sou vernag in die wildernis!Sela.	",
"	8 Gou sou ek vir my ’n skuilplek soek teen die onstuimige wind, teen die storm.	",
"	9 Verslind hulle, my Meester, verdeel hulle spraak, want ek sien geweld en twis in die Stad.	",
"	10 Dag en nag omring hulle hom op haar mure, en binne-in haar is onreg en moeite.	",
"	11 Wat verwoesting aanbring, is binne-in haar, en verdrukking en bedrog wyk nie van haar markplein nie.	",
"	12 Want dit is geen vyand wat my smaad nie, anders sou ek dit dra; dit is nie my hater wat hom teen my groot maak nie, anders sou ek my vir hom wegsteek;	",
"	13 maar jy, ’n man soos ek, my vriend en my vertroude!	",
"	14 Ons wat innig met mekaar omgegaan het, in die Huis van Elohim gewandel het met die woelige skare.	",
"	15 Laat Dood hulle oorval, laat hulle lewendig na die Doderyk/Sheol neerdaal; want besoedeling is in hulle woning, in hulle binneste.	",
"	16 Maar ek, ek roep Elohim aan, en JaHWeH sal my verlos.	",
"	17 Saans en smôrens en smiddags klaag ek en steun, en Hy hoor my stem.	",
"	18 Hy verlos my siel in Vrede van die stryd teen my, want met menigtes is hulle teen my.	",
"	19 El sal hoor en hulle antwoord; ja, Hy wat op die troon sit van lankal af,Sela.omdat by hulle geen verbetering is en die Elohim nie vrees nie.	",
"	20 Hy het sy hande uitgesteek teen die wat in Vrede met hom geleef het; hy het Sy Verbond besoedel.	",
"	21 Glad is die botterwoorde van sy mond, maar sy hart is oorlog; sy woorde is sagter as olie, maar hulle is ontblote swaarde.	",
"	22 Werp jou sorg op JaHWeH, en Hy sal jou onderhou; Hy sal nooit die regverdige laat wankel nie.	",
"	23 Maar U, o Elohim, sal hulle laat neerdaal in die put van vernietiging; manne van bloed en bedrog sal hulle dae nie tot op die helfte bring nie; maar ék vertrou op U.	",

]
},
{
book: 'Psalms',
chapter: '56',
content: [
		
"	1 WEES my barmhartig, o Elohim, want mense vertrap my; hy wat my beveg, verdruk my die hele dag.	",
"	2 My vyande vertrap die hele dag, want baie veg teen my in hoogmoed.	",
"	3 Die dag as ek vrees, sal ék op U vertrou.	",
"	4 Deur Elohim sal ek Sy Woord prys; ek vertrou op Elohim, ek vrees nie; wat kan vlees my doen?	",
"	5 Die hele dag verdraai hulle my woorde; al hulle gedagtes is teen my, om besoedeling te pleeg.	",
"	6 Hulle val aan, lê en loer - hulle let op my hakskene net soos hulle op my siel geloer het.	",
"	7 Ondanks [hul] ongeregtigheid - sal hulle ontvlug? Werp volke neer in Toorn, o Elohim!	",
"	8 U het my omswerwinge getel; hou my trane in U kruik; is hulle nie in U Boekrol nie?	",
"	9 Dan sal my vyande agteruitwyk op die dag as ek roep; dit weet ek dat Elohim aan my kant is.	",
"	10 Deur Elohim sal ek die Woord prys; deur JaHWeH sal ek die Woord prys.	",
"	11 Ek vertrou op Elohim, ek vrees nie wat ’n adamiet my kan aandoen nie.	",
"	12 Op my, o Elohim, [rus] Geloftes aan U; die sal ek met dank aan U vergoed;	",
"	13 want U het my siel gered van die Dood - ja, my voete van struikeling - om te wandel voor die Aangesig van Elohim, die Lig van die lewe.	",

]
},
{
book: 'Psalms',
chapter: '57',
content: [
	
"	1 WEES my barmhartig, o Elohim, wees my barmhartig, want by U het my siel geskuil, en in die skaduwee van U Vleuels sal ek skuil totdat die verwoesting verbygegaan het.	",
"	2 Ek roep Elohim, die Hoogste El aan, El wat dit vir my voleindig.	",
"	3 Hy sal uit die Hemele stuur en my verlos terwyl hy wat my vertrap, [my] smaadheid aandoen.Sela.Elohim sal Sy Medelye en Sy Waarheid stuur.	",
"	4 My siel [is] tussen brullende leeus en ek lê [tussen] vuriges, seuns van adam wie se tande spiese en pyle is, en wie se tong ’n skerp swaard is.	",
"	5 Verhef U bo die Hemele, o Elohim, U Glansrykheid bo die hele Aarde!	",
"	6 Hulle het ’n net gespan vir my voetstappe, hulle het my siel neergebuig; hulle het ’n kuil voor my gegrawe, hulle val binne-in haar.Sela.	",
"	7 My hart is gerus, o Elohim, my hart is gerus; ek wil sing en musiek maak.	",
"	8 Waak op, my Eer! Waak op, harp en siter! Ek wil Shagar wakker maak!	",
"	9 Ek wil U loof onder die volke, my Meester, musiek maak tot U Eer onder die gemeenskappe.	",
"	10 Want U Medelye is groot tot by die Hemele en U Waarheid tot by die wolke.	",
"	11 Verhef U bo die Hemele, o Elohim, U Glansrykheid bo die hele Aarde!	",

]
},
{
book: 'Psalms',
chapter: '58',
content: [
	
"	1 SPREEK julle waarlik Geregtigheid, o stomme? Oordeel julle die seuns van adam regverdig?	",
"	2 Ja, julle bedryf ongeregtigheid in die hart; julle weeg op Aarde die geweld van julle hande af.	",
"	3 Die verbasterde is besoedel vanaf die moederskoot; hulle dwaal sodra hulle gebore word.	",
"	4 Hulle gif is soos die gif van Nagash/die slang; soos ’n dowe adder wie se oor toegestop is,	",
"	5 wat nie luister na die stem van die bekoorders, van hom wat ervare is om met towerspreuke om te gaan nie.	",
"	6 o Elohim, verbreek hulle tande in hulle mond; slaan die tande van die jong leeus uit, o JaHWeH!	",
"	7 Laat hulle vergaan soos urine wat wegloop; as hy sy pyle rig, laat hulle wees asof hulle opgekerf is.	",
"	8 [Laat hulle wees] soos ’n slak wat wegsmelt so ver as hy loop, soos ’n misgeboorte van ‘n vrou wat die son nie sal sien nie.	",
"	9 Voordat hulle dorings kan steek, sal Hy dit met ‘n stormwind wegvee, alle lewe, deur Sy brandende Woede.	",
"	10 Die regverdige sal bly wees as hy die wraak sien; hy sal sy voete was in die bloed van die besoedelde.	",
"	11 En die adamiete sal sê: Gewis, daar is beloning vir die regverdige; gewis, daar is ’n Elohim wat in die Aarde oordeel!	",
	
]
},
{
book: 'Psalms',
chapter: '59',
content: [
	
"	1 RED My van My vyande, o My Elohey! Beskerm My teen My teëstanders!	",
"	2 Red My van die bewerkers van besoedeling, en verlos My van die manne van bloed!	",
"	3 Want kyk, hulle lê en loer op My Siel; sterkes val My aan, nie [vir] oortreding en nie [vir] opstandigheid nie, o JaHWeH!	",
"	4 Sonder oop oë hardloop hulle en maak hulle klaar. Ontwaak en help My, en neem in ag!	",
"	5 Ja U, JaHWeH Elohim van die skeppings-leërmagte, Elohey van JisraEl, word wakker om al die nasies te straf; moenie Medelye gee aan die ongehoorsames en moenie die verraaiers barmhartig wees nie!Sela.	",
"	6 Elke aand kom hulle terug; hulle huil soos honde en dwaal deur die Stad.	",
"	7 Kyk, hulle smaal met hul mond; swaarde is op hulle lippe, want - wie sou dit hoor?	",
"	8 Maar U, o JaHWeH, lag oor hulle; U spot met al die nasies.	",
"	9 My Sterkte, op U wil Ek wag, want Elohim is My Rotsvesting.	",
"	10 My Elohey van Medelye sal My tegemoetkom; Elohim sal My op My vyande laat neersien.	",
"	11 Moet hulle nie ombring nie, sodat My volk dit nie vergeet nie: laat hulle rondswerwe deur U Krag, en werp hulle neer, My Meester, Ons Skild!	",
"	12 Die oortreding van hulle mond is die woorde van hulle lippe; laat hulle dan gevang word in hul trots, en vanweë die vloek en die leuen wat hulle vertel.	",
"	13 Vernietig [hulle] in Grimmigheid, vernietig [hulle], sodat hulle daar nie meer is nie; en laat hulle weet dat Elohim heers in Jakob, tot by die eindes van die Aarde!Sela.	",
"	14 En elke aand kom hulle terug; hulle huil soos honde en dwaal deur die Stad.	",
"	15 Húlle swerwe rond om voedsel te soek; as hulle nie versadig word nie, vertoef hulle die hele nag.	",
"	16 Maar Ek sal sing van U Sterkte en elke môre jubel oor U Medelye, want U was ’n Rotsvesting vir My en ’n toevlug in die dag toe Ek benoud was.	",
"	17 My Sterkte, tot U Eer wil Ek musiek maak, want Elohim is My Rotsvesting, My Elohey van Medelye.	",

]
},
{
book: 'Psalms',
chapter: '60',
content: [
		
"	1 O ELOHIM, U het Ons verstoot, Ons vanmekaar geskeur; U was toornig; herstel Ons! [Barug 4:12]	",
"	2 U het die Aarde laat bewe, haar gekloof; genees haar breuke, want sy wankel!	",
"	3 U het U volk harde dinge laat sien; U het Ons bedwelmende wyn laat drink.	",
"	4 U het aan die wat U vrees, ’n Banier gegee, om te vlug vir die boog!Sela.	",
"	5 Sodat U bemindes gered mag word; verlos Ons deur U Regterhand en verhoor Ons!	",
"	6 Elohim het gespreek in Sy Apartheid: Ek wil jubel, Ek wil Sigem verdeel en die dal van Sukkot afmeet.	",
"	7 Gílead is Myne en Manasse is Myne, en Efraim is die beskutting van My Hoof; JeHûWdah is My Wetgewer.	",
"	8 Moab is My waskom; op Edom werp Ek My skoen; jubel oor My, o Filistéa!	",
"	9 Wie sal My bring in die versterkte stad? Wie kan My lei tot in Edom?	",
"	10 Het U, o Elohim, Ons nie verwerp nie? En U trek nie uit, o Elohim, saam met Ons leërs nie.	",
"	11 Verleen Ons hulp teen die vyand, want die adamiet se hulp is nietigheid.	",
"	12 In Elohim sal Ons kragtige dade doen, en Hy Self sal Ons vyande vertrap.	",

]
},
{
book: 'Psalms',
chapter: '61',
content: [
		
"	1 O ELOHIM, hoor my smeking, luister na my gebed!	",
"	2 Van die Einde van die Aarde af roep ek U aan as my hart beswyk; lei my op ’n Rots wat bo my verhewe is. [Miga 4:8]	",
"	3 Want U het ’n toevlug vir my geword, ’n sterk Toring teen die vyand.	",
"	4 Ek wil in U Tent vertoef vir ewig, in die skuilplek van U Vleuels my verberg. [JeshaJaH 18:1]Sela.	",
"	5 Want U, o Elohim, het my Geloftes gehoor; U het die besitting gegee aan die wat U Naam vrees.	",
"	6 Mag U dae by die koning se dae byvoeg; mag sy jare wees soos van geslag tot geslag.	",
"	7 Mag hy vir ewig voor die Aangesig van Elohim op die troon sit; beskik Medelye en Waarheid, dat Hulle hom bewaar.	",
"	8 Só wil ek musiek maak tot eer van U Naam tot in ewigheid, om my Geloftes te voltooi, dag ná dag.	",

]
},
{
book: 'Psalms',
chapter: '62',
content: [
		
"	1 JA, My Siel is stil tot Elohim; van Hom is My Verlossing.	",
"	2 Hy alleen is My Rots en My Verlossing, My Rotsvesting; Ek sal nie grootliks wankel nie.	",
"	3 Hoe lank sal julle besoedeling beplan teen ’n Man, julle sal vermoor word soos ’n muur wat oorhang, julle sal ‘n omgestote muur word.	",
"	4 Ja, julle hou raad om Hom van Sy hoogte af te stoot; julle het behae in leuens; met jul mond seën julle, maar met jul binneste vloek julle.Sela.	",
"	5 Wees net maar stil tot Elohim, My Siel, want van Hom is My verwagting!	",
"	6 Sekerlik, Hy is My Rots en My Verlossing, My Rotsvesting; Ek sal nie wankel nie.	",
"	7 By Elohim is My Lossing en My Eer; die Rots van My Sterkte, My toevlug is in Elohim.	",
"	8 Vertrou op Hom altyd, o volk! Stort julle hart uit voor Sy Aangesig! Elohim is ’n toevlug vir Ons.Sela.	",
"	9 Ja, nietigheid is die seuns van adam, leuens is die aansienlikes; in die weegskaal moet hulle opgaan, almal saam is hulle minder as nietigheid.	",
"	10 Vertrou nie op verdrukking en bou geen ydele hoop op rowery nie; as die vermoë aangroei, sit daar die hart nie op nie!	",
"	11 Een ding het Elohim gespreek, twee is dit wat Ek gehoor het: dat die Sterkte aan Elohim behoort,	",
"	12 en aan U, My Meester, [behoort die] Medelye; want U vergeld elkeen na sy werk.	",

]
},
{
book: 'Psalms',
chapter: '63',
content: [
		
"	1 O ELOHIM, U is My El, U soek ek; My Siel dors na U, My Vlees smag na U, in ’n dor en uitgedroogde Aarde, sonder water.	",
"	2 Só het ek U in die Apartheid aanskou, om U Sterkte en U Glansrykheid te sien.	",
"	3 Want U Medelye is suiwerder as die lewe; My Lippe moet U prys.	",
"	4 Só sal ek U prys My lewe lank, in U Naam My handpalms ophef.	",
"	5 Soos met vet en vettigheid sal My Siel versadig word, en My Mond sal roem met jubelende lippe	",
"	6 as ek aan U dink op My bed, in die nagwake oor U peins.	",
"	7 Want U was ’n Hulp vir My, en in die skaduwee van U Vleuels sal Ek jubel.	",
"	8 My Siel is aan U verkleef; U Regterhand ondersteun My.	",
"	9 Maar húlle wat soek om My Siel te verderwe, hulle sal kom in die onderste plekke van die Aarde.	",
"	10 Hy sal oorgelewer word in die Mag van die swaard; die deel van die jakkalse sal hulle word.	",
"	11 Maar die Koning sal bly wees in Elohim; elkeen wat by Hom sweer, sal hom beroem; want die mond van die leuensprekers sal gestop word.	",

]
},
{
book: 'Psalms',
chapter: '64',
content: [
		
"	1 HOOR my stem, o Elohim, in my klagte; bewaar my lewe vir die skrik van die vyand.	",
"	2 Steek my weg vir die raad van die kwaaddoeners, vir die gewoel van die bewerkers van besoedeling;	",
"	3 wat hulle tong skerp maak soos ’n swaard, hulle pyl rig - bitter woorde! -	",
"	4 om in skuilplekke na die rassuiwere te skiet; skielik skiet hulle Hom en vrees nie.	",
"	5 ‘n Besoedelde plan beraam hulle vir hulle; hulle spreek af om strikke te span; hulle sê: Wie sal dit sien?	",
"	6 Hulle snuffel besoedeling uit: Ons is gereed! ’n Fyn uitgedinkte plan! Ja, ’n man se binneste en onpeilbare hart!	",
"	7 Maar Elohim tref hulle met ’n pyl, skielik is hulle wonde daar.	",
"	8 En hulle tong laat hulle oor hulself struikel; almal wat hulle aansien, skud die hoof.	",
"	9 En alle adamiete vrees en verkondig die dade van Elohim en gee ag op wat Hy doen.	",
"	10 Die regverdige sal bly wees in JaHWeH en by Hom skuil, en al die opregtes van hart sal hulle beroem.	",

]
},
{
book: 'Psalms',
chapter: '65',
content: [
		
"	1 AAN U kom ’n lofsang toe, o Elohim, in Sion, en aan U moet die Gelofte betaal word.	",
"	2 o Hoorder van die gebed, tot U moet alle vlees kom!	",
"	3 Besoedelde spraak het die oorhand oor My gehad, [maar] U versoen Ons oortredinge.	",
"	4 Geseënd is hy wat U uitkies en laat nader kom, dat hy kan woon in U voorhowe. Ons wil versadig word met die suiwerheid van U Huis, U apartgestelde Tempel.	",
"	5 Ontsagwekkende dinge antwoord U Ons met Geregtigheid, o Elohey van Ons Lossing, Vertroue van al die eindes van die Aarde en van die verste see!	",
"	6 Wat die berge grondves deur U Krag, wat omgord is met Mag,	",
"	7 wat die gebruis van die seë stilmaak, die gebruis van hulle golwe en die rumoer van die gemeenskappe;	",
"	8 sodat die bewoners van die eindes vrees vir U kentekens; U laat die uitgange van die môre en die aand jubel.	",
"	9 U het die Aarde besoek en U het haar oorvloed gegee; U oorvloei haar grootliks; die stroom van Elohim is vol water. U berei hulle koring; ja, so voorsien U haar.	",
"	10 U laat haar vore oorvloei, haar kluite gelyk; deur reënbuie maak U haar week; U seën haar uitspruitsel.	",
"	11 U kroon die jaar van U Suiwerheid, en U Voetspore drup van vettigheid.	",
"	12 Die weivelde van die wildernis drup, en die heuwels gord hulleself met gejuig.	",
"	13 Die weivelde is bekleed met troppe kleinvee, en die dale is bedek met koring; hulle juig, ook sing hulle.	",

]
},
{
book: 'Psalms',
chapter: '66',
content: [
		
"	1 JUIG tot eer van Elohim, o ganse Aarde!	",
"	2 Besing die Eer van Sy Naam, maak Sy lofsang pragtig!	",
"	3 Sê tot Elohim: Hoe ontsagwekkend is U dade! Deur die grootheid van U Sterkte sal U vyande kruipende na U toe kom.	",
"	4 Laat die hele Aarde voor U neerval en musiek maak tot U eer; laat hulle U Naam verhef met musiek.Sela.	",
"	5 Kom en aanskou die dade van Elohim, Hy wat gedug is in werking oor die seuns van adam.	",
"	6 Hy het die see verander in droë grond; hulle het te voet deur die rivier gegaan. Daar was ons bly in Hom.	",
"	7 Hy heers vir ewig deur Sy Mag; Sy Oë hou wag oor die nasies. Laat die wederstrewiges hulleself nie verhef nie.Sela.	",
"	8 Loof, volksgenote, onse Elohey, en laat hoor die Stem wat Hom roem -	",
"	9 wat aan ons siel die lewe gee en nie toelaat dat ons voet wankel nie.	",
"	10 Want U het ons getoets, o Elohim, U het ons gelouter soos ’n mens silwer louter.	",
"	11 U het ons in die net gebring, ’n swaar las op ons heupe gelê.	",
"	12 U het mense oor ons hoof laat ry; ons het in die vuur en in die water gekom, maar U het ons uitgelei in die oorvloed.	",
"	13 Ek sal met brandoffers in U Huis ingaan; ek sal U my Geloftes betaal,	",
"	14 wat my lippe geuit en my mond uitgespreek het toe ek benoud was.	",
"	15 Brandoffers van vet diere sal ek U bring saam met geurigheid van ramme; ek sal beeste saam met bokke berei.Sela.	",
"	16 Kom luister, en laat my vertel, julle almal wat Elohim vrees, wat Hy aan my siel gedoen het.	",
"	17 Ek het Hom aangeroep met my mond, en lofgesang was onder my tong.	",
"	18 As ek ongeregtigheid bedink het in my hart, sou my Meester nie gehoor het nie.	",
"	19 Waarlik, Elohim het gehoor; Hy het geluister na die stem van my gebed.	",
"	20 Prys Elohim wat my gebed nie afgewys en Sy Medelye aan my nie [onttrek het] nie!	",

]
},
{
book: 'Psalms',
chapter: '67',
content: [
	
"	1 MAG Elohim Ons barmhartig wees en Ons seën; mag Hy Sy Aangesig oor Ons laat skyn!Sela.	",
"	2 Sodat U Weg geken kan word op Aarde, al die nasies U Verlossing. [Psalm 18:30]	",
"	3 Die volke sal U loof, o Elohim, die volke almal saam sal U loof.	",
"	4 Die gemeenskappe sal bly wees en jubel, omdat U die volke regverdig oordeel en die gemeenskappe op Aarde lei.Sela.	",
"	5 Die volke sal U loof, o Elohim, die volke almal saam sal U loof.	",
"	6 Die Aarde het haar opbrengs gelewer; Elohim, Onse Elohey, sal Ons seën.	",
"	7 Elohim sal Ons seën, en al die eindes van die Aarde sal Hom vrees.	",

]
},
{
book: 'Psalms',
chapter: '68',
content: [
		
"	1 ELOHIM staan op, Sy vyande raak verstrooid, en Sy haters vlug voor Sy Aangesig weg!	",
"	2 Soos rook verdryf word, verdryf U [hulle]; soos was smelt voor die vuur, vergaan die besoedeldes voor die Aangesig van Elohim.	",
"	3 Maar die regverdiges is bly, hulle juig voor die Aangesig van Elohim, en hulle is vrolik met blydskap.	",
"	4 Sing tot eer van Elohim, maak musiek tot eer van Sy Naam, verhef Hom wat deur die ooptes ry in Sy Naam JaH en jubel voor Sy Aangesig!	",
"	5 ’n Vader van die wese en ’n Regter van die weduwees is Elohim in die Woning van Sy Apartheid.	",
"	6 Elohim laat die eensames woon in ’n huisgesin, Hy lei die gevangenes uit in voorspoed; maar die wederstrewiges woon in ’n dorre plek .	",
"	7 o Elohim, toe U uitgetrek het voor U volk, toe U voortgestap het in die [woesteny van] Jesimon.Sela.	",
"	8 Het die Aarde gebewe! Ook het die Hemele gedrup voor die Aangesig van Elohim; hierdie Sinai voor die Aangesig van Elohim, die Elohey van JisraEl!	",
"	9 Met ’n vrywillige Reën het U, o Elohim, U Erfdeel besproei; en toe sy moeg was, het U haar versterk.	",
"	10 U skare het in haar gewoon; U het haar deur U Suiwerheid berei vir die ellendige, o Elohim!	",
"	11 My Meester het die Woord laat hoor - die wat die magtige tyding gebring het, was ’n groot skare:	",
"	12 Die konings van die leërs vlug, hulle vlug; en sy wat tuis gebly het, verdeel die buit.	",
"	13 As julle daar lê tussen die veekrale, is die vlerke van die Duif oordek met silwer en Haar vere met liggroen goud.	",
"	14 Toe die Almagtige konings in Haar verstrooi het, het dit gesneeu op Salmon.	",
"	15 ’n Berg van Elohim is die berg Basan, ’n berg met toppe is die berg Basan.	",
"	16 Waarom kyk julle afgunstig, o berge met toppe, na die Berg wat Elohim begeer het vir Sy Woning? Ja, JaHWeH sal [daar] woon tot in ewigheid.	",
"	17 Die waens van Elohim is tienduisende, duisend maal duisende; My Meester is onder hulle; [dit is] Sinai in Apartheid.	",
"	18 U het opgeklim na die hoogte, U het gevangenes weggevoer, U het geskenke geneem onder die adamiete; ja, ook die wederstrewiges, o JaHH Elohim, [wat tussen hulle] woon.	",
"	19 Geseënd sy My Meester! Dag na dag dra Hy Ons; die El is Ons Verlossing!Sela.	",
"	20 El is vir Ons ’n El van verlossinge, en JaHWeH My Meester het uitkoms teen die Dood.	",
"	21 Gewis, Elohim sal die kop van Sy vyande verbrysel, en die harige kroontjie van die wat in skuld rondloop.	",
"	22 My Meester het gesê: Ek sal terugbring uit Basan, Ek sal terugbring uit die dieptes van die see;	",
"	23 sodat jy jou voet kan steek in bloed, die tong van jou honde van die vyande sy deel [kan hê].	",
"	24 o Elohim, hulle sien U Weë, die Paaie van My El, My Koning [is] in Apartheid.	",
"	25 Vooraan gaan die sangers, daaragter die snaarspelers, tussen jongmeisies in wat die tamboeryn slaan.	",
"	26 Loof Elohim, in die vergaderinge, My Meester, uit die Fontein van JisraEl!	",
"	27 Daar is Benjamin, die kleinste, wat oor hulle geheers het; die vorste van JeHûWdah - hulle menigte; die vorste van Sébulon, die vorste van Náftali.	",
"	28 Jou Elohey het jou Sterkte gebied: betoon U sterk, o Elohim, wat vir Ons gewerk het!	",
"	29 Ter wille van U Tempel in Jerusalem sal die konings aan U geskenke bring. [Openbaring 11:1]	",
"	30 Bestraf die wilde wese wat assegaai gooi - die massa sterkmanne saam met die jonges van die volke - die wat hulleself onderwerp vir stukke silwer. Verstrooi die volke wat lus het vir oorloë.	",
"	31 Welgesteldes sal uit Egipte uitgaan, Kuwsh/swartes sal haastig verdryf word deur die Sterk Hand van Elohim.	",
"	32 o Koninkryke van die Aarde, sing tot eer van Elohim; maak musiek tot eer van My Meester!Sela.	",
"	33 Van Hom wat ry in die hoogste Hemele, wat uit die voortyd is; kyk, Hy verhef Sy Stem, ’n magtige Stem.	",
"	34 Gee Sterkte aan Elohim! Sy Hoogheid is oor JisraEl en Sy Sterkte in die wolke.	",
"	35 Vreeslik is Elohim uit jou Apartheidsplekke, [Die] El van JisraEl - Hy gee aan die volk Sterkte en Krag. Geseënd sy Elohim!	",

]
},
{
book: 'Psalms',
chapter: '69',
content: [
	
"	1 VERLOS My, o Elohim, want die waters het tot by My Siel gekom.	",
"	2 Ek sink in grondelose modder waar geen staanplek is nie; Ek het in waterdieptes gekom, en die stroom loop oor My.	",
"	3 Ek is moeg van My geroep, My keel brand, My oë versmag terwyl Ek wag op My Elohey.	",
"	4 Die wat My sonder oorsaak haat, is meer as die hare van My hoof; die wat klaar staan om My te vernietig, wat sonder grond My vyande is, is magtig; wat Ek nie geroof het nie, moet Ek dan teruggee.	",
"	5 O Elohim, U weet dat dwaasheid, en skuldige dade nie vir U verborge is nie.	",
"	6 Laat die wat U verwag, deur My nie beskaamd staan nie, My Meester JaHWeH van die skeppings-leërmagte! Laat die wat U soek, deur My nie in die skande kom nie, o Elohey van JisraEl!	",
"	7 Want om U ontwil dra Ek smaad, bedek skande My Aangesig.	",
"	8 Vreemd het Ek vir My broers geword en ’n onbekende vir die seuns van My Moeder. [Lukas 22:54-61]	",
"	9 Want die ywer vir U Huis het My verteer, en die smaadhede van die wat U smaad, het op My geval. [JeHôWganan 2:17]	",
"	10 Wat My aangaan, My Siel het geween met vas; maar sy het ‘n smaad vir My geword.	",
"	11 Ek het ook ’n rougewaad My kleding gemaak en vir hulle ’n spreekwoord geword.	",
"	12 Die wat in die poort sit, praat van My - ook die spotlied van die wat sterk drank drink.	",
"	13 Maar Ek - My gebed is tot U, o JaHWeH: in die tyd van Barm-hartigheid, o Elohim, verhoor My deur die grootheid van U Medelye, deur die Waarheid van U  Lossing!	",
"	14 Red My uit die modder en laat My nie sink nie; laat My gered word van My haters en uit waterdieptes.	",
"	15 Laat die waterstroom nie oor My loop en die Afgrond My nie verslind nie, en laat die put haar mond bo My nie toesluit nie!	",
"	16 Verhoor My, o JaHWeH, want U Medelye is Suiwerheid; wend U tot My na die grootheid van U dade van Barmhartigheid.	",
"	17 En verberg U Aangesig nie vir U Kneg nie; want Ek is benoud. Verhoor My dan gou!	",
"	18 Kom nader na My Siel, verlos haar; bevry My om My vyande ontwil.	",
"	19 U ken My smaad en My beskaming en My skande; al My teëstanders is voor U.	",
"	20 Die smaad breek My hart, en Ek is verswak; ja, Ek het gewag op Medelye, maar verniet; en op vertroosters, maar het hulle nie gevind nie.	",
"	21 En hulle het aan My gal gegee as My spys, en vir My dors het hulle My asyn laat drink. [JeHôWganan 19:29]	",
"	22 Laat hul tafel voor hulle ’n vangnet wees en vir hulle wat sorgeloos is, ’n strik.	",
"	23 Laat hulle oë duister word, sodat hulle nie sien nie; en maak dat hulle heupe voortdurend bewe.	",
"	24 Stort oor hulle U verontwaardiging uit, en laat U brandende Woede hulle inhaal.	",
"	25 Laat hulle laer woes word, laat in hulle tente geen bewoner wees nie.	",
"	26 Want hulle vervolg Hom wat deur U swaar getref is, en vertel van die smart van U gewondes.	",
"	27 Voeg skuldlas by hulle Ongereg-tigheid, en laat hulle nie in U Geregtigheid kom nie. [Lukas 23:34]	",
"	28 Laat hulle uitgevee word uit die Boekrol van die Lewe en nie saam met die regverdiges opgeskrywe word nie. [Exodus 32:33; Openbaring van Henog 13:83, 102; Boekrol van Henog 108:3]	",
"	29 Maar Ek is ellendig en in pyn: laat U Verlossing, o Elohim, My beskerm!	",
"	30 Ek wil die Naam van Elohim prys met ’n lied en HOM groot maak met dank;	",
"	31 en dit sal JaHWeH welgevalliger wees as beeste, as stiere wat horings en gesplitste kloue het.	",
"	32 As die ootmoediges dit sien, sal hulle bly wees; julle wat na Elohim soek, laat julle hart lewe!	",
"	33 Want JaHWeH luister na die behoeftiges en verag SY gevangenes nie.	",
"	34 Laat Hemele en Aarde HOM prys, die see en alles wat daarin roer.	",
"	35 Want Elohim sal Sion verlos en die stede van JeHûWdah bou; en daar sal hulle woon en Haar besit.	",
"	36 En die saad van SY knegte sal Haar beërwe, en die liefhebbers van SY Naam sal in Haar woon.	",
		

]
},
{
book: 'Psalms',
chapter: '70',
content: [
		
"	1 O ELOHIM, maak tog gou om My te red, o JaHWeH, om My te help!	",
"	2 Laat hulle wat My Siel soek, beskaamd staan en rooi van skaamte word; laat hulle wat behae het in My teistering, agteruitwyk en in die skande kom.	",
"	3 Laat hulle wat sê: Ha, ha! teruggaan vanweë hul beskaming.	",
"	4 Laat in U vrolik en bly wees almal wat U soek; en laat die liefhebbers van U Verlossing voortdurend sê: Groot is Elohim!	",
"	5 Maar Ek is ellendig en behoeftig: o Elohim, kom tog gou na My! U is My Hulp en My Redder; JaHWeH, vertoef tog nie!	",

]
},
{
book: 'Psalms',
chapter: '71',
content: [
	
"	1 BY U, o JaHWeH, skuil Ek: laat My nie vir altyd beskaamd staan nie!	",
"	2 Red My deur U Geregtigheid en bevry My; neig U Oor tot My en verlos My!	",
"	3 Wees vir My ’n Rots om in te woon, om voortdurend in te gaan; U wat bevel gegee het om My te verlos, want U is My Rots en My Bergvesting.	",
"	4 My Elohey, red My uit die handpalm van die besoedelde, uit die mag van hom wat onreg doen, en van die geweldenaar.	",
"	5 Want U is My verwagting, My Meester JaHWeH, My Vertroue van My jeug af.	",
"	6 Op U het Ek gesteun van die geboorte af, van die Moederskoot af is U My Bevryder; oor U is My lof voortdurend.	",
"	7 Ek was vir baie soos ’n wonder; maar U is My magtige Toevlug.	",
"	8 My Mond is vol van U lof, die hele dag van U roem.	",
"	9 Verwerp My nie in die tyd van die ouderdom nie, verlaat My nie as My Krag gedaan is nie.	",
"	10 Want My vyande praat van My, en die wat op My Siel loer, hou saam raad	",
"	11 en sê: Elohim het Hom verlaat; agtervolg en gryp Hom, want daar is geen Redder nie!	",
"	12 o Elohim, wees nie ver van My af nie; My Elohey, maak tog gou om My te help!	",
"	13 Laat hulle wat My Siel as vyand behandel, beskaamd staan, verteer word; laat hulle wat My ongeluk soek, hulleself toedraai in smaad en skande.	",
"	14 Maar Ek sal voortdurend hoop en al U lof vermeerder.	",
"	15 My Mond sal U Geregtigheid vertel, die hele dag van U Verlossing; want Ek ken nie die maat van Hulle nie.	",
"	16 Ek sal gaan in die Sterkte van My Meester JaHWeH; Ek sal U Geregtigheid vermeld, dié van U alleen.	",
"	17 o Elohim, U het My geleer van My jeug af, en tot nou toe verkondig Ek U wonders.	",
"	18 En ook tot die ouderdom en die grysheid toe - o Elohim, verlaat My nie, totdat Ek aan die [volgende] geslag U Arm verkondig, aan almal wat sal kom, U Sterkte.	",
"	19 Ook is U Geregtigheid, o Elohim, tot in die hoogte; U wat groot dinge gedoen het, o Elohim, wie is soos U?	",
"	20 U wat My groot ellende laat sien het, sal My weer lewend maak en My weer ophaal uit die Afgrond van die Aarde.	",
"	21 Vermeerder My grootheid, en wend U om [en] troos My.	",
"	22 So wil Ek U dan ook loof met die instrument van die harp, U Waarheid, My Elohey! Ek wil musiek maak tot U Eer op die siter, o Aparte Een van JisraEl!	",
"	23 My Lippe sal hard sing as Ek musiek maak tot U Eer, en My Siel, wat U verlos het.	",
"	24 Ook sal My Tong U Geregtigheid die hele dag prys, want hulle het beskaamd gestaan, want hulle wat My ongeluk soek, het rooi van skaamte geword.	",
	
]
},
{
book: 'Psalms',
chapter: '72',
content: [
		
"	1 O ELOHIM, gee aan die Koning U Regsprake en U Geregtigheid aan die Seun van die Koning. [JeHôWganan 3:35; 5:22]	",
"	2 Laat Hy U volk oordeel met Regverdigheid en U ellendiges met Reg.	",
"	3 Die berge sal Vrede dra vir die volk, en die heuwels, deur Geregtigheid.	",
"	4 Hy sal aan die ellendiges van die volk Reg verskaf, die kinders van die behoeftige verlos en die verdrukker verbrysel.	",
"	5 Hulle sal U vrees solank as die son skyn en solank as die maan daar is, van geslag tot geslag.	",
"	6 Hy sal neerdaal soos reën op die grasveld, soos buie - ’n swaar reën op die Aarde.	",
"	7 In Sy dae sal die regverdige bot in volheid van Vrede, totdat die maan nie meer is nie.	",
"	8 En Hy sal heers van see tot see en van die Rivier tot by die eindes van die Aarde.	",
"	9 Die wilde wesens van dor plekke sal voor Hom kniel, en Sy vyande sal die stof lek.	",
"	10 Die konings van Tarsis en van die eilande sal spysbydraes aanbied, die konings van Skeba en Seba geskenke naderbring.	",
"	11 Ja, al die konings sal hulle voor Hom buig, al die nasies sal Hom dien. [Boekrol van Henog 46:5]	",
"	12 Want Hy sal die behoeftige red wat daar roep om hulp, en die ellendige en wie geen helper het nie.	",
"	13 Hy sal hom ontferm oor die arme en behoeftige, en die siele van die behoeftiges sal Hy red.	",
"	14 Van die verdrukker en uit die geweld verlos Hy siele, en hulle bloed is waardevol in die Oë van Hom.	",
"	15 Mag Hy dan lewe! en mag hulle aan Hom gee van die goud van Skeba en voortdurend vir Hom bid; mag hulle die hele dag Hom seën! [MattithJaHûW 12:42]	",
"	16 Mag daar volheid van koring wees in die Aarde, op die top van die berge; mag die vrug daarvan ruis soos die Líbanon; en mag hulle bot uit die Stad soos die plante van die Aarde!	",
"	17 Mag Sy Naam vir ewig wees; mag Sy Naam uitspruit solank as die son daar is! En mag al die nasies in Hom geseën word, Hom as geseënd prys!	",
"	18 Prys JaHWeH Elohim, die Elohey van JisraEl, wat alleen wonders doen!	",
"	19 En geloofd sy vir ewig Sy Glansryke Naam! En laat die hele Aarde met Sy Glansrykheid gevul word! Amein, ja amein.	",
"	20 Hier eindig die gebede van Dawid, die seun van Isai.	",

]
},
{
book: 'Psalms',
chapter: '73',
content: [
	
"	1 WAARLIK, Elohim betoon suiwerheid aan JisraEl, vir die wat opreg van hart is.	",
"	2 Maar wat My aangaan, My voete het amper gestruikel, My voetstappe het byna uitgegly.	",
"	3 Want Ek was afgunstig op die onsinniges toe Ek die voorspoed van die besoedeldes sien.	",
"	4 Want daar is geen kwellings van die Dood by hulle nie, gesond en vet is hulle liggaam.	",
"	5 In die moeite van sterwelinge is hulle nie, en saam met adamiete word hulle nie geplaag nie.	",
"	6 Daarom is die trots om hulle soos ’n halssieraad, die geweld bedek hulle soos ’n gewaad.	",
"	7 Hulle oë peul uit van vet; die inbeeldinge van die hart loop oor.	",
"	8 Hulle spot en spreek in besoedeling verdrukking; hulle spreek uit die hoogte.	",
"	9 Hulle stel hul mond teen die Hemele, en hul tong wandel op die Aarde.	",
"	10 Daarom draai hulle mense hul hierheen, en waters in volheid word deur hulle geslurp.	",
"	11 En hulle sê: Hoe sou El dit weet, en sou daar Kennis by die Hoogste El wees?	",
"	12 Kyk, so is die besoedelde mense, en altyd onbesorg vermeerder hulle die rykdom!	",
"	13 Waarlik, tevergeefs het Ek My Hart suiwer gehou en My handpalms in onskuld gewas.	",
"	14 Die hele dag tog is Ek geslaan, en My Tugtiging was daar elke môre.	",
"	15 As Ek gesê het: Ek wil óók so spreek - dan sou Ek verraad gepleeg het teenoor die geslag van U kinders!	",
"	16 Toe het Ek nagedink om dit te verstaan, [maar] dit was moeite in My oë,	",
"	17 totdat Ek in die Apartheidsplekke van El ingegaan [en] op hulle einde gelet het.	",
"	18 Waarlik, U stel hulle op gladde plekke; U laat hulle in puin val.	",
"	19 Hoe word hulle in ’n oomblik ’n voorwerp van verbasing, vergaan hulle, raak hulle tot niet deur verskrikkinge!	",
"	20 Soos ’n droom nadat ’n mens wakker word, o My Meester, so verag U, as U opwaak, hulle beeld!	",
"	21 Toe My Hart bitter gestemd en Ek in My niere geprikkel was,	",
"	22 toe was Ek dom en het niks geweet nie; Ek was soos ’n dier by U. [2 Ezra 5:39]	",
"	23 Nogtans is Ek voortdurend by U; U het My regterhand gevat.	",
"	24 U sal My lei deur U Raad en My daarna na Glansrykheid neem.	",
"	25 Wie het Ek [buiten] U in die Hemele? Buiten U begeer Ek ook niks op die Aarde nie.	",
"	26 Al beswyk My Vlees en My Hart - Elohim is die Rots van My Hart en My deel tot in ewigheid.	",
"	27 Want kyk, die wat hulle ver van U af hou, vergaan; U roei almal uit wat van U af hoereer.	",
"	28 Maar wat My aangaan, My suiwerheid om naby Elohim te wees; in My Meester JaHWeH het Ek My toevlug gestel, om al U werke te vertel.	",
	
]
},
{
book: 'Psalms',
chapter: '74',
content: [
	
"	1 O ELOHIM, waarom het U vir altyd verstoot? [Waarom] rook U Toorn teen die skape van U weide?	",
"	2 Dink aan U vergadering wat U in die voortyd verwerf het, wie U verlos het om die Septer van U Erfdeel te wees, die Berg van Sion waar U op gewoon het.	",
"	3 Hef U Voete op na die ewige puinhope: alles het die vyand in die Apartheid verniel.	",
"	4 U teëstanders het binne-in U vergaderplek gebrul; hulle het hul kentekens as merk gestel.	",
"	5 Dit lyk soos wanneer iemand byle omhoog hef in ’n digte plek bome.	",
"	6 En nou - die houtsnywerk daarvan het hulle alles met byl en hamers stukkend geslaan.	",
"	7 Hulle het U Apartheidsplekke aan die brand gesteek; tot die Aarde toe het hulle die Tabernakel van U Naam besoedel.	",
"	8 Hulle het in hul hart gesê: Laat Ons hulle almal saam onderdruk! Hulle het al die vergaderplekke van El in die Aarde verbrand.	",
"	9 Ons sien nie Ons kentekens nie; daar is geen profeet meer nie, en by Ons is daar niemand wat weet hoe lank nie.	",
"	10 Hoe lank, o Elohim, sal die teëstander smaad aandoen, sal die vyand U Naam vir altyd verag?	",
"	11 Waarom trek U U Hand, ja, U Regterhand, terug? [Trek dit] uit U boesem! Vernietig!	",
"	12 Nogtans is Elohim My Koning van die voortyd af, wat Verlossinge bewerk op die Aarde.	",
"	13 U het deur U Sterkte die see geklief; U het die koppe van die Draak op die waters verbreek.	",
"	14 U het die koppe van die Leviátan verbrysel; U het hom gegee as voedsel vir ’n volk - vir die wesens van die woestyn.	",
"	15 U het fontein en stroom oopgeslaan; U het standhoudende riviere laat opdroog.	",
"	16 Aan U behoort die dag, aan U behoort ook die nag; U het hemelligte en son vasgestel.	",
"	17 U het al die grense van die Aarde bepaal; somer en winter, U het hulle geformeer.	",
"	18 Dink hieraan: Die vyand het JaHWeH gesmaad, en ’n dwase volk het U Naam verag.	",
"	19 Gee aan die wilde wesens die Siel van U Tortelduif nie oor nie; vergeet nie vir altyd die lewe van U ellendiges nie. [Hooglied van Salomo 2:12 ; 5:2]	",
"	20 Kyk na die Verbond, want die donker plekke van die Aarde is vol wonings van geweld.	",
"	21 Laat die verdrukte nie beskaamd terugkom nie; laat die ellendige en behoeftige U Naam prys.	",
"	22 Staan op, o Elohim, verdedig U saak; dink aan die smaad wat U die hele dag aangedoen word deur ’n dwaas.	",
"	23 Vergeet nie die geroep van U teëstanders nie - die rumoer van U opstandige vyande, wat voortdurend opgaan!	",
	
]
},
{
book: 'Psalms',
chapter: '75',
content: [
		
"	1 ONS loof U, o Elohim, Ons loof, en naby is U Naam; hulle vertel U wonders.	",
"	2 As Ek die regte tydstip aangryp, oordeel Ék regverdig.	",
"	3 Al wankel die Aarde en al haar bewoners - Ék het haar pilare vasgestel.Sela.	",
"	4 Ek sê tot die onsinniges: Wees nie onsinnig nie! en tot die besoedelde: Verhef die horing nie!	",
"	5 Verhef julle horing nie hoog [en] spreek nie met trotse uitgerekte nek nie.	",
"	6 Want verhoging van die berge kom nie van die Ooste ook nie van die Weste of van die Suide nie,	",
"	7 maar Elohim is Regter: Hy verneder die een en verhef die ander.	",
"	8 Want in die Hand van JaHWeH is ’n Beker, en die wyn skuim; sy is oorvloedig gemeng en Hy skink uit haar; ja, die afsaksel van haar moet al die besoedeldes van die Aarde opslurp, uitdrink. [Openbaring 8 en 16]	",
"	9 Maar Ek sal vir ewig verkondig - Ek wil musiek maak tot Eer van die Elohey van Jakob.	",
"	10 En Ek sal al die horings van die besoedelde mense stukkend breek; die horings van die regverdige sal verhef word.	",

]
},
{
book: 'Psalms',
chapter: '76',
content: [
	
"	1 ELOHIM is bekend in JeHûWdah, Sy Naam is groot in JisraEl.	",
"	2 Ook het in Salem Sy Tabernakel verrys en in Sion Sy Woning.	",
"	3 Daar het Hy die blitspyle van die boog verbreek, skild en swaard en oorlog.Sela.	",
"	4 Glansend is U, groter as die berge van verskeurdheid!	",
"	5 Geplunder is die sterkes van hart; hulle het hul slaap gesluimer, en geeneen van die dapper manne het hulle hande gevind nie.	",
"	6 Deur U dreiging, o Elohey van Jakob, het strydwa en perd saam bedwelmd geraak.	",
"	7 U, ontsagwekkend is U, en wie kan voor U Aangesig bestaan as U Toorn uitgebreek het?	",
"	8 Uit die Hemele het U ’n oordeel laat hoor; die Aarde het gevrees en stil geword,	",
"	9 toe Elohim opgestaan het vir die Reg, om al die ootmoediges van die Aarde te verlos.Sela.	",
"	10 Want die grimmigheid van die adamiet moet U loof; met die oorblyfsel van grimmighede gord U Uself.	",
"	11 Doen Geloftes en betaal dié aan JaHWeH julle Elohey! Laat almal wat rondom HOM is, geskenke bring aan die Ontsagwekkende,	",
"	12 wat die gees van die vorste wegsny; wat ontsagwekkend is vir die konings van die Aarde.	",

]
},
{
book: 'Psalms',
chapter: '77',
content: [
		
"	1 MY Stem is tot Elohim en Ek roep; My Stem is tot Elohim, dat Hy na My kan luister.	",
"	2 Op die dag van My benoudheid soek Ek My Meester; snags bly My hand uitgestrek sonder om moeg te word; My Siel weier om getroos te word.	",
"	3 As Ek aan Elohim dink, moet Ek steun; peins Ek, dan versmag My Gees.Sela.	",
"	4 U hou My ooglede oop; Ek is onrustig en kan nie spreek nie.	",
"	5 Ek dink oor die dae van die voortyd, oor die ou, ou jare.	",
"	6 Ek wil dink aan My snarespel in die nag, wil peins met My Hart, en My Gees deurvors:	",
"	7 Sal My Meester vir altyd verstoot en verder nie meer goedgunstig wees nie?	",
"	8 Hou Sy Medelye vir altyd op? Is dit met die belofte gedaan van geslag tot geslag?	",
"	9 Het El vergeet om barmhartig te wees? Of het Hy in toorn Sy dade van Barmhartigheid toegesluit? Sela.	",
"	10 Toe het Ek gesê: Dit is My grootste bekommernis dat die Regterhand van die Hoogste El verander!	",
"	11 Ek dink aan die dade van Jah; ja, Ek wil dink aan U wonders uit die voortyd	",
"	12 en al U werk oordink, en Ek wil peins oor U dade.	",
"	13 o Elohim, U Weg is in Apartheid. Wie is ’n groot El soos Elohim?	",
"	14 U is die El wat wonders doen; U het U Sterkte onder die volke bekend gemaak.	",
"	15 U het U volk met ’n Sterke Arm verlos, die kinders van Jakob en van JôWsef.Sela.	",
"	16 Die waters het U gesien, o Elohim, die waters het U gesien, hulle het gebewe; ja, die Afgrond het gesidder.	",
"	17 Die wolke het water uitgegiet, die Hemele het donder laat hoor, ook het U pyle rondgevlieg.	",
"	18 U rollende donder het weerklink; bliksems het die wêreld verlig; die Aarde het gesidder en gebewe.	",
"	19 U weg was in die see en U Paaie in groot waters, en U spore was nie te beken nie.	",
"	20 U het U volk soos skape gelei deur die hand van Moshè en Aäron. [Wysheid 10:15-21]	",
	
]
},
{
book: 'Psalms',
chapter: '78',
content: [
		
"	1 MY volk, luister na My Wet; neig julle oor tot die woorde van My Mond.	",
"	2 Ek wil My Mond open met ’n spreuk, raaisels uit die voortyd laat stroom.	",
"	3 Wat Ons gehoor het en weet en Ons vaders Ons vertel het,	",
"	4 sal Ons nie verberg vir hulle kinders nie, maar aan die volgende geslag vertel die roemryke dade van JaHWeH en Sy Mag en Sy Wonders wat Hy gedoen het.	",
"	5 Hy tog het ’n Getuienis opgerig in Jakob en ’n Wet gegee in JisraEl, wat Hy Ons vaders beveel het - om haar aan hulle kinders bekend te maak,	",
"	6 sodat die volgende geslag haar kan ken, die kinders wat gebore word, dat hulle kan opstaan en vertel aan hulle kinders,	",
"	7 en hulle vertroue op Elohim kan stel en die dade van El nie vergeet nie, maar Sy Gebooie kan bewaar,	",
"	8 en nie word soos hulle vaders nie, ’n koppige en rebelse geslag, ’n geslag met ’n onvaste hart en wie se gees nie ondersteunend was teenoor El nie.	",
"	9 Die kinders van Efraim, gewapende boogskutters, het omgespring op die dag van oorlog.	",
"	10 Hulle het die Verbond van Elohim nie gehou nie en geweier om te wandel binne Sy Wet.	",
"	11 En hulle het Sy dade vergeet en Sy wonders wat Hy hulle laat sien het.	",
"	12 Voor hulle vaders het Hy wonders gedoen, in die Aarde van Egipte, die veld van Soan.	",
"	13 Hy het die see geklief en hulle laat deurgaan en die waters laat staan soos ’n wal.	",
"	14 En Hy het hulle bedags gelei met die Wolkkolom en die hele nag met die Lig van Vuur.	",
"	15 Hy het rotse gekloof in die wildernis en [hulle] oorvloedig laat drink uit groot dieptes.	",
"	16 En Hy het strome laat uitgaan uit die rots en die waters laat afloop soos riviere.	",
"	17 Nog het hulle voortgegaan om teen Hom te oortree, deur te rebelleer teen die Hoogste El in die dorre grond .	",
"	18 En hulle het El versoek in hul hart deur voedsel te vra na hulle siel.	",
"	19 En hulle het teen Elohim gespreek, hulle het gesê: Sou El ’n tafel kan dek in die wildernis ?	",
"	20 Kyk, Hy het die rots geslaan, dat waters gevloei en spruite gestroom het - sou Hy ook brood kan gee of vleis kan verskaf aan Sy volk?	",
"	21 Daarom het JaHWeH gehoor en toornig geword, en Vuur is aangesteek teen Jakob, en Toorn het ook opgegaan teen JisraEl;	",
"	22 omdat hulle in Elohim nie geglo en op Sy Verlossing nie vertrou het nie.	",
"	23 En Hy het aan die wolke daarbo bevel gegee en die deure van die Hemele oopgemaak;	",
"	24 en Hy het manna op hulle laat reën om te eet en koring van die Hemele aan hulle gegee.	",
"	25 Mense het die brood van die Boodskappers geëet; Hy het hulle volop padkos gestuur. [2 Ezra 1:19]	",
"	26 Hy het die Oostewind laat uitbreek aan die Hemele en die Suidewind deur Sy Sterkte aangevoer;	",
"	27 en Hy het vleis soos stof op hulle laat reën en gevleuelde voëls soos sand aan die seë;	",
"	28 en Hy het dit binne-in Sy laer laat val, rondom hulle tente.	",
"	29 Toe het hulle geëet en ten volle versadig geword, en hulle begeerte het Hy bevredig.	",
"	30 Die verbasterde se begeerte na vleis; die vleis was nog in hulle mond -	",
"	31 toe die Toorn van Elohim teen hulle opgegaan het en Hy ’n slagting onder hulle kragtige manne aangerig en die jongmanne van JisraEl neergewerp het.	",
"	32 Ondanks dit alles het hulle verder oortree en nie aan Sy wonders geglo nie.	",
"	33 So het Hy dan hulle dae laat vergaan in nietigheid en hulle jare in verskrikking.	",
"	34 Elke keer as Hy hulle gedood het, het hulle na Hom gevra en teruggekom en El gesoek;	",
"	35 en hulle het daaraan gedink dat Elohim hul Rots was en El, die Hoogste El, hul Verlosser.	",
"	36 En hulle het Hom met hul mond gevlei en Hom met hul tong belieg;	",
"	37 maar hulle hart het nie aan Hom vasgehou nie, en hulle het nie geglo in Sy Verbond nie.	",
"	38 Maar Hy is barmhartig, Hy vergeef die ongeregtigheid en verdelg [hulle] nie, en dikwels wend Hy Sy Toorn af en wek nie al Sy Grimmigheid op nie.	",
"	39 En Hy het daaraan gedink dat hulle vlees was, gees wat weggaan en nie terugkom nie.	",
"	40 Hoe dikwels het hulle teen Hom gerebelleer in die wildernis, het hulle Hom gegrief in die [woesteny van] Jesimon;	",
"	41 en hulle het El opnuut versoek en die Aparte Een van JisraEl gekrenk.	",
"	42 Hulle het nie aan Sy Hand gedink, aan die dag toe Hy hulle van die teëstander verlos het nie;	",
"	43 toe Hy Sy tekens gedoen het in Egipte en Sy wonders in die veld van Soan.	",
"	44 En Hy het hulle riviere verander in bloed en hulle strome, sodat hulle nie kon drink nie.	",
"	45 Hy het onder hulle muskiete gestuur wat hulle verteer het, en paddas wat verwoesting oor hulle gebring het.	",
"	46 En Hy het hulle opbrengs aan die kommandowurm gegee en die vrug van hulle werk aan die treksprinkaan.	",
"	47 Hy het hulle Wingerdstok deur die hael doodgemaak en hulle wildevyeboom deur ryp.	",
"	48 Ook het Hy hulle diere aan die hael oorgegee en hulle vee aan die blitse.	",
"	49 Hy het die gloed van Sy brandende Woede onder hulle gestuur, Grimmigheid en Woede en benoudheid, deur besoedelde boodskappers te stuur.	",
"	50 Hy het ’n pad vir Sy Toorn gebaan, hulle siel nie gered van die Dood nie, maar hulle lewe aan die pes oorgegee.	",
"	51 En Hy het al die eersgeborenes in Egipte getref, die eerstelinge van [hul] krag in die tente van Gam.	",
"	52 Maar Hy het Sy volk laat wegtrek soos skape en hulle gelei soos ’n kudde in die wildernis.	",
"	53 Ja, Hy het hulle veilig gelei, sodat hulle nie gevrees het nie; maar die see het hulle vyande oordek.	",
"	54 En Hy het hulle gebring na die grens van die gebied van Sy Apartheid, na die bergland wat Sy Regterhand verwerf het.	",
"	55 En Hy het nasies voor hulle uit verdrywe en dié [aan hulle] as afgemete Erfdeel laat val, en Hy het die stamme van JisraEl in hulle tente laat woon.	",
"	56 Maar hulle het [Hom] versoek en het gerebelleer teen Elohim, die Hoogste El, en hulle het SY Getuienisse nie onderhou nie.	",
"	57 En hulle was afvallig en het verraad gepleeg soos hul vaders; hulle het omgedraai soos ’n bedrieglike boog.	",
"	58 En hulle het Hom getart deur hul Hoogtes en deur hul gesnede beelde Sy jaloersheid gewek.	",
"	59 Elohim het dit gehoor en toornig geword, en Hy het JisraEl heeltemal verwerp.	",
"	60 En Hy het die Tabernakel in Silo prysgegee, die Tent wat Hy opgeslaan het onder die adamiete.	",
"	61 En Hy het Sy Sterkte oorgegee in gevangenskap en Sy versierings in die hand van die teëstander. [Hooglied van Salomo 2:9]	",
"	62 En Hy het Sy volk oorgelewer aan die swaard en toornig geword op Sy Erfdeel.	",
"	63 Die vuur het hulle jongmanne verteer, en hulle maagde is nie geprys nie.	",
"	64 Hulle priesters het deur die swaard geval, en hulle weduwees het nie geween nie.	",
"	65 My Meester het wakker geword soos een wat slaap, soos ’n dappere wat uitbundig sing deur die blydskap van wyn;	",
"	66 en Hy het Sy teëstanders van agter geslaan, Hy het hulle ’n ewige smaadheid aangedoen.	",
"	67 En Hy het die Tent van JôWsef verwerp, en die Septer van Efraim het Hy nie uitverkies nie,	",
"	68 maar die Septer van JeHûWdah uitverkies, die Berg van Sion wat Hy liefhet.	",
"	69 En Hy het Sy Apartheidsplek soos hemelhoogtes gebou, soos die Aarde wat Hy vir ewig gegrondves het.	",
"	70 En Hy het Sy kneg Dawid uitverkies en hom van die skaapkrale af geneem.	",
"	71 Agter die lammerooie het Hy hom gaan weghaal, om Jakob, Sy volk, op te pas en JisraEl, Sy Erfdeel.	",
"	72 En hy het hulle opgepas na die egtheid van sy hart en hulle gelei met die verstandige oorleg van sy handpalms.	",
	
]
},
{
book: 'Psalms',
chapter: '79',
content: [
	
"	1 O ELOHIM, nasies het gekom in U Erfdeel, hulle het die Tempel van U Apartheid besoedel, Jerusalem tot puinhope gemaak.	",
"	2 Hulle het die lyke van U Knegte aan die vlieënde wesens van die Hemele tot spys gegee, die vlees van U Toegewydes aan die wilde wesens van die Aarde.	",
"	3 Hulle het húlle bloed rondom Jerusalem soos water uitgegiet, sonder dat iemand hulle begrawe. [1Makkabeër 7:17]	",
"	4 Ons het vir Ons bure ’n smaad geword, ’n spot en beskimping vir die wat rondom Ons is.	",
"	5 Hoe lank, JaHWeH, sal U vir ewig toornig wees, sal U Ywer brand soos ’n vuur?	",
"	6 Stort U Grimmigheid uit oor die nasies wat U nie ken nie, en oor die koninkryke wat U Naam nie aanroep nie.	",
"	7 Want hulle het Jakob verteer en sy Woning verwoes.	",
"	8 Reken Ons die ongeregtigheid van die voorvaders nie toe nie; laat U dade van Barmhartigheid Ons gou tegemoetkom, want Ons is baie swak.	",
"	9 Help Ons, o Elohey van Ons Lossing, om die Eer van U Naam, en red Ons en versoen Ons oortredinge ter wille van U Naam.	",
"	10 Waarom sou die nasies sê: Waar is hulle Elohey? Laat voor Ons oë onder die nasies bekend word die wraak oor die vergote bloed van U knegte.	",
"	11 Laat die gesug van die Gevangene voor U Aangesig kom; laat die kinders van die Dood oorbly na die grootheid van U Arm.	",
"	12 En vergeld Ons bure sewevoudig in hulle skoot die smaad waarmee hulle U, My Meester, gesmaad het.	",
"	13 En Ons, U volk en die skape van U weide, Ons sal U vir ewig loof, van geslag tot geslag sal Ons U lof vertel.	",
	
]
},
{
book: 'Psalms',
chapter: '80',
content: [
		
"	1 O HERDER van JisraEl, hoor tog; U wat JôWsef soos skape lei, wat bo-oor die Gérubs troon, verskyn in Lig- glans!	",
"	2 Wek U Mag op voor Efraim en Benjamin en Manasse, en kom Ons tot Verlossing!	",
"	3 o Elohim, herstel Ons, en laat U Aangesig skyn, sodat Ons verlos kan word!	",
"	4 o JaHWeH, Elohim van die skeppings-leërmagte, hoe lank nog rook U Toorn by die gebed van U volk?	",
"	5 U het hulle tranebrood laat eet, hulle oorvloedig trane laat drink.	",
"	6 U het Ons ’n voorwerp van stryd gemaak vir Ons bure, en Ons vyande drywe die spot.	",
"	7 o Elohim van die skeppings-leërmagte, herstel Ons, en laat U Aangesig skyn, sodat Ons verlos kan word!	",
"	8 ’n Wingerdstok het U uitgetrek uit Egipte; U het die nasies uitgedrywe en Haar geplant. [Sirag 24:17]	",
"	9 Hy verskyn voor Haar Aangesig en het Haar laat wortels skiet en Sy het die Aarde gevul.	",
"	10 Die berge was oordek met Haar skaduwee, en met Haar ranke die seders van El.	",
"	11 Sy het Haar ranke uitgebrei tot by die see en Haar lote na die rivier toe.	",
"	12 Waarom het Hy Haar mure stukkend gebreek, sodat almal wat met die pad verbygaan, Haar kaal pluk?	",
"	13 Die wildevark uit die bos eet Haar op, en wat beweeg op die veld, wei Haar af. [Henog 89:12]	",
"	14 o Elohim van die skeppings-leërmagte, kom tog terug; aanskou uit die Hemele en kyk, en gee ag op hierdie Wingerdstok;	",
"	15 en wees ’n beskerming vir Haar wat U Regterhand geplant het, en oor die Seun wat U vir Uself grootgemaak het.	",
"	16 Sy is met vuur verbrand, Sy is afgekap; vanweë die dreiging van U Aangesig kom Hulle om.	",
"	17 Laat U Hand wees oor die Man van U Regterhand, oor die Seun van Adam wat U vir Uself grootgemaak het.	",
"	18 Dan sal Ons nie van U afwyk nie; hou Ons in die lewe, dan sal Ons U Naam aanroep.	",
"	o JaHWeH, Elohim van die skeppings-leërmagte, herstel Ons; laat U Aangesig skyn, sodat Ons verlos kan word!	",
	
]
},
{
book: 'Psalms',
chapter: '81',
content: [
		
"	1 JUBEL tot die Eer van Elohim, Ons Sterkte! Juig tot Eer van die Elohey van Jakob!	",
"	2 Hef aan ’n lied en laat die tamboeryn klink, die lieflike siter saam met die harp.	",
"	3 Blaas die ramshoring op Maandsvernuwing, op die aangewese tyd vir Ons Feesdag.	",
"	4 Want sy is ’n Insetting vir JisraEl, ’n Verordening van die Elohey van Jakob.	",
"	5 Hy het haar ingestel as Getuienis in JôWsef toe Hy uitgetrek het teen die Aarde van Egipte. Die taal wat Ek gehoor het, het Ek geken:	",
"	6 Ek het sy skouer bevry van die las, sy handpalms het die mandjie gelos.	",
"	7 In die nood het jy geroep, en Ek het jou uitgered; Ek het jou geantwoord in die skuilplek van die donder; Ek het jou getoets by die waters van Mériba.Sela.	",
"	8 Hoor, My volk, en Ek wil jou dit inskerp; JisraEl, as jy tog na My wou luister!	",
"	9 Daar mag by jou geen verbasterde gode wees nie, en voor ’n uitlandse god mag jy jou nie neerbuig nie.	",
"	10 Ek is JaHWeH, jou Elohey wat jou laat optrek het uit die Aarde van Egipte; maak jou mond wyd oop, dat Ek haar kan vul.	",
"	11 Maar My volk het na My Stem nie geluister nie, en JisraEl was vir My nie gewillig nie.	",
"	12 Toe het Ek hulle oorgegee aan die verhardheid van hul hart, dat hulle in hul eie planne kon wandel.	",
"	13 Ag, as My volk maar na My wou luister, JisraEl in My Weë wou wandel!	",
"	14 Gou sou Ek hul vyande onderwerp en My Hand teen hul teëstanders uitstrek.	",
"	15 Die haters van JaHWeH sou kruipende na Hom toe kom; maar hulle tyd sou vir ewig wees.	",
"	16 Ja, Hy sou hulle voed met die beste van die koring; en met heuning uit die Rots sou Ek jou versadig.	",
	
]
},
{
book: 'Psalms',
chapter: '82',
content: [
	
"	1 ELOHIM staan in die vergadering van El; Hy regeer vanuit die midde van die Elohim. [Openbaring 5:6]	",
"	2 Hoe lank sal julle onregverdig oordeel en die aangesigte van die besoedelde verdra?Sela.	",
"	3 Doen Reg aan die swakke en die wees; gee aan die ellendige en die arme sy Reg.	",
"	4 Red die swakke en behoeftige, bevry [hulle] uit die hand van die besoedelde mense.	",
"	5 Hulle weet nie en verstaan nie; hulle loop rond in Duisternis: al die fondamente van die Aarde wankel.	",
"	6 Ek self het gesê: Julle is Elohim, en julle is almal Seuns van die Hoogste El -	",
"	7 nogtans sal julle sterwe soos adamiete, en soos een van die vorste sal julle val.	",
"	8 Staan op, o Elohim, oordeel die Aarde! Want U het erfbesit van al die nasies.	",
	
]
},
{
book: 'Psalms',
chapter: '83',
content: [
	
"	1 O ELOHIM, hou U nie stil nie, swyg nie en rus nie, o El!	",
"	2 Want kyk, U vyande maak rumoer, en U haters steek die hoof op.	",
"	3 Teen U volk smee hulle listig ’n plan en hou onder mekaar raad teen U verborgenes.	",
"	4 Hulle sê: Kom, laat ons hulle vernietig, dat hulle geen nasie meer is nie, sodat aan die naam van JisraEl nie meer gedink word nie.	",
"	5 Want hulle het van harte saam raad gehou; teen U sluit hulle ’n verbond:	",
"	6 die tente van Edom en die JismaEliete, Moab en die Hagareners,	",
"	7 Gebal en Ammon, en Amalek, Filistéa saam met die inwoners van Tirus.	",
"	8 Ook het Assur by hulle aangesluit; hulle is ’n arm vir die kinders van Lot.Sela.	",
"	9 Maak met hulle soos met Mídian, soos met Sísera, soos met Jabin by die spruit Kison:	",
"	10 hulle is verdelg by Endor, hulle het mis geword vir die  Adamah [die adamiet se Aarde].	",
"	11 Maak hulle, hul edeles, soos Oreb en Seëb, en al hulle vorste soos Seba en Salmúna,	",
"	12 wat sê: Laat ons die woninge van Elohim vir ons in besit neem!	",
"	13 My Elohey, maak hulle soos strooi, soos stoppels voor die Gees.	",
"	14 Soos vuur wat ’n bos verbrand, en soos die vlam wat berge aan die brand steek -	",
"	15 vervolg hulle só met U storm en verskrik hulle met U Stormwind.	",
"	16 Oordek hulle aangesig met skande, dat hulle U Naam kan soek, o JaHWeH!	",
"	17 Laat hulle beskaamd staan en verskrik wees vir ewig, en laat hulle rooi van skaamte word en omkom;	",
"	18 sodat hulle kan weet dat U, wie se Naam JaHWeH is, alleen die Hoogste El is oor die hele Aarde.	",

]
},
{
book: 'Psalms',
chapter: '84',
content: [
		
"	1 HOE lieflik is U Tabernakels, o JaHWeH van die skeppings-leërmagte!	",
"	2 My Siel verlang, ja, smag na die voorhowe van JaHWeH; My Hart en My Vlees jubel uit tot die lewende El.	",
"	3 Selfs vind die mossie ’n huis en die swaweltjie ’n nes vir haar, waar sy haar kleintjies neerlê, naamlik U altare, JaHWeH van die skeppings-Leërmagte, My Koning en My Elohey!	",
"	4 Geseënd is hulle wat woon in U Huis; hulle prys U gedurig.Sela.	",
"	5 Geseënd is die adamiet wie se sterkte in U is, in wie se hart die gebaande Weë is.	",
"	6 As hulle deur die droë laagte trek, maak hulle haar ’n fonteinland; ook oordek die vroeë reën haar met seëninge.	",
"	7 Hulle gaan van krag tot krag; elkeen [van hulle] sal verskyn voor Elohim in Sion.	",
"	8 JaHWeH, Elohim van die skeppings-Leërmagte, hoor My gebed; luister tog, o Elohey van Jakob!Sela.	",
"	9 O Elohim, Ons Skild, kyk en aanskou die Aangesig van U Gesalfde.	",
"	10 Want ’n dag in U voorhowe is suiwerder as duisend; Ek wil liewer by die drumpel staan in die Huis van My Elohey, as om te woon in die tente van besoedeling.	",
"	11 Want JaHWeH Elohim is ’n Sonsopkoms en ’n Skild; JaHWeH sal Guns en Eer gee; HY sal die suiwer [dinge] nie terughou aan die wat rassuiwerheid beoefen nie.	",
"	12 JaHWeH van die skeppings-Leërmagte, Geseënd is die adamiet wat op U vertrou!	",

]
},
{
book: 'Psalms',
chapter: '85',
content: [
	
"	1 U het, o JaHWeH, ’n welbehae gehad in U Aarde; die lot van Jakob het U verander.	",
"	2 U het die ongeregtigheid van U volk weggeneem, en hulle oortredinge bedek.Sela.	",
"	3 U het al U Grimmigheid teruggetrek, U het U brandende Woede afgewend.	",
"	4 Herstel Ons, o Elohey van Ons Lossing, en maak tot niet U Grimmigheid teen Ons!	",
"	5 Sal U vir ewig teen Ons toornig wees, U Toorn laat duur van geslag tot geslag?	",
"	6 Sal U Ons nie weer lewend maak, sodat U volk in U bly kan wees nie?	",
"	7 Toon Ons U Medelye, o JaHWeH, en gee Ons U  Lossing!	",
"	8 Ek wil hoor wat El van JaHWeH spreek. Ja, Hy spreek Vrede vir Sy volk en vir Sy toegewydes; maar laat hulle nie tot Dwaasheid terugkeer nie!	",
"	9 Gewis, Sy Lossing is naby die wat Hom Vrees, sodat Glansrykheid in Ons Aarde kan woon.	",
"	10 Medelye en Waarheid ontmoet mekaar; Regverdigheid en Vrede raak aan mekaar.	",
"	11 Waarheid spruit uit die Aarde en Regverdigheid kyk uit die Hemele neer.[Génesis 1:1; Psalm 108:4]	",
"	12 Ook gee JaHWeH Suiwerheid, en Ons Aarde lewer haar opbrengs.	",
"	13 Regverdigheid gaan voor Hom uit, en Hy let op die Weg van Sy voetstappe.	",
	
]
},
{
book: 'Psalms',
chapter: '86',
content: [
	
"	1 JaHWeH, neig U Oor, verhoor My, want Ek is ellendig en behoeftig.	",
"	2 Bewaar My Siel, want ’n toegewyde is Ek; U, My Elohey, verlos U kneg wat op U vertrou. [JeshaJaH 49:7]	",
"	3 Wees My barmhartig, My Meester, want Ek roep U aan die hele dag deur.	",
"	4 Verbly die Siel van U Kneg, want tot U, My Meester, hef Ek My Siel op.	",
"	5 Want U, My Meester, is suiwer en vergewensgesind en groot van Medelye vir almal wat U aanroep.	",
"	6 JaHWeH, luister na My gebed en let op die Stem van My smekinge.	",
"	7 In die dag van My benoudheid roep Ek U aan, want U verhoor My.	",
"	8 Daar is niemand soos U onder die Elohim, My Meester, en daar is niks soos U werke nie.	",
"	9 Al die nasies wat U gemaak het, sal kom en hulle voor U Aangesig neerbuig, My Meester, en hulle sal U Naam eer;	",
"	10 want U is groot en doen wonders, U alleen is Elohim.	",
"	11 Leer My, JaHWeH, U Weg: Ek sal in U Waarheid wandel; verenig My Hart tot die Vrees van U Naam. [JeHôWganan 14:26]	",
"	12 My Meester, My Elohey, Ek wil U loof met My hele Hart en U Naam vir ewig eer;	",
"	13 want U Medelye is groot oor My, en U het My Siel uit die Doderyk/Sheol diep daaronder gered.	",
"	14 o Elohim, hoogmoediges het teen My opgestaan, en ’n bende tiranne soek My Siel; en hulle stel U nie voor hul oë nie. [Psalm 22:12]	",
"	15 Maar U, My Meester, is ’n barmhartige en goedgunstige El, lankmoedig en groot van Medelye en Waarheid.	",
"	16 Wend U tot My en wees My barmhartig; gee U Sterkte aan U Kneg en verlos die Seun van U Diensmaagd.	",
"	17 Doen aan My ’n Teken ten goede, sodat My haters haar sien en beskaamd kan staan, omdat U, o JaHWeH, My gehelp en getroos het. [Lukas 2:34]	",
	
]
},
{
book: 'Psalms',
chapter: '87',
content: [
	
"	1 SY Fondament is in die berge van Apartheid. [Openbaring 21:14]	",
"	2 JaHWeH het die Poorte van Sion lief bo al die Tabernakels van Jakob.	",
"	3 Eerbare dinge word van U gesê, o Stad van die Elohim!Sela.	",
"	4 Ek wil Rahab en Babel vermeld onder hulle wat My ken; kyk, Filistéa en Tirus saam met Kuwsh - hierdie Een is daar gebore. [JeshaJaH 51:9]	",
"	5 En van Sion sal gesê word: Man vir man is in Haar gebore, en Hy, die Hoogste El, hou Haar in stand.	",
"	6 JaHWeH sal tel as Hy die volke opskrywe: Hierdie Een is daar gebore.Sela.	",
"	7 En die sangers, sowel as die musikante sê: Al My fonteine is in U!	",
	
]
},
{
book: 'Psalms',
chapter: '88',
content: [
	
"	1 JaHWeH, Elohey van My Verlossing, bedags roep Ek, in die nag is Ek voor U.	",
"	2 Laat My gebed voor U Aangesig kom, neig U Oor tot My smeking.	",
"	3 Want My Siel is sat van besoedeling, en My lewe raak aan die Doderyk/Sheol.	",
"	4 Ek word gereken by die wat in die put neerdaal; Ek het geword soos ’n magtige sonder krag,	",
"	5 vrygelaat onder die dooies; soos die wat verslaan is, wat in die graf lê, aan wie U nie meer dink nie, en wat afgesny is van U Hand.	",
"	6 U het My gesit in die put diep daaronder, in duister plekke, in dieptes.	",
"	7 U Grimmigheid rus op My, en U druk [My] neer met al U golwe.Sela.	",
"	8 U het My bekendes ver van My verwyder, My iets afskuweliks gemaak vir hulle; Ek is ingesluit en kan nie uitkom nie. [Hooglied 2:9]	",
"	9 My oog vergaan van ellende. JaHWeH, Ek roep U aan die hele dag deur, Ek strek My handpalms na U uit.	",
"	10 Kan U aan die dooies ’n wonder doen? Of kan skimme opstaan, kan hulle U loof?Sela.	",
"	11 Kan U Medelye vertel word in die graf, U  Getrouheid in Abáddon?	",
"	12 Kan U wonderwerke in die Duisternis bekend word en U Geregtigheid in die Aarde van vergetelheid?	",
"	13 Maar Ek, JaHWeH, roep U aan om hulp, en in die môre kom My gebed U tegemoet.	",
"	14 JaHWeH, waarom verstoot U My Siel, verberg U U Aangesig vir My?	",
"	15 Van jongs af is Ek ellendig en klaar om te sterwe; Ek dra U verskrikkinge, Ek is radeloos.	",
"	16 U brandende Woede het oor My gegaan; U verskrikkinge vernietig My;	",
"	17 die hele dag omring hulle My soos water, saam omsingel hulle My.	",
"	18 U het vriend en metgesel ver van My verwyder; My bekendes is Duisternis.	",

]
},
{
book: 'Psalms',
chapter: '89',
content: [
	
"	1 DIE Medelye van JaHWeH wil Ek vir ewig besing; Ek wil U Getrouheid bekend maak met My mond, van geslag tot geslag.	",
"	2 Want Ek het gesê: Medelye sal vir ewig gebou word; in die Hemele - daar bevestig U U Getrouheid.	",
"	3 Ek het ’n Verbond gesluit met My uitverkorene, met ’n eed aan Dawid, My kneg, belowe:	",
"	4 Tot in ewigheid sal Ek jou saad bevestig en jou troon opbou van geslag tot geslag.Sela.	",
"	5 En die Hemele loof U Wondermag, o JaHWeH, ook U Getrouheid in die vergadering van die apartes.	",
"	6 Want wie kan in die Hemele met JaHWeH vergelyk word? [Wie] is soos JaHWeH onder die seuns van El,	",
"	7 ’n El grootliks gedug in die Raad van die apartes en ontsagwekkend bo almal wat rondom Hom is?	",
"	8 O JaHWeH, Elohey van die skeppings-leërmagte, wie is soos U? Grootmagtig is U, o JaHH, en U Getrouheid is rondom U!	",
"	9 U heers oor die oprysing van die see; as sy golwe hulle verhef, bring U hulle tot bedaring.	",
"	10 U het Rahab verbrysel soos een wat verslaan is, met U Sterke Arm U vyande verstrooi. [JeshaJaH 51:9]	",
"	11 Aan U behoort die Hemele, aan U ook die Aarde; die wêreld en haar volheid - U het haar gegrond.	",
"	12 Die Noorde en die Suide - U het hulle geskape; Tabor en Hermon jubel in U Naam.	",
"	13 U het ’n Arm met mag; U Hand is sterk, U Regterhand verhewe.	",
"	14 Geregtigheid en Reg is die grondslag van U Troon: Medelye en Waarheid gaan voor U Aangesig uit.	",
"	15 Geseënd is die volk wat die geklank ken; o JaHWeH, hulle wandel in die Lig van U Aangesig.	",
"	16 In U Naam juig hulle die hele dag, en deur U Geregtigheid word hulle verhef.	",
"	17 Want U is hulle magtige sieraad, en deur U welbehae word Ons Horing verhef.	",
"	18 Want aan JaHWeH behoort Ons Skild, en die Aparte Een van JisraEl is Ons Koning.	",
"	19 Toe het U in ’n gesig gespreek met U Toegewyde en gesê: Ek het hulp verleen aan ’n dappere, ’n uitverkorene uit die volk verhef.	",
"	20 Ek het Dawid, My kneg, gevind, met die olie van My Apartheid hom gesalf;	",
"	21 met wie My Hand bestendig sal wees; ook sal My Arm hom versterk.	",
"	22 Die vyand sal hom nie oorval en die kwaaddoener hom nie verdruk nie;	",
"	23 maar Ek sal sy teëstanders voor hom weg verpletter; en die wat hom haat, sal Ek verslaan.	",
"	24 En My Getrouheid en My Medelye sal met hom wees, en deur My Naam sal sy horing verhef word.	",
"	25 En Ek sal sy hand lê op die see en sy regterhand op die riviere.	",
"	26 Hy is dit wat My sal noem: U is My Vader, My El en die Rots van My Verlossing!	",
"	27 Ja, Ék sal hom ’n Eersgeborene maak, die hoogste onder die konings van die Aarde.	",
"	28 Vir ewig sal Ek My Medelye vir hom bewaar, en My Verbond bly vir hom vas.	",
"	29 En Ek sal sy saad vir ewig laat duur en sy troon soos die dae van die Hemele.	",
"	30 As sy kinders My Wet verlaat en in My Reg nie wandel nie;	",
"	31 as hulle My Insettinge vermeng en My Gebooie nie hou nie,	",
"	32 dan sal Ek hulle oortreding met die Septer besoek en met plae hulle skuld vir ongeregtigheid.	",
"	33 Maar My Medelye sal Ek van hom nie ontneem en My Getrouheid nie verbreek nie.	",
"	34 Ek sal My Verbond nie besoedel nie, en wat oor My Lippe gegaan het, sal Ek nie verander nie.	",
"	35 Een maal het Ek gesweer in My Apartheid: Waarlik, Ek sal vir Dawid nie lieg nie!	",
"	36 Sy saad sal vir ewig wees en sy troon soos die son voor My.	",
"	37 Soos die maan sal hy vir ewig vasstaan, en die Getuie in die Hemele is getrou.Sela.	",
"	38 Maar U het self verstoot en verag, U het toornig geword teen U gesalfde.	",
"	39 U het die Verbond van U kneg tot niet gemaak, U het sy separatisme besoedel teen die Aarde.	",
"	40 U het al sy mure stukkend gebreek, sy vestings ’n puinhoop gemaak.	",
"	41 Almal wat met die pad verbygaan, het hom beroof; vir sy bure het hy ’n smaad geword.	",
"	42 U het die regterhand van sy teëstanders verhef, al sy vyande bly gemaak.	",
"	43 Ook het U die skerpte van sy swaard laat omdraai en hom nie laat standhou in die geveg nie.	",
"	44 U het sy suiwerheid onttrek en sy troon teen die Aarde neergewerp.	",
"	45 U het die dae van sy jeug verkort, hom met skaamte oordek.Sela.	",
"	46 Hoe lank sal U, o JaHWeH, Uself vir altyd verberg, sal U Grimmigheid brand soos ’n vuur?	",
"	47 Gedenk van watter lewensduur Ek is, tot watter nietigheid U al die seuns van adamiete geskape het!	",
"	48 Watter sterk man leef daar wat die Dood nie sal sien nie, wat sy siel sal kan red uit die mag van die Doderyk/Sheol?Sela.	",
"	49 My Meester, waar is U vorige Medelye wat U aan Dawid met ’n eed beloof het in U Getrouheid?	",
"	50 Onthou, My Meester, die skande van U knegte, hoe Ek in My boesem baie volke dra,	",
"	51 waarmee U vyande, o JaHWeH, smaad, waarmee hulle die voetstappe van U gesalfde smaad.	",
"	52 Geloofd sy JaHWeH vir ewig! Amein, ja amein.	",
	
]
},
{
book: 'Psalms',
chapter: '90',
content: [
		
"	1 MY Meester, U was vir ons ’n toevlug van geslag tot geslag.	",
"	2 Voordat die berge gebore was en U die Aarde en die wêreld voortgebring het, ja, van ewigheid tot ewigheid is U El.	",
"	3 U laat die man terugkeer tot stof en sê: Keer terug, o seuns van adam!	",
"	4 Want duisend jaar is in U Oë soos die dag van gister as dit verbyskiet, en soos ’n nagwaak.	",
"	5 Weggespoel het U hulle; hulle word ’n slaap; in die môre [is hulle] soos die gras wat weer uitspruit-	",
"	6 in die môre bot dit en spruit weer uit; in die aand sny ’n mens dit af, en dit verdor.	",
"	7 Want ons vergaan deur U Toorn, en deur U Grimmigheid word ons verskrik.	",
"	8 U stel ons ongeregtigheid voor U, ons verborgenhede in die Lig van U Aangesig.	",
"	9 Want al ons dae gaan verby deur U Grimmigheid, ons bring ons jare deur soos ’n gedagte.	",
"	10 Die dae van ons jare - daarin is sewentig jaar, of as ons baie sterk is, tagtig jaar; en die uitnemendste daarvan is moeite en verdriet; want gou gaan dit verby, en ons vlieg daarheen.	",
"	11 Wie ken die Sterkte van U Toorn en U Grimmigheid, ooreenkomstig die Vrees wat aan U verskuldig is?	",
"	12 Leer [ons] om ons dae so te tel dat ons ’n wyse hart mag bekom!	",
"	13 Keer terug, JaHWeH! Tot hoe lank? En ontferm U oor U knegte.	",
"	14 Versadig ons in die môre met U Medelye, sodat ons kan jubel en bly wees in al ons dae.	",
"	15 Maak ons bly na die dae waarin U ons verdruk het, na die jare waarin ons besoedeling gesien het.	",
"	16 Laat U werk vir U knegte sigbaar word en U Grootsheid oor hulle kinders.	",
"	17 En laat die Lieflikheid van my Meester onse Elohey oor ons wees, en bevestig die werk van ons hande oor ons, ja, die werk van ons hande, bevestig dit!	",

]
},
{
book: 'Psalms',
chapter: '91',
content: [
	
"	1 HY wat in die skuilplek van die Hoogste El sit, sal vernag in die skaduwee van die Almagtige.	",
"	2 Ek sal tot JaHWeH sê: My toevlug en My bergvesting, My Elohey op wie Ek vertrou.	",
"	3 Want dit is Hy wat U sal red uit die net van die voëlvanger, van die verderflike pes.	",
"	4 Hy sal U dek met Sy Vlerke, en onder Sy Vleuels sal U skuil; Sy Waarheid is U Skild en Pantser.	",
"	5 U hoef nie te vrees vir die skrik van die nag, vir die pyl wat bedags vlieg nie,	",
"	6 vir die pes wat in die donker wandel, vir die siekte wat op die middag verwoes nie!	",
"	7 Al val daar duisend aan U sy en tienduisend aan U regterhand - na U sal dit nie aankom nie.	",
"	8 Net met u oë sal U dit aanskou en die vergelding van die besoedelde sien.	",
"	9 Want U, JaHWeH, is My toevlug. Die Hoogste El het U U beskutting gemaak.	",
"	10 Geen besoedeling sal U tref en geen plaag naby U Tent kom nie;	",
"	11 want Hy sal Sy Boodskappers aangaande U bevel gee om U te bewaar op al U weë. [Lukas 4:10]	",
"	12 Hulle sal U op die handpalms dra, sodat U U voet teen geen klip stamp nie. [MattithJaHûW 4:6; Lukas 4:11]	",
"	13 Op die leeu en die adder sal U trap, die jong leeu en die Draak vertrap.	",
"	14 Omdat Hy My liefhet, daarom sal Ek Hom red; Ek sal Hom beskerm, omdat Hy My Naam ken.	",
"	15 Hy sal My aanroep, en Ek sal Hom verhoor; in die nood sal Ek by Hom wees; Ek sal Hom uitred en Eer aan Hom gee.	",
"	16 Met lengte van dae sal Ek Hom versadig, en Ek sal Hom My Verlossing laat sien.	",

]
},
{
book: 'Psalms',
chapter: '92',
content: [
	
"	1 DIT is suiwer om JaHWeH te loof en tot eer van U Naam musiek te maak, O Hoogste El,	",
"	2 om in die môre U Medelye te verkondig en U Getrouheid in die nagte;	",
"	3 by die tiensnarige instrument en by die harp, by snarespel op die siter.	",
"	4 Want U het My bly gemaak, JaHWeH, deur U dade; Ek jubel oor die werke van U Hande.	",
"	5 Hoe groot is U werke, o JaHWeH; baie diep is U gedagtes!	",
"	6 ’n Dom mens weet nie, en ’n dwaas verstaan dit nie:	",
"	7 as die besoedelde mense groei soos die plante en al die bewerkers van ongeregtigheid bot, [is dit] om hulle vir ewig te verdelg.	",
"	8 Maar U is hoog verhewe tot in ewigheid, O, JaHWeH!	",
"	9 Want kyk, U vyande, o JaHWeH, want kyk, U vyande sal vergaan; al die bewerkers van Ongeregtigheid sal verstrooi word.	",
"	10 Maar U verhoog My krag soos die van ’n eenhoring; Ek is met vars olie gesalf.	",
"	11 En My oog sien met welgevalle neer op die wat My voorlê, My ore hoor van die wat teen My as kwaaddoeners opstaan.	",
"	12 Die regverdige sal groei soos ’n palmboom; hy sal opgroei soos ’n seder op die Libanon.	",
"	13 Hulle wat geplant is in die Huis van JaHWeH, sal uitspruit in die Tuin van onse Elohey.	",
"	14 In die gryse ouderdom sal hulle nog vrugte dra, hulle sal vet en groen wees,	",
"	15 om te verkondig dat JaHWeH Reg is, My Rots, en in Hom is geen onreg nie.	",

]
},
{
book: 'Psalms',
chapter: '93',
content: [
		
"	1 JaHWeH regeer; Hy is met Majesteit bekleed. JaHWeH is bekleed, en met Sterkte gegord. Ook staan die wêreld vas, sodat sy nie wankel nie.	",
"	2 Vas staan U Troon van ouds af; van ewigheid af is U.	",
"	3 Die riviere, o JaHWeH, het verhef, die riviere het hulle gebruis verhef; die riviere verhef hulle geraas!	",
"	4 Meer as die gebruis van groot, geweldige waters, van die golwe van die see, is JaHWeH geweldig in die hoogte!	",
"	5 U Getuienisse is baie betroubaar. Apartheid is gepas by U Huis, JaHWeH, tot in lengte van dae!	",

]
},
{
book: 'Psalms',
chapter: '94',
content: [
	
"	1 EL van wraak, o JaHWeH, El van wraak, verskyn in Ligglans!	",
"	2 Verhef U, o Regter van die Aarde, vergeld die trotsaards [hulle] dade!	",
"	3 Hoe lank sal die besoedelde, o JaHWeH, hoe lank sal die besoedelde jubel?	",
"	4 Hulle smaal, hulle praat onbeskaamd - al die bewerkers van Ongeregtigheid verhef hulleself.	",
"	5 o JaHWeH, hulle verbrysel U volk, en hulle verdruk U Erfdeel.	",
"	6 Hulle maak die weduwee en die besoeker dood en vermoor die wese.	",
"	7 en sê: JaHWeH sien dit nie, en die Elohey van Jakob merk dit nie.	",
"	8 Let op, o onverstandiges onder die volk, en julle dwase, wanneer sal julle verstandig word?	",
"	9 Sou Hy wat die oor plant, nie hoor nie, of Hy wat die oog formeer, nie sien nie?	",
"	10 Sou Hy wat die nasies tugtig, nie straf nie - Hy wat die adamiet Kennis leer?	",
"	11 JaHWeH ken die gedagtes van die adamiete - dat hulle nietigheid is.	",
"	12 Geseënd is die sterk man, o JaHH, wat hom onderrig en wat hom leer uit U Wet,	",
"	13 om hom rus te gee van die dae van besoedeling, totdat die kuil vir die besoedelde gegrawe word.	",
"	14 Want JaHWeH sal Sy volk nie verwerp en sal Sy Erfdeel nie verlaat nie;	",
"	15 want die Reg sal terugkeer na Geregtigheid, en al die opregtes van hart sal haar volg.	",
"	16 Wie sal vir my optree teen die besoedeldes? Wie sal my bystaan teen die bewerkers van besoedeling?	",
"	17 As JaHWeH vir my nie ’n Hulp was nie, dan het my Siel gou in die stilte gewoon.	",
"	18 As Ek dink: my Voet wankel - dan ondersteun U Medelye my, o JaHWeH!	",
"	19 As my gedagtes binne-in my vermenigvuldig, dan verkwik U vertroostinge my Siel.	",
"	20 Sal die troon van verderflikheid met U verenig; wie bedrog bewerkstellig deur wetgewing?	",
"	21 Hulle bestorm die siel van die regverdige en besoedel onskuldige bloed.	",
"	22 Maar JaHWeH is ’n Rotsvesting vir my, en my Elohey is die Rots van my toevlug.	",
"	23 En Hy laat hulle eie ongeregtigheid op hulle terugkeer en verdelg hulle in hul besoedeling; JaHWeH, onse Elohey verdelg hulle.	",

]
},
{
book: 'Psalms',
chapter: '95',
content: [
		
"	1 KOM, laat Ons jubel tot die Eer van JaHWeH, laat Ons juig ter ere van die Rots van Ons Lossing!	",
"	2 Laat Ons SY Aangesig tegemoet gaan met dank, met lofsange HOM toejuig!	",
"	3 Want JaHWeH is ’n grote El, ja, die groot Koning bo al die elohim.	",
"	4 In Wie se Hand die diepste plekke van die Aarde is, en die toppe van die berge is Syne.	",
"	5 Aan Wie die see behoort wat Hy self gemaak het, en die droë grond wat Sy hande geformeer het.	",
"	6 Kom, laat Ons aanbid en neerbuk; laat Ons kniel voor die Aangesig van JaHWeH Ons Maker.	",
"	7 Want Hy is Onse Elohey, en Ons is die volk van Sy weide en die skape van Sy Hand. Ag, as julle vandag maar na Sy Stem wou luister!	",
"	8 Verhard julle hart nie soos by Mériba(versoeking), soos op die dag van Massa(beproewing) in die wildernis nie;	",
"	9 waar julle vaders My versoek het, My beproef het, alhoewel hulle My werk gesien het.	",
"	10 Veertig jaar het Ek ’n afkeer gehad van [hierdie] geslag en gesê: Hulle is ’n volk met ’n dwalende hart, en hulle ken My Weë nie;	",
"	11 sodat Ek in My Woede gesweer het: Waarlik, hulle sal in My rus nie ingaan nie! [Hebreërs 4:3, 5]	",

]
},
{
book: 'Psalms',
chapter: '96',
content: [
	
"	1 SING tot die Eer van JaHWeH ’n nuwe lied; sing voor JaHWeH, o ganse Aarde!	",
"	2 Sing tot die Eer van JaHWeH, loof Sy Naam, verkondig Sy Verlossing van dag tot dag.	",
"	3 Vertel onder die nasies Sy Eer, onder al die volke Sy wonders.	",
"	4 Want JaHWeH is groot en baie lofwaardig; Hy is gedug bo al die elohim.	",
"	5 Want al die gode van die volke is drek, maar JaHWeH het die Hemele gemaak.	",
"	6 Uitnemendheid en grootsheid is voor Sy Aangesig, Sterkte en prag in Sy Apartheidsplek.	",
"	7 Gee aan JaHWeH, o stamme van die volke, gee aan JaHWeH Eer en Sterkte.	",
"	8 Gee aan JaHWeH die Eer van Sy Naam, bring spysbydraes en kom in Sy voorhowe.	",
"	9 Buig neer vir JaHWeH in die prag van Apartheid; beef voor Sy Aangesig, o ganse Aarde!	",
"	10 Sê onder die volke: JaHWeH is Koning! Ook staan die wêreld vas, sodat sy nie wankel nie. Hy sal die volke regverdig oordeel.	",
"	11 Laat die Hemele bly wees en die Aarde juig; laat die see en sy volheid bruis.	",
"	12 Laat die veld juig en al wat daarin is; dan sal al die bome van die bos jubel	",
"	13 voor die Aangesig van JaHWeH; want Hy kom, want Hy kom om die Aarde te oordeel; Hy sal die wêreld oordeel met Geregtigheid en die volke in Getrouheid. [JeHôWganan 5:22]	",
	
]
},
{
book: 'Psalms',
chapter: '97',
content: [
	
"	1 JaHWeH is Koning; draai o Aarde; juig o groot eilande !	",
"	2 Die Wolkkolom en donkerheid is rondom Hom; Regverdigheid en Reg is die grondslag van Sy Troon.	",
"	3 ’n Vuur gaan voor Sy Aangesig uit en steek Sy teëstanders rondom aan die brand.	",
"	4 Sy bliksems verlig die wêreld; die Aarde sien en bewe.	",
"	5 Berge smelt weg soos was voor die Aangesig van JaHWeH, voor die Aangesig van die Meester van die hele Aarde.	",
"	6 Die Hemele verkondig Sy Geregtigheid, en al die volke sien Sy Glansrykheid.	",
"	7 Beskaamd staan almal wat die gesnede afbeeldings dien, wat drek verhef. Buig voor Hom neer al [julle] gode.	",
"	8 Sion hoor dit en is bly, en die dogters van JeHûWdah juig oor U Regsprake, o JaHWeH!	",
"	9 Want U, JaHWeH, is die Hoogste El oor die hele Aarde; U is hoog verhewe bo al die elohim.	",
"	10 o Liefhebbers van JaHWeH, haat die besoedeling! Hy bewaar die siele van Sy toegewydes, Hy red hulle uit die hand van die besoedelde.	",
"	11 Die Lig is vir die regverdige gesaai en vrolikheid vir die opregtes van hart.	",
"	12 o Regverdiges, wees bly in JaHWeH, en hef die hande op in dank aan die herinnering van Sy Apartheid!	",

]
},
{
book: 'Psalms',
chapter: '98',
content: [

		
"	1 SING tot die Eer van JaHWeH ’n nuwe lied, want Hy het wonders gedoen; Sy Regterhand en die Arm van Sy Apartheid het Hom gehelp.	",
"	2 JaHWeH het Sy Verlossing bekend gemaak, Sy Geregtigheid voor die oë van die nasies geopenbaar. [2 Ezra 7:26]	",
"	3 Hy het Sy Medelye en Sy Getrouheid aan die huis van JisraEl onthou; al die eindes van die Aarde het die Verlossing van onse Elohey gesien.	",
"	4 Juig voor die Aangesig van JaHWeH, o ganse Aarde, breek uit en maak musiek!	",
"	5 Maak musiek tot die Eer van JaHWeH met die siter, met die siter en die klank van ’n melodie,	",
"	6 met trompette en ramshoring geklank; juig voor die Aangesig van die Koning, JaHWeH!	",
"	7 Laat die see bruis en sy volheid, die wêreld en die wat in haar woon.	",
"	8 Laat die riviere [hul] handpalms klap, die berge tesame jubel	",
"	9 voor die Aangesig van JaHWeH; want Hy kom om die Aarde te oordeel; Hy sal die wêreld rig met Geregtigheid en die volke met Reg.	",
		
]
},
{
book: 'Psalms',
chapter: '99',
content: [
		
"	1 JaHWeH is Koning; laat die volke bewe! Hy troon op die Gérubs; laat die Aarde sidder! [JeségiEl 1:26]	",
"	2 JaHWeH is groot in Sion, en verhewe is Hy bo al die volke.	",
"	3 Laat hulle U grote en gedugte Naam loof, want Hy is Apart !	",
"	4 Ook die sterkte van die Koning wat die Reg liefhet. U het bevestig wat regverdig is; U het Reg en Geregtigheid gedoen in Jakob.	",
"	5 Verhoog JaHWeH Onse Elohey, en buig julle neer voor dieVoetbank van Sy Voete, [want] Apart [is] Hy! [JeshaJaH 66:1]	",
"	6 Moshè en Aäron was onder Sy priesters, en ShemuEl onder die aanroepers van Sy Naam. Hulle het JaHWeH aangeroep, en Hy het hulle verhoor.	",
"	7 In die Wolkkolom het Hy met hulle gespreek. Hulle het Sy Getuienisse onderhou en die Insetting wat Hy hulle gegee het.	",
"	8 o JaHWeH Onse Elohey, U het hulle verhoor, U was vir hulle ’n vergewende El en Een wat wraak oefen oor hulle dade.	",
"	9 Verhef JaHWeH Onse Elohey, en buig julle neer vir die Berg van Sy Apartheid. Want Apart is JaHWeH Onse Elohey.	",

]
},
{
book: 'Psalms',
chapter: '100',
content: [
		
"	1 JUIG voor JaHWeH, o ganse Aarde!	",
"	2 Dien JaHWeH met blydskap; kom voor Sy Aangesig met gejubel.	",
"	3 Erken dat JaHWeH Elohim is: Hy het ons gemaak, en ons is Syne, Sy volk en die skape van Sy weide.	",
"	4 Gaan Sy Poorte in met danksegging, Sy voorhowe met lofgesang; loof Hom, prys Sy Naam.	",
"	5 Want JaHWeH is suiwer; Sy Medelye is tot in ewigheid, en Sy Getrouheid van geslag tot geslag.	",
	
]
},
{
book: 'Psalms',
chapter: '101',
content: [
		
"	1 EK wil sing van Medelye en Reg; tot U Eer wil ek musiek maak, o JaHWeH!	",
"	2 Ek wil Myself wys gedra deur ‘n rassuiwere lewenswyse - wanneer sal U na My kom? Ek wandel in die egtheid van My Hart, binne-in My huis.	",
"	3 Ek stel Belijaal nie voor My oë nie; die dade van afvalliges haat Ek; dié sal My nie aankleef nie.	",
"	4 [Iemand met] verbasterings-neigings moet ver van My af bly, wie besoedel is, wil Ek nie ken nie.	",
"	5 Hy wat heimlik van sy naaste kwaad spreek, hom sal Ek vernietig; hy wat hoog van oë is en trots van hart, hom verdra Ek nie.	",
"	6 My oë sal wees op die getroues in die Aarde, dat hulle by My kan woon; dié wat rassuiwer wandel, dié mag My dien.	",
"	7 Hy wat bedrog pleeg, mag binne-in My Huis nie bly nie; wie leuens praat, kan voor My oë nie bestaan nie.	",
"	8 Elke môre sal Ek al die besoedelde van die Aarde vernietig, om al die bewerkers van Ongeregtigheid uit die Stad van JaHWeH uit te roei.	",

]
},
{
book: 'Psalms',
chapter: '102',
content: [
	
"	1 O JaHWeH, hoor My gebed, en laat My hulpgeroep tot by U kom!	",
"	2 Verberg U Aangesig nie vir My op die dag as Ek in benoudheid is nie; neig U oor tot My; op die dag as Ek roep, verhoor My gou!	",
"	3 Want My dae verdwyn soos rook en My Gebeente gloei soos ’n vuurherd.	",
"	4 Platgeslaan soos die plante en verdor is My Hart; want Ek vergeet om My Brood te eet.	",
"	5 Vanweë My harde gesug kleef My Gebeente aan My Vlees.	",
"	6 Ek is soos ’n pelikaan van die wildernis, Ek het geword soos ’n uil op die puinhope.	",
"	7 Ek is slapeloos en het geword soos ’n eensame voël op die dak.	",
"	8 Die hele dag smaad My vyande My; die wat teen My raas, gebruik My Naam as ’n vloek.	",
"	9 Want ek eet as soos brood en meng My drank met trane,	",
"	10 vanweë U Grimmigheid en U Toorn; want U het My opgehef en My weggewerp.	",
"	11 My dae is soos ’n skaduwee wat lank geword het, en Ek, soos die plante verdor Ek.	",
"	12 Maar U, o JaHWeH, U bly tot in ewigheid, en U gedenkteken van geslag tot geslag.	",
"	13 U sal opstaan, U oor Sion ontferm; want dit is tyd om Haar barmhartig te wees, want die bestemde tyd het gekom. [JeshaJaH 29:1]	",
"	14 Want U knegte het Haar klippe lief en betoon guns aan Haar stof. [2Ezra 7:71]	",
"	15 Dan sal die nasies die Naam van JaHWeH vrees en al die konings van die Aarde U Glansrykheid;	",
"	16 omdat JaHWeH Sion opgebou het, in Sy Glansrykheid verskyn het,	",
"	17 Hom gewend het tot die gebed van die Verstotene, en hulle gebed nie verag het nie. [JeshaJaH 54:1; Openbaring 6:10]]	",
"	18 Dit sal vir die volgende geslag opgeskrywe word, en die volk wat geskape gaan word, sal JaHWeH loof; [TsefánJaH 3:10]	",
"	19 omdat Hy neergekyk het uit die hoogte van Sy Apartheid, vanuit die Hemele het JaHWeH op die Aarde gelet, [JeshaJaH 18:4]	",
"	20 om die gekerm van die Gevangene te hoor, om los te maak die kinders van die Dood;	",
"	21 sodat hulle in Sion die Naam van JaHWeH kan vermeld en Sy lof in Jerusalem,	",
"	22 as die volke almal saam vergader, ook die koninkryke om JaHWeH te dien.	",
"	23 Hy het My Krag op die weg swak gemaak, My dae verkort.	",
"	24 My El, sê Ek, neem My nie weg in die helfte van My dae nie - U jare is van geslag tot geslag!	",
"	25 In die voortyd het U die Aarde gegrondves, en die Hemele is die werk van U Hande.	",
"	26 Hulle sal vergaan, maar U sal bly; ja, hulle almal sal soos ’n kleed verslyt; U verwissel hulle soos ’n kledingstuk, en hulle verdwyn.	",
"	27 Maar U bly dieselfde, en U jare het geen einde nie.	",
"	28 Die kinders van U knegte sal woon, en hulle saad sal voor U Aangesig bly bestaan.	",

]
},
{
book: 'Psalms',
chapter: '103',
content: [
	
"	1 LOOF JaHWeH, o My Siel, en alles wat binne-in My is, Sy gewyde Naam!	",
"	2 Loof JaHWeH, o My Siel, en vergeet geeneen van Sy weldade nie!	",
"	3 Wat al jou oortredinge vergewe, wat al jou krankhede genees,	",
"	4 wat jou lewe verlos van die verderf, wat jou kroon met Medelye en dade van Barmhartigheid,	",
"	5 wat jou mond versadig met die suiwere, sodat jou jeug weer nuut word soos dié van ’n arend.	",
"	6 JaHWeH doen dade van Geregtigheid en Reg aan almal wat verdruk word.	",
"	7 Hy het aan Moshè Sy Weë bekend gemaak, aan die kinders van JisraEl Sy dade.	",
"	8 Barmhartig en goedgunstig is JaHWeH, lankmoedig en groot in Medelye.	",
"	9 Hy sal nie vir altyd twis en nie vir ewig die Toorn behou nie.	",
"	10 Hy handel met ons nie na ons oortredinge en vergeld ons nie na ons skuld vir ongeregtigheid nie.	",
"	11 Want so hoog as die Hemele is bo die Aarde, so geweldig is Sy Medelye oor die wat Hom vrees.	",
"	12 So ver as die Ooste verwyderd is van die Weste, so ver verwyder Hy ons oortredinge van ons.	",
"	13 Soos ’n vader hom ontferm oor die kinders, so ontferm JaHWeH Hom oor die wat Hom vrees.	",
"	14 Want Hy, Hy weet watter maaksel ons is, gedagtig dat ons stof is.	",
"	15 Die man - soos die gras is sy dae; soos ’n blom van die veld, so bot hy.	",
"	16 As die wind oor haar gaan, is sy nie meer nie en sy plek ken hom nie meer nie.	",
"	17 Maar die Medelye van JaHWeH is van ewigheid tot ewigheid oor die wat Hom vrees, en Sy Geregtigheid vir kindskinders,	",
"	18 vir die wat Sy Verbond hou en aan Sy Bevele dink om dié te doen.	",
"	19 JaHWeH het Sy Troon in die Hemele gevestig, en Sy Koninkryk heers oor alles.	",
"	20 Loof JaHWeH, Sy Boodskappers, wat kragtig in sterkte is, wat Sy Woord volbring, in gehoorsaamheid aan die Stem van Sy Woord!	",
"	21 Loof JaHWeH, al Sy skeppings-leërmagte, Sy dienaars wat Sy welbehae doen!	",
"	22 Loof JaHWeH, al Sy werke, op al die plekke van Sy heerskappy! Loof JaHWeH, o My Siel!	",

]
},
{
book: 'Psalms',
chapter: '104',
content: [
	
"	1 LOOF JaHWeH, o My Siel! JaHWeH My Elohey, U is baie groot! Met Majesteit en grootsheid is U bekleed -	",
"	2 wat Uself omhul met Lig soos met ’n kleed, wat die Hemele uitspan soos ’n tentdoek; [JeségiEl 1:22; 2 Ezra 16:60]	",
"	3 wat Sy solders bou in die waters, wat van die wolke Sy wa maak, wat op die Vleuels van die Gees wandel, [JeshaJaH 6:2]	",
"	4 wat van Sy Boodskappers Geeste maak, Sy dienaars ‘n Verterende Vuur. [2 Ezra 8:22; Hebreërs 1:7 ; JeségiEl 1:5]	",
"	5 Hy het die Aarde gegrond op sy grondveste, sodat sy vir Ewig tot in Ewigheid nie wankel nie.	",
"	6 U het haar met die waterdieptes soos met ’n kleed oordek; die waters het bo-oor die berge gestaan.	",
"	7 Vir U dreiging het hulle gevlug, vir die Stem van U donder het hulle weggeskrik -	",
"	8 berge het opgerys, laagtes het weggesak - na die plek wat U vir hulle reggemaak het.	",
"	9 ’n Grens het U gestel waar hulle nie oor mag gaan nie; hulle mag die Aarde nie weer oordek nie. [Génesis 9:11]	",
"	10 Hy wat die Fonteine uitstuur in die holtes: tussen die berge loop hulle deur.	",
"	11 Hulle laat al die wilde wesens van die veld drink; die wilde-esels les hulle dors. [2 Ezra 16:61]	",
"	12 By hulle woon die vlieënde wesens in die lug; tussen die takke uit laat hulle die stem hoor.	",
"	13 Hy laat die berge drink uit Sy boonste kamers; die Aarde word versadig uit die vrug van U werke.	",
"	14 Hy laat gras uitspruit vir die diere en die plante tot diens van die adamiet: om broodkoring uit die Aarde te laat voortkom,	",
"	15 en dat wyn die mens se hart kan bly maak; om die aangesig te laat blink van olie, en dat brood die mens se hart kan versterk.	",
"	16 Die bome van JaHWeH word versadig, die seders van die Libanon wat Hy geplant het;	",
"	17 waar die voëls hulle neste maak, die ooievaar wie se huis die sipresse is.	",
"	18 Die hoë berge is vir die steenbokke, die rotse is ’n skuilplek vir die dasse.	",
"	19 Hy het die maan gemaak vir die vaste tye; die son ken sy tyd om onder te gaan.	",
"	20 U stel Duisternis, en dit word Nag, waarin al die lewende wesens van die bos uitkruip.	",
"	21 Die jong leeus brul om roof en begeer hulle voedsel van El.	",
"	22 As die son opgaan, dan trek hulle hul terug en gaan lê in hul slaapplekke.	",
"	23 Die adamiet gaan uit na sy werk en na sy arbeid tot die aand toe.	",
"	24 Hoe talryk is U werke, o JaHWeH! U het hulle almal deur Wysheid gemaak; die Aarde is vol van U skepsele!	",
"	25 Daar is die see, groot en alkante toe wyd - daar is ’n gewemel sonder getal, klein diere saam met grotes.	",
"	26 Daar gaan die skepe en die Leviátan wat U geformeer het om daarin te speel.	",
"	27 Hulle almal wag op U, dat U hulle voedsel kan gee op die regte tyd.	",
"	28 U gee [dit] aan hulle, hulle tel [dit] op; U maak U Hand oop, hulle word versadig met die suiwer dinge.	",
"	29 U verberg U Aangesig, hulle word verskrik; U neem hulle gees weg, hulle sterwe en keer terug tot hul stof.	",
"	30 U stuur U Gees uit, hulle word geskape; en U maak die aangesig van die Adamah[adamiet se Aarde] nuut. [JeségiEl 37]	",
"	31 Laat die Glansrykheid van JaHWeH vir ewig wees, laat JaHWeH bly wees oor Sy werke,	",
"	32 Hy wat die Aarde aankyk, en sy bewe; Hy raak die berge aan, en hulle rook.	",
"	33 Ek wil sing tot die Eer van JaHWeH solank as ek lewe; ek wil musiek maak tot die Eer van My Elohey solank as ek daar is.	",
"	34 Mag My oordenking Hom welgevallig wees; Ek sal bly wees in JaHWeH!	",
"	35 Mag die oortreders omkom van die Aarde en die besoedelde nie meer wees nie! Loof JaHWeH, o My Siel! Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '105',
content: [
	
"	1 LOOF JaHWeH, roep Sy Naam aan, maak onder die volke Sy dade bekend.	",
"	2 Sing, maak musiek tot Sy Eer, spreek van al Sy wonders.	",
"	3 Beroem julle in die Naam van Sy Apartheid; laat die hart van die wat JaHWeH soek, bly wees.	",
"	4 Vra na JaHWeH en Sy Sterkte; soek Sy Aangesig voortdurend.	",
"	5 Dink aan Sy wonders wat Hy gedoen het, aan Sy wondertekens en die Regsprake van Sy Mond,	",
"	6 o saad van Abraham, Sy kneg, o kinders van Jakob, Sy uitverkorenes!	",
"	7 Hy, JaHWeH, is onse Elohey; oor die hele Aarde is Sy Regsprake.	",
"	8 Hy dink vir ewig aan Sy Verbond, aan die Woorde wat Hy ingestel het vir duisend geslagte - [Génesis 17]	",
"	9 wat Hy met Abraham gesluit het, en Sy Eed aan Isak.	",
"	10 wat Hy ook vir Jakob as Insetting bekragtig het, vir JisraEl as ’n ewige Verbond,	",
"	11 met die woorde: Ek sal aan jou die Aarde van Kanaän gee, julle aangewese Erfdeel.	",
"	12 Toe hulle min manne in getal was, baie klein en vreemdelinge in haar,	",
"	13 en hulle getrek het van nasie tot nasie, van die een koninkryk na die ander volk,	",
"	14 het Hy geen adamiet toegelaat om hulle te verdruk nie; ook het Hy konings om hulle ontwil gestraf [en gesê]:	",
"	15 Raak My gesalfdes nie aan en doen My profete geen kwaad nie.	",
"	16 En Hy het ’n hongersnood oor die Aarde geroep: elke staf van brood het Hy verbreek.	",
"	17 Hy het ’n man voor hulle uitgestuur: JôWsef is as slaaf verkoop.	",
"	18 Hulle het sy voete in boeie geknel, sy siel het in die ysters gekom,	",
"	19 tot op die tyd dat sy woord uitgekom het, die Woord van JaHWeH hom beproef verklaar het.	",
"	20 Die koning het gestuur en hom losgemaak, die vors van die volke, en hom losgelaat.	",
"	21 Hy het hom aangestel as meester oor sy huis en as regeerder oor al sy goed;	",
"	22 om sy vorste te bind na sy siel, en aan sy oudstes moes hy Wysheid leer.	",
"	23 Toe het JisraEl na Egipte gekom, en Jakob het as vreemdeling vertoef in die Aarde van Gam.	",
"	24 En Hy het Sy volk baie vrugbaar gemaak en dit meer versterk as Sy teëstanders.	",
"	25 Hy het hulle hart verander, om Sy volk te haat, om listig teen Sy knegte te handel.	",
"	26 Hy het Moshè, Sy kneg, gestuur en Aäron wat Hy uitgekies het.	",
"	27 Dié het onder hulle Sy aangekondigde tekens gedoen en wonders in die Aarde van Gam.	",
"	28 Hy het Duisternis gestuur en dit donker gemaak; en hulle het nie teen Sy Woorde gerebelleer nie.	",
"	29 Hy het hulle waters verander in bloed en hulle visse laat sterwe.	",
"	30 Hulle Aarde het gewemel van paddas, in die kamers van hulle konings.	",
"	31 Hy het gespreek, en daar het muskiete gekom, muggies in hulle hele grondgebied.	",
"	32 Hy het hulle reëns hael gemaak, vuurvlamme in hulle Aarde.	",
"	33 En Hy het hulle wingerdstok en hulle vyeboom geslaan en die bome van hulle grondgebied verbreek. [Spreuke 30:15]	",
"	34 Hy het gespreek, en daar het sprinkane gekom en jong sprinkane sonder getal,	",
"	35 wat al die plante in hulle Aarde verslind het, ja, verslind het die vrugte van hulle Adamah [die adamiet se Aarde].	",
"	36 Hy het ook al die eersgeborenes in hulle Aarde getref, die eerstelinge van al hulle krag.	",
"	37 Toe het Hy hulle laat uitgaan met silwer en goud, en onder Sy stamme was daar niemand wat gestruikel het nie.	",
"	38 Egipte was bly toe hulle uittrek, want Vrees vir hulle het op hulle geval.	",
"	39 Hy het die Wolkkolom uitgebrei as bedekking en Vuur om die nag te verlig.	",
"	40 Hulle het gebid: toe laat Hy kwartels kom; en Hy het hulle versadig met hemelbrood.	",
"	41 Hy het ’n rots oopgemaak, en waters het gevloei; hy het geloop deur die dor plekke - ’n rivier!	",
"	42 Want Hy het onthou van die Woord van Sy Apartheid, aan Abraham, Sy kneg.	",
"	43 En Hy het Sy volk laat uitgaan met Vreugde, Sy uitverkorenes met gejubel.	",
"	44 En Hy het aan hulle die Aarde van die nasies gegee, en wat deur gemeenskappe met moeite verwerf is, het hulle in besit geneem,	",
"	45 dat hulle Sy Insettinge kan onderhou en Sy Wette bewaar. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '106',
content: [
		
"	1 HALALU-JaHH ! Loof JaHWeH, want Hy is suiwer, want Sy Medelye is tot in ewigheid.	",
"	2 Wie kan die magtige dade van JaHWeH uitspreek, al Sy roem verkondig?	",
"	3 Geseënd is hulle wat die Reg bewaar, die wat altyd Geregtigheid doen.	",
"	4 Dink aan My, o JaHWeH, na die welbehae in U volk, besoek My met U Verlossing,	",
"	5 dat Ek kan aanskou die suiwerheid van U uitverkorenes, dat Ek bly kan wees in die blydskap van U volk, My kan beroem met U Erfdeel.	",
"	6 Ons het oortree, saam met ons vaders; ons het verkeerd gedoen, besoedeld gehandel.	",
"	7 Ons vaders in Egipte het nie ag gegee op U wonders, hulle het nie gedink aan die veelheid van U Medelye nie, maar het gerebelleer by die see, by die Skelfsee.	",
"	8 Maar Hy het hulle verlos om Sy Naam ontwil, om Sy mag bekend te maak.	",
"	9 En Hy het die Skelfsee gedreig, sodat hy opgedroog het, en hulle deur die diepte laat gaan soos deur ’n wildernis.	",
"	10 En Hy het hulle verlos uit die hand van die hater en hulle bevry uit die hand van die vyand.	",
"	11 En die waters het hulle teëstanders oordek: nie een van hulle het oorgebly nie.	",
"	12 Toe het hulle aan Sy Woorde geglo, hulle het Sy lof gesing.	",
"	13 [Maar] hulle het gou Sy werke vergeet, op die besluite van Sy Raad nie gewag nie.	",
"	14 En hulle het baie begerig geword in die wildernis en El versoek in die [woesteny van] Jesimon.	",
"	15 Toe het Hy hulle gegee wat hulle gevra het, maar in hulle siel ’n maerte gestuur.	",
"	16 En hulle was in die laer afgunstig op Moshè, [en] op Aäron, die apartes van JaHWeH.	",
"	17 Die Aarde het oopgegaan en Datan verslind en die bende van Abiram oordek.	",
"	18 En ’n vuur het gebrand onder hulle bende, ’n vlam het die besoedelde aan die brand gesteek.	",
"	19 Hulle het by Horeb ’n kalf gemaak en gebuig voor ’n gegote beeld.	",
"	20 En hulle het hul Glansrykheid verruil vir die model van ’n bees wat gras eet.	",
"	21 Hulle het hul El vergeet, hulle Verlosser, wat groot dinge gedoen het in Egipte,	",
"	22 wonders in die Aarde van Gam, ontsagwekkende dinge by die Skelfsee.	",
"	23 Toe het Hy gesê dat Hy hulle sou verdelg, as Moshè, Sy uitverkorene, nie voor Sy Aangesig in die bres gaan staan het om Sy Grimmigheid af te keer, dat Hy nie sou vernietig nie.	",
"	24 Hulle het ook die kosbare Aarde versmaad, Sy woorde nie geglo nie;	",
"	25 en hulle het gemurmureer in hul tente, na die Stem van JaHWeH nie geluister nie.	",
"	26 Toe het Hy Sy Hand teen hulle opgehef om hulle neer te slaan in die wildernis,	",
"	27 en om hulle saad te versprei onder die nasies en hulle te verstrooi in die Aarde.	",
"	28 Ook het hulle hul aan Baäl-Peor gekoppel en dooie slagdiere geëet;	",
"	29 en hulle het Hom getart deur hul dade, sodat ’n plaag onder hulle uitgebreek het.	",
"	30 Toe het Pínehas opgetree en gerig geoefen, en die plaag het opgehou;	",
"	31 en dit is hom gereken tot Geregtigheid, van geslag tot geslag tot in ewigheid.	",
"	32 Hulle het [Hom] ook vertoorn by die waters van Mériba, en dit het met Moshè sleg gegaan om hulle ontwil;	",
"	33 want hulle het gerebelleer teen Sy Gees, sodat hy onverskillig gepraat het met sy lippe.	",
"	34 Hulle het die volke nie verdelg soos JaHWeH aan hulle gesê het nie,	",
"	35 maar hul met die nasies vermeng en hulle werke geleer.	",
"	36 En hulle het hulle idole gedien, en dit het vir hulle ’n strik geword.	",
"	37 Bowendien het hulle hul seuns en hul dogters aan die demone geslag	",
"	38 en onskuldige bloed vergiet - die bloed van hul seuns en hul dogters wat hulle aan die idole van Kanaän geslag het - sodat die Aarde deur bloedskuld besoedel is.	",
"	39 En hulle het besoedel geword deur hul dade en ontug gepleeg deur hul uitvindings.	",
"	40 Toe het die Toorn van JaHWeH ontvlam teen Sy volk, en Hy het ’n afsku gekry van Sy Erfdeel.	",
"	41 En Hy het hulle in die hand van die nasies gegee, en hulle haters het oor hulle geheers;	",
"	42 en hulle vyande het hulle verdruk, sodat hulle onder hul hand moes buig.	",
"	43 Hy het hulle baiekeer gered maar hulle was rebels in hulle raad. So het húlle dan weggesink deur hul wetsverbreking.	",
"	44 Nogtans het Hy hulle benoudheid aangesien toe Hy hulle smeking gehoor het;	",
"	45 en Hy het tot hulle beswil aan Sy Verbond gedink en berou gekry na die veelheid van Sy Medelye.	",
"	46 En Hy het hulle Medelye laat vind by almal wat hulle as gevangenes weggevoer het.	",
"	47 Verlos ons, JaHWeH onse Elohey, en versamel ons uit die nasies, dat ons die Naam van U Apartheid, kan loof en ons beroem in U lof!	",
"	48 Geloofd sy JaHWeH, die Elohey van JisraEl, van ewigheid tot ewigheid! En laat die hele volk sê: Amein. Halalu-JaHH/Prys jul JaHH!	",
	
]
},
{
book: 'Psalms',
chapter: '107',
content: [
		
"	1 LOOF JaHWeH, want Hy is suiwer, want Sy Medelye is tot in ewigheid!	",
"	2 Dit moet die verlostes van JaHWeH sê, wat HY uit die nood verlos het	",
"	3 en uit die Aarde versamel het, van die Ooste en die Weste, van die Noorde en van die see af.	",
"	4 Hulle het gedwaal in die wildernis, op woeste paaie; ’n Stad om in te woon het hulle nie gevind nie.	",
"	5 Honger, ook dors was hulle; hulle siel het in hulle versmag.	",
"	6 Toe het hulle JaHWeH aangeroep in hul benoudheid; uit hul angste het Hy hulle gered.	",
"	7 En Hy het hulle gelei op ’n regte pad om te gaan na ’n Stad om in te woon.	",
"	8 Laat hulle JaHWeH loof om Sy Medelye en om Sy wonderdade by die seuns van adam;	",
"	9 want Hy het die dorstige siel versadig en die hongerige siel met die suiwer dinge gevul.	",
"	10 Die wat in Duisternis en Doodskaduwee gesit het, gevang in ellende en ysters -	",
"	11 omdat hulle gerebelleer het teen die Woorde van El en die Raad van die Hoogste El verwerp het,	",
"	12 het Hy hulle hoogmoed deur smarte verneder; hulle het gestruikel, maar daar was geen helper nie.	",
"	13 Toe het hulle JaHWeH aangeroep in hul benoudheid; uit hul angste het Hy hulle verlos.	",
"	14 Hy het hulle uit Duisternis en die Doodskaduwee laat uitgaan en hulle bande verbreek.	",
"	15 Laat hulle JaHWeH loof om Sy Medelye en om Sy wonderdade aan die seuns van adam;	",
"	16 want Hy het koperdeure verbreek en ystergrendels stukkend geslaan. [2 Nikodemus 5:1]	",
"	17 Die [wat] dwase [was] vanweë die weg van hulle oortreding en weens hulle ongeregtigheid gepynig is	",
"	18 hulle siel het ’n afsku gehad van elke soort voedsel, en hulle het tot by die poorte van die Dood gekom.	",
"	19 Toe het hulle JaHWeH aangeroep in hul benoudheid; uit hul angste het Hy hulle verlos.	",
"	20 HY het Sy Woord uitgestuur, dat Hy hulle kon gesond maak en hulle uit hul kuile red.	",
"	21 Laat hulle JaHWeH loof oor Sy Medelye en oor Sy wonderdade aan die seuns van adam;	",
"	22 en laat hulle slagdiere slag met dank en Sy werke tel met gejubel.	",
"	23 Die wat na die see toe afdaal in skepe, wat handel drywe op die groot waters -	",
"	24 hulle het die werke van JaHWeH gesien en SY wonders in die Afgrond.	",
"	25 Want HY het gespreek en ’n stormwind laat opsteek wat die golwe daarvan opgesweep het.	",
"	26 Hulle het opgerys na die Hemele, neergedaal na die Afgrond - hulle siel het gesmelt vanweë die besoedeling.	",
"	27 Hulle het getuimel en gewaggel soos ’n dronk man, en al hulle Wysheid is beëindig.	",
"	28 Toe het hulle JaHWeH aangeroep in hul benoudheid, en uit hul angste het Hy hulle uitgelei.	",
"	29 Hy het die storm ’n gesuis gemaak, en hulle golwe het stil geword. [Markus 4:39]	",
"	30 Toe was hulle bly, omdat dit rustig geword het, en Hy het hulle gelei na die Hawe van hul begeerte. [Psalm 37:39]	",
"	31 Laat hulle JaHWeH loof oor Sy Medelye en oor Sy wonderdade aan die seuns van adam.	",
"	32 En laat hulle Hom verhoog in die vergadering van die volk en Hom roem in die kring van die oudstes.	",
"	33 Hy het riviere ’n wildernis gemaak en waterfonteine ’n dorsland,	",
"	34 vrugbare Aarde ’n brak Aarde, oor die besoedeling van die wat in haar woon.	",
"	35 Hy het die wildernis ’n waterplas gemaak en die dor Aarde waterfonteine;	",
"	36 en Hy het hongeriges daar laat bly, en hulle het ’n Stad gestig om in te woon.	",
"	37 En hulle het landerye gesaai en Wingerde geplant wat vrugte as opbrengs verskaf het.	",
"	38 En Hy het hulle geseën, sodat hulle sterk vermenigvuldig het, en hulle vee het Hy nie min gemaak nie.	",
"	39 Toe het hulle min geword en weggesink deur die druk van besoedeling en kommer -	",
"	40 Hy wat veragting uitstort oor edeles en hulle laat dwaal in ’n woeste wêreld, sonder pad -	",
"	41 Hy het die behoeftige beskerm teen verdrukking en die families soos kuddes gemaak.	",
"	42 Die opregtes sien dit en is bly, maar Ongeregtigheid sal haar mond toe hou.	",
"	43 Wie wys is, laat hy op hierdie dinge ag gee, en laat hulle let op die Medelye van JaHWeH.	",
	
]
},
{
book: 'Psalms',
chapter: '108',
content: [
	
"	1 MY Hart is gerus, o Elohim! Ek wil sing en musiek maak, met eerbetoon.	",
"	2 Waak op, harp en siter! Ek wil Shagar wakker maak.	",
"	3 Ek wil U loof onder die volke, o JaHWeH, en musiek maak tot U Eer, onder die gemeenskappe;	",
"	4 want U Medelye is groot bo die Hemele uit en U Waarheid tot by die wolke. [Psalm 85:11]	",
"	5 Verhef U bo die Hemele, o Elohim, en U Glansrykheid bo die hele Aarde!	",
"	6 Dat U bemindes gered kan word - verlos Ons deur U Regterhand en verhoor Ons!	",
"	7 Elohim het gespreek in Sy Apartheid: Ek wil jubel, Ek wil Sigem verdeel en die dal van Sukkot afmeet.	",
"	8 Gílead is Myne, Manasse is Myne, en Efraim is die beskutting van My hoof; JeHûWdah is My wetgewer.	",
"	9 Moab is My waskom; op Edom werp Ek My skoen; oor Filistéa jubel Ek.	",
"	10 Wie sal My bring in die versterkte Stad? Wie lei My tot in Edom?	",
"	11 Het U, o Elohim, Ons nie verwerp nie? En U trek nie uit, o Elohim, saam met Ons leërs nie.	",
"	12 Gee Ons Hulp teen die vyand, want die adamiet se hulp is vergeefse moeite.	",
"	13 In Elohim sal Ons kragtige dade doen, en Hy self sal Ons vyande vertrap.	",

]
},
{
book: 'Psalms',
chapter: '109',
content: [
		
"	1 O ELOHEY van My lof, moenie swyg nie!	",
"	2 Want hulle het die mond van die Besoedelde Een en die mond van die Bedriegster teen My oopgemaak; hulle het met My gespreek met ’n leuenagtige tong, [Psalm 109:14]	",
"	3 en My met woorde van haat omring; ja, hulle het My sonder oorsaak beveg.	",
"	4 Vir My liefde behandel hulle My vyandig, terwyl Ek tog [gedurig] bid.	",
"	5 En hulle het My besoedel vir suiwer opgelê en haat vir My liefde.	",
"	6 Stel ’n besoedelde oor hom en laat Satan staan aan sy regterhand.	",
"	7 As hy geoordeel word, laat hom as skuldige uitgaan, en laat sy gebed ‘n oortreding word.	",
"	8 Laat sy dae min wees; laat ’n ander sy amp neem.	",
"	9 Laat sy kinders wese word en sy vrou ’n weduwee;	",
"	10 en laat sy kinders oral rondswerwe en bedel en [brood] soek, weg van hulle puinhope af.	",
"	11 Laat die skuldeiser alles neem wat hy het, en laat verbasterdes sy goed buitmaak.	",
"	12 Laat niemand medelye hê met hom, en laat niemand hom oor sy wese ontferm nie.	",
"	13 Laat sy nakomelingskap uitgeroei word; laat hulle naam uitgedelg word in die volgende geslag.	",
"	14 Laat die ongeregtigheid van sy vaders onthou word deur JaHWeH, en laat die oortredinge van sy moeder nie uitgedelg word nie. [Psalm 109:2]	",
"	15 Laat hulle voortdurend voor die Aangesig van JaHWeH wees, dat Hy hulle gedagtenis van die Aarde af kan uitroei;	",
"	16 omdat hy nie daaraan gedink het om medelye te toon nie, maar die ellendige en behoeftige Man vervolg het en die moedelose van hart, om [hom] dood te maak.	",
"	17 Ja, hy het die vloek liefgehad en - sy het oor hom gekom; en hy het geen welbehae gehad in die seën nie en - sy het ver van hom af gebly.	",
"	18 Hy het die vloek aangetrek soos ’n kleed en - sy het soos water in sy binneste gekom en soos olie in sy gebeente.	",
"	19 Laat sy vir hom wees soos ’n kleed waarin hy hom toedraai, en ’n gordel wat hy voortdurend ombind.	",
"	20 Laat sy die loon van My teëstanders wees vanaf JaHWeH, en van hulle wat besoedeling spreek teen My Siel.	",
"	21 Maar U, o JaHWeH My Meester, maak dit [goed] met My om U Naam ontwil; omdat U Medelye suiwer is, red My.	",
"	22 Want Ek is ellendig en behoeftig, en My Hart is deurwond in My binneste.	",
"	23 Ek gaan heen soos ’n skaduwee as dit lank word; Ek is afgeskud soos ’n sprinkaan.	",
"	24 My knieë knik van vas, en My Vlees het maer geword, sonder vet.	",
"	25 En Ek het vir hulle ’n smaad geword; as hulle My sien, skud hulle hul hoof.	",
"	26 Help My, JaHWeH My Elohey! Verlos My deur U Goedgunstigheid,	",
"	27 sodat hulle kan weet dat Sy U Hand is: U, o JaHWeH, het dit gedoen.	",
"	28 Laat húlle vloek, maar U, seën U. Hulle het opgestaan en beskaamd geword, maar U Kneg is bly.	",
"	29 Laat My teëstanders beklee word met smaad en hulle toedraai in hul skande soos in ’n mantel.	",
"	30 Ek sal JaHWeH hardop loof met My Mond, en onder baie sal Ek Hom prys;	",
"	31 want Hy staan aan die Regterhand van die Behoeftige om te verlos van die wat Sy Siel veroordeel.	",

]
},
{
book: 'Psalms',
chapter: '110',
content: [
	
"	1 JAHWEH het tot My Meester gespreek: Sit aan My regterkant, totdat Ek U vyande maak ’n Voetbank vir U Voete. [Boekrol van Henog 1:8]	",
"	2 U Magtige Septer sal JaHWeH uitstrek uit Sion [en sê]: Heers te midde van U vyande.	",
"	3 U volk sal hul vrywillig aanbied op die dag van U Krag; in die prag van Apartheid, uit die Moederskoot van die môreskemer, en Sy sal vir U wees die Dou van U jeug.	",
"	4 JaHWeH het gesweer, en dit sal Hom nie berou nie: U is Priester vir ewig volgens die orde van Melgisédek. [Hebreërs 7:21]	",
"	5 My Meester, aan U regterhand, verbrysel konings in die dag van Sy Toorn.	",
"	6 Hy sal ’n strafgerig hou onder die nasies; Hy maak dit vol dooie liggame; Hy verbrysel ’n hoof oor ‘n groot deel van die Aarde.	",
"	7 Uit die stroom sal Hy drink op die pad; daarom sal Hy die Hoof ophef.Halalu-JaHH/Prys jul JaHH !	",

]
},
{
book: 'Psalms',
chapter: '111',
content: [

"	1 [a Alef.] Ek wil JaHWeH loof van ganser harte; [B Bet.] in die kring van die opregtes en in die vergadering.	",
"	2 [GÒ Ghimel.] Die werke van JaHWeH is groot; [D Dalet.] nagespeur [word hulle] deur almal wat daar ’n welbehae in het.	",
"	3 [h Hé.] Sy dade is Majesteit en grootsheid; [wÒ Waw.] en Sy Geregtigheid bestaan tot in ewigheid.	",
"	4 [z Zajin.] Hy het vir Sy wonders ’n gedenkteken opgerig; [j’ Get.] JaHWeH is goedgunstig en barmhartig.	",
"	5 [f Tet.] Aan die wat Hom vrees, het Hy spys gegee; [yI Jod.] Hy dink vir ewig aan Sy Verbond.	",
"	6 [K Kaf.] Hy het die Krag van Sy werke aan Sy volk bekend gemaak, [l Lamed.] deur hulle die Erfdeel van die nasies te gee.	",
"	7 [m’ Mem.] Die werke van Sy Hande is Waarheid en Reg; [n Noen.] al Sy bevele is betroubaar.	",
"	8 [s Samek.] Vasgestel is [hulle] vir altyd, vir ewig; [[ Ajin.] uitgevoer in Waarheid en Opregtheid.	",
"	9 [P Pé.] Hy het aan Sy volk Verlossing gestuur; [xi Tzadé.] Hy het Sy Verbond vir ewig ingestel; [q Kof.] Sy Naam is Apart en Ontsagwekkend.	",
"	10 [r Resj.] Die Vrees van JaHWeH is die beginsel van die Wysheid [ce Sin.] almal wat Haar beoefen, het ’n suiwer Verstand.[ce Sin.] almal wat Haar beoefen, het ’n suiwer Verstand.[T Taw.] Sy lof bestaan tot in ewigheid.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '112',
content: [
	
"	1 [a’ Alef.] Geseënd is die Man wat JaHWeH vrees,[B Bet.] wat ’n groot welbehae in Sy Gebooie het.	",
"	2 [G Ghimel.] Sy Saad sal geweldig wees op die Aarde;[Do Dalet.] die Geslag van die Opregtes sal geseën word.	",
"	3 [ho Hé.] Oorvloed en rykdom is in Sy Huis;[wÒ Waw.] en Sy Geregtigheid bestaan tot in Ewigheid.	",
"	4 [zÉ Zajin.] Vir die opregtes gaan Hy op as die Lig in die Duisternis:[j’ Get.] goedgunstig en barmhartig en regverdig.	",
"	5 [f Tet.] ‘n Suiwer Man wat Hom ontferm en uitleen,[yÒ Jod.] wat Sy sake volgens Reg besorg.	",
"	6 [K Kaf.] Want Hy sal nooit wankel nie;[l Lamed.] die Regverdige is in ewige nagedagtenis.	",
"	7 [mi Mem.] Hy vrees nie vir besoelde nuus nie;[n Noen.] Sy hart is gerus, vol vertroue op JaHWeH.	",
"	8 [s Samek.] Vas is Sy hart, Hy vrees nie.[[ Ajin.] totdat Hy op Sy teëstanders neersien.	",
"	9 [P Pé.] Hy strooi uit, Hy gee aan die behoeftiges; [xi Tzadé.] Sy Geregtigheid bestaan tot in Ewigheid; [q’ Kof.] Sy Horing word verhoog in Eer.	",
"	10 [r Resj.] Die besoedelde sien Hom en word vererg; [vi Sjin.] hy kners met sy tande en smelt weg; [T’ Taw.] die begeerte van die besoedelde mense vergaan.	",

]
},
{
book: 'Psalms',
chapter: '113',
content: [
	
"	1 HALALU-JaHH/Prys jul JaHH! Loof, o knegte van JaHWeH, loof die Naam van JaHWeH!	",
"	2 Laat die Naam van JaHWeH geprys word, van nou af tot in ewigheid!	",
"	3 Van die opgang van die son tot by sy ondergang, moet die Naam van JaHWeH geloof word!	",
"	4 JaHWeH is hoog bo al die nasies; bo die Hemele is SY Glansrykheid.	",
"	5 Wie is soos JaHWeH onse Elohey, wat hoog woon,	",
"	6 wat laag neersien, in die Hemele en op die Aarde?	",
"	7 Wat die Geringe uit die stof oprig, die Behoeftige van die ashoop af verhef;	",
"	8 om Haar te laat sit by die Edeles, by die Edeles van Sy volk.	",
"	9 Wat die Onvrugbare van die Huis laat woon, ’n blye Moeder van kinders. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '114',
content: [
		
"	1 TOE JisraEl uit Egipte getrek het, die huis van Jakob uit ’n volk met ’n vreemde taal,	",
"	2 het JeHûWdah Sy Apartheid geword, JisraEl Sy ryksgebied.	",
"	3 Die see het dit gesien en gevlug; die Jordaan het agteruitgewyk.	",
"	4 Die berge het rondgespring soos ramme, die heuwels soos lammers.	",
"	5 Wat is dit met jou, o see, dat jy vlug? o Jordaan, dat jy agteruitwyk?	",
"	6 o Berge, dat julle rondspring soos ramme? o Heuwels, soos lammers?	",
"	7 Beef, Aarde, voor die Aangesig van My Meester, voor die Aangesig van die Elowahh van Jakob,	",
"	8 wat die rots verander het in ’n waterplas, die keisteen in ’n waterfontein!	",
	
]
},
{
book: 'Psalms',
chapter: '115',
content: [
		
"	1 NIE aan Ons, o JaHWeH, nie aan Ons nie, maar aan U Naam gee Eer, om U Medelye, om U Waarheid ontwil.	",
"	2 Waarom sou die nasies sê: Waar is dan hulle Elohey?	",
"	3 terwyl Onse Elohey tog in die Hemele is; Hy doen alles wat Hom behaag.	",
"	4 Hulle afbeeldings is silwer en goud, ’n werk van adamitiese hande.	",
"	5 Hulle het ’n mond, maar praat nie; hulle het oë, maar sien nie;	",
"	6 ore het hulle, maar hoor nie; hulle het ’n neus, maar ruik nie;	",
"	7 hande, maar hulle tas nie; voete, maar hulle loop nie; hulle gee geen geluid deur hul keel nie.	",
"	8 Die wat hulle maak, sal net soos hulle word - elkeen wat op hulle vertrou.	",
"	9 JisraEl, vertrou op JaHWeH: Hy is hulle Hulp en hulle Skild!	",
"	10 Huis van Aäron, vertrou op JaHWeH: Hy is hulle Hulp en hulle Skild!	",
"	11 Julle wat JaHWeH vrees, vertrou op JaHWeH: Hy is hulle Hulp en hulle Skild.	",
"	12 JaHWeH het aan Ons gedink: Hy sal seën, Hy sal die huis van JisraEl seën, Hy sal die huis van Aäron seën.	",
"	13 Hy sal diegene seën wat JaHWeH vrees, die kleintjies saam met die grotes.	",
"	14 JaHWeH sal julle vermenigvuldig, julle en jul kinders.	",
"	15 Julle is geseënd deur JaHWeH wat Hemele en Aarde gemaak het.	",
"	16 Die Hemele is Hemele vir JaHWeH, maar die Aarde het Hy aan die seuns van adam gegee.	",
"	17 Die dode en almal wat na die stilte neerdaal, sal JaHH nie loof nie;	",
	
]
},
{
book: 'Psalms',
chapter: '116',
content: [
	
"	1 EK het JaHWeH lief, want HY hoor My Stem, My smekinge,	",
"	2 want HY het SY Oor tot My geneig; daarom sal Ek [Hom] in My dae aanroep.	",
"	3 Bande van Dood het My omring, en angste van die Doderyk/Sheol het My getref; Ek het benoudheid en kommer gevind.	",
"	4 Maar Ek het die Naam van JaHWeH aangeroep: Ag, JaHWeH, red My Siel.	",
"	5 JaHWeH is barmhartig en regverdig, en Onse Elohey is ’n Ontfermer.	",
"	6 JaHWeH bewaar die eenvoudiges; Ek het swak geword, maar HY het My gehelp.	",
"	7 My Siel, keer terug tot jou rus; want JaHWeH het goed aan jou gedoen.	",
"	8 Want U het My Siel gered van die Dood, My Oog van trane, My Voet van struikeling.	",
"	9 Ek sal wandel voor die Aangesig van JaHWeH in die Aarde van die lewendes.	",
"	10 Ek het geglo toe Ek gespreek het: Ek is diep neergebuig.	",
"	11 Ék het in My angs gesê: Alle adamiete is leuenaars.	",
"	12 Waarmee sal Ek JaHWeH vergoed vir al Sy weldade aan My?	",
"	13 Ek sal die Beker van Verlossinge opneem en die Naam van JaHWeH aanroep.	",
"	14 My Geloftes sal Ek aan JaHWeH betaal in die teenwoordigheid van Sy ganse volk.	",
"	15 Kosbaar is in die Oë van JaHWeH die dood van SY Toegewyde.	",
"	16 Ag, JaHWeH, sekerlik, Ek is U Kneg, Ek is U Kneg, die Seun van U Diensmaagd; U het My bande losgemaak.	",
"	17 Ek sal U ’n slagdier met dank slag en die Naam van JaHWeH aanroep.	",
"	18 Ek sal My Geloftes aan JaHWeH betaal in die teenwoordigheid van Sy ganse volk,	",
"	19 in die voorhowe van die Huis van JaHWeH, binne-in jou, o Jerusalem! Halalu-JaHH/Prys jul JaHH!	",
	
]
},
{
book: 'Psalms',
chapter: '117',
content: [
	
"	1 LOOF JaHWeH, alle nasies! Prys Hom, alle stamme!	",
"	2 Want Sy Medelye is geweldig oor ons, en die Waarheid van JaHWeH is tot in ewigheid. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '118',
content: [
		
"	1 LOOF JaHWeH, want Hy is suiwer, want Sy Medelye is tot in ewigheid!	",
"	2 Laat JisraEl dan sê dat Sy Medelye tot in ewigheid is!	",
"	3 Laat die huis van Aäron dan sê dat Sy Medelye tot in ewigheid is!	",
"	4 Laat die wat JaHWeH vrees, dan sê dat Sy Medelye tot in ewigheid is!	",
"	5 Uit die benoudheid het Ek JaHH aangeroep; JaHH het My verhoor in die ruimte.	",
"	6 JaHWeH is vír My; Ek sal nie vrees nie: wat kan ’n adamiet My aandoen?	",
"	7 JaHWeH is vír My as My Helper; so sal Ek dan neersien op die wat My haat.	",
"	8 Dit is beter om by JaHWeH te skuil as om op ‘n adamiet te vertrou.	",
"	9 Dit is beter om by JaHWeH te skuil as om op edeles te vertrou.	",
"	10 Alle nasies het My omsingel; dit is in die Naam van JaHWeH dat Ek hulle stukkend gekap het.	",
"	11 Hulle het My omsingel, ja, hulle het My omsingel; dit is in die Naam van JaHWeH dat Ek hulle stukkend gekap het.	",
"	12 Hulle het My omsingel soos bye - hulle is uitgeblus soos ’n doringtakvuur; dit is in die Naam van JaHWeH dat Ek hulle stukkend gekap het.	",
"	13 Jy het My hard gestamp om My te laat val, maar JaHWeH het My gehelp.	",
"	14 JaHH is My sterkte en lofprysing, en het My Verlossing geword.	",
"	15 ’n Stem van gejubel en van Verlossing is in die tente van die regverdiges: die Regterhand van JaHWeH doen kragtige dade.	",
"	16 Die Regterhand van JaHWeH verhef; die Regterhand van JaHWeH doen kragtige dade.	",
"	17 Ek sal nie sterwe nie, maar lewe en die werke van JaHH vertel.	",
"	18 JaHH het My hard gekasty, maar My aan Dood nie oorgegee nie.	",
"	19 Maak oop vir My die Poorte van Geregtigheid; Ek wil deur Haar ingaan, Ek wil JaHH loof.	",
"	20 Sy is die Poort van JaHWeH; regverdiges mag deur Haar ingaan.	",
"	21 Ek wil U loof, omdat U My verhoor het en My Verlossing geword het.	",
"	22 Die Klip wat die bouers verwerp het, het ’n Hoeksteen geword.	",
"	23 Sy het van JaHWeH gekom; Sy is wonderbaar in Ons oë.	",
"	24 Dit is die Dag wat JaHWeH gemaak het; laat Ons daaroor juig en bly wees. [Génesis 1:5]	",
"	25 Ek smeek, JaHWeH verlos nou!; Ek smeek, JaHWeH, gee tog voorspoed!	",
"	26 Geseënd is Hy wat kom in die Naam van JaHWeH! Ons seën julle uit die Huis van JaHWeH. [Lukas 13:35]	",
"	27 El van JaHWeH, Hy het Ons verlig. Span die feesbyeenkoms af met toue, tot by die horings van die altaar.	",
"	28 U is My El, en Ek wil U loof; o My Elohey, Ek wil U verhoog.	",
"	29 Loof JaHWeH, want Hy is suiwer, want Sy Medelye is tot in ewigheid!	",

]
},
{
book: 'Psalms',
chapter: '119',
content: [
	
"	1 [a’ Alef.] GESEËND is die met ‘n rassuiwer Weg, wat in die Wet van JaHWeH wandel.	",
"	2 Geseënd is die wat Sy Getuienisse bewaar, Hom van ganser harte soek;	",
"	3 wat geen ongeregtigheid bedryf nie, [maar] in Sy Weë wandel.	",
"	4 U het bevel gegee om U Insettinge uitermatig te bewaar.	",
"	5 Ag, was My weë maar vas om U Wette te onderhou!	",
"	6 Dan sal Ek nie beskaamd staan as Ek op al U Gebooie let nie.	",
"	7 Ek sal U loof in opregtheid van hart as Ek U regverdige Regsprake leer.	",
"	8 Ek sal U Insettinge onderhou; verlaat My nie geheel en al nie.	",
		
"	9 [B’ Bet.] Waarmee sal die jongeling sy pad rassuiwer hou? Deur [dit] te hou na U Woord.	",
"	10 Ek soek U met My hele Hart; laat My nie afdwaal van U Gebooie nie.	",
"	11 Ek het U Woord in My Hart gebêre, dat Ek teen U nie sal oortree nie.	",
"	12 Lofwaardig is U, o JaHWeH! Leer My U Insettinge!	",
"	13 Ek het met My lippe vertel al die Regsprake van U Mond.	",
"	14 Ek is vrolik in die Weg van U Getuienisse, soos oor allerhande rykdom.	",
"	15 Ek wil U Bevele oordink en op U Paaie let.	",
"	16 Ek sal My verlustig in U Insettinge, U Woord sal Ek nie vergeet nie.	",
		
"	17 [GÒ Ghimel.] Doen goed aan U Kneg, sodat Ek kan lewe; dan wil Ek U Woord bewaar.	",
"	18 Open My oë, dat Ek kan sien die wonders uit U Wet.	",
"	19 Ek is ’n besoeker in die Aarde; verberg U Gebooie nie vir My nie.	",
"	20 My Siel vergaan van verlange na U Regsprake altyddeur.	",
"	21 U dreig die hoogmoediges as gevloektes wat van U Gebooie afdwaal.	",
"	22 Wentel smaad en veragting van My af, want U Getuienisse het Ek bewaar.	",
"	23 Al sit vorste [en] beraadslaag teen My - U Kneg oordink U Insettinge.	",
"	24 Ja, U Getuienisse is My verlustiging, My Raadsmanne.	",
		
"	25 [D Dalet.] My Siel kleef aan die stof; maak My lewend na U Woord.	",
"	26 My weë het Ek vertel, en U het My verhoor; leer My U Insettinge!	",
"	27 Laat My die Weg van U Bevele verstaan, dat Ek U wonders kan oordink.	",
"	28 My Siel drup weg van kommer; rig My op na U Woord.	",
"	29 Verwyder van My die weg van leuens, en verleen My barmhartiglik U Wet.	",
"	30 Ek het die Weg van Getrouheid verkies; U Regsprake het Ek [voor My] gestel.	",
"	31 Ek kleef U Getuienisse aan; o JaHWeH, maak My nie beskaamd nie!	",
"	32 Ek sal op die Weg van U Gebooie wandel, want U verruim My Hart.	",
		
"	33 [h Hé.] JaHWeH, leer My die Weg van U Insettinge, sodat Ek haar tot die einde toe kan bewaar.	",
"	34 Gee My Verstand, dat Ek U Wet kan bewaar, ja, haar kan onderhou van ganser harte.	",
"	35 Laat My wandel op die Weg van U Gebooie, want in haar het Ek ’n behae.	",
"	36 Neig My Hart tot U Getuienisse en nie tot winsbejag nie.	",
"	37 Wend My oë af, dat hulle geen onbenulligheid sien nie; maak My lewend in U Weë.	",
"	38 Vervul aan U Kneg U belofte wat [pas by] U Vrees.	",
"	39 Wend My smaadheid af wat Ek vrees, want U Regsprake is suiwer.	",
"	40 Gewis, Ek het ’n begeerte tot U Bevele; maak My lewend deur U Geregtigheid.	",
"	41 [wI Waw.] En laat U Medelye oor My kom, o JaHWeH, U Verlossing volgens U Belofte,	",
"	42 sodat Ek My smader iets kan antwoord, want Ek vertrou op U Woord.	",
"	43 En onttrek die Woord van Waarheid nie geheel en al aan My Mond nie, want op U Regsprake wag Ek.	",
"	44 Dan wil Ek U Wet voortdurend onderhou, vir Ewig tot in Ewigheid,	",
"	45 en in die ruimte wandel, want Ek soek U Bevele.	",
"	46 Ook wil Ek voor konings van U Getuienisse spreek en My nie skaam nie.	",
"	47 En Ek wil My verlustig in U Gebooie wat Ek liefhet,	",
"	48 en My handpalms ophef na U Gebooie wat Ek liefhet, en U Insettinge oordink.	",
		
"	49 [z Zajin.] Gedenk die Woord aan U Kneg, omdat U My laat hoop het.	",
"	50 Dit is My troos in My ellende, dat U Belofte My lewend maak.	",
"	51 Hoogmoediges het baie met My gespot; van U Wet het Ek nie afgewyk nie.	",
"	52 Ek het gedink, o JaHWeH, aan U Regsprake van ouds, en Ek het My getroos.	",
"	53 Woede het My aangegryp vanweë die besoedelde wat U Wet verlaat.	",
"	54 U Insettinge was gesange vir My in die huis van My vreemdelingskap.	",
"	55 JaHWeH, in die nag het Ek gedink aan U Naam, en Ek het U Wet onderhou.	",
"	56 Sy het My deel geword, omdat Ek U Bevele bewaar het.	",
		
"	57 [h Get.] JaHWeH is My deel; Ek het gesê dat Ek U Woorde sal bewaar.	",
"	58 Ek het U van ganser harte om Barmhartigheid gesmeek; wees My barmhartig volgens U Belofte.	",
"	59 Ek het My weë oordink en My voete laat teruggaan na U Getuienisse.	",
"	60 Ek het My gehaas, en nie getalm nie, om U Gebooie te onderhou.	",
"	61 Die strikke van die besoedelde het My omring; U Wet het Ek nie vergeet nie.	",
"	62 Middernag staan Ek op om U te loof vir U Regsprake van Geregtigheid.	",
"	63 Ek is ’n metgesel van almal wat U vrees, en van die wat U Bevele onderhou.	",
"	64 JaHWeH, die Aarde is vol van U Medelye, leer My U Insettinge.	",
"	65 [fo Tet.] U het suiwer opgetree teenoor U Kneg, JaHWeH, na U Woord.	",
"	66 Leer My ’n suiwer Insig en Kennis, want Ek glo aan U Gebooie.	",
"	67 Voordat Ek neergebuig het, het Ek gedwaal; maar nou onderhou Ek U Woord.	",
"	68 U is suiwer en tree  suiwer op; leer My U Insettinge.	",
"	69 Hoogmoediges het My leuens toegedig; [maar] Ek bewaar van ganser harte U Bevele.	",
"	70 Hulle hart is ongevoelig soos vet; [maar] Ek verlustig My in U Wet.	",
"	71 Dit is tot My suiwerheid dat Ek verdruk was, sodat Ek U Insettinge sou leer.	",
"	72 Die Wet van U Mond is vir My suiwerder as duisende stukke goud en silwer.	",
		
"	73 [y Jod.] U Hande het My gemaak en My toeberei; maak My verstandig, dat Ek U Gebooie kan leer. [Odes van Salomo 19]	",
"	74 Die wat U vrees, sien My, en hulle is bly; want op U Woord wag Ek.	",
"	75 Ek weet, JaHWeH, dat U Regsprake regverdig is en dat U My deur Getrouheid verdruk het.	",
"	76 Laat tog U Medelye wees om My te troos volgens U belofte aan U Kneg.	",
"	77 Laat U dade van Barmhartigheid oor My kom, dat Ek kan lewe; want U Wet is My verlustiging.	",
"	78 Laat die hoogmoediges beskaamd staan, omdat hulle sonder oorsaak My onregverdig behandel het; [maar] Ek oordink U Bevele.	",
"	79 Laat die wat U vrees, na My terugkeer, en die wat U Getuienisse ken.	",
"	80 Laat My Hart volkome suiwer wees in U Insettinge, sodat Ek nie beskaamd hoef te staan nie.	",
		
"	81 [K Kaf.] My Siel smag na U redding; op U Woord wag Ek.	",
"	82 My oë smag na U belofte en sê: Wanneer sal U My vertroos?	",
"	83 Want Ek het geword soos ’n leersak in die rook; U Insettinge het Ek nie vergeet nie.	",
"	84 Hoeveel sal die dae van U Kneg wees? Wanneer sal U Reg oefen onder My vervolgers?	",
"	85 Hoogmoediges het vir My kuile gegrawe, hulle wat nie [lewe] na U Wet nie.	",
"	86 Al U Gebooie is Getrouheid; hulle vervolg My sonder oorsaak; help My! [Markus 14:1]	",
"	87 Hulle het My amper vernietig op die Aarde; maar Ek het U Bevele nie verlaat nie.	",
"	88 Maak My lewend deur U Medelye, dat Ek die Getuienis van U Mond kan onderhou.	",
		
"	89 [l Lamed.] Vir ewig, o JaHWeH, is U Woord aangestel in die Hemele.	",
"	90 U Getrouheid is van geslag tot geslag; U het die Aarde bevestig, en sy bly staan.	",
"	91 Volgens U Regsprake bly hulle vandag [nog] staan, want alle dinge is U knegte.	",
"	92 As U Wet nie My verlustiging was nie, dan het Ek omgekom in My ellende.	",
"	93 Ek sal U Bevele tot in ewigheid nie vergeet nie, want deur hulle het U My lewend gemaak.	",
"	94 Aan U behoort Ek: verlos My, want Ek soek U Bevele.	",
"	95 Die besoedelde lê en wag op My, om My om te bring; Ek gee ag op U Getuienisse.	",
"	96 Aan alle rasegtheid het Ek ’n einde gesien, [maar] U Gebooie is baie wyd.	",
		
"	97 [m Mem.] Hoe lief het Ek U Wet; sy is My bepeinsing die hele dag.	",
"	98 U Gebooie maak My wyser as My vyande, want hulle is myne vir ewig.	",
"	99 Ek is verstandiger as al My leermeesters, want U Getuienisse is My bepeinsing.	",
"	100 Ek het meer Verstand as die oues, want Ek bewaar U Bevele.	",
"	101 Ek het My voete teruggehou van elke besoedelde pad, dat Ek U Woord kan bewaar.	",
"	102 Ek het van U Regsprake nie afgewyk nie, want U het My geleer.	",
"	103 Hoe soet is U Beloftes vir My verhemelte, meer as heuning vir My Mond.	",
"	104 Uit U Bevele kry Ek Verstand; daarom haat Ek elke leuenpad.	",
		
"	105 [nE Noen.] U Woord is ’n lamp vir My voet en die Lig van My pad.	",
"	106 Ek het gesweer, en dit gehou, om U regverdige Regsprake te onderhou.	",
"	107 Ek is baie diep neergedruk; JaHWeH, maak My lewend na U Woord!	",
"	108 Laat tog die vrywillige gawes van My Mond U behaag, o JaHWeH, en leer My U Regsprake.	",
"	109 My Siel is voortdurend in My handpalms; nogtans vergeet Ek U Wet nie.	",
"	110 Die besoedelde het vir My ’n vangnet gespan; nogtans het Ek van U Bevele nie afgedwaal nie.	",
"	111 Ek het U Getuienisse vir ewig as Erfdeel ontvang, want hulle is die Vreugde van My Hart.	",
"	112 Ek het My Hart geneig, om U Insettinge te betrag, vir ewig, tot die einde toe.	",
		
"	113 [se Samek.] Twyfelaars haat Ek, maar U Wet het Ek lief.	",
"	114 U is My skuilplek en My Skild; op U Woord wag Ek.	",
"	115 Gaan weg van My, kwaaddoeners, dat Ek die Gebooie van My Elohey kan bewaar!	",
"	116 Ondersteun My volgens U Belofte, dat Ek kan lewe; en maak My nie beskaamd vanweë My hoop nie.	",
"	117 Steun My, dat Ek verlos word; dan sal Ek voortdurend op U Insettinge let.	",
"	118 U verag almal wat van U Insettinge afdwaal, want hulle bedrieëry is leuens.	",
"	119 U ruim al die besoedeldes van die Aarde weg [soos] skuim; daarom het Ek U Getuienisse lief.	",
"	120 My vlees sidder van skrik vir U, en Ek vrees vir U Regsprake.	",
		
"	121[[oo Ajin.] Ek het Reg en Geregtigheid gedoen: gee My nie oor aan My verdrukkers nie.	",
"	122 Wees Borg vir U Kneg tot suiwerheid; laat hoogmoediges My nie verdruk nie. [Hebreërs 7:22]	",
"	123 My oë smag na U Verlossing en na die belofte van U Geregtigheid.	",
"	124 Handel met U Kneg na U Medelye, en leer My U Insettinge.	",
"	125 Ek is U Kneg; gee My Verstand, dat Ek U Getuienisse kan ken.	",
"	126 Dit is tyd vir JaHWeH om te handel: hulle het U Wet verbreek.	",
"	127 Daarom het Ek U Gebooie lief, meer as goud, ja, as baie fyn goud. [Klaagliedere 4:2]	",
"	128 Daarom hou Ek al die Bevele aangaande alles vir Reg; elke leuenpad haat Ek.	",
		
"	129 [P Pé.] U Getuienisse is wonderbaar; daarom bewaar My Siel hulle.	",
"	130 Die ingang van U Woorde Verlig; dit gee onderskeiding aan die eenvoudiges.	",
"	131 Ek maak My Mond wyd oop en hyg, want na U Gebooie verlang Ek.	",
"	132 Wend U tot My en wees My barmhartig volgens die Reg van die wat U Naam liefhet.	",
"	133 Maak My voetstappe vas in U Woord, en laat geen Ongeregtigheid oor My heers nie.	",
"	134 Verlos My van die adamiet se verdrukking, sodat Ek U Bevele kan onderhou.	",
"	135 Laat U Aangesig skyn oor U Kneg, en leer My U Insettinge.	",
"	136 My oë loop af in strome van water, omdat hulle U Wet nie onderhou nie.	",
		
"	137 [x Tzadé.] JaHWeH, U is regverdig, en opreg is U Regsprake.	",
"	138 Die Getuienisse het U neergelê in Regverdigheid en Getrouheid.	",
"	139 My ywer verteer My, omdat My teëstanders U woorde vergeet het. [JeHôWganan 2:17]	",
"	140 U Woord is deur en deur gelouter, en U Kneg het Hom lief.	",
"	141 Ek is klein en verag, [maar] U Bevele vergeet Ek nie.	",
"	142 U Geregtigheid is Regverdigheid tot in ewigheid, en U Wet is Waarheid.	",
"	143 Benoudheid en angs het My getref, [maar] U Gebooie is My verlustiging.	",
"	144 U Getuienisse is Geregtigheid tot in ewigheid; maak My verstandig, dat Ek kan lewe.	",
		
"	145 [q Kof.] Ek het geroep van ganser harte; verhoor My, o JaHWeH! Ek wil U Insettinge bewaar.	",
"	146 Ek het U aangeroep; verlos My, dat Ek U Getuienisse kan onderhou.	",
"	147 Voor die môreskemering roep Ek om Hulp; op U Woord wag Ek.	",
"	148 My oë is die nagwake voor om U Woord te oordink.	",
"	149 Luister na My stem in Medelye; o JaHWeH, maak My lewend volgens U Regsprake.	",
"	150 Hulle kom nader wat bloedvermenging najaag, hulle wat ver van U Wet af is.	",
"	151 U, o JaHWeH, is naby, en al U Gebooie is Waarheid.	",
"	152 Lankal het Ek geweet uit U Getuienisse dat U hulle vir ewig gegrond het.	",
		
"	153 [r Resj.] Sien My ellende aan en red My, want U Wet vergeet Ek nie.	",
"	154 Verdedig My regsaak en verlos My; maak My lewend volgens U Belofte.	",
"	155 Die Verlossing is ver van die besoedelde, want hulle soek U Insettinge nie.	",
"	156 JaHWeH, U dade van Barmhartigheid is menigvuldig; maak My lewend volgens U Regsprake.	",
"	157 My vervolgers en My teëstanders is talryk; van U Getuienisse wyk Ek nie af nie.	",
"	158 Ek het die verraaiers gesien, en hulle het My gewalg omdat hulle U Woord nie onderhou nie.	",
"	159 Aanskou dat Ek U Bevele liefhet; o JaHWeH, maak My lewend na U Medelye.	",
"	160 Die hele inhoud van U Woord is Waarheid, en al U regverdige Regsprake is tot in ewigheid. [JeHôWganan 5:39]	",
		
"	161 [v Sin.] Vorste het My sonder oorsaak vervolg, maar My Hart vrees vir U Woord. [JeHôWganan 15:25]	",
"	162 Ek is vrolik oor U Belofte soos een wat ’n groot buit vind. [Lukas 15:9]	",
"	163 Leuens haat Ek en het daar ’n afsku van; U Wet het Ek lief.	",
"	164 Ek loof U sewe maal elke dag oor U regverdige Regsprake.	",
"	165 Die wat U Wet liefhet, het groot Vrede, en vir hulle is daar geen struikelblok nie. [JehôWganan 14:27]	",
"	166 o JaHWeH, Ek hoop op U Verlossing, en Ek hou U Gebooie.	",
"	167 My Siel onderhou U Getuienisse, en Ek het hulle baie lief.	",
"	168 Ek onderhou U Bevele en U Getuienisse, want al My weë is voor U.	",
		
"	169 [T Taw.] o JaHWeH, laat My Smeking nader kom voor U Aangesig; gee My Verstand volgens U Woord.	",
"	170 Laat My Smeking voor U Aangesig kom; red My volgens U Belofte. [ZekarJaH 12:10]	",
"	171 My lippe sal lofsange laat uitstroom, want U leer My U Insettinge.	",
"	172 My tong sal U Woord besing, want al U Gebooie is regverdig.	",
"	173 Laat U Hand My tot Hulp wees, want Ek het U Bevele verkies.	",
"	174 o JaHWeH, Ek verlang na U Verlossing, en U Wet is My verlustiging.	",
"	175 Laat My Siel lewe, dat sy U kan loof; en laat U Regsprake My help.	",
"	176 Sy het gedwaal soos ’n verlore skaap, soek U Kneg, want U Gebooie vergeet Ek nie.	",
	
]
},
{
book: 'Psalms',
chapter: '120',
content: [
		
"	1 EK roep JaHWeH aan in My benoudheid, en Hy verhoor My.	",
"	2 o JaHWeH, red My Siel van die valse lippe, van die bedrieglike tong!	",
"	3 Wat sal Hy jou gee of wat vir jou daaraan toevoeg, o bedrieglike tong?	",
"	4 Skerp pyle van ’n dappere saam met gloeiende kole van besembosse.	",
"	5 Wee My dat Ek as vreemdeling vertoef in Meseg, dat Ek by die tente van Duisternis woon!	",
"	6 Te lank al woon My Siel by haar, sy wat die Vrede haat.	",
"	7 Ek is vredeliewend; maar as Ek spreek, is hulle op oorlog uit.	",

]
},
{
book: 'Psalms',
chapter: '121',
content: [
	
"	1 EK slaan My oë op na die berge: waar sal My Hulp vandaan kom?	",
"	2 My Hulp is van JaHWeH wat Hemele en Aarde gemaak het.	",
"	3 Hy kan jou voet nie laat wankel nie; jou Bewaarder kan nie sluimer nie.	",
"	4 Kyk, die Bewaarder van JisraEl sluimer of slaap nie.	",
"	5 JaHWeH is jou Bewaarder; JaHWeH is jou Skaduwee aan jou regterhand.	",
"	6 Die son sal jou bedags nie steek nie, die maan ook nie by nag nie.	",
"	7 JaHWeH sal jou bewaar van alle besoedeling; jou siel sal Hy bewaar.	",
"	8 JaHWeH sal jou uitgang en jou ingang bewaar, van nou af tot in ewigheid.	",

]
},
{
book: 'Psalms',
chapter: '122',
content: [
	
"	1 EK was bly toe hulle vir my gesê het: Laat ons na die Huis van JaHWeH gaan!	",
"	2 Ons voete staan in Jou Poorte, o Jerusalem!	",
"	3 Jerusalem wat gebou is soos ’n Stad wat saamgevoeg is,	",
"	4 waarheen die stamme optrek, die stamme van JaHH - ’n Getuienis vir JisraEl! - om die Naam van JaHWeH te loof.	",
"	5 Want daar staan die Trone vir die Regspraak, die Trone van die huis van Dawid. [MattithJaHûW 19:28; Openbaring 20:4]	",
"	6 Bid om die Vrede van Jerusalem; mag hulle wat Jou liefhet, rustig lewe!	",
"	7 Mag daar Vrede wees in Jou skanse, rus in Jou paleise! [JeshaJaH 9:6]	",
"	8 Ter wille van my broers en my vriende wil ek spreek: Vrede in Jou!	",
"	9 Ter wille van die Huis van JaHWeH, onse Elohey, wil ek die suiwere vir Jou soek.	",
	
]
},
{
book: 'Psalms',
chapter: '123',
content: [
		
"	1 EK slaan My oë op tot U wat in die Hemele troon.	",
"	2 Kyk, soos die oë van die knegte is op die hand van hulle meesters, soos die oë van die Diensmaagd is op die hand van haar Meesteres - so is Ons oë op JaHWeH Onse Elohey, totdat Hy Ons barmhartig is.	",
"	3 Wees Ons barmhartig, o JaHWeH, wees Ons barmhartig, want meer as versadig is Ons van veragting;	",
"	4 meer as versadig is Ons siel van die spot van die oormoediges, van die veragting van die trotsaards!	",

]
},
{
book: 'Psalms',
chapter: '124',
content: [
	
"	1 AS JaHWeH nie vir Ons was nie - laat JisraEl dit sê;	",
"	2 as JaHWeH nie vir Ons was toe die adamiete teen Ons opgestaan het nie,	",
"	3 dan het hulle Ons lewendig verslind toe hulle toorn teen Ons ontvlam het;	",
"	4 dan het die waters Ons oorstroom, ’n stroom het oor Ons siel gegaan;	",
"	5 dan het die trotse waters oor Ons siel gegaan.	",
"	6 Geloofd sy JaHWeH wat Ons aan hulle tande nie as buit oorgegee het nie!	",
"	7 Ons siel het vrygeraak soos ’n voël uit die vangnet van die voëlvangers; die vangnet is gebreek, en Ons, Ons het vrygeraak.	",
"	8 Ons Hulp is in die Naam van JaHWeH wat Hemele en Aarde gemaak het.	",
	
]
},
{
book: 'Psalms',
chapter: '125',
content: [
	
"	1 HULLE wat op JaHWeH vertrou, is die Berg van Sion wat nie wankel nie, [maar] bly tot in ewigheid.	",
"	2 Rondom Jerusalem is berge vir Haar; so is JaHWeH rondom Sy volk van nou af tot in ewigheid.	",
"	3 Want die septer van die Besoedelde sal nie rus op die Erfdeel van die regverdiges nie, mits die regverdiges hulle hande nie sal uitsteek na wat verkeerd is nie. [JeségiEl 44:28]	",
"	4 JaHWeH, doen goed aan die suiweres en aan die wat opreg is in hulle harte.	",
"	5 Maar die wat langs krom paaie wegdraai, sal JaHWeH laat vergaan saam met die bewerkers van Ongeregtigheid. Vrede oor JisraEl!	",
	
]
},
{
book: 'Psalms',
chapter: '126',
content: [
	
"	1 TOE JaHWeH die gevangenisskap van Sion verander het, was Ons soos die wat droom.	",
"	2 Toe is Ons mond gevul met gelag en Ons tong met gejubel; toe het hulle onder die nasies gesê: JaHWeH het groot dinge aan hulle gedoen.	",
"	3 JaHWeH het groot dinge aan Ons gedoen: Ons was bly!	",
"	4 o JaHWeH, verander Ons gevange-nisskap soos waterstrome in die Suidland.	",
"	5 Hulle wat met trane saai, sal met gejubel maai.	",
"	6 Hy loop aldeur en ween en dra die saadkoring; Hy sal sekerlik kom met gejubel en Sy gerwe dra.	",

]
},
{
book: 'Psalms',
chapter: '127',
content: [
	
"	1 AS JaHWeH die Huis nie bou nie, tevergeefs werk die wat aan hom bou; as JaHWeH die Stad nie bewaar nie, tevergeefs waak die Wagter.	",
"	2 Tevergeefs dat julle vroeg opstaan, laat opbly, brood van smarte eet - net so goed gee Hy hom aan Sy Beminde in die slaap!	",
"	3 Kyk, seuns is ’n Erfdeel van JaHWeH; die vrug van die Moederskoot is ’n beloning.	",
"	4 Soos pyle in die hand van ’n dappere, so is die seuns van die jeug. [Odes van Salomo 23:6]	",
"	5 Geseënd is die Magtige wat sy pylkoker met hulle gevul het! Hulle sal nie beskaamd staan as hulle met die vyande in die poort spreek nie.	",
	
]
},
{
book: 'Psalms',
chapter: '128',
content: [
		
"	1 GESEËND is elkeen wat die Vrees van JaHWeH het, wat in Sy Weë wandel!	",
"	2 Die opbrengs van U handpalms sal U sekerlik eet; geseënd is U, en dit gaan met U goed!	",
"	3 U Vrou is soos ’n vrugbare Wingerdstok binne-in U Huis; U kinders soos Olyfboompies rondom U tafel. [Wysheid van Sirah 24:17; JeshaJaH 5:6; ZekarJaH 8:12]	",
"	4 Kyk, so sal sekerlik geseën word die Magtige wat JaHWeH vrees.	",
"	5 Mag JaHWeH U seën uit Sion, dat U die voorspoed van Jerusalem mag aanskou al die dae van U lewe!	",
"	6 En dat U U kindskinders mag aanskou! Vrede oor JisraEl!	",

]
},
{
book: 'Psalms',
chapter: '129',
content: [
		
"	1 ALREEDS te veel het hulle My as vyand behandel van My jeug af - laat JisraEl dit sê -	",
"	2 alreeds te veel het hulle My as vyand behandel van My jeug af; tog het hulle My nie oorwin nie.	",
"	3 Ploeërs het op My rug geploeg; hulle het hul vore lank getrek. [JeshaJaH 50:6; 53:7; Boodskap van Petrus 1:9]	",
"	4 JaHWeH is regverdig: Hy het die toue van die besoedelde afgekap.	",
"	5 Laat hulle beskaamd staan en agteruitwyk, almal wat Sion haat. [Openbaring 3:9]	",
"	6 Laat hulle word soos gras op die dakke wat verdor voordat ’n mens dit uittrek,	",
"	7 waarmee die maaier sy handpalms en die gerwebinder sy arm nie vul nie.	",
"	8 Sodat die wat verbygaan, nie sê nie: Die seën van JaHWeH oor julle! Ons seën julle in die Naam van JaHWeH.	",
	
]
},
{
book: 'Psalms',
chapter: '130',
content: [
	
"	1 UIT die dieptes roep Ek U aan, o JaHWeH!	",
"	2 My Meester, luister na My Stem; laat U Ore luister na die Stem van My Smekinge.	",
"	3 As U, JaHH, die Ongeregtigheid in gedagtenis hou, My Meester, wie sal bestaan?	",
"	4 Maar by U is vergewing, dat U gevrees mag word.	",
"	5 Ek wag op JaHWeH; My Siel wag, en Ek hoop op Sy Woorde.	",
"	6 My Siel [wag] op My Meester meer as hulle wat wag op die môre - wat wag op die môre.	",
"	7 Wag op JaHWeH, o JisraEl! want by JaHWeH is Medelye, en by Hom is daar veel Verlossing;	",
"	8 en Hy self sal JisraEl verlos van al sy skuld van ongeregtigheid.	",
	
]
},
{
book: 'Psalms',
chapter: '131',
content: [
	
"	1 O JaHWeH, My Hart is nie hoog en My oë nie trots nie, ook wandel Ek nie in dinge wat vir My te groot en te wonderbaar is nie.	",
"	2 Waarlik, Ek het My Siel tot bedaring gebring en stilgemaak; soos ’n gespeende Kind by Haar Moeder, soos ’n gespeende Kind is My Siel in My. [Hebreërs 5:12]	",
"	3 Wag op JaHWeH, o JisraEl, van nou af tot in ewigheid!	",
	
]
},
{
book: 'Psalms',
chapter: '132',
content: [
	
"	1 O JaHWeH, dink aan Dawid, aan al sy moeite;	",
"	2 dat hy aan JaHWeH gesweer het, [hierdie] Gelofte gedoen het aan die Magtige van Jakob:	",
"	3 Sekerlik sal Ek nie ingaan in die tent van My woning, of klim op die bed wat vir My gesprei is nie; [Sirag 14:25]	",
"	4 sekerlik sal Ek My oë geen slaap gun, aan My ooglede geen sluimering nie, [Wysheid van Salomo 6:15]	",
"	5 totdat Ek ’n Plek vind vir JaHWeH, ’n Tabernakel vir die Magtige van Jakob!	",
"	6 Kyk, Ons het van Hom gehoor in Efrata; Ons het Hom gevind in die velde van Jaär.	",
"	7 Laat Ons na Sy Tabernakel gaan, Ons neerbuig voor die Voetbank van Sy Voete.	",
"	8 Staan op na U Rusplek, JaHWeH, U en die Ark van U Sterkte!	",
"	9 Laat U priesters bekleed wees met Geregtigheid, en laat U toegewydes jubel.	",
"	10 Wys U Gesalfde nie af nie, ter wille van Dawid, U kneg.	",
"	11 JaHWeH het aan Dawid gesweer oor Waarheid, dat Hy nie Sy rug op Haar sal draai nie: Van die vrug van jou liggaam sal Ek laat sit op jou Troon.	",
"	12 As jou seuns My Verbond hou en My Getuienisse wat Ek hulle leer, dan sal húlle seuns ook vir ewig op jou Troon sit.	",
"	13 Want JaHWeH het Sion uitgekies, Hy het Haar as woonplek vir Hom begeer [en gesê]:	",
"	14 In Haar is My rusplek vir ewig; hier wil Ek woon, want Ek het Haar begeer.	",
"	15 Haar voorraad sal Ek ryklik seën, Haar Behoeftiges versadig met Brood;	",
"	16 en Haar priesters sal Ek met Lossing beklee, en Haar toegewydes sal vrolik jubel.	",
"	17 Daar sal Ek vir Dawid ’n Horing laat uitspruit; Ek het vir My Gesalfde ’n lamp toeberei.	",
"	18 Ek sal Sy vyande met skaamte beklee, maar op Hom sal Sy separatisme floreer.	",
	
]
},
{
book: 'Psalms',
chapter: '133',
content: [
	
"	1 KYK, hoe goed en hoe lieflik is dit dat broers ook saamwoon!	",
"	2 Sy is soos die suiwer olie op die hoof, wat afloop op die baard, die baard van Aäron, wat afloop op die soom van sy klere.	",
"	3 Sy is soos die Dou van Hermon wat neerdaal op die Berge van Sion; want daar gebied JaHWeH die Seën, die Lewe tot in Ewigheid!	",

]
},
{
book: 'Psalms',
chapter: '134',
content: [
	
"	1 KOM, loof JaHWeH, o alle knegte van JaHWeH wat snags in die Huis van JaHWeH staan!	",
"	2 Hef op julle Hande na die Apartheid, en loof JaHWeH!	",
"	3 Mag JaHWeH jou seën uit Sion, Hy wat Hemele en Aarde gemaak het!	",
	
]
},
{
book: 'Psalms',
chapter: '135',
content: [
		
"	1 HALALU-JaHH/Prys jul JaHH! Prys jul die Naam van JaHWeH! Prys jul, o knegte van JaHWeH,	",
"	2 wat staan in die Huis van JaHWeH, in die voorhowe van die Huis van onse Elohey!	",
"	3 Halalu-JaHH/Prys jul JaHH, want JaHWeH is Suiwerheid; maak musiek tot Eer van Sy Naam, want Hy is lieflik!	",
"	4 Want JaHH het Jakob vir Hom uitverkies, JisraEl as Sy eiendom.	",
"	5 Waarlik, Ek weet dat JaHWeH groot en onse Regeerder bo al die Elohim is.	",
"	6 Alles wat JaHWeH behaag, doen Hy in die Hemele en op die Aarde, in die seë en al die plekke van die Afgrond.	",
"	7 Hy wat die dampe laat opgaan van die Einde van die Aarde af, bliksemstrale by die reën maak, die Gees uit Sy wapenkamers laat uitgaan;	",
"	8 wat die eersgeborenes van Egipte getref het, van adamiete sowel as van wilde wesens;	",
"	9 wat tekens en wonders gestuur het binne-in jou, o Egipte, teen Farao en teen al sy knegte;	",
"	10 wat baie nasies verslaan het en magtige konings gedood het:	",
"	11 Sihon, die koning van die Amoriete, en Og, die koning van Basan, en al die koninkryke van Kanaän,	",
"	12 en hulle Aarde as Erfdeel gegee het, as Erfdeel aan JisraEl, Sy volk.	",
"	13 o JaHWeH, U Naam is tot in ewigheid, U herinnering, JaHWeH, van geslag tot geslag!	",
"	14 Want JaHWeH sal aan Sy volk Reg doen en Medelye hê met Sy knegte.	",
"	15 Die afbeeldinge van die nasies is silwer en goud, ’n werk van die hande van ‘n adamiet.	",
"	16 Hulle het ’n mond, maar praat nie; hulle het oë, maar sien nie;	",
"	17 ore het hulle, maar hoor nie; ook is daar geen asem in hulle mond nie.	",
"	18 Die wat hulle maak, sal net soos hulle word - elkeen wat op hulle vertrou.	",
"	19 Huis van JisraEl, loof JaHWeH! Huis van Aäron, loof JaHWeH!	",
"	20 Huis van Levi, loof JaHWeH! Julle wat JaHWeH vrees, loof JaHWeH!	",
"	21 Geloofd sy JaHWeH uit Sion, Hy wat in Jerusalem woon! Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '136',
content: [
		
"	1 LOOF JaHWeH, want Hy is Suiwerheid, want Sy Medelye is tot in ewigheid.	",
"	2 Loof die Elohey van die Elohim, want Sy Medelye is tot in ewigheid.	",
"	3 Loof die Meester van die Meesters, want Sy Medelye is tot in ewigheid -	",
"	4 Hy wat alleen groot wonders doen, want Sy Medelye is tot in ewigheid.	",
"	5 Wat die Hemele met verstand gemaak het, want Sy Medelye is tot in ewigheid.	",
"	6 Wat die Aarde op die water uitgespan het, want Sy Medelye is tot in ewigheid.	",
"	7 Wat die groot ligte gemaak het, want Sy Medelye is tot in ewigheid.	",
"	8 Die son om te heers oor die dag, want Sy Medelye is tot in ewigheid.	",
"	9 Die maan en Sterre om te heers oor die nag, want Sy Medelye is tot in ewigheid.	",
"	10 Wat die Egiptenaars getref het in hulle eersgeborenes, want Sy Medelye is tot in ewigheid.	",
"	11 En JisraEl onder hulle uitgelei het, want Sy Medelye is tot in ewigheid.	",
"	12 Met ’n Sterk Hand en met ’n Uitgestrekte Arm, want Sy Medelye is tot in ewigheid.	",
"	13 Wat die Skelfsee in stukke gesny het, want Sy Medelye is tot in ewigheid.	",
"	14 En JisraEl daar dwarsdeur laat gaan het, want Sy Medelye is tot in ewigheid.	",
"	15 En Farao saam met sy leër in die Skelfsee gestort het, want Sy Medelye is tot in ewigheid.	",
"	16 Wat Sy volk deur die wildernis gelei het, want Sy Medelye is tot in ewigheid.	",
"	17 Wat groot konings verslaan het, want Sy Medelye is tot in ewigheid.	",
"	18 En geweldige konings gedood het, want Sy Medelye is tot in ewigheid.	",
"	19 Sihon, die koning van die Amoriete, want Sy Medelye is tot in ewigheid.	",
"	20 En Og, die koning van Basan, want Sy Medelye is tot in ewigheid.	",
"	21 En hulle Aarde as Erfdeel gegee het, want Sy Medelye is tot in ewigheid.	",
"	22 As Erfdeel aan JisraEl, Sy kneg, want Sy Medelye is tot in ewigheid.	",
"	23 Wat in Ons vernedering aan Ons gedink het, want Sy Medelye is tot in ewigheid.	",
"	24 En Ons van Ons teëstanders losgeruk het, want Sy Medelye is tot in ewigheid.	",
"	25 Wat voedsel gee aan alle vlees, want Sy Medelye is tot in ewigheid.	",
"	26 Loof die El van die Hemele, want Sy Medelye is tot in ewigheid.	",
	
]
},
{
book: 'Psalms',
chapter: '137',
content: [
	
"	1 BY die riviere van Babel, daar het Ons gesit, ook geween as Ons aan Sion dink.	",
"	2 Aan die wilgerbome wat in Haar midde is, het Ons siters opgehang.	",
"	3 Want daar het hulle wat Ons as gevangenes weggevoer het, van Ons die woorde van ’n lied gevra en hulle wat Ons verdruk het, vreugde, deur te sê: Sing vir Ons ’n Sionslied.	",
"	4 Hoe sou Ons die lied van JaHWeH kan sing in ’n volksvreemde Adamah [die adamiet se Aarde]?	",
"	5 As Ek jou vergeet, o Jerusalem, laat My regterhand dan [Haarself] vergeet!	",
"	6 Laat My Tong kleef aan My verhemelte as Ek aan Jou nie dink nie, as Ek Jerusalem nie verhef bo My hoogste vreugde nie.	",
"	7 JaHWeH, bring in herinnering vir die kinders van Edom die dag van Jerusalem, hulle wat gesê het: Breek weg, breek weg, tot op die fondament in Haar!	",
"	8 o Dogter van Babel, jy wat verwoes moet word, geseënd is Hy wat jou sal vergeld wat jy Ons aangedoen het!	",
"	9 Geseënd is Hy wat jou kinders gryp en verpletter teen die rots!	",
	
]
},
{
book: 'Psalms',
chapter: '138',
content: [
	
"	1 EK sal U loof met My hele Hart; voor die Aangesig van die Elohim sal Ek musiek maak tot U Eer.	",
"	2 Ek sal My neerbuig na die Tempel van U Apartheid en U Naam loof, oor U Medelye en oor U Waarheid; want U het U Woord groot gemaak, bowenal U Naam.	",
"	3 Die dag toe Ek geroep het, het U My verhoor, My moedig gemaak met Krag in My Siel.	",
"	4 Al die konings van die Aarde sal U loof, o JaHWeH, as hulle gehoor het die Woorde van U Mond;	",
"	5 en hulle sal sing van die Weë van JaHWeH, want die Glansrykheid van JaHWeH is groot.	",
"	6 Want JaHWeH is verhewe; nogtans sien Hy die nederige aan, en die hoogmoedige ken Hy uit die verte.	",
"	7 As Ek te midde van benoudheid wandel, behou U My in die lewe; U steek U Hand uit teen die toorn van My vyande, en U Regterhand verlos My.	",
"	8 JaHWeH sal dit vir My voleindig! U Medelye, JaHWeH, is tot in ewigheid: laat nie vaar die werke van U Hande nie!	",
	
]
},
{
book: 'Psalms',
chapter: '139',
content: [
	
"	1 JaHWeH, U deurgrond en ken My.	",
"	2 U ken My sit en My opstaan; U verstaan van ver My gedagte.	",
"	3 U deurvors My gaan en My lê, en U is met al My weë goed bekend.	",
"	4 Want daar is nog geen woorde op My Tong nie - of U, JaHWeH, U ken alles van haar.	",
"	5 U sluit My in van agter en van voor, en U lê U Handpalms op My.	",
"	6 Kennis is te wonderbaar vir My, Sy is hoog: Ek kan nie tot by Haar kom nie.	",
"	7 Waar sou Ek heengaan van U Gees en waarheen vlug van U Aangesig?	",
"	8 Klim Ek op na die Hemele, U is daar; en maak Ek die Doderyk/Sheol My bed, kyk, U is daar!	",
"	9 Neem Ek die vleuels van Shagar, gaan Ek by die uiteinde van die see woon, [JeshaJaH 14:12]	",
"	10 ook daar sou U Hand My lei en U Regterhand My vashou.	",
"	11 En as Ek sê: Sekerlik, die Duisternis oorweldig My, selfs die Nag sal Lig hê om My,	",
"	12 dan is selfs die Duisternis vir U nie donker nie, en die Nag is verlig soos die Dag, die Duisternis, soos die Lig.	",
"	13 Want U het My Niere gevorm, My in My Moeder se skoot geweef.	",
"	14 Ek loof U, omdat U so ontsagwekkend wonderbaar is; wonderbaar is U werke! En My Siel weet dit alte goed.	",
"	15 My gebeente was vir U nie verborge toe Ek in die verborgenheid gemaak is nie, kunstig geweef in die dieptes van die Aarde.	",
"	16 U Oë het My ongevormde fetus gesien; en in U Boekrol is hulle almal opgeskrywe: dae dat [alles] bepaal was, toe nog geeneen van hulle daar was nie.	",
"	17 Hoe kosbaar is dan vir My U gedagtes, o El! Hoe geweldig is hulle volle som nie!	",
"	18 Wil Ek hulle tel, hulle is meer as die sand; word Ek wakker, dan is Ek nog by U.	",
"	19 o Elowahh, as U tog maar die besoedelde wou ombring! En julle manne van bloed, gaan van My af weg!	",
"	20 Hulle wat doelgerig teen U spreek, [U Naam] valslik verhef- U vyande!	",
"	21 JaHWeH, sou Ek dié nie haat wat vir U haat, en ’n afsku hê van die wat teen U opstaan nie?	",
"	22 Ek haat hulle met ’n volkome haat; vyande is hulle vir My! [Génesis 3:15; JirmeJaH 18:23]	",
"	23 Deurgrond My, o El, en ken My Hart; toets My en ken My gedagtes;	",
"	24 en kyk of daar by My ’n weg is van smart, en lei My op die ewige Weg!	",

]
},
{
book: 'Psalms',
chapter: '140',
content: [
	
"	1 RED My, JaHWeH, van die besoedelde adamiet, bewaar My vir die manne van geweld;	",
"	2 wat besoedelde dinge in die hart bedink, wat elke dag stryd verwek.	",
"	3 Hulle maak hul tong nat met Nagash/slang; gif van die adder is onder hulle lippe.Sela.	",
"	4 Bewaar My, JaHWeH, vir die hande van die besoedelde; behoed My vir die manne van geweld wat planne beraam om My Voete weg te stoot.	",
"	5 Trotsaards het vir My ’n vangnet gespan en toue; hulle het ’n net uitgespan aan die kant van die pad; strikke het hulle vir My gestel.Sela.	",
"	6 Ek het tot JaHWeH gesê: U is My El; luister tog, JaHWeH, na die Stem van My Smekinge!	",
"	7 JaHWeH My Meester, Sterkte van My Verlossing, U beskut My Hoof in die dag van stryd!	",
"	8 JaHWeH, gee tog nie die begeertes van die besoedelde nie; laat sy listige plan nie uitgaan, sodat hulle hul verhef nie.Sela.	",
"	9 Wat betref die hoof van die wat My omring - laat die bedrog van hulle lippe hulle oordek.	",
"	10 Laat vurige kole op hulle afgegooi word; mag Hy hulle laat val in die vuur, in kuile, sodat hulle nie weer opstaan nie!	",
"	11 Laat die besoedelde sprekers nie op Aarde bevestig word nie; die man van geweld - laat die besoedeling hom jaag met slag op slag.	",
"	12 Ek weet dat JaHWeH die regsaak van die Ellendige, die Reg van die Behoeftiges sal behartig.	",
"	13 Sekerlik, die regverdiges sal U Naam loof, die opregtes sal voor U Aangesig woon.	",
	
]
},
{
book: 'Psalms',
chapter: '141',
content: [
	
"	1 JaHWeH, Ek roep U aan; kom tog gou na My toe; luister na My Stem as Ek U aanroep.	",
"	2 Laat My Gebed soos reukwerk voor U Aangesig staan, die opheffing van My Handpalms soos die skemer spysbydrae. [Spreuke van Salomo 28:9; JeshaJaH 1:15]	",
"	3 JaHWeH, stel ’n wag voor My Mond, bewaar die deur van My Lippe.	",
"	4 Neig My Hart nie tot iets wat besoedel is, om besoedelde dade te doen saam met manne wat ongeregtigheid bewerk nie; en laat My van hulle lekkernye nie eet nie.	",
"	5 Laat die Regverdige My met Medelye slaan en My tugtig - hoofsalf is dit wat nie My Hoof sal breek nie; want nog is My gebed teen hulle besoedeling.	",
"	6 As hulle regters aan die kant van die rots afgegooi word, dan sal hulle hoor dat My woorde lieflik is.	",
"	7 Soos ’n mens in die Aarde vore en skeure trek, is Ons beendere gestrooi by die mond van die Doderyk/Sheol.	",
"	8 Want op U is My oë, My Meester, by U skuil Ek: moenie My Siel ontbloot nie!	",
"	9 Bewaar My vir die mag van die vangnet van die wat vir My strikke stel, en vir die strikke van die bewerkers van besoedeling.	",
"	10 Laat die besoedelde in hulle vangkuile val, almal saam, terwyl Ek verbygaan!	",

]
},
{
book: 'Psalms',
chapter: '142',
content: [
	
"	142 HARDOP roep Ek JaHWeH aan, hardop smeek Ek JaHWeH.	",
"	2 Ek stort My klagte uit voor Sy Aangesig; Ek maak voor Sy Aangesig My nood bekend.	",
"	3 As My Gees in My versmag, dan ken U My pad. Op die pad wat Ek moet gaan, het hulle ’n vangnet vir My gespan.	",
"	4 Ek sien uit na regs en kyk, maar daar is niemand wat My ken nie; die toevlug is vir My verlore; niemand vra na My nie. [Prediker 10:2]	",
"	5 Ek roep U aan, o JaHWeH! Ek sê: U is My skuilplek, My deel in die Aarde van die lewendes.	",
"	6 Luister na My Smeking, want Ek is baie swak; red My van My vervolgers, want hulle is vir My te sterk.	",
"	7 Lei My Siel uit die gevangenis om U Naam te loof. Die regverdiges sal My omring as U aan My goed doen. [Hooglied 2:9]	",

]
},
{
book: 'Psalms',
chapter: '143',
content: [
	
"	1 O JaHWeH, hoor My gebed; luister tog na My smekinge; verhoor My in U Getrouheid, in U Geregtigheid.	",
"	2 En gaan nie na die Reg met U Kneg nie, want niemand wat leef, is voor U Aangesig regverdig nie.	",
"	3 Want die vyand vervolg My Siel; hy vertrap My Lewe teen die Aarde; hy laat My woon in duister plekke, soos hulle wat dood is vir ewig.	",
"	4 En My Gees versmag in My, My Hart verstyf in My binneste.	",
"	5 Ek dink aan die dae uit die voortyd; Ek peins oor al U dade; Ek dink ná oor die werk van U Hande.	",
"	6 Ek brei My Hande tot U uit; My Siel [dors] na U soos ’n uitgedorde Aarde.Sela.	",
"	7 Verhoor My tog gou, JaHWeH: My Gees beswyk! Verberg U Aangesig nie vir My nie, sodat Ek nie word soos hulle wat in die put neerdaal nie. [MattithJaHûW 27:46]	",
"	8 Laat My U Medelye in die môre hoor, want op U vertrou Ek; maak My bekend die pad wat Ek moet gaan, want Ek hef My Siel op tot U.	",
"	9 Red My van My vyande, JaHWeH! By U skuil Ek.	",
"	10 Leer My om U welbehae te doen, want U is My Elohim. Laat U Gees van Suiwerheid My lei in ’n gelyk Aarde.	",
"	11 o JaHWeH, maak My lewend om U Naam ontwil; lei My Siel uit die benoudheid, in U Geregtigheid.	",
"	12 En vernietig My vyande deur U Medelye, en bring hulle almal om wat My as vyand behandel; want Ek is U Kneg.	",

]
},
{
book: 'Psalms',
chapter: '144',
content: [
		
"	1GELOOFD sy JaHWeH, My Rots, wat My hande leer om te veg, My vingers om oorlog te voer -	",
"	2 My Suiwerheid en My Bergvesting, My Skans en My Redder, My Skild en die Een by wie Ek skuil, wat My volk aan My onderwerp.	",
"	3 o JaHWeH, wat is die adamiet dat U hom ken, die Seun van Adam dat U op hom ag gee?	",
"	4 Die adamiet is soos die nietigheid; sy dae is soos ’n vlugtige skaduwee.	",
"	5 Buig U Hemele, JaHWeH, en daal neer; raak die berge aan, dat hulle rook!	",
"	6 Slinger bliksems en verstrooi hulle; stuur U pyle uit en verwar hulle!	",
"	7 Strek uit die hoogte U Hande uit; ruk My uit, en red My uit groot waters, uit die hand van die seuns van die uitlander,	",
"	8 wie se mond leuens spreek en wie se regterhand ’n regterhand van bedrog is.	",
"	9 o Elohim, Ek wil ’n nuwe lied sing tot U Eer, op die tiensnarige harp wil Ek musiek maak.	",
"	10 U wat aan konings die oorwinning gee, wat U kneg Dawid ontruk aan die besoedelde swaard.	",
"	11 Ruk My uit en red My uit die hand van die seuns van die uitlander, wie se mond leuens spreek en wie se regterhand ’n regterhand van bedrog is;	",
"	12 sodat Ons seuns soos plante mag wees wat opgekweek is in hulle jeug, Ons dogters soos hoekpilare wat uitgebeitel is na die vorm van ’n paleis;	",
"	13 dat Ons skure vol mag wees, wat allerhande soorte [voorraad] oplewer; Ons kleinvee by duisende mag aanteel, by tienduisende vermeerder word op Ons velde;	",
"	14 Ons beeste gelaai mag wees; geen bres [in Ons mure] en geen uittog daaruit, en geen geskreeu op Ons pleine nie.	",
"	15 Geseënd is die volk met wie dit so gaan; geseënd is die volk wie se Elohey JaHWeH is!	",

]
},
{
book: 'Psalms',
chapter: '145',
content: [
	
"	1 [a Alef.] o My Elohim, o Koning, Ek wil U verhoog en U Naam loof vir Ewig tot in Ewigheid.	",
"	2 [B Bet.] Elke dag wil Ek U loof en U Naam prys vir Ewig tot in Ewigheid.	",
"	3 [G Ghimel.] JaHWeH is groot en baie lofwaardig, en Sy grootheid is ondeurgrondelik.	",
"	4 [Do Dalet.] Die een geslag prys U werke by die ander, en hulle verkondig U magtige dade.	",
"	5 [h Hé.] Ek wil spreek van die Glansrykheid van U Eer, die Majesteit van U onderskeidende Woorde.	",
"	6 [w Waw.] En hulle sal spreek van die Krag van U ontsagwekkende dade, en U Grootheid wil Ek vertel.	",
"	7 [z Zajin.] Hulle sal die gedagtenis van U grote Suiwerheid laat uitstroom en jubel oor U Geregtigheid.	",
"	8 [j Get.] Goedgunstig en barmhartig is JaHWeH, lankmoedig en groot van Medelye.	",
"	9 [f Tet.] JaHWeH is Suiwerheid, en Sy dade van Barmhartigheid is oor al Sy werke.	",
"	10 [y Jod.] Al U Werke loof U, o JaHWeH, en U Toegewydes prys U.	",
"	11 [K Kaf.] Hulle maak melding van die Glansrykheid van U Koninkryk en spreek van U mag,	",
"	12 [l Lamed.] om aan die seuns van Adam Sy magtige dade bekend te maak en die Glansrykheid en Grootsheid van Sy Koninkryk.	",
"	13 [m’ Mem.] U Koninkryk is ’n ewige Koninkryk, en U Koningskap duur van geslag tot geslag.	",
"	14 [so Samek.] JaHWeH ondersteun almal wat val, en Hy rig almal op wat neergeboë is.	",
"	15 [[ Ajin.] Die oë van almal wag op U, en U gee hulle hul spys op die regte tyd.	",
"	16 [P Pé.] U maak U Hand oop en versadig alles wat lewe met vreugde.	",
"	17 [x’ Tzadé.] JaHWeH is regverdig in al Sy Weë en barmhartig in al Sy werke.	",
"	18 [q Kof.] JaHWeH is naby almal wat Hom aanroep, almal wat Hom aanroep in Waarheid.	",
"	19 [r Resj.] Hy vervul die verwagting van die wat Hom vrees, en Hy hoor hul hulpgeroep en verlos hulle.	",
"	20 [v Sjin.] JaHWeH bewaar almal wat Hom liefhet, maar Hy verdelg al die besoedeldes.	",
"	21 [T Taw.] My Mond sal die lof van JaHWeH uitspreek, en laat alle vlees [die] Naam van Sy Apartheid loof vir Ewig tot in Ewigheid.	",
	
]
},
{
book: 'Psalms',
chapter: '146',
content: [
		
"	1 HALALU-JaHH/Prys jul JaHH! Prys JaHWeH, o My Siel!	",
"	2 Ek wil JaHWeH prys solank as Ek lewe; Ek wil musiek maak tot die Eer van My Elohey solank as Ek nog daar is.	",
"	3 Vertrou nie op prinse, op die seun van adam, by wie geen bevryding is nie.	",
"	4 Sy gees gaan uit, hy keer terug na sy Adamah [die adamiet se Aarde] toe; op daardie dag is dit met sy planne gedaan.	",
"	5 Geseënd is hy wat die El van Jakob het as sy Hulp, wie se hoop is op JaHWeH sy Elohey,	",
"	6 wat Hemele en Aarde gemaak het, die see en alles wat daarin is; wat Waarheid bewaar tot in ewigheid;	",
"	7 wat aan die verdruktes Reg doen, wat aan die hongeriges Brood gee. JaHWeH maak die gevangenes los.	",
"	8 JaHWeH open [die oë van] die blindes; JaHWeH rig die wat geboë is, op; JaHWeH het die regverdiges lief.	",
"	9 JaHWeH behoed die besoekers; Hy rig wees en Weduwee weer op; maar die weg van die besoedeldes maak Hy krom.	",
"	10 JaHWeH is vir ewig Koning; jou Elohey, o Sion, is van geslag tot geslag! Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '147',
content: [
		
"	1 HALALU-JaHH/Prys jul JaHH, want dit is goed om Onse Elohey te besing, ja lieflik; ’n loflied is gepas!	",
"	2 JaHWeH bou Jerusalem op; Hy versamel van JisraEl die wat verdryf is.	",
"	3 Hy genees die wat gebroke is van hart, en Hy verbind hulle wonde.	",
"	4 Hy bepaal die getal van die Sterre; Hy gee hulle almal name.	",
"	5 Onse Meester is groot en ryk aan Krag; Sy Verstand is oneindig.	",
"	6 JaHWeH rig die ootmoediges weer op; die besoedelde mense verneder Hy tot die Aarde toe.	",
"	7 Spreek tot JaHWeH met dank, maak musiek tot die Eer van Onse Elohey met die siter;	",
"	8 wat die Hemele met wolke oordek, wat vir die Aarde reën berei, wat op die berge gras laat uitspruit,	",
"	9 wat aan die vee haar voedsel gee, aan die jong rawe as hulle roep.	",
"	10 Hy het geen welbehae in die krag van die perd, geen welgevalle in die bene van die man nie.	",
"	11 JaHWeH het ’n welgevalle in die wat Hom vrees, wat op Sy Medelye hoop.	",
"	12 o Jerusalem, prys JaHWeH! o Sion, loof jou Elohey!	",
"	13 Want Hy het die grendels van jou Poorte sterk gemaak; Hy het jou kinders binne-in jou geseën.	",
"	14 Hy wat aan jou grondgebied Vrede verskaf, wat jou versadig met die beste van die koring,	",
"	15 wat Sy Bevel na die Aarde stuur - Sy Woord loop baie vinnig.	",
"	16 Hy gee sneeu soos wol; Hy strooi ryp soos as.	",
"	17 Hy werp Sy ys heen soos stukke - wie kan bestaan voor Sy koue?	",
"	18 Hy stuur Sy Woord en laat hulle smelt; Hy laat Sy Gees verdryf - die waters loop.	",
"	19 Hy maak aan Jakob Sy Woorde bekend, aan JisraEl Sy Insettinge en Sy Verordeninge.	",
"	20 So het Hy aan geen enkele nasie gedoen nie; en Sy Verordeninge, dié ken hulle nie. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '148',
content: [
	
"	1 HALALU-JaHH/Prys jul JaHH! Loof JaHWeH uit die Hemele; loof Hom in die verhewe plek!	",
"	2 Loof Hom, al Sy Boodskappers, loof Hom, al Sy menigtes!	",
"	3 Loof Hom, son en maan, loof Hom, Sterre van die Lig!	",
"	4 Loof Hom, hoogste Hemele en waters wat bo die Hemele is!	",
"	5 Laat hulle die Naam van JaHWeH loof; want Hy het bevel gegee - en hulle is geskape.	",
"	6 En Hy het hulle in stand gehou vir altyd, vir ewig; Hy het ’n Wet gegee wat geeneen oortree nie.	",
"	7 Loof JaHWeH vanuit die Aarde - Drake van die Afgrond!	",
"	8 Vuur en hael, sneeu en damp, stormwind wat Sy Woord volbring;	",
"	9 berge en alle heuwels, vrugtebome en alle sederbome,	",
"	10 wilde wesens en alle vee, kruipende diere en gevleuelde wesens;	",
"	11 Konings van die Aarde en alle gemeenskappe, Vorste en alle Regters van die Aarde;	",
"	12 Jongelinge en ook Maagde, oues saam met die jonges	",
"	13 laat hulle die Naam van JaHWeH loof! Want Sy Naam alleen is hoog: Sy Majesteit is oor Aarde en Hemele!	",
"	14 En Hy het ’n Horing vir Sy volk verhef: ’n roem vir al Sy toegewydes; vir die kinders van JisraEl, die volk wat naby Hom is. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Psalms',
chapter: '149',
content: [
	
"	1 HALALU-JaHH/Prys jul JaHH! Sing tot die Eer van JaHWeH ’n nuwe lied, Sy lof in die vergadering van die Toegewydes!	",
"	2 Laat JisraEl hom verheug in Sy Maker; laat die kinders van Sion juig oor hulle Koning!	",
"	3 Laat hulle Sy Naam loof in koordans, tot Hom musiek maak met tamboeryn en siter.	",
"	4 Want JaHWeH het ’n welbehae in Sy volk; Hy versier die ootmoediges met Verlossing .	",
"	5 Laat die Toegewydes opspring in Glansrykheid; laat hulle jubel op hul beddens.	",
"	6 Lofverheffinge van El is in hulle keel, en ’n Tweesnydende Swaard in hulle hand;	",
"	7 om wraak te bewerk onder die nasies, Tugtiging [by] tekortkoming van gemeenskappe;	",
"	8 om hulle konings met kettings te bind en hulle edeles met ysterboeie;	",
"	9 om ’n Regspraak wat opgeskrywe is, aan hulle te voltrek. ’n Eer is Sy vir al Sy toegewydes! Halalu-JaHH/Prys jul JaHH! [Boekrol van Henog 48:9; 98:12; 105:1]	",

]
},
{
book: 'Psalms',
chapter: '150',
content: [
	
"	1 HALALU-JaHH/Prys jul JaHH! Loof El in Sy Apartheid, loof Hom in die Koepel van Sy Krag!	",
"	2 Loof Hom oor Sy magtige dade, loof Hom na die volheid van SY grootheid!	",
"	3 Loof Hom met ramshoring geklank, loof Hom met harp en siter;	",
"	4 loof Hom met tamboeryn en koordans, loof Hom met snarespel en fluit;	",
"	5 loof Hom met helder simbale, loof Hom met klinkende simbale!	",
"	6 Laat alles wat asem het, JaHH prys! Halalu-JaHH/Prys jul JaHH!	",

]
}
];
