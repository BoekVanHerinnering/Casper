const openbaring_van_jahwèshuaChapters = [

{
book: 'Openbaring_Van_Jahwèshua',
chapter: '1',
content: [

"	1 DIE openbaring van JaHWèshua die Gesalfde wat die Elohim Hom gegee het om aan Sy diensknegte te toon wat gou moet gebeur, en wat Hy deur die sending van Sy Boodskapper aan Sy dienskneg JeHôWganan te kenne gegee het,	",
"	2 wat getuig het van die Woord van die Elohim en die Getuienis van JaHWèshua die Gesalfde - alles wat Hy gesien het.	",
"	3 Geseënd is hy wat die woorde van die profesie lees, en die wat dit hoor en onderhou wat in haar geskrywe is, want die tyd is naby.	",
"	4 JeHôWganan aan die sewe gemeentes in Asië: Barmhartigheid vir julle en Vrede van Hom wat is en wat was en wat kom, en van die sewe Geeste wat voor Sy Troon is,	",
"	5 en van JaHWèshua die Gesalfde, die getroue Getuie, die Eersgeborene uit die dode en die Koning oor die konings van die Aarde! Aan Hom wat ons liefgehad het en ons van ons oortredinge gewas het in Sy bloed	",
"	6 en ons gemaak het konings en priesters vir Elohim en Sy VADER, aan Hom die Majesteit en die Krag tot in alle ewigheid! Amein. [Wysheid van Salomo 6:20]	",
"	7 Kyk, Hy kom met die Wolkkolom, en elke oog sal Hom sien, ook hulle wat Hom deursteek het; en al die stamme van die Aarde sal oor Hom rou bedryf; ja, amein!	",
"	8 Ek is die Alef [a] en die Taw [T], die begin en die einde, sê JaHWeH, wat is en wat was en wat kom, die Almagtige. [Exodus 3:14; JeshaJaH 41:4; 44:6]	",
"	9 Ek, JeHôWganan, julle broeder en deelgenoot in die verdrukking en in die koninkryk en lydsaamheid van JaHWèshua die Gesalfde, was op die eiland wat Patmos genoem word, ter wille van die Woord van die Elohim en om die Getuienis van JaHWèshua, die Gesalfde.	",
"	10 Ek was in die gees op die dag van die Meester, en ek het agter my ’n groot Stem gehoor, soos van ’n ramshoring, [Exodus 19:16]	",
"	11 wat sê: Ek is die Alef [a] en die Taw [T], die eerste en die laaste, en skryf wat jy sien in ’n boekrol en stuur dit na die sewe gemeentes wat in Asië is: na Éfese en Smirna en Pérgamus en Thiatíre en Sardis en Filadelfía en Laodicéa.	",
"	12 Toe draai ek my om, om te sien watter Stem met my gespreek het; en toe ek my omgedraai het, sien ek sewe goue kandelaars,	",
"	13 en tussen die sewe kandelaars Een soos die Seun van die adam met ’n kleed aan wat tot op die voete hang, en gegord om die bors met ’n goue gordel. [Exodus 25:34]	",
"	14 Sy hoof en hare was wit soos wit wol, soos sneeu, en Sy Oë soos ’n Vuurvlam,	",
"	15 en Sy voete soos glansende koper wat gloei soos in ’n oond, en Sy Stem soos die stem van baie Waters.	",
"	16 En in Sy Regterhand het Hy sewe Sterre gehou, en ’n skerp tweesnydende Swaard het uit Sy Mond uitgegaan, en Sy aangesig was soos die son wat skyn in Sy Krag. [Openbaring 19:15]	",
"	17 En toe ek Hom sien, val ek soos ’n dooie aan Sy voete; en Hy het Sy Regterhand op my gelê en vir my gesê: Moenie vrees nie; Ek is die eerste en die laaste	",
"	18 en die lewende; en Ek was dood en kyk, Ek leef tot in alle ewigheid. Amein. En Ek het die sleutels van die Doderyk/Sheol en van die Dood.	",
"	19 Skryf die dinge op wat jy gesien het, die wat is, sowel as die wat gaan gebeur;	",
"	20 die verborgenheid van die sewe Sterre wat jy in My Regterhand gesien het, en die sewe goue kandelaars: die sewe Sterre is die boodskappers van die sewe gemeentes, en die sewe kandelaars wat jy gesien het, is die sewe gemeentes. [Exodus 25:37; Profeet Miga 5:5]	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '2',
content: [
		
"	1 SKRYF aan die boodskapper van die gemeente in Éfese: Dít sê Hy wat die sewe Sterre in Sy Regterhand hou, wat wandel tussen die sewe goue kandelaars:	",
"	2 Ek ken jou werke en jou arbeid en jou lydsaamheid, en dat jy verdraaide mense nie kan verdra nie; en dat jy dié op die proef gestel het wat sê dat hulle Apostels is en dit nie is nie, en hulle leuenaars bevind het;	",
"	3 en dat jy verdra het en lydsaamheid besit, en ter wille van My Naam gearbei en nie moeg geword het nie.	",
"	4 Maar Ek het teen jou dat jy jou Eerste Liefde verlaat het.	",
"	5 Onthou dan waarvandaan jy uitgeval het, en bekeer jou en doen die eerste werke. Anders kom Ek gou na jou toe en sal jou kandelaar van sy plek verwyder as jy jou nie bekeer nie.	",
"	6 Maar dit het jy, dat jy die werke van die Nikolaïete haat, wat Ek ook haat.	",
"	7 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê. Aan hom wat oorwin, sal Ek gee om te eet van die Boom van die Lewe wat binne-in die Paradys van Elohim is.	",
"	8 En skryf aan die boodskapper van die gemeente in Smirna: Dít sê die eerste en die laaste, wat dood was en lewend geword het:	",
"	9 Ek ken jou werke en verdrukking en armoede - maar jy is ryk - en die laster van die wat sê dat hulle manne van JeHûWdah is en dit nie is nie, maar ’n vergadering van die Satan.	",
"	10 Vrees vir niks wat jy sal ly nie. Kyk, die Satan gaan sommige van julle in die gevangenis werp, sodat julle op die proef gestel kan word; en julle sal tien dae lank verdrukking hê. Wees getrou tot die dood toe, en Ek sal jou die Kroon van die lewe gee. [Boekrol van die Opregte 12:1; Odes van Salomo 1]	",
"	11 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê. Die wat oorwin, sal deur die tweede dood geen skade ly nie.	",
"	12 En skryf aan die boodskapper van die gemeente in Pérgamus: Dít sê Hy wat die skerp tweesnydende Swaard het:	",
"	13 Ek ken jou werke en die plek waar jy woon, waar die troon van die Satan is. En jy hou vas aan My Naam en het nie in die Geloof teen My getuig nie, selfs in die dae waarin Antipas My getroue getuie was, wat gedood is by julle waar die Satan woon.	",
"	14 Maar Ek het enkele dinge teen jou: dat jy daar mense het wat vashou aan die leer van Bíleam wat Balak geleer het om ’n struikelblok voor die kinders van JisraEl te werp, naamlik om slagdiere vir idole te eet en om te verbaster.	",
"	15 So het jy ook mense wat vashou aan die leer van die Nikolaïete, wat Ek haat.	",
"	16 Bekeer jou; anders kom Ek gou na jou toe en sal teen hulle oorlog voer met die Swaard van My Mond.	",
"	17 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê. Aan Hom wat oorwin, sal Ek gee om te eet van die Verborge Manna, en Ek sal Hom gee ’n wit keursteen, en op dié steen ’n nuwe Naam geskrywe wat niemand ken nie, behalwe Hy wat hom ontvang.	",
"	18 En skryf aan die boodskapper van die gemeente in Thiatíre: Dit sê die Seun van Elohim wat Oë het soos ’n Vuurvlam, en Sy voete is soos glansende koper:	",
"	19 Ek ken jou werke en liefde en diens en Geloof en jou lydsaamheid en jou werke, en dat die laaste meer is as die eerste.	",
"	20 Maar Ek het enkele dinge teen jou, dat jy die vrou Isébel, wat haarself ’n profetes noem, toelaat om te leer en My diensknegte te verlei om te verbaster en slagdiere vir idole te eet. [Miga 6:16]	",
"	21 En Ek het haar tyd gegee om haar van haar verbastering te bekeer, en sy het haar nie bekeer nie.	",
"	22 Kyk, Ek werp haar neer op ’n siekbed, en die wat met haar vermeng het, in ’n groot verdrukking, as hulle hul nie van hul werke bekeer nie.	",
"	23 En haar kinders sal Ek sekerlik doodmaak, en al die gemeentes sal weet dat dit Ek is wat niere en harte deursoek, en Ek sal aan elkeen van julle gee volgens sy handelinge. [JirmeJaH 17:10, Psalm 17:3]	",
"	24 En Ek sê vir julle en die oorblyfsel wat in Thiatíre is, almal wat hierdie leer nie het nie, en die wat die dieptes van die Satan, soos hulle hom noem, nie leer ken het nie: Ek sal op julle geen ander las lê nie.	",
"	25 Hou maar net vas wat julle het, totdat Ek kom.	",
"	26 En aan Hom wat oorwin en My werke tot die einde toe onderhou, sal Ek mag oor die nasies gee,	",
"	27 en Hy sal hulle regeer met ’n Septer van Yster; soos erdegoed word hulle verbrysel, net soos Ek ook van My VADER ontvang het.	",
"	28 En Ek sal Hom die Môrester gee.	",
"	29 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '3',
content: [
		
"	1 EN skryf aan die boodskapper van die gemeente in Sardis: Dít sê Hy wat die sewe Geeste van Elohim en die sewe Sterre het: Ek ken jou werke, dat jy die naam het dat jy leef, en jy is dood.	",
"	2 Wees wakker en versterk die wat oorbly, wat op die punt staan om te sterwe, want Ek het jou werke nie volkome voor Elohim gevind nie.	",
"	3 Onthou dan hoe jy dit ontvang en gehoor het, en onderhou dit en bekeer jou; as jy dan nie wakker word nie, sal Ek op jou afkom soos ’n dief, en jy sal nie weet in watter uur Ek op jou afkom nie.	",
"	4 Maar jy het enkele persone ook in Sardis wat hulle klere nie besoedel het nie, en hulle sal saam met My in wit klere wandel, omdat hulle dit waardig is.	",
"	5 Wie oorwin, sal beklee word met wit klere, en Ek sal sy naam nooit uitwis uit die Boek van die Lewe nie, en Ek sal vir sy naam getuig voor My VADER en voor SY Boodskappers.	",
"	6 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê.	",
"	7 En skryf aan die boodskapper van die gemeente in Filadelfía: Dít sê die Aparte Een, die Ware Een, wat die sleutel van Dawid het, wat oopmaak en niemand sluit nie, en Hy sluit en niemand maak oop nie: [JeshaJaH 22:22]	",
"	8 Ek ken jou werke. Kyk, Ek het voor jou ‘n geopende deur gegee, en niemand kan haar sluit nie, want jy het min krag en jy het My Woorde onderhou en nie teen My Naam getuig nie. [JeHóWganan 10:7]	",
"	9 Kyk, Ek gee jou uit die vergadering van die Satan, van die wat sê dat hulle manne van JeHûWdah is en dit nie is nie, maar lieg - Ek sal maak dat hulle kom en voor jou voete neerbuig en erken dat Ek jou liefgehad het. [2 Konings 2:15; Boekrol van die Opregte 51:18; Psalm 129:5]	",
"	10 Omdat jy die Woord van My lydsaamheid bewaar het, sal Ek jou ook bewaar in die uur van beproewing wat oor die hele wêreld kom om die bewoners van die Aarde op die proef te stel.	",
"	11 Kyk, Ek kom gou! Hou vas wat jy het, sodat niemand jou Kroon kan neem nie. [JeshaJaH 22:23]	",
"	12 Wie oorwin, Ek sal hom ’n pilaar in die Tempel van My Elohey maak, [1 ShemuEl 2:8] en hy sal daar nooit weer uitgaan nie; en Ek sal op hom die Naam van My Elohey skrywe en die naam van die Stad van My Elohey, van die nuwe Jerusalem, wat uit die Hemele van My Elohey neerdaal, en My nuwe Naam. [JeshaJaH 61:3]	",
"	13 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê.	",
"	14 En skryf aan die boodskapper van die gemeente van die Laodicense: Dít sê die Amein, die getroue en Ware Getuie, die Begin van die skepping van die Elohim:	",
"	15 Ek ken jou werke, dat jy nie koud is en ook nie warm nie. Was jy tog maar koud of warm!	",
"	16 Maar nou, omdat jy lou is en nie koud of warm nie, sal Ek jou uit My Mond spuug.	",
"	17 Want jy sê: Ek is ryk en het verryk geword en het aan niks gebrek nie; en jy weet nie dat dit jy is wat ellendig en beklaenswaardig en arm en blind en naak is nie.	",
"	18 Ek raai jou aan om van My te koop goud wat deur vuur gelouter is, sodat jy kan ryk word; en wit klere, dat jy jou kan aantrek en die skande van jou naaktheid nie openbaar word nie; en salf om jou oë te salf, sodat jy kan sien. [2 Ezra 2:40]	",
"	19 Almal wat Ek liefhet, bestraf en tugtig Ek. Wees dan ywerig en bekeer jou.	",
"	20 Kyk, Ek staan by die deur en Ek klop. As iemand My Stem hoor en die deur oopmaak, sal Ek ingaan na hom toe en saam met hom maaltyd hou, en hy met My.	",
"	21 Aan Hom wat oorwin, sal Ek gee om saam met My te sit op My Troon, soos Ek ook oorwin het en saam met My VADER op SY Troon gaan sit het. [Boekrol van Henog 69:29	",
"	22 Wie ’n oor het, laat hom hoor wat die Gees aan die gemeentes sê.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '4',
content: [
	
"	1 NÁ hierdie dinge het ek gesien - kyk, ’n geopende deur in die Hemele, en die eerste Stem wat ek soos ’n ramshoring met my hoor spreek het, het gesê: Kom op hierheen, en Ek sal jou toon wat ná hierdie dinge moet gebeur.	",
"	2 En dadelik was ek in die Gees, en kyk, daar staan ’n Troon in die Hemele en Een sit op die Troon.	",
"	3 En Hy wat daarop sit, het in Sy voorkoms gelyk soos die Steen jaspis en sardius; en rondom die Troon was ’n reënboog wat in Sy voorkoms gelyk het soos ’n smarag.	",
"	4 En rondom die Troon was daar vier-en-twintig trone, en op die trone het ek die vier-en-twintig oudstes sien sit, bekleed met wit klere; en hulle het goue krone op hulle hoofde gehad. [Boekrol van Henog 14:20]	",
"	5 En daar het weerligte en donderslae en stemme uit die Troon uitgegaan, en sewe vuurfakkels wat die sewe Geeste van die Elohim is, het voor die Troon gebrand;	",
"	6 en voor die Troon was daar ’n see van glas soos kristal, en in die middel van die Troon en rondom die Troon vier lewende Wesens vol Oë van voor en van agter. [Boekol van Henog 40:2; 71:5; JeségiEl 1:5]	",
"	7 En die eerste lewende Wese was soos ’n leeu, en die tweede lewende Wese was soos ’n kalf, en die derde lewende Wese het ’n gesig gehad soos ’n adamiet, en die vierde lewende Wese was soos ’n arend wat vlieg. [JeségiEl 1:10]	",
"	8 En die vier lewende Wesens het elkeen vir homself ses Vleuels gehad, en hulle was rondom en van binne vol Oë; en hulle het sonder ophou dag en nag gesê: Apart gestel, Apart gestel, Apart gestel is JaHWeH Elohim, El Almagtige, wat was en wat is en wat kom! [JeshaJaH 6:3, Boekrol van Henog 39:12; Openbaring van Henog 9:6]	",
"	9 En elke keer as die lewende Wesens Glans en Eer en danksegging gee aan Hom wat op die Troon sit, wat tot in alle ewigheid lewe, [Boekrol van Henog 39:13]	",
"	10 val die vier-en-twintig oudstes neer voor Hom wat op die Troon sit, en aanbid Hom wat tot in alle ewigheid lewe, en werp hulle krone voor die Troon en sê:	",
"	11 U is waardig, o JaHWeH, onse Elohey, om te ontvang die Glansrykheid en die Eer en die Krag, want U het alles geskape en deur U wil bestaan hulle en is hulle geskape.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '5',
content: [
		
"	1 EN ek het in die Regterhand van Hom wat op die Troon sit, ’n Boekrol gesien, van binne en van buite beskrywe en met sewe seëls goed verseël. [Openbaring van Henog 13:56]	",
"	2 En ek het ’n sterk Boodskapper gesien wat met ’n groot stem uitroep: Wie is waardig om die Boekrol oop te maak en sy seëls te breek?	",
"	3 En niemand in die Hemele of op die Aarde of onder die Aarde kon die Boekrol oopmaak of daarin kyk nie.	",
"	4 En ek het baie geween, omdat daar niemand waardig bevind is om die Boekrol oop te maak en te lees of daarin te kyk nie.	",
"	5 Toe sê een van die oudstes vir my: Moenie ween nie; kyk, die Leeu wat uit die stam van JeHûWdah is, die Wortel van Dawid, het oorwin om die Boekrol oop te maak en sy sewe seëls te breek. [JeshaJaH 11:10; DaniEl 7:13; 2 Ezra 6:20]	",
"	6 En ek het gesien, en kyk, in die middel van die Troon en die vier lewende Wesens en in die midde van die oudstes staan daar ’n Lam asof Hy doodgebloei is, met sewe Horings en sewe Oë, wat die sewe Geeste van Elohim is wat uitgestuur is oor die hele Aarde. [2 Makkabeërs 12:22; Psalm 82:1]	",
"	7 Hy het gekom en die Boekrol geneem uit die Regterhand van Hom wat op die Troon sit;	",
"	8 en toe Hy die Boekrol neem, val die vier lewende Wesens en die vier-en-twintig oudstes voor die Lam neer, elkeen met siters en goue bekers vol reukwerk, wat die gebede van die Apartes is.	",
"	9 Toe sing hulle ’n nuwe lied en sê: U is waardig om die Boekrol te neem en sy seëls oop te maak, want U is doodgebloei en het ons vir Elohim met U bloed gekoop uit elke stam en taal en volk en nasie, [JeshaJaH 53:7]	",
"	10 en het ons konings en priesters vir onse Elohey gemaak, en ons sal as konings op die Aarde heers.	",
"	11 Toe sien ek, en ek hoor ’n stem van baie Boodskappers rondom die Troon en van die lewende Wesens en die oudstes; en hulle getal was tienduisende van tienduisende en duisende van duisende; [Boekrol van Henog 14:22; 40:1]	",
"	12 en met ’n groot stem het hulle gesê: Die Lam wat doodgebloei is, is waardig om te ontvang die Krag en Rykdom en Wysheid en Sterkte en Eer en Glansrykheid en Lof. [Boekrol van Henog 63:2]	",
"	13 En elke skepsel wat in die Hemele en op die Aarde en onder die Aarde en wat op die see is, en alles wat in hulle is, het ek hoor sê: Aan Hom wat op die Troon sit, en aan die Lam kom toe die Lof en die Eer en die Glansrykheid en die Krag tot in alle ewigheid!	",
"	14 En die vier lewende Wesens het gesê: Amein! En die vier-en-twintig oudstes het neergeval en Hom aanbid wat lewe tot in alle ewigheid.	",
		

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '6',
content: [
		
"	1 EN ek het gesien toe die Lam die eerste van die seëls oopmaak; en ek het een van die vier lewende Wesens hoor sê, soos die geluid van ’n donderslag: Kom kyk!	",
"	2 En ek het gesien, en kyk, daar was ’n wit perd. En hy wat daarop sit, het ’n boog; en aan hom is ’n Kroon gegee, en hy het uitgegaan as ‘n oorwinnaar en om te oorwin. [Odes van Salomo 23:6; ZekarJaH 10:3]	",
"	3 En toe Hy die tweede Seël oopgemaak het, hoor ek die tweede lewende Wese sê: Kom kyk!	",
"	4 En ’n ander perd, ’n vuurrooie, het uitgekom, en aan hom wat daarop sit, is dit gegee om die vrede van die Aarde af weg te neem en dat hulle mekaar sou doodmaak; en ’n groot swaard is aan hom gegee.	",
"	5 En toe Hy die derde Seël oopgemaak het, hoor ek die derde lewende Wese sê: Kom kyk! En ek het gesien, en kyk, daar was ’n swart perd; en hy wat daarop sit, het ’n skaal in sy hand.	",
"	6 En ek het ’n Stem tussen die vier lewende Wesens hoor sê: ’n Rantsoen koring vir ’n penning en drie rantsoene gars vir ’n penning; en moenie die olie en die wyn beskadig nie.	",
"	7 En toe Hy die vierde Seël oopgemaak het, hoor ek die stem van die vierde lewende Wese sê: Kom kyk!	",
"	8 En ek het gesien, en kyk, daar was ‘n vaal perd. En hy wat daarop sit, sy naam is die Dood, en die Doderyk/Sheol het hom gevolg. En aan hom is mag gegee oor die vierde deel van die Aarde om dood te maak met swaard en hongersnood, deur die pes en die wilde wesens van die Aarde. [JeségiEl 14:21]	",
"	9 En toe Hy die vyfde Seël oopgemaak het, sien ek onder die Altaar die siele van die wat gedood is ter wille van die Woord van die Elohim en die Getuienis wat hulle gehad het. [Psalm 34:2; Boekrol van Henog 22:12; 39:5; 47:2; 2 Ezra 2:47; Openbaring van Petrus 1:27]	",
"	10 En hulle het met ’n groot stem uitgeroep en gesê: Hoe lank, o Aparte Een en Ware Vors oordeel en wreek U nie ons bloed op die bewoners van die Aarde nie? [Génesis 4:10; Boekrol van Henog 9:10; 22:7; 47:4; 2Ezra 4:35; 15:8]	",
"	11 En aan elkeen van hulle is wit klere gegee; en aan hulle is gesê dat hulle nog ’n klein tydjie moes rus totdat ook hulle medediensknegte en hulle broers wat nog gedood sou word soos hulle, voltallig sou wees. [Profeet JôWEl 1:13; 2:17; 2 Ezra 2:45]	",
"	12 En ek het gesien toe Hy die sesde Seël oopgemaak het, en kyk, daar was ’n groot aardbewing; en die son het swart geword soos ’n harige sak, en die maan het geword soos bloed; [Boekrol van die Opregte 6:11; JeségiEl 38:19]	",
"	13 en die Sterre van die Hemele het op die Aarde geval, soos ’n Vyeboom wat deur ’n groot Gees geskud word, Haar navye laat afval;	",
"	14 en die Hemele het weggewyk soos ’n Boekrol wat toegerol word, en al die berge en eilande is uit hulle plekke versit; [JeshaJaH 24:19]	",
"	15 en die konings van die Aarde en die grotes en die rykes en die owerstes oor duisend en die magtiges en al die slawe en al die vrymense het hulle weggesteek in die spelonke en in die rotse van die berge,	",
"	16 en vir die berge en die rotse gesê: Val op ons en verberg ons vir die Aangesig van Hom wat op die Troon sit, en vir die toorn van die Lam; [JeshaJaH 2:19-21]	",
"	17 want die groot dag van Sy toorn het gekom, en wie kan bestaan?	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '7',
content: [
		
"	1 EN ná hierdie dinge het ek vier Boodskappers op die vier hoeke van die Aarde sien staan, en hulle het die vier winde van die Aarde vasgehou, sodat geen wind sou waai op die Aarde of op die see of teen enige Boom nie.	",
"	2 En ek het ’n ander Boodskapper sien opkom van die opgang van die son, met die Seël van die lewende Elohim; en hy het met ’n groot stem geroep na die vier Boodskappers aan wie dit gegee is om die Aarde en die see te beskadig [Boekrol van die Opregte 8:2]	",
"	3 en gesê: Moenie die Aarde of die see of die bome beskadig voordat ons die diensknegte van onse Elohey op hulle voorhoofde verseël het nie. [JeségiEl 9:3,4]	",
"	4 En ek het die getal van die verseëldes gehoor: honderd-vier-en-veertigduisend verseëldes uit al die stamme van die kinders van JisraEl -[JeHôWshua 4:2; 2 Ezra 2:38, 40; 13:36]	",
"	5 uit die stam van JeHûWdah twaalfduisend verseëldes; uit die stam van Ruben twaalfduisend verseëldes; uit die stam van Gad twaalfduisend verseëldes;	",
"	6 uit die stam van Aser twaalfduisend verseëldes; uit die stam van Náftali twaalfduisend verseëldes; uit die stam van Manasse twaalfduisend verseëldes;	",
"	7 uit die stam van Símeon twaalfduisend verseëldes; uit die stam van Levi twaalfduisend verseëldes; uit die stam van Issaskar twaalfduisend verseëldes;	",
"	8 uit die stam van Sébulon twaalfduisend verseëldes; uit die stam van JôWsef twaalfduisend verseëldes; uit die stam van Benjamin twaalfduisend verseëldes.	",
"	9 Ná hierdie dinge het ek gesien, en kyk, daar was ’n groot menigte wat niemand kon tel nie, uit al die nasies en die stamme en die volke en die tale; hulle het gestaan voor die Troon en voor die Lam, bekleed met wit klere en met palmtakke in hulle hande; 1  [Boekrol van Henog 65:12; 2 Ezra 13:39]	",
"	10 en het met ’n harde stem geroep en gesê: Verlossing aan onse Elohey wat op die Troon sit, en aan die Lam!	",
"	11 En al die Boodskappers het rondom die Troon en die oudstes en die vier lewende Wesens gestaan, en hulle het voor die Troon op hulle aangesig neergeval en Elohim aanbid	",
"	12 en gesê: Amein! Die lof en die Glansrykheid en die Wysheid en die danksegging en die Eer en die Krag en die Sterkte aan onse Elohey tot in alle ewigheid! Amein. [1 Kronieke 29:11]	",
"	13 Toe het een van die oudstes gespreek en vir my gesê: Hulle wat bekleed is met die wit klere, wie is hulle en waarvandaan het hulle gekom?	",
"	14 En ek sê vir hom: My meester, u weet dit. En hy sê vir my: Dit is hulle wat uit die groot verdrukking kom, en hulle het hul klere gewas en hul klere wit gemaak in die bloed van die Lam.	",
"	15 Daarom is hulle voor die Troon van die Elohim en dien Hom dag en nag in Sy Tempel; en Hy wat op die Troon sit, sal Sy Tent oor hulle oopspan. [JeshaJaH 40:22]	",
"	16 Hulle sal nie meer honger en nie meer dors hê nie, en nooit sal die son of enige hitte op hulle val nie;	",
"	17 want die Lam wat in die middel van die Troon is, sal hulle laat wei en hulle na lewende Fonteine van Water lei, en Elohim sal alle trane van hulle oë afvee. [JeshaJaH 25:8]	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '8',
content: [
		
"	1 EN toe Hy die sewende Seël oopgemaak het, kom daar stilte in die Hemele omtrent ’n halfuur lank.	",
"	2 En ek het die sewe Boodskappers gesien wat voor Elohim staan, en sewe ramshorings is aan hulle gegee.	",
"	3 En ’n ander Boodskapper het gekom en met ’n goue Wierookbak by die Altaar gaan staan, en baie reukwerk is aan hom gegee, om haar met die gebede van al die Apartes op die goue Altaar voor die Troon te lê; [Psalm 141:2; Boekrol Tobias 3:16]	",
"	4 en die rook van die reukwerk het met die gebede van die Apartes uit die hand van die Boodskapper opgegaan voor Elohim. [Exodus 30:22-38]	",
"	5 En die Boodskapper het die Wierookbak geneem en haar met vuur van die Altaar volgemaak en haar op die Aarde gegooi; en daar het stemme gekom en donderslae en weerligte en aardbewing.	",
"	6 En die sewe Boodskappers met die sewe ramshorings het hulle gereedgemaak om te blaas. [2 Ezra 6:23]	",
"	7 En die eerste Boodskapper het geblaas, en daar het hael en vuur gekom met bloed gemeng, en dit is op die Aarde gegooi. En ’n derde van die bome het verbrand, en al die groen gras het verbrand.	",
"	8 En die tweede Boodskapper het geblaas, en iets soos ’n groot berg wat brand met vuur, is in die see gegooi. En ’n derde van die see het bloed geword,	",
"	9 en ’n derde van die skepsele in die see [wat] ‘n siel het, het gesterwe, en ’n derde van die skepe het vergaan.	",
"	10 En die derde Boodskapper het geblaas, en ’n groot Ster wat soos ’n fakkel brand, het uit die Hemele geval, en hy het geval op ’n derde van die riviere en op die waterfonteine. [Boekrol van Henog 80:6; 2 Ezra 15:39]	",
"	11 En die naam van die Ster word genoem Alsem; en ’n derde van die waters het als geword, en baie mense het gesterwe van die water, omdat hy dit bitter geword het. [2 Ezra 5:9]	",
"	12 En die vierde Boodskapper het geblaas, en ’n derde van die son is getref en ’n derde van die maan en ’n derde van die Sterre, sodat ’n derde van hulle donker sou word en die dag vir sy derde deel nie lig sou gee nie, en die nag net so.	",
"	13 En ek het gesien en gehoor ’n Boodskapper wat in die middel van die Hemele vlieg, wat met ’n groot stem sê: Wee, wee, wee hulle wat op die Aarde woon, vanweë die orige geluide van die ramshoring van die drie Boodskappers wat nog sal blaas!	",
		

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '9',
content: [
		
"	1 EN toe die vyfde Boodskapper blaas, sien ek ’n Ster wat uit die Hemele op die Aarde geval het, en aan hom is die sleutel van die put van die Afgrond gegee. [Openbaring van Henog 13:33; 2 Ezra 15:39]	",
"	2 En hy het die put van die Afgrond oopgemaak, en daar het rook opgekom uit die put soos rook van ’n groot oond, en die son en die lug is deur die rook van die put verduister.[Openbaring van Henog 22:11]	",
"	3 En uit die rook het daar sprinkane uitgekom op die Aarde, en aan hulle is mag gegee soos die skerpioene van die Aarde mag het. [JeshaJaH 13:5]	",
"	4 En aan hulle is gesê dat hulle nie die gras van die Aarde of enige groenigheid of enige Boom moet beskadig nie, maar net alleen die mense wat die Seël van Elohim nie op hulle voorhoofde het nie. [Openbaring van Henog 11:41; JeshaJaH 40:7; ]	",
"	5 En dit is aan hulle gegee, nie om hulle dood te maak nie, maar dat hulle vyf maande lank gepynig sou word; en hulle pyniging was soos die pyniging van ’n skerpioen wanneer hy ’n adamiet steek.	",
"	6 En in dié dae sal die mense die Dood soek en haar vind nie; en hulle sal verlang om te sterwe, en die Dood sal vir hulle wegvlug.	",
"	7 En die voorkoms van die sprinkane was soos dié van perde wat vir die oorlog toegerus is, en op hulle koppe was iets soos krone wat net soos goud gelyk het, en hulle gesigte was soos die gesigte van mense.	",
"	8 En hulle het hare gehad soos vrouehare, en hulle tande was soos dié van leeus. [Openbaring van Henog 13:34]	",
"	9 En hulle het borsharnasse gehad soos van yster, en die gedruis van hulle Vleuels was soos die gedruis van baie strydwaens met perde wat opruk na die oorlog.	",
"	10 En hulle het sterte gehad soos dié van skerpioene, en daar was angels in hulle sterte, en hulle mag was om die mense vyf maande lank skade aan te doen.	",
"	11 En hulle het as koning oor hulle die boodskapper van die Afgrond; sy naam in Hebreeus is Abáddon, en in Grieks het hy die naam van Apóllion. [Psalm 88:11 ; Spreuke 15:11 ; Job 26:6]	",
"	12 Die een wee het verbygegaan; hierna kom daar nog twee weë. [2 Ezra 4:3]	",
"	13 EN die sesde Boodskapper het geblaas, en ek het ’n Stem gehoor uit die vier horings van die goue Altaar wat voor Elohim is,	",
"	14 en dié het aan die sesde Boodskapper met die ramshoring gesê: Maak die vier Boodskappers los wat gebind is by die groot rivier, die Eufraat.	",
"	15 Toe is die vier Boodskappers losgemaak wat gereed gehou was vir die uur en dag en maand en jaar, om ’n derde van die adamiete dood te maak.	",
"	16 En die getal van die leërs van perderuiters was twee maal tienduisend maal tienduisend; en ek het hulle getal gehoor.	",
"	17 En só het ek in hierdie gesig die perde gesien en die wat op hulle sit, met vuurrooi en blou en swawelgeel borsharnasse. En die koppe van die perde was soos leeukoppe, en uit hulle bekke het vuur en rook en swawel uitgegaan.	",
"	18 Deur hierdie drie plae is ’n derde van die adamiete gedood, deur die vuur en deur die rook en deur die swawel wat uit hulle bekke uitgegaan het;	",
"	19 want hulle mag is in hulle bek en in hulle sterte; want hulle sterte is soos slange en het koppe, en daarmee rig hulle skade aan.	",
"	20 En die oorblyfsel adamiete wat deur hierdie plae nie gedood is nie, het hulle nie bekeer van die werke van hul hande, om die demone te aanbid, of die afbeelding van goud en silwer en koper en klip en hout wat nie kan sien of hoor of loop nie.	",
"	21 En hulle het hul nie bekeer van hul moorde en hul dwelmgebruik en hul verbastering en hul diefstalle nie.	",
		

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '10',
content: [
		
"	1 EN ek het ’n ander sterk Boodskapper uit die Hemele sien neerdaal, bekleed met die Wolkkolom, en ’n reënboog was oor Sy hoof, en Sy aangesig was soos die son, en Sy voete soos pilare van vuur;	",
"	2 en in Sy Hand het Hy ’n geopende Boekie gehad, en Hy het Sy regtervoet op die see gesit en Sy linkervoet op die land;	",
"	3 en Hy het met ’n groot stem uitgeroep soos ’n leeu wat brul, en toe Hy uitgeroep het, het die sewe donderslae hulle stemme laat hoor. [Boekrol van Henog 20:2]	",
"	4 En toe die sewe donderslae hulle stemme laat hoor het, wou ek skrywe; maar ek het ’n Stem uit die Hemele vir my hoor sê: Verseël wat die sewe donderslae gespreek het, en skryf dit nie op nie.	",
"	5 En die Boodskapper wat ek op die see en op die land sien staan het, het Sy hand na die Hemele opgehef,	",
"	6 en Hy het gesweer by Hom wat tot in alle ewigheid lewe, wat die Hemele geskape het en wat daarin is, en die Aarde en wat daarin is, en die see en wat daarin is dat daar geen tyd meer sal wees nie;	",
"	7 maar in die dae van die stem van die sewende Boodskapper, wanneer Hy begin blaas, dan is die verborgenheid van Elohim volbring, soos Hy die goeie nuus verkondig het aan Sy diensknegte, die Profete.	",
"	8 En die Stem wat ek uit die Hemele gehoor het, het weer tot my gespreek en gesê: Gaan, neem die geopende boekie in die hand van die Boodskapper wat op die see en land staan.	",
"	9 En ek het na die Boodskapper gegaan en aan hom gesê: Gee my die boekie. Toe sê Hy vir my: Neem en eet haar op, en sy sal jou maag bitter maak, maar in jou mond sal sy soet wees soos heuning. [JeségiEl 3:1]	",
"	10 Toe neem ek die Boekie uit die hand van die Boodskapper en eet haar op, en in my mond was sy soet soos heuning; maar toe ek haar geëet het, het my maag bitter geword.	",
"	11 En Hy het vir my gesê: Jy moet weer profeteer oor baie volke en nasies en tale en konings.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '11',
content: [
		
"	1 EN ’n riet soos ’n stok is aan my gegee, en die Boodskapper het gestaan en gesê: Staan op en meet die Tempel van die Elohim en die Altaar en die wat daarin aanbid. [Psalm 68:29; Boekrol van Henog 61:2; JôWel 2:17]	",
"	2 Maar die voorhof buitekant die Tempel moet jy uitlaat en dit nie meet nie, want dit is aan die nasies gegee; en hulle sal die Stad van Apartheid twee-en-veertig maande lank vertrap.	",
"	3 En Ek sal aan My twee getuies gee dat hulle, met sakke bekleed, duisend-tweehonderd-en-sestig dae lank sal profeteer.	",
"	4 Hulle is die twee Olyfbome en die twee kandelaars wat voor die Meester van die Aarde staan. [Boekrol van Henog 58:4; ZekarJaH 4:2-6, 11-14]	",
"	5 En as iemand hulle wil beskadig, gaan daar vuur uit hulle Mond en verslind hulle vyande; en as iemand hulle wil beskadig, moet hy op dieselfde manier gedood word.	",
"	6 Hulle het mag om die Hemele te sluit, sodat daar in die dae van hulle profesie geen reën val nie; en hulle het mag oor die waters, om dit in bloed te verander en om die Aarde te tref met allerhande plae so dikwels as hulle wil. [1 Konings 17:1]	",
"	7 En wanneer hulle hul Getuienis voleindig het, sal die Dier wat uit die Afgrond opkom, teen hulle oorlog voer en hulle oorwin en hulle doodmaak;	",
"	8 en hulle lyke sal lê op die straat van die groot Stad wat geestelik genoem word Sodom en Egipte, waar ook onse Meester gefolter is.	",
"	9 En mense uit die volke en stamme en tale en nasies sal hulle lyke drie en ’n halwe dag lank sien en nie toelaat dat hulle lyke in die graf gelê word nie.	",
"	10 Die bewoners van die Aarde sal bly en verheug wees oor hulle en sal vir mekaar geskenke stuur, omdat dié twee Profete die bewoners van die Aarde gepynig het.	",
"	11 En ná die drie en ’n halwe dag het ’n Gees van Lewe uit die Elohim in hulle ingegaan, en hulle het op hul voete gaan staan, en ’n groot Vrees het geval op die wat hulle aanskou het.	",
"	12 En hulle het ’n groot Stem uit die Hemele vir hulle hoor sê: Kom op hierheen! En hulle het opgevaar na die Hemele in die Wolkkolom, en hul vyande het hulle aanskou.	",
"	13 En in dié uur het daar ’n groot aardbewing gekom, en ’n tiende van die Stad het geval, en seweduisend adamiete het in die aardbewing omgekom, en die oorblyfsel het bevrees geword en aan die Elohey van die Hemele Majesteit toegebring.	",
"	14 Die tweede wee het verbygegaan; kyk, die derde kom gou.	",
"	15 EN die sewende Boodskapper het geblaas, en daar was groot stemme in die Hemele wat sê: Die koninkryke van die wêreld het [die eiendom] van onse Majesteit geword en van die Gesalfde, en Hy sal as Koning heers tot in alle ewigheid.	",
"	16 En die vier-en-twintig oudstes wat voor die Elohim op hulle trone sit, het op hulle aangesig geval en Elohim aanbid	",
"	17 en gesê: Ons dank U, o, JaHWeH, onse Elohey, Almagtige, wat is en wat was en wat kom, dat U U groot mag aangeneem en as Koning geheers het.	",
"	18 En die nasies was vertoornd, en U Toorn het gekom en die tyd van die dode om geoordeel te word en om die loon te gee aan U diensknegte, die Profete, en aan die Apartes en aan die wat U Naam vrees, klein en groot, en om die verderwers van die Aarde te verderf.	",
"	19 En die Tempel van die Elohim het in die Hemele oopgegaan, en Sy Verbondsark is in Sy Tempel gesien, en daar was weerligte en stemme en donderslae en aardbewing en groot hael.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '12',
content: [
		
"	1 EN ’n groot Teken het in die Hemele verskyn: ’n Vrou wat met die son bekleed was, en die maan was onder Haar voete, en op Haar hoof ’n Kroon van twaalf Sterre; [MattithJaHûW 24:30]	",
"	2 en Sy was swanger en het uitgeroep in Haar Weë en barensnood.	",
"	3 En ’n ander Teken het in die Hemele verskyn, en daar was ’n groot vuurrooi Draak met sewe koppe en tien horings, en op sy koppe sewe krone;	",
"	4 en sy stert het die derde van die Sterre van die Hemele meegesleep en hulle op die Aarde gegooi. En die Draak het gestaan voor die Vrou wat op die punt was om te baar, sodat hy Haar kind sou verslind sodra Sy gebaar het. [JeshaJaH 21:3]	",
"	5 En Sy het ’n manlike Kind gebaar, wat al die nasies met ’n Septer van Yster sou regeer; en Haar Kind is weggeruk na die Elohim en Sy Troon.	",
"	6 En die Vrou het na die wildernis gevlug waar Sy ’n plek het wat deur die Elohim gereed gemaak is, dat hulle Haar daar sou onderhou duisend-tweehonderd-en-sestig dae lank. [JeHôWshua 4:17; 2 Konings 8:1; JeségiEl 19:10]	",
"	7 En daar het oorlog in die Hemele gekom: MikaEl en sy Boodskappers het oorlog gevoer teen die Draak, en die Draak en sy boodskappers het oorlog gevoer;	",
"	8 en hulle kon nie oorwin nie, en hulle plek was in die Hemele nie meer te vinde nie.	",
"	9 En die groot Draak is neergewerp, die ou slang/Nagash wat genoem word Duiwel en Satan, wat die hele wêreld verlei, hy is neergewerp op die Aarde, en sy boodskappers is saam met hom neergewerp.	",
"	10 Toe hoor ek ’n groot Stem in die Hemele sê: Nou het die Verlossing en die Krag en die Koningskap die eiendom van onse Elohey geword, en die mag van Sy Gesalfde; want die aanklaer van ons broers is neergewerp, hy wat hulle aanklaag voor onse Elohey, dag en nag.	",
"	11 En hulle het hom oorwin deur die Bloed van die Lam en deur die woord van hulle Getuienis, en hulle het tot die dood toe hulle siel nie liefgehad nie.	",
"	12 Daarom, wees verheug, o Hemele en die wat daarin woon; wee die bewoners van die Aarde en die see, want die Satan het na julle neergedaal met groot woede, omdat hy weet dat hy min tyd het.	",
"	13 En toe die Draak sien dat hy neergewerp is op die Aarde, het hy die Vrou vervolg wat die Seuntjie gebaar het;	",
"	14 maar die twee Vleuels van die groot Arend is aan die Vrou gegee, sodat Sy na die wildernis, na Haar plek, kon vlieg, waar Sy uit die gesig van die slang/Nagash onderhou word, ’n tyd en tye en ’n halwe tyd. [Boekrol Job 28:20; DaniEl 7:4]	",
"	15 En die slang/Nagash het uit sy bek water soos ’n rivier agter die Vrou aan uitgegooi, om Haar te laat wegvoer deur die rivier. [Odes van Salomo 39:1; JeshaJaH 59:19]	",
"	16 En die Aarde het die Vrou te hulp gekom, en die Aarde het haar Mond oopgemaak en die rivier opgesluk, wat die Draak uit sy bek uitgegooi het. [2 Konings 8:1 - 6]	",
"	17 En die Draak was vertoornd op die Vrou, en hy het weggegaan om oorlog te voer teen die oorblyfsel van Haar saad wat die Gebooie van Elohim onderhou en die Getuienis van JaHWèshua die Gesalfde hou.	",
"	18 En ek het op die sand van die see gaan staan.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '13',
content: [
		
"	1 EN ek het ’n Dier uit die see sien opkom met sewe koppe en tien horings, en op haar horings tien krone en op haar koppe ‘n naam van laster. [DaniEl 8:3]	",
"	2 En die Dier wat ek gesien het, was soos ’n luiperd, en haar pote soos die van ‘n beer, en haar bek soos die bek van ’n leeu; en die Draak het haar haar krag gegee en haar troon en groot mag. [DaniEl 7]	",
"	3 En ek het een van haar koppe gesien net of sy dodelik gewond was, en haar dodelike wond is genees. En die hele wêreld het verwonderd agter die Dier aan gegaan.	",
"	4 En hulle het die Draak vereer wat die Dier mag gegee het, en die Dier vereer en gesê: Wie is aan die Dier gelyk? Wie kan teen haar oorlog voer?	",
"	5 En ’n mond is aan haar gegee wat groot woorde en lasterlike dinge spreek, en aan haar is mag gegee om dit twee-en-veertig maande lank te doen.	",
"	6 En sy het haar mond oopgemaak om te laster teen die Elohim, om Sy Naam en Sy Tabernakel en die wat in die Hemele woon, as oneervol te laster.	",
"	7 Dit is ook aan haar gegee om oorlog te voer teen die Apartes en hulle te oorwin, en aan haar is mag gegee oor elke stam en taal en nasie. [DaniEl 7:21]	",
"	8 En al die bewoners van die Aarde sal haar vereer, almal wie se name nie van die grondlegging van die wêreld af in die Boek van die Lewe van die Lam wat doodgebloei is, geskrywe is nie. [Exodus 32:32]	",
"	9 As iemand ’n oor het, laat hom hoor.	",
"	10 Hy wat iemand in gevangeneskap lei, gaan self in gevangenskap; hy wat met die swaard doodmaak, moet self met die swaard doodgemaak word. Hier is die lydsaamheid en die Geloof van die Apartes.	",
"	11 En uit die Aarde het ek ’n ander Dier sien opkom, en hy het twee horings gehad net soos ’n lam en het gepraat soos ’n Draak.	",
"	12 En hy oefen al die mag van die eerste Dier uit voor sy oë, en hy maak dat die Aarde en die wat op haar woon, die eerste Dier vereer, waarvan die dodelike wond genees is.	",
"	13 Hy doen ook groot tekens, sodat hy selfs vuur uit die Hemele laat neerdaal op die Aarde voor die oë van die mense.	",
"	14 En hy verlei die bewoners van die Aarde deur die tekens wat hom gegee is om voor die oë van die Dier te doen, deur aan die bewoners van die Aarde te sê dat hulle ’n beeld moet maak vir die Dier wat die swaardwond ontvang en lewendig geword het.	",
"	15 En dit is hom gegee om ’n gees aan die Dier se beeld te gee, sodat die Dier se beeld ook sal praat en maak dat almal gedood word wat die Dier se beeld nie vereer nie.	",
"	16 En hy maak dat aan almal, klein en groot, en die rykes en die armes, en die vrymense en die slawe ’n merk op hulle regterhand en op hulle voorhoofde gegee word;	",
"	17 sodat niemand kan koop of verkoop nie, behalwe hy wat die merk of die naam van die Dier of die getal van haar naam het.	",
"	18 Hier kom die Wysheid te pas. Wie die Verstand het, laat hom die getal van die Dier bereken, want dit is die getal van ’n mens; en haar getal is seshonderd-ses-en-sestig.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '14',
content: [
		
"	1 EN ek het gesien, en kyk, die Lam staan op die Berg van Sion, en saam met Hom honderd-vier-en-veertigduisend met Sy Naam en die Naam van Sy VADER op hulle voorhoofde geskrywe. [Odes van Salomo 23:21; 42:20; JeshaJaH 11:12; 2 Ezra 2:38]	",
"	2 En ek het ’n geluid uit die Hemele gehoor soos die geluid van baie waters en soos die geluid van ’n harde donderslag, en ek het die geluid gehoor van siterspelers wat speel op hulle siters. [2 Ezra 6:17]	",
"	3 En hulle het ’n nuwe lied gesing voor die Troon en voor die vier lewende Wesens en die oudstes; en niemand kon die lied leer nie, behalwe die honderd-vier-en-veertigduisend wat van die Aarde vrygekoop is. [2 Ezra 2:42]	",
"	4 Dit is hulle wat hulself met vroue nie besoedel het nie, want hulle is maagdelik skoongewas; [Exodus 19:15] dit is hulle wat die Lam volg waar Hy ook heengaan; dit is hulle wat gekoop is uit die adamiete as eerstelinge vir Elohim en die Lam.[Levítikus 21:14]	",
"	5 En in hulle mond is daar geen bedrog gevind nie; want hulle is raseg voor die Troon van Elohim.	",
"	6 En ek het ’n ander Boodskapper in die middel van die lug sien vlieg met ’n ewige goeie tyding en nuus om te verkondig aan die bewoners van die Aarde en aan alle nasies en stamme en tale en volke.	",
"	7 En hy het met ’n groot stem gesê: Vrees die Elohim en gee Hom Majesteit, want die uur van Sy oordeel het gekom; en aanbid Hom wat die Hemele en die Aarde en die see en die waterfonteine gemaak het.	",
"	8 En ’n ander Boodskapper het gevolg en gesê: Geval, geval het Babel die groot stad, omdat sy al die nasies laat drink het van die wyn van die grimmigheid van haar verbastering.	",
"	9 En ’n derde Boodskapper het hulle gevolg en met ’n groot stem gesê: As iemand die Dier en haar beeld vereer en ’n merk op sy voorhoof of op sy hand ontvang,	",
"	10 sal hy self ook drink van die wyn van die Grimmigheid van Elohim wat ongemeng ingeskink is in die Beker van Sy Toorn, en hy sal gepynig word met vuur en swawel voor die Leër van die Apartheid en voor die Lam.	",
"	11 En die rook van hulle pyniging gaan op tot in alle ewigheid, en hulle het dag en nag geen rus nie - hulle wat die Dier en haar beeld vereer, en elkeen wat die merk van haar naam ontvang.	",
"	12 Hier kom die lydsaamheid van die Apartes te pas; hier is hulle wat die Gebooie van Elohim en die Geloof in JaHWèshua onderhou.	",
"	13 En ek het ’n Stem uit die Hemele aan my hoor sê: Skryf - geseënd is van nou af die dode wat in die Meester sterwe. Ja, sê die Gees, sodat hulle kan rus van hul arbeid, en hulle werke volg met hulle.	",
"	14 En ek het gesien, en kyk, daar was ’n wit Wolkkolom en een soos ’n Seun van die adam wat op die Wolkkolom sit, met ’n goue Kroon op Sy hoof en in Sy Hand ’n skerp sekel.	",
"	15 En ’n ander Boodskapper het uit die Tempel gekom en met ’n groot stem geroep na Hom wat op die Wolkkolom sit: Slaan U sekel in en maai, want die uur het vir U gekom om te maai, omdat die oes van die Aarde oorryp geword het. [JôWEl 3:13]	",
"	16 En Hy wat op die Wolkkolom sit, het Sy sekel oor die Aarde laat gaan, en die Aarde is afgemaai.	",
"	17 En ’n ander Boodskapper het uitgekom uit die Tempel wat in die Hemele is, en hy het ook ’n skerp sekel gehad;	",
"	18 en ’n ander Boodskapper wat mag oor die vuur gehad het, het uit die Altaar uitgekom en met ’n groot stem geroep na hom wat die skerp sekel het, en gesê: Slaan U skerp sekel in en samel die trosse van die Wingerdstok van die Aarde in, want Haar druiwe het ryp geword.	",
"	19 En die Boodskapper het Sy sekel oor die Aarde laat gaan en die Wingerdstok van die Aarde afgeoes en hulle gegooi in die groot parskuip van die Grimmigheid van Elohim.	",
"	20 En die parskuip is buitekant die Stad getrap, en bloed het uit die parskuip gekom tot aan die tooms van die perde, tweehonderd myl ver. [Boekrol van Henog 100:3; 2 Ezra 15:35]	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '15',
content: [
	
"	1 EN ek het ’n ander Teken in die Hemele gesien, groot en wonderlik: sewe Boodskappers met die sewe laaste plae, want daarmee is die Grimmigheid van Elohim voleindig.	",
"	2 En ek het gesien iets soos ’n see van glas, gemeng met vuur. En die oorwinnaars oor die Dier en oor haar beeld en oor haar teken, oor die getal van haar naam, het ek by die see van glas sien staan, met siters van El.	",
"	3 En hulle het die lied gesing van Moshè, die dienskneg van die Elohim, en die lied van die Lam, en gesê: Groot en wonderlik is U werke, JaHWeH Elohim, El Almagtige; regverdig en waaragtig is U Weë, o Koning van die Apartes! [Boekrol van Henog 39:7]	",
"	4 Wie sal U nie vrees nie, O JaHWeH, en U Naam nie vereer nie? Want U alleen is Apart; want al die nasies sal kom en voor U neerval, omdat U regverdige dade openbaar geword het.	",
"	5 En ná hierdie dinge het ek gesien, en kyk, die Tempel van die Tent van die Getuienis in die Hemele is geopen.	",
"	6 En die sewe Boodskappers met die sewe plae het uit die Tempel uitgekom, bekleed met skoon, glansende linne, en om die bors omgord met goue gordels.	",
"	7 En een van die vier lewende Wesens het aan die sewe Boodskappers sewe goue bekers gegee, vol van die Grimmigheid van Elohim wat leef tot in alle ewigheid.	",
"	8 En die Tempel het vol rook geword uit die Glansrykheid van Elohim en Sy Krag, en niemand kon ingaan in die Tempel voordat die sewe plae van die sewe Boodskappers voleindig was nie.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '16',
content: [
		
"	1 EN ek het ’n groot Stem uit die Tempel aan die sewe Boodskappers hoor sê: Gaan gooi die bekers van die Grimmigheid van die Elohim op die Aarde uit.	",
"	2 Toe gaan die eerste een weg en gooi sy beker op die Aarde uit, en vernietigende en besoedelde swere het aan die mense gekom wat die merk van die Dier gehad het en haar beeld vereer het.	",
"	3 En die tweede Boodskapper het sy beker op die see uitgegooi, en hy het bloed geword soos van ’n dooie, en elke lewende siel in die see het gesterwe.	",
"	4 En die derde Boodskapper het sy beker uitgegooi op die riviere en op die waterfonteine, en dit het bloed geword	",
"	5 En ek het die Boodskapper van die waters hoor sê: Regverdig, JaHWeH, is U WAT IS EN WAT WAS, U, die APARTE, omdat U hierdie oordeel uitgevoer het;	",
"	6 want hulle het die bloed van die Apartes en Profete vergiet, en U het aan hulle bloed gegee om te drink, want hulle het dit verdien. [JeshaJaH 26:21]	",
"	7 En ek het ’n ander een uit die Altaar hoor sê: Ja, JaHWeH Elohim, El Almagtig, waaragtig en regverdig is U oordele.	",
"	8 En die vierde Boodskapper het sy beker op die son uitgegooi, en aan hom is dit gegee om die mense met vuur te skroei.	",
"	9 En die mense is geskroei met ’n groot hitte, en hulle het die Naam van Elohim gelaster wat mag het oor hierdie plae, en hulle het hul nie bekeer om Hom lof te gee nie.	",
"	10 En die vyfde Boodskapper het sy beker uitgegooi op die troon van die Dier, en haar koninkryk is verduister, en hulle het hul tonge gekou van pyn; [Exodus 10:22]	",
"	11 en hulle het die Elohey van die Hemele gelaster oor hulle pyne en oor hulle swere, en het hulle nie bekeer van hul werke nie.	",
"	12 En die sesde Boodskapper het sy beker uitgegooi op die groot rivier, die Eufraat, en sy water het opgedroog, sodat die pad van die konings wat van die Ooste af kom, reggemaak kon word.	",
"	13 En ek het uit die bek van die Draak en uit die bek van die Dier en uit die mond van die valse profeet drie geeste van besoedeling  soos paddas sien kom. [Exodus 8:2]	",
"	14 Want hulle is geeste van demone wat tekens doen, wat uitgaan na die konings van die Aarde en die hele wêreld, om hulle te versamel vir die oorlog van daardie groot dag van die Almagtige Elohey.	",
"	15 Kyk, Ek kom soos ’n dief. Geseënd is hy wat waak en sy klere bewaar, sodat hy nie miskien naak rondloop en hulle sy skaamte sien nie.	",
"	16 En hulle het hul versamel op die plek wat in Hebreeus genoem word Har-Megiddon.	",
"	17 En die sewende Boodskapper het sy beker uitgegooi in die lug, en ’n groot Stem het uit die Tempel van die Hemele gekom, van die Troon af, wat gesê het: Dit is verby!	",
"	18 En daar het stemme gekom en donderslae en bliksemstrale, en daar het ’n groot aardbewing gekom soos daar nog nie gewees het vandat die mense op die Aarde was nie - so ’n geweldige groot aardbewing.	",
"	19 En die groot stad is in drie dele verdeel, en die stede van die nasies het geval. En die groot Babel is in gedagtenis gebring voor die Elohim, om haar te gee die Beker met die wyn van die Grimmigheid van Sy toorn.	",
"	20 En alle eilande het gevlug, en berge is daar nie gevind nie;	",
"	21 en groot hael, omtrent ’n talent swaar, het uit die Hemele op die mense geval; en die mense het die Elohim gelaster oor die plaag van die hael, omdat Sy plaag ontsettend groot was. [Exodus 9:24]	",
		

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '17',
content: [
		
"	1 EN een van die sewe Boodskappers met die sewe bekers het gekom en met my gespreek en vir my gesê: Kom hierheen, ek sal jou toon die oordeel van die groot hoer wat op die baie waters sit,	",
"	2 met wie die konings van die Aarde verbaster het, en die bewoners van die Aarde het dronk geword van die wyn van haar verbastering.	",
"	3 En hy het my in die gees weggevoer na ’n wildernis, en ek het ’n vrou sien sit op ’n skarlakenrooi Dier, vol lasterlike name, met sewe koppe en tien horings.	",
"	4 En die vrou was bekleed met purper en skarlaken en versierd met goud en kosbare stene en pêrels, en sy het in haar hand ’n goue beker gehad, vol van gruwels en die besmetlikheid van haar verbastering;	",
"	5 en op haar voorhoof was ’n naam geskrywe: GEHEIMSINNIGHEID, DIE GROOT BABEL, DIE MOEDER VAN DIE HOERE EN VAN DIE GRUWELS VAN DIE AARDE.	",
"	6 En ek het die vrou gesien, dronk van die bloed van die Apartes en van die bloed van die getuies van JaHWèshua, en ek het my uitermate verwonder toe ek haar sien.	",
"	7 Toe sê die Boodskapper vir my: Waarom het jy jou verwonder? Ek sal jou die geheimenisse van die vrou vertel en van die Dier met die sewe koppe en die tien horings, wat haar dra.	",
"	8 Die Dier wat jy gesien het, was en is nie en sal uit die Afgrond opkom en na die verderf vaar; en die bewoners van die Aarde wie se name nie van die grondlegging van die wêreld af in die Boekrol van die Lewe geskryf is nie, sal hulle verwonder as hulle die Dier sien wat was en nie is nie, alhoewel sy is.	",
"	9 Hier kom die verstand wat Wysheid het, te pas. Die sewe koppe is sewe berge waar die vrou op sit.	",
"	10 En hulle is sewe konings: vyf het geval en een is; die ander een het nog nie gekom nie; en wanneer hy kom, moet hy ’n kort tydjie bly.	",
"	11 En die Dier wat was en nie is nie, is self ook die agtste, en sy behoort by die sewe en gaan na die verderf.	",
"	12 En die tien horings wat jy gesien het, is tien konings wat nog geen koningskap ontvang het nie, maar hulle ontvang mag soos konings een uur lank saam met die Dier.	",
"	13 Hulle het een gesindheid en sal hulle krag en mag oorgee aan die Dier.	",
"	14 Hulle sal teen die Lam oorlog voer, en die Lam sal hulle oorwin - want Hy is die Elohey van die Elohim en die Meester van die meesters - en die wat saam met Hom is, geroepe en uitverkore en getrou. [Deuteronómium 10:17]	",
"	15 En hy sê vir my: Die waters wat jy gesien het, waar die hoer op sit, is volke en menigtes en nasies en tale.	",
"	16 En die tien horings wat jy op die Dier gesien het, hulle sal die hoer haat en haar verlate maak en naak, en haar vlees eet en haar met vuur verbrand.	",
"	17 Want die Elohim het dit in hulle harte gegee om Sy bedoeling uit te voer en een bedoeling uit te voer, en haar heerskappy aan die Dier te gee totdat die Woord van die Elohim volbring is.	",
"	18 En die vrou wat jy gesien het, is die groot stad wat heerskappy voer oor die konings van die Aarde.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '18',
content: [
		
"	1 EN ná hierdie dinge het ek ’n Boodskapper sien neerdaal uit die Hemele, met groot mag, en die Aarde is verlig deur sy Glansrykheid.	",
"	2 En hy het met ’n groot stem kragtig uitgeroep en gesê: Geval, geval het die groot Babel, en sy het geword ’n woonplek van demone en ’n versamelplek van allerhande geeste van besoedeling en ’n versamelplek van allerhande besoedelde en haatlike vlieënde wesens,	",
"	3 omdat al die nasies gedrink het van die wyn van die grimmigheid van haar verbastering, en die konings van die Aarde met haar vermeng het, en die handelaars van die Aarde ryk geword het deur die mag van haar weelderigheid.	",
"	4 En ek het ’n ander Stem uit die Hemele hoor sê: Gaan uit haar midde uit, My volk, sodat julle nie deelneem aan haar oortredinge en so van haar plae ontvang nie. [JirmeJaH 51: 7 en 45]	",
"	5 Want haar oortredinge reik tot aan die Hemele, en Elohim het haar verkeerde werke onthou.	",
"	6 Vergeld haar soos sy ook julle vergeld het, en verdubbel dit vir haar volgens haar werke. Skink vir haar dubbel in die beker waarin sy geskink het.	",
"	7 Namate sy haarself verhoog het en weelderig geleef het, na dié mate moet julle haar pyniging en droefheid aandoen. Omdat sy in haar hart sê: Ek sit as koningin en is geen weduwee nie, en droefheid sal ek nooit sien nie -	",
"	8 daarom sal haar plae op een dag kom: dood en droefheid en honger; en met vuur sal sy verbrand word, want sterk is die Elohim, JaHWeH wat haar oordeel.	",
"	9 En die konings van die Aarde wat met haar vermeng en weelderig geleef het, sal oor haar ween en oor haar weeklaag wanneer hulle die rook van haar verbranding sien,	",
"	10 terwyl hulle ver weg staan uit vrees vir haar pyniging en sê: Wee, wee jou, o groot stad Babel, o sterk stad, want in een uur het jou oordeel gekom!	",
"	11 En die handelaars van die Aarde sal ween en rou bedrywe oor haar, omdat niemand hulle koopware meer koop nie,	",
"	12 koopware van goud en silwer en edelgesteente en pêrels en fyn linne en purper en sy en skarlaken; en allerhande geurige hout en allerhande voorwerpe van ivoor en allerhande voorwerpe van die kosbaarste hout en van koper en yster en marmer	",
"	13 en kaneel en reukwerk en salf en wierook en wyn en olyfolie en fynmeel en koring en grootvee en skape; en van perde en waens en slawe en die siele van adamiete.[ JeségiEl 27:13]	",
"	14 En die vrugte wat jou siel begeer, het van jou gewyk, en al die blinkende en die skitterende dinge het van jou gewyk, en jy sal dit nooit weer kry nie.	",
"	15 Die handelaars in hierdie dinge, wat van haar ryk geword het, sal ver weg staan uit vrees vir haar pyniging, terwyl hulle ween en rou bedrywe [JeségiEl 27:29]	",
"	16 en sê: Wee, wee die groot stad wat bekleed was met fyn linne en purper en skarlaken en versierd met goud en edelgesteente en pêrels, omdat in een uur soveel rykdom verwoes is! [Boekrol van Henog 98:3]	",
"	17 En elke stuurman en die hele menigte op die skepe, en die matrose en almal wat die see bevaar, het ver weg gaan staan	",
"	18 en het uitgeroep toe hulle die rook van haar verbranding sien, en gesê: Watter stad is soos die groot stad?	",
"	19 En hulle het stof op hul hoofde gegooi en onder geween en weeklag uitgeroep en gesê: Wee, wee die groot stad waarin almal wat skepe op die see het, deur haar kostelike skatte ryk geword het; want sy is in een uur verwoes!	",
"	20 Verbly jou oor haar, o Hemele, en o Apostels van Apartheid en Profete, omdat Elohim julle oordeel aan haar voltrek het!	",
"	21 En een sterk Boodskapper het ’n klip opgetel soos ’n groot meulsteen en haar in die see gegooi en gesê: So, met ’n vaart, sal Babel, die groot stad, neergegooi word en nooit meer gevind word nie.	",
"	22 En die stem van siterspelers en sangers en fluitspelers en basuinblasers sal nooit meer in jou gehoor word nie, en geen kunstenaar van enige kuns sal ooit weer in jou gevind word nie, en die geluid van die meul sal nooit meer in jou gehoor word nie.	",
"	23 En die Lig van ’n lamp sal nooit meer in jou skyn nie, en die stem van bruidegom en bruid sal nooit meer in jou gehoor word nie; want jou handelaars was die grotes van die Aarde; want deur jou dwelmverbruik is al die nasies verlei. [JeshaJaH 47:12]	",
"	24 En die bloed van Profete en Apartes is in haar gevind, en van almal wat op die Aarde gedood is.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '19',
content: [
	
"	1 EN na hierdie dinge het ek iets soos ’n groot stem van ’n groot menigte in die Hemele gehoor wat sê: HalleluJaHH/Prys-JaHH, die Verlossing en die Majesteit en die Eer en die Krag aan JaHWeH onse Elohey!	",
"	2 Want Sy oordele is waar en regverdig; want Hy het die groot hoer geoordeel wat die Aarde met haar verbastering verderf het, en Hy het die bloed van Sy diensknegte op haar gewreek. [2 Ezra 13:11]	",
"	3 En vir die tweede maal het hulle gesê: HalleluJaHH/Prys-JaHH! En haar rook gaan op tot in alle ewigheid.	",
"	4 En die vier-en-twintig oudstes en die vier lewende Wesens het neergeval en Elohim aanbid wat op die Troon sit, en gesê: Amein, HalleluJaHH/Prys-JaHH! [2 Ezra 13:12]	",
"	5 En ’n Stem het uit die Troon uitgegaan en gesê: Prys onse Elohey, al Sy diensknegte, en julle wat Hom vrees, klein en groot!	",
"	6 En ek het iets gehoor soos die stem van ’n groot menigte en soos die geluid van baie waters en soos die geluid van sterk donderslae wat sê: HalleluJaHH/Prys-JaHH! want onse Elohey JaHWeH El Almagtig, het die Koningskap aanvaar.	",
"	7 Laat ons bly wees en ons verheug en aan Hom die Majesteit gee, want die Bruilof van die Lam het gekom en Sy Vrou het Haar gereed gemaak.	",
"	8 En aan Haar is gegee om bekleed te wees met gewasde en glansende fyn linne, want die fyn linne is die regverdige dade van die Apartes.	",
"	9 Toe sê hy vir my: Skryf - geseënd is die wat genooi is na die bruilofsmaal van die Lam. En hy sê vir my: Dit is die ware Woorde van Elohim.	",
"	10 En ek het voor sy voete neergeval om hom te aanbid; maar hy het vir my gesê: Moenie! Ek is ’n mededienskneg van jou en van jou broers wat die Getuienis van JaHWèshua het. Aanbid Elohim. Want die Getuienis van JaHWèshua is die Gees van die profesie.	",
"	11 Toe het ek die Hemele geopend gesien; en daar was ’n wit perd, en Hy wat daarop sit, word genoem Getrou en Waaragtig, en Hy oordeel en voer oorlog in Geregtigheid.	",
"	12 En Sy Oë was soos ’n Vuurvlam, en op Sy hoof was baie krone; en Hy het ’n Naam wat geskrywe is, wat niemand ken nie, behalwe Hy self.	",
"	13 En Hy was bekleed met ’n kleed wat in bloed gedoop was, en Sy Naam is: Die Woord van die Elohim.	",
"	14 En die leërs in die Hemele het Hom gevolg op wit perde, bekleed met wit en skoongewaste fyn linne.	",
"	15 En uit Sy Mond gaan daar ’n skerp Swaard om die nasies met haar te slaan; en Hy sal hulle met ’n Septer van Yster regeer, en Hy trap die parskuip van die wyn van die Grimmigheid en van die toorn van El, Almagtig. [Psalm 37:15; Boekrol van Henog 62:2; JeshaJaH 13:6; 31:8; 49:2; 66:16; Openbaring 1:16]	",
"	16 En Hy dra op Sy kleed en op Sy heup die Naam wat geskrywe is: Die Koning van die konings en die Meester van die meesters. [Deuteronómium 10:17]	",
"	17 En ek het een Boodskapper sien staan in die son; en hy het met ’n groot stem uitgeroep en vir al die vlieënde wesens gesê wat in die middel van die lug vlieg: Kom hierheen en versamel julle tot die maaltyd van die grote Elohim,	",
"	18 dat julle kan eet die vlees van konings en die vlees van owerstes oor duisend en die vlees van sterkes en die vlees van perde en van die wat daarop sit, en die vlees van almal, vrymense sowel as slawe, klein sowel as groot.	",
"	19 En ek het die Dier en die konings van die Aarde en hulle leërs versameld gesien, om oorlog te voer teen Hom wat op die perd sit, en teen Sy leër.	",
"	20 En die Dier is gevange geneem, en saam met haar die valse profeet wat die tekens in haar teenwoordigheid gedoen het, waarmee hy húlle verlei het wat die merk van die Dier ontvang en haar beeld vereer het. Lewend is die twee gewerp in die vuurpoel wat met swawel brand.	",
"	21 En die oorblyfsel is gedood met die Swaard wat uit die Mond gaan van Hom wat op die perd sit; en al die vlieënde wesens is versadig van hulle vlees.	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '20',
content: [
		
"	1 EN ek het ’n Boodskapper uit die Hemele sien neerdaal, met die sleutel van die Afgrond en ’n groot ketting in sy hand.	",
"	2 En hy het die Draak gegryp - die ou slang/Nagash wat die duiwel en die Satan is - en hy het hom gebind duisend jaar lank,	",
"	3 en hom in die Afgrond gewerp en hom toegesluit en dit bo hom verseël, sodat hy die nasies nie meer sou verlei totdat die duisend jaar voleindig is nie. Daarna moet hy dan ’n kort tydjie ontbind word.	",
"	4 En ek het trone gesien, en hulle het daarop gaan sit, en aan hulle is die oordeel gegee; en ek het die siele gesien van die wat onthoof is oor die Getuienis van JaHWèshua en oor die Woord van die Elohim, en die wat die Dier en haar beeld nie vereer het nie, en die merk op hulle voorhoof en op hulle hand nie ontvang het nie; en hulle het geleef en geheers saam met die Gesalfde ’n duisend jaar lank. [Psalm 122:4; MattithJaHûW 19:28]	",
"	5 En die oorblyfsel van die dode het nie herlewe totdat die duisend jaar voleindig was nie. Dit is die eerste opstanding.	",
"	6 Geseënd en apartgestel is hy wat deel het aan die eerste opstanding; oor hulle het die tweede dood geen mag nie, maar hulle sal priesters van Elohim en van die Gesalfde wees en sal saam met Hom heers duisend jaar lank.	",
"	7 En wanneer die duisend jaar voleindig is, sal die Satan uit sy gevangenis ontbind word;	",
"	8 en hy sal uitgaan om die nasies te verlei wat in die vier hoeke van die Aarde is, die Gog en die Magog, om hulle te versamel vir die oorlog; en hulle getal is soos die sand van die see.	",
"	9 En hulle het opgekom oor die breedte van die Aarde en die laer van die Apartes en die geliefde Stad omsingel, en vuur het van Elohim uit die Hemele neergedaal en hulle verslind.	",
"	10 En die Satan wat hulle verlei het, is in die poel van vuur en swawel gewerp waar die Dier en die valse profeet is; en hulle sal dag en nag gepynig word tot in alle ewigheid.	",
"	11 En ek het ’n groot wit Troon gesien en Hom wat daarop sit, voor Wie se Aangesig die Aarde en die Hemele weggevlug het; en daar is geen plek vir hulle gevind nie.	",
"	12 En ek het die dode, klein en groot, voor Elohim sien staan, en die Boekrol is geopen; en ’n ander Rol, die Boekrol van die Lewe, is geopen. En die dode is geoordeel na wat in die Rol geskryf is, volgens hulle werke. [Boekrol van Henog 47:3; 51:1; 60:2; 89:20; 2 Ezra 8:33]	",
"	13 En die see het die dode gegee wat in hom was, en die Dood en die Doderyk/Sheol het die dode gegee wat in haar was; en hulle is geoordeel, elkeen volgens sy werke. [2 Ezra 7:32]	",
"	14 En die Dood en die Doderyk/Sheol is in die poel van vuur gewerp. Dit is die tweede dood.	",
"	15 En as dit bevind is dat iemand nie opgeskryf was in die Boek van die Lewe nie, is hy in die poel van vuur gewerp. [Boekrol van Henog 100:9]	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '21',
content: [
		
"	1 EN ek het ’n nuwe Hemele en ’n nuwe Aarde gesien, want die eerste Hemele en die eerste Aarde het verbygegaan; en die see was daar nie meer nie. [Boekrol van Henog 91:16; 2 Petrus 3:10]	",
"	2 En ek, JeHôWganan, het die Stad van Apartheid, die nuwe Jerusalem, sien neerdaal van Elohim uit die Hemele, toeberei soos ’n Bruid wat vir Haar Man versier is. [Boekrol van Henog 53:6]	",
"	3 En ek het ’n groot Stem uit die Hemele hoor sê: Kyk, die Tabernakel van Elohim is by die adamiete, en Hy sal by hulle woon, en hulle sal Sy volk wees; en die Elohim self sal by hulle wees as hulle Elohim.	",
"	4 En Elohim sal al die trane van hulle oë afvee, en daar sal geen Dood meer wees nie; ook droefheid en geween en moeite sal daar nie meer wees nie, want die eerste dinge het verbygegaan. [Boekrol van Henog 96:3]	",
"	5 En Hy wat op die Troon sit, het gesê: KYK, EK MAAK ALLES NUUT. En Hy het aan my gesê: Skryf, want hierdie Woorde is waar en betroubaar.	",
"	6 En Hy het vir my gesê: DIT IS VERBY! Ek [is] die Alef [a] en die Taw [T], die begin en die einde. Aan die dorstige sal Ek gee uit die Fontein van die water van die lewe, verniet. [Odes van Salomo 30:1]	",
"	7 Hy wat oorwin, sal alles beërwe; en Ek sal vir hom ’n Elohim wees, en hy sal vir My ’n seun wees.	",
"	8 Maar wat die vreesagtiges aangaan en die ongelowiges en gruwelikes en moordenaars en homoseksuele en dwelmhandelaars en idoledienaars en al die leuenaars - hulle deel is in die poel wat brand met vuur en swawel: sy is die tweede dood.	",
"	9 En een van die sewe Boodskappers wat die sewe bekers gehad het, vol van die sewe laaste plae, het na my gekom en met my gespreek en gesê: Kom hierheen, ek sal jou die Bruid toon, die Vrou van die Lam.	",
"	10 En hy het my in die gees weggevoer op ’n groot en hoë berg en my die groot Stad getoon, die Aparte Jerusalem, wat uit die Hemele van Elohim neerdaal;	",
"	11 en Sy het die Glansrykheid van Elohim gehad, en Haar Lig was soos ’n baie kosbare Steen, soos die kristalhelder jaspissteen.	",
"	12 En Sy het ’n groot en hoë muur met twaalf Poorte gehad, en by die Poorte twaalf Boodskappers, en name daarop geskrywe, naamlik dié van die twaalf stamme van die kinders van JisraEl. [Boekrol van Henog 75:6]	",
"	13 Aan die oostekant was daar drie Poorte, aan die noordekant drie Poorte, aan die suidekant drie Poorte, aan die westekant drie Poorte.	",
"	14 En die muur van die Stad het twaalf fondamente gehad, en op hulle was die name van die twaalf Apostels van die Lam. [Psalm 87:1]	",
"	15 En hy wat met my gespreek het, het ’n goue meetroede gehad, om die Stad en haar Poorte en Haar muur te meet.	",
"	16 En die Stad het vierkantig gelê, en Haar lengte was net so groot as haar breedte. En hy het die Stad met die meetroede gemeet op duisend-vyfhonderd myl; Haar lengte en breedte en hoogte was gelyk.	",
"	17 En hy het Haar muur gemeet op honderd-vier-en-veertig voorarm, volgens ’n adamiet se maat, wat die maat van ‘n Boodskapper is. [ZekarJaH 2:5]	",
"	18 En die boustof van Haar muur was jaspis, en die Stad was suiwer goud soos suiwer glas.	",
"	19 En die fondamente van die muur van die Stad was versierd met allerhande edelgesteentes. Die eerste fondament was jaspis, die tweede saffier, die derde chalcedoon, die vierde smarag;	",
"	20 die vyfde sardóniks, die sesde sardius, die sewende chrisoliet, die agtste beril, die negende topaas, die tiende chrísopraas, die elfde hiasínt, die twaalfde ametís.	",
"	21 En die twaalf Poorte was twaalf Pêrels; elkeen van die Poorte was uit een Pêrel, en die straat van die Stad was suiwer goud soos deurskynende glas.	",
"	22 En ’n Tempel het ek nie in Haar gesien nie, want Elohey, die ALMAGTIGE, is Haar Tempel, en die Lam. [Openbaring van Henog 17:9]	",
"	23 En die Stad het die son of die maan nie nodig om in Haar te skyn nie, want die Glansrykheid van Elohim het Haar verglans, en die Lam is Haar lamp.	",
"	24 En die nasies van die wat gered word, sal in die Lig van Haar wandel, en die konings van die Aarde bring hulle majesteit en eer in Haar.	",
"	25 En bedags - want nag sal daar nie meer wees nie - sal Haar Poorte nooit gesluit word nie;	",
"	26 en hulle sal die majesteit en die eer van die nasies in Haar bring.	",
"	27 En in Haar sal nie inkom iets wat vuil [ongewas] is en gruwelikheid en leuens doen nie; maar net die wat geskrywe is in die Boek van die Lewe van die Lam. [Levítikus 11:44; JôWEl 3:17; Odes van Salomo 9:11-12]	",

]
},
{
book: 'Openbaring_Van_Jahwèshua',
chapter: '22',
content: [
		
"	1 EN hy het my getoon ’n suiwer rivier van die water van die lewe, helder soos kristal, wat uitstroom uit die Troon van die Elohim en van die Lam.	",
"	2 In die middel van Haar straat en weerskante van die rivier was die Boom van die Lewe wat twaalf maal vrugte dra en elke maand Haar vrugte gee, en die blare van die Boom is tot genesing van die nasies. [Boekrol van Henog 25:6, 7]	",
"	3 En daar sal geen enkele vervloeking meer wees nie, en die Troon van die Elohim en van die Lam sal in Haar wees, en Sy diensknegte sal Hom dien. [Boekrol van Henog 91:17]	",
"	4 En hulle sal Sy Aangesig sien, en Sy Naam sal op hulle voorhoofde wees.	",
"	5 En nag sal daar nie wees nie; en hulle het geen lamp of sonlig nodig nie, omdat JaHWeH Elohim hulle verlig; en hulle sal as konings regeer tot in alle ewigheid. [Boekrol van Henog 58:6; 2 Ezra 2:43]	",
"	6 En hy het vir my gesê: Hierdie Woorde is betroubaar en waar; en JaHWeH, die Elohey van die Profete van die Aparthede, het Sy Boodskapper gestuur om Sy diensknegte te toon wat gou moet gebeur.	",
"	7 Kyk, Ek kom gou. Geseënd is hy wat die Woorde van die profesie van hierdie Boekrol bewaar.	",
"	8 En dit is ek, JeHôWganan, wat dit gesien en gehoor het; en toe ek dit gehoor en gesien het, het ek neergeval om te aanbid voor die voete van die Boodskapper wat my hierdie dinge getoon het.	",
"	9 Toe sê hy vir my: Moenie! want Ek is ’n mededienskneg van jou en van jou broers, die Profete, en van hulle wat die Woorde van hierdie Boekrol bewaar. Aanbid Elohim.	",
"	10 En hy het vir my gesê: Moenie die Woorde van die profesie van hierdie Boekrol verseël nie, want die tyd is naby.	",
"	11 Wie onreg doen, laat hom nog meer onreg doen; en wie vuil is, laat hom nog vuiler word; en laat die regverdige nog regverdiger word, en laat die aparte nog meer apartgestel word in sy apartgesteldheid.	",
"	12 En kyk, Ek kom gou, en My loon is by My, om elkeen te vergeld soos sy werk sal wees.	",
"	13 Ek is die Alef [a] en die Taw [T], die begin en die einde, die eerste en die laaste.	",
"	14 Geseënd is die wat Sy Gebooie doen, sodat hulle Reg kan hê op die Boom van die Lewe en ingaan deur die Poorte in die Stad.	",
"	15 Maar buite is die honde en die dwelmhandelaars en die homoseksuele en die moordenaars en die idoledienaars en elkeen wat leuens liefhet en doen. [Openbaring van Henog 5:17; JeshaJaH 47:9]	",
"	16 Ek, JaHWèshua, het My Boodskapper gestuur om hierdie dinge aan julle voor die gemeentes te betuig. Ek is die wortel en die saadlyn van Dawid, die glansende Môrester.	",
"	17 En die Gees en die Bruid sê: Kom! En laat hom wat hoor, sê: Kom! En laat hom wat dors het, kom; en laat hom wat wil, die water van die lewe neem, verniet.	",
"	18 Want Ek betuig aan elkeen wat die Woorde van die profesie van hierdie Boekrol hoor: As iemand by hierdie dinge byvoeg, dan sal Elohim oor hom die plae byvoeg waarvan in hierdie Boekrol geskrywe is.	",
"	19 En as iemand iets van die Woorde van die boekrol van hierdie profesie wegneem, dan sal Elohim Sy deel wegneem uit die Boekrol van die Lewe en uit die Stad van Apartheid en uit die dinge waarvan in hierdie boek geskrywe is. [Levítikus11:44]	",
"	20 Hy wat dit getuig, sê: Ja, Ek kom gou. Amein, ja kom, Meester JaHWèshua!	",
"	21 Die Barmhartigheid van onse Meester JaHWèshua, die Gesalfde, sy met julle almal! Amein.	",

]
}


];
