const amosChapters = [

{
book: 'Amos',
chapter: '1',
content: [

"	1 DIE woorde van Amos, een van die skaapboere uit Tekóa, wat hy gesien het aangaande JisraEl in die dae van UzziJaH, koning van JeHûWdah, en in die dae van Jeróbeam, die seun van JôWash, koning van JisraEl, twee jaar voor die aardbewing.	",
"	2 En hy het gesê: JaHWeH brul uit Sion en verhef Sy Stem uit Jerusalem, sodat die weivelde van die herders treur en die top van Karmel verdor.	",
"	3 So sê JaHWeH: Oor drie oortredinge van Damaskus, ja, oor vier, sal Ek dit nie afwend nie; omdat hulle Gílead met ysterdorssleë gedors het.	",
"	4 Daarom sal Ek ’n Vuur slinger in die huis van GazaEl, en Hy sal die paleise van Bénhadad verteer.	",
"	5 En Ek sal die grendel van Damaskus verbreek en die inwoners uit die laagte van Awen uitroei en die wat die septer dra, uit die Huis van Eden, en die volk van Sirïe sal in ballingskap gaan na Kir, sê JaHWeH.	",
"	6 So sê JaHWeH: Oor drie oortredinge van Gasa, ja, oor vier, sal Ek dit nie afwend nie; omdat hulle ’n ganse bevolking in ballingskap weggevoer het om dit aan Edom uit te lewer.	",
"	7 Daarom sal Ek ’n Vuur stuur tussen die muur van Gasa, en Hy sal haar paleise verteer.	",
"	8 En Ek sal die inwoners uit Asdod uitroei en die wat die septer dra, uit Askelon; en Ek sal My Hand teen Ekron uitstrek, en die oorblyfsel van die Filistyne sal omkom, sê My Meester JaHWeH.	",
"	9 So sê JaHWeH: Oor drie oortredinge van Tirus, ja, oor vier, sal Ek dit nie afwend nie; omdat hulle ’n ganse bevolking as ballinge aan Edom uitgelewer het en nie gedink het aan die verbond van die broers nie.	",
"	10 Daarom sal Ek ’n Vuur stuur tussen die muur van Tirus, en Hy sal haar paleise verteer.	",
"	11 So sê JaHWeH: Oor drie oortredinge van Edom, ja, oor vier, sal Ek dit nie afwend nie; omdat hy sy broer met die swaard agtervolg het en sy jammergevoel verstik het, sodat sy toorn altyd verskeur en hy gedurigdeur sy grimmigheid behou.	",
"	12 Daarom sal Ek ’n Vuur stuur in Teman, en Hy sal die paleise van Bosra verteer.	",
"	13 So sê JaHWeH: Oor drie oortredinge van die kinders van Ammon, ja, oor vier, sal Ek dit nie afwend nie; omdat hulle die swanger vroue van Gílead oopgesny het om hulle grense te verlê (te vertrap).	",
"	14 Daarom sal Ek ’n Vuur aansteek in die muur van Rabbah, en Hy sal haar paleise verteer, met krygsgeskreeu op die dag van stryd, in ’n storm op die dag van die orkaan.	",
"	15 En hulle koning sal in ballingskap gaan, hy en sy vorste tesame, sê JaHWeH.	",

]
},
{
book: 'Amos',
chapter: '2',
content: [
		
"	1 SO sê JaHWeH: Oor drie oortredinge van Moab, ja, oor vier, sal Ek dit nie afwend nie; omdat hy die beendere van die koning van Edom tot kalk verbrand het.	",
"	2 Daarom sal Ek ’n Vuur stuur in Moab, en Hy sal die paleise van Kérijot verteer; en Moab sal met oorlogsrumoer sterwe, met krygsgeskreeu en ramshoringgeskal.	",
"	3 En Ek sal die regeerder uit haar binneste uitroei en al haar vorste saam met hom doodmaak, sê JaHWeH.	",
"	4 So sê JaHWeH: Oor drie oortredinge van JeHûWdah, ja, oor vier, sal Ek dit nie afwend nie; omdat hulle die Wet van JaHWeH verwerp het en Sy Insettinge nie onderhou het nie; en die leuens het hulle verlei waar hulle vaders agter aan geloop het.	",
"	5 Daarom sal Ek ’n Vuur slinger in JeHûWdah, en Hy sal die paleise van Jerusalem verteer.	",
"	6 So sê JaHWeH: Oor drie oortredinge van JisraEl, ja, oor vier, sal Ek dit nie afwend nie; omdat hulle die regverdige vir silwer verkoop het en die behoeftige vir ’n paar skoene.	",
"	7 Hulle wat daarna hyg dat die stof van die Aarde op die hoof van die hulpeloses kom, en wat die weg van die behoeftiges buig; en die man en sy vader gaan na die jongedogter om [die] Naam van My Apartheid te besoedel.	",
"	8 En hulle strek hul uit op verpande klere by elke altaar, en die wyn van die wat veroordeel is, drink hulle in die huis van hulle gode. [Spreuke 4:17]	",
"	9 En tog het Ék die Amoriet voor hulle uit verdelg wie se hoogte was soos die hoogte van die seders, en hy was sterk soos die eikebome; maar Ek het sy vrug daarbo en sy wortels daaronder verdelg.	",
"	10 Ook het Ek julle uit die Aarde van Egipte laat optrek en julle veertig jaar lank in die wildernis gelei, om die Aarde van die Amoriet in besit te neem.	",
"	11 En Ek het uit julle seuns profete en uit julle jongelinge separatiste verwek. Is dit nie so nie, o kinders van JisraEl? spreek JaHWeH.	",
"	12 Maar julle het die separatiste wyn laat drink en aan die profete bevel gegee en gesê: Julle mag nie profeteer nie!	",
"	13 Kyk, Ek laat dit onder julle kraak, soos ’n wa kraak wat vol gerwe is;	",
"	14 sodat die wat gou is, nie kan ontvlug nie, en die sterke sy krag nie kan ontwikkel en die dappere sy siel nie kan red nie.	",
"	15 En die boogskutter sal nie bly staan en die wat gou is op sy voete, nie vrykom nie, en die perderuiter sal sy siel nie red nie.	",
"	16 En die dapperste onder die dapperes sal op dié dag naak wegvlug, spreek JaHWeH.	",

]
},
{
book: 'Amos',
chapter: '3',
content: [
		
"	1 LUISTER na wat die Woord van JaHWeH oor julle gespreek het, o kinders van JisraEl, oor die hele familie wat Ek uit die Aarde van Egipte laat optrek het, naamlik:	",
"	2 Julle alleen het Ek geken uit al die stamme op die Adamah[adamiet se Aarde]; dáárom sal Ek julle straf, oor al julle ongeregtigheid.	",
"	3 Sal twee met mekaar wandel tensy hulle [eers] afgespreek het?	",
"	4 Sal ’n leeu brul in die woud as hy geen prooi het nie? Sal ’n jong leeu sy stem uit sy lêplek laat hoor as hy niks gevang het nie?	",
"	5 Sal ’n voël in ’n net val op die Aarde as daar vir haar geen strik [gestel] is nie? Sal ’n wip van die Adamah[adamiet se Aarde] af opspring as dit glad nie gevang het nie?	",
"	6 Sal die ramshoring in die stad geblaas word en die bevolking nie skrik nie? Sal daar besoedeling in die stad kom as JaHWeH dit nie bewerk het nie?	",
"	7 Want My Meester JaHWeH doen niks tensy Hy die besluit van Sy Raad aan Sy knegte, die Profete, geopenbaar het nie.	",
"	8 Die leeu het gebrul, wie sal nie vrees nie? my Meester JaHWeH het gespreek, wie sal nie profeteer nie?	",
"	9 Roep dit uit oor die paleise van Asdod en oor die paleise van die Aarde van Egipte en sê: Versamel julle op die berge van Samaría, en aanskou die groot beroering in haar midde en die verdrukkinge binne-in haar.	",
"	10 Ja, hulle weet nie om Reg te doen nie, spreek JaHWeH - hulle wat geweld en verdrukking opstapel in hulle paleise.	",
"	11 Daarom, so sê my Meester JaHWeH: ’n Vyand! En dit rondom die Aarde; en hy sal jou vesting van jou af neerwerp, en jou paleise sal geplunder word.	",
"	12 So sê JaHWeH: Soos ’n herder ’n paar pote of ’n oorlappie red uit die bek van ’n leeu, net so sal gered word die kinders van JisraEl wat daar in Samaría in die hoek van ’n bed of op die damás van ’n rusbank sit.	",
"	13 Hoor en waarsku die huis van Jakob, spreek my Meester JaHWeH, die Elohey van die skeppings-leërmag,	",
"	14 dat Ek in die dag as Ek die oortredinge van JisraEl aan hom besoek, ook besoeking sal doen oor die altare van BetEl1, sodat die horings van die altaar afgekap sal word en op die Aarde val.	",
"	15 Dan sal Ek die winterhuis saam met die somerhuis tref, en die huise van ivoor sal te gronde gaan, en baie huise sal verdwyn, spreek JaHWeH.	",

]
},
{
book: 'Amos',
chapter: '4',
content: [
		
"	1 HOOR hierdie Woord, koeie van Basan, wat op die gebergte van Samaría is! Wat die armes verdruk, die behoeftiges hard behandel; wat aan hulle meesters sê: Bring aan en laat ons drink!	",
"	2 My Meester JaHWeH het gesweer in Sy Apartheid: Want kyk, daar sal dae oor julle kom dat hy julle sal oplig met ’n Skild, en die agterkant van haar met vissershoeke.	",
"	3 En julle sal deur gapings uittrek, , en julle sal weggeruk word na Harmown2 , spreek JaHWeH.	",
"	4 Kom na BetEl, en wees opstandig! Na Gilgal, en wees nog meer opstandig! En bring julle slagdiere in die môre en julle tiendes al om die derde dag.	",
"	5 En laat rook met wat gesuurd is - as danksegging - en roep vrywillige gawes uit, laat dit hoor! Want so is dit na julle sin, kinders van JisraEl, spreek my Meester JaHWeH.	",
"	6 Alhoewel Ék julle suiwerheid van tande gegee het in al julle stede en broodsgebrek in al julle woonplekke - nogtans het julle jul tot My nie bekeer nie, spreek JaHWeH.	",
"	7 Alhoewel Ék die reën van julle teruggehou het toe dit nog drie maande voor die oestyd was en op die een stad laat reën maar op die ander nie laat reën het nie, die een stuk Aarde reën gekry het, maar die ander geen reën op haar geval het nie, [en] sy verdor het;	",
"	8 en twee, drie stede na een stad geslinger het om water te drink sonder om die dors te les - nogtans het julle jul tot My nie bekeer nie, spreek JaHWeH.	",
"	9 Ek het julle met brandkoring en met heuningdou swaar getref, baie van julle tuine en julle Wingerde en julle Vyebome en julle Olyfbome het die sprinkaan verslind - nogtans het julle jul tot My nie bekeer nie, spreek JaHWeH.	",
"	10 Ek het die pes onder julle gestuur, op die manier van Egipte; Ek het julle jongmanne met die swaard gedood saam met die wegvoering van julle perde; en Ek het die stank van julle laer laat opstyg, ja, tot in julle neus - nogtans het julle jul tot My nie bekeer nie, spreek JaHWeH.	",
"	11 Ek het julle omgekeer soos Elohim Sodom en Gomorra omgekeer het, sodat julle soos ’n stuk brandhout was wat uit die vuur geruk is - nogtans het julle jul tot My nie bekeer nie, spreek JaHWeH.	",
"	12 Daarom sal Ek só met jou handel, o JisraEl; omdat Ek só met jou sal handel - maak jou klaar om jou Elohey te ontmoet, o JisraEl!	",
"	13 Want kyk, Hy wat die berge formeer en die wind skep en aan die adamiet sy gedagte bekend maak, wat die dagbreek duisterheid maak, wat op die hoogtes van die Aarde wandel, JaHWeH, Elohey van die skeppings-leërmag, is Sy Naam!	",

]
},
{
book: 'Amos',
chapter: '5',
content: [
"	1 HOOR hierdie Woord wat Ek oor julle as klaaglied aanhef, o huis van JisraEl!	",
"	2 Die Maagd van JisraEl het geval, Sy sal nie weer opstaan nie; neergewerp lê Sy op haar Adamah [die adamiet se Aarde], niemand rig Haar op nie.	",
"	3 Want so sê my Meester JaHWeH: Die stad wat met duisend uitgetrek het, hou honderd oor; en die wat met honderd uitgetrek het, hou tien oor vir die huis van JisraEl.	",
"	4 Want so sê JaHWeH aan die huis van JisraEl: Soek My, dan sal julle lewe!	",
"	5 Maar soek BetEl nie, en kom nie na Gilgal nie en trek nie deur na Berséba nie. Want Gilgal sal gewis in ballingskap gaan, en BetEl sal tot niks word nie.	",
"	6 Soek JaHWeH, dan sal julle lewe, sodat Hy nie teen die huis van JôWsef uitbreek soos ’n Vuur wat verteer sonder dat iemand dit vir BetEl kan blus nie.	",
"	7 Julle verander die Reg in Alsem en smyt die Geregtigheid teen die Aarde!	",
"	8 Hy wat die Sewe-ster en die Oríon gemaak het en die Doodskaduwee in môrelig verander en die dag tot nag verduister, wat die waters van die see roep en hom uitgiet oor die oppervlakte van die Aarde – JaHWeH [is] Sy Naam!	",
"	9 Hy wat verwoesting laat aanblits oor die sterke, en verwoesting kom oor die vesting!	",
"	10 Hulle haat die man wat in die poort die Reg handhaaf, en hulle het ’n afsku van hom wat rassuiwerheid verkondig.	",
"	11 Daarom, omdat julle die arm man vertrap en van hom ’n heffing van koring neem, het julle huise van gekapte klippe gebou, maar julle sal nie daarin woon nie; julle het pragtige Wingerde geplant, maar julle sal die wyn daarvan nie drink nie.	",
"	12 Want Ek weet dat julle opstandigheid menigvuldig en julle oortredinge sonder getal is, julle wat die vyande is van die regverdige, wat omkoopgeld aanneem en die behoeftiges wegstoot in die poort.	",
"	13 Daarom swyg die verstandige in so ’n tyd, want dit is ’n tyd van besoedeling.	",
"	14 Soek wat suiwer is, en nie wat besoedel is nie, sodat julle kan lewe en JaHWeH, die Elohey van die skeppings-leërmag, só met julle kan wees soos julle sê.	",
"	15 Julle moet haat wat besoedel is en liefhê wat suiwer is en handhaaf die Reg in die poort - miskien sal JaHWeH, die Elohey van die skeppings-leërmag, Hom ontferm oor die oorblyfsel van JôWsef.	",
"	16 Daarom, so sê JaHWeH, die Elohey van die skeppings-leërmag, my Meester: Op al die pleine weeklag! En op al die strate sal hulle sê: Ag, ag! En hulle sal na die landbouer roep om te treur, en te weeklaag na die wat verstaan om treurliedere te sing.	",
"	17 Ook sal daar in al die Wingerde weeklag wees wanneer Ek in jou midde deurtrek, sê JaHWeH.	",
"	18 Wee die wat na die dag van JaHWeH verlang! Wat sal tog die dag van JaHWeH vir julle wees? Dit sal Duisternis wees en geen Lig nie.	",
"	19 Soos wanneer iemand vlug vir ’n leeu, maar ’n beer loop hom raak; of hy kom in die huis en leun met sy hand teen die muur, en ’n slang byt hom!	",
		
		
"	20 IS die Dag van JaHWeH nie Duisternis en geen Lig nie, ja, pikdonker sonder ’n ligstraal?	",
"	21 Ek haat, Ek versmaad julle feeste en het geen welgevalle aan julle feestye nie.	",
"	22 Want al bring julle vir My brandoffers saam met julle spysbydraes, Ek het daar geen welbehae in nie, en die vergoeding van julle vetgemaakte kalwers sien Ek nie met welgevalle aan nie.	",
"	23 Verwyder van My die geraas van jou liedere! En na die geluid van jou harpe wil Ek nie luister nie.	",
"	24 Maar laat die Reg aanrol soos watergolwe, en Geregtigheid soos ’n standhoudende stroom.	",
"	25 Het julle aan My slagdiere en spysbydraes gebring veertig jaar lank in die wildernis, o huis van JisraEl?	",
"	26 Ja julle het die takskuiling van julle koning gedra, en Kewan3, julle Ster, julle god, die afbeelding wat julle vir julself gemaak het?	",
"	27 Daarom sal Ek julle anderkant Damaskus in ballingskap wegvoer, sê JaHWeH wie se Naam Elohey van die skeppings-leërmag is.	",

]
},
{
book: 'Amos',
chapter: '6',
content: [
	
"	1 WEE die geruste in Sion en die sorgelose op die berg van Samaría, die aangestelde eerstelinge onder die nasies, na wie die huis van JisraEl kom!	",
"	2 Marsjeer deur na Kalne en kyk, en gaan dan na Hamat, die groot versamelpunt van wraak, en marsjeer dan af na Gat van die Filistyne! Is julle beter af as hierdie koninkryke? Of is hulle grondgebied groter as julle grondgebied? -	",
"	3 julle wat die dag van besoedeling wil uitstel, wat die setel van geweld laat nader skuiwe!	",
"	4 Wat op hul beddens van ivoor lê, wat kommerloos strek op hulle rusbanke, wat die gras van die weide vir die kleinvee en die kalwers uit die midde van die stal eet!	",
"	5 Wat dreunsang by die mond van die harp soos Dawid, [wat] vir hulself sanginstrumente prakseer.	",
"	6 Wat wyn drink uit sprinkelflesse en hulleself salf met die beste olies, maar hulle nie oor die verbreking van JôWsef bekommer nie.	",
"	7 Daarom sal hulle nou op die voorpunt van die ballinge in ballingskap gaan, en die geskreeu van hulle wat sorgloos gehandel het, sal weg wees.	",
"	8 My Meester JaHWeH het by Sy siel gesweer, spreek JaHWeH die Elohey van die skeppings-leërmag: Ek het ’n afsku van die trotsheid van Jakob en haat sy paleise; daarom lewer Ek die Stad en haar volheid oor.	",
"	9 En as daar tien man in een huis oorgebly het, sal hulle sterwe.	",
"	10 Die geliefde van die een wat verbrand het, sal die Bene(oorskot) uit die huis dra, en hy sal aan die een wat in die agterste vertrekke van die huis is, sê: Is daar nog iemand by jou? En die sal antwoord: Geen – dan sal hy(die eerste) sê: Bly stil, want ons mag die Naam van JaHWeH nie noem nie!	",
"	11 Want kyk, JaHWeH gee bevel, en Hy sal die groot huis slaan tot ’n puinhoop en die klein huis tot splinters.	",
"	12 Sal perde draf op rotse, of kan ’n [persoon] met osse [daarop] ploeg? - dat julle die Reg in gif verander en die vrugte van Geregtigheid in Alsem.	",
"	13 Julle wat bly is oor ’n nietige ding, wat sê: Het ons nie deur ons eie krag horings gekry nie?	",
"	14 Want kyk, Ek gaan teen julle, o huis van JisraEl, ’n nasie opwek, openbaar JaHWeH, die Elohey van die skeppings-leërmag, en hulle sal julle verdruk van die ingang na Hamat tot by die Vallei4 van die Grasvlakte.	",

]
},
{
book: 'Amos',
chapter: '7',
content: [
"   1 DIT het my Meester JaHWeH my laat sien - kyk, Hy het sprinkane geformeer toe die na-gras begin uitspruit het; en kyk, dit was die na-gras nadat die snysels van die koning af was.	",
"	2 En toe hulle al die gewasse van die Aarde afgeëet het, sê ek: My Meester JaHWeH, vergeef tog! Hoe sal Jakob staande bly? want hy is klein.	",
"	3 Toe het JaHWeH berou gekry oor hierdie saak. Dit sal nie gebeur nie, het JaHWeH gesê.	",
"	4 Dit het my Meester JaHWeH my laat sien - kyk, my Meester JaHWeH roep om ’n regstryd te voer deur Vuur, en Hy het die groot Afgrond verteer en sou die akkerland verteer het.	",
"	5 Toe sê ek: My Meester JaHWeH, hou tog op! Hoe sal Jakob staande bly? want hy is klein.	",
"	6 JaHWeH het berou gekry oor hierdie saak. Dit sal ook nie gebeur nie, het my Meester JaHWeH gesê.	",
"	7 Dit het Hy my laat sien - kyk, my Meester het op ’n loodregte muur gestaan, en daar was ’n skietlood in Sy Hand.	",
"	8 Toe sê JaHWeH vir my: Wat sien jy, Amos? En ek het geantwoord: ’n Skietlood. Daarop sê my Meester: Kyk, Ek gaan ’n skietlood aanlê in die midde van My volk JisraEl. Ek sal hom verder nie meer verbygaan nie.	",
"	9 En die Hoogtes van Isak sal verwoes word, en die Apartheidsplekke van JisraEl sal puinhope wees, en teen die huis van Jeróbeam sal Ek met die swaard optree.	",
		
		
"	10 TOE het AmátsJaH, die priester van BetEl, Jeróbeam, koning van JisraEl, laat weet: Amos het ’n sameswering gesmee teen u midde-in die huis van JisraEl; die Aarde sal haarself onder al sy woorde nie kan uithou nie.	",
"	11 Want so het Amos gesê: Jeróbeam sal deur die swaard sterwe, en JisraEl sal sekerlik uit sy Adamah [die adamiet se Aarde] in ballingskap gaan.	",
"	12 Toe sê AmátsJaH vir Amos: Gaan weg, siener, vlug na die Aarde van JeHûWdah en eet daar brood en profeteer daar!	",
"	13 Maar in BetEl mag jy verder nie meer profeteer nie, want hy is die koning se Apartheidsplek en hy is die koninkryk se huis.	",
"	14 Toe het Amos geantwoord en aan AmátsJaH gesê: Ek was geen profeet en ook geen profeteseun nie; maar ek was ’n veewagter en kweker van wildevyebome.	",
"	15 Maar JaHWeH het my agter die kleinvee weggeneem, en JaHWeH het aan my gesê: Gaan heen, profeteer teen My volk JisraEl.	",
"	16 Luister dan nou na die Woord van JaHWeH! Jy sê: Jy mag nie teen JisraEl profeteer nie, en jy mag [geen woorde] laat druppel teen die huis van Isak nie.	",
"	17 Daarom, so sê JaHWeH: Jou vrou sal in die Stad hoereer, en jou seuns sowel as jou dogters sal deur die swaard val, en jou Adamah[adamiet se Aarde] met die meetsnoer verdeel word, en; jy self sal in ’n besoedelde Adamah [die adamiet se Aarde] sterwe, en JisraEl sekerlik in ballingskap uit sy Adamah [die adamiet se Aarde] gaan.	",

]
},
{
book: 'Amos',
chapter: '8',
content: [
		
"	1 DÍT het my Meester JaHWeH my laat sien - kyk, daar was ’n mandjie met somervrugte.	",
"	2 En Hy sê: Wat sien jy, Amos? En ek antwoord: ’n Mandjie met somervrugte. Toe sê JaHWeH vir my: Die einde het vir My volk JisraEl gekom; Ek sal hom verder nie meer verbygaan nie.	",
"	3 En die liedere van die Tempel sal in dié dag weeklaag, spreek my Meester JaHWeH: ’n menigte lyke; hulle gooi dit oral neer. Stilte!	",
"	4 Hoor dit, julle wat die behoeftige vertrap en [daarop uit is] om die ootmoediges van die Aarde uit te roei,	",
"	5 deur te sê: Wanneer is die maandsvernuwing verby, sodat ons koring kan verkoop, en die Sabbat, sodat ons die graan[skuur] kan oopsluit - om die efa te verklein en die sikkel te vergroot en bedrieglik te handel met ’n valse weegskaal;	",
"	6 om die armes vir geld te koop en die behoeftige vir ’n paar skoene; ook die afval van die koring sal ons verkoop.	",
"	7 JaHWeH het gesweer by die HOOGHEID van Jakob: Gewis, Ek sal in ewigheid nie een van hulle werke vergeet nie.	",
"	8 Moet hieroor die Aarde nie bewe en almal [wat] in haar woon nie treur nie? Ja, sy sal oprys alles [van] haar soos die Nyl en onstuimig opkook en wegsak soos weerlig van Egipte.	",
"	9 En in dié dag, spreek my Meester JaHWeH, laat Ek die son op die middag ondergaan en vir die Aarde die Lig duister word terwyl dit nog dag is.	",
"	10 En Ek verander julle feeste in rou en al julle liedere in klaagsang, en Ek bring op alle lendene ’n roukleed en op alle hoofde kaalheid. En Ek maak dit soos by die rou oor ’n enigste kind en die einde daarvan soos ’n bittere dag.	",
"	11 Kyk, daar kom dae, spreek my Meester JaHWeH, dat Ek ’n honger in die Aarde stuur, nie ’n honger na brood nie en nie ’n dors na water nie, maar om die Woord van JaHWeH te hoor.	",
"	12 En hulle sal swerwe van see tot see en rondslinger van Noord na Oos, om na die Woord van JaHWeH te soek, maar hulle sal Hom nie vind nie.	",
"	13 In dié dag sal die mooi maagde en die jongmanne van dors beswyk-	",
"	14 hulle wat sweer by die skuld van Samaría, en ook sê: So waar as jou Elohey leef, o Dan! en: So waar as die weg van Berséba leef! En hulle sal val en nie weer opstaan nie.	",

]
},
{
book: 'Amos',
chapter: '9',
content: [
		
"	1 EK het my Meester op die altaar sien staan, en Hy het gesê: Slaan die kapiteel [van die pilaar], sodat die drumpels bewe; laat die altaar op almal val! En Ek sal die wat van hulle oorbly, met die swaard ombring: die vlugteling uit hulle sal nie ontsnap nie, en geen vrygeraakte onder hulle homself red nie.	",
"	2 Al dring hulle deur na die Doderyk/Sheol, My Hand sal hulle daaruit haal; en al klim hulle op na die Hemele, Ek sal hulle van daar laat neerdaal.	",
"	3 En al steek hulle hul weg op die top van Karmel, Ek sal hulle daar opspoor en weghaal; en al verberg hulle hul voor My Oë op die bodem van die see, dan sal Ek Nagash ontbied om hulle te byt.	",
"	4 En al gaan hulle as gevangenes voor hulle vyande uit, Ek sal van daar die swaard ontbied om hulle dood te maak; en Ek sal My Oog op hulle rig om te besoedel en nie om te suiwer nie.	",
"	5 Ja, dit is my Meester JaHWeH van die skeppings-leërmag wat die Aarde aanraak, sodat sy smelt en almal treur wat in haar woon; en sy sal in haar geheel oprys soos die Nyl en wegsak soos die rivier van Egipte.	",
"	6 Hy wat Sy trappe in die Hemele bou en Sy koorde op die Aarde vestig, wat die waters van die see roep en hom uitgiet oor die aangesig van die Aarde, JaHWeH [is] Sy Naam!	",
"	7 Is julle nie vir My soos die kinders van kuwshiete(swartes) nie, o kinders van JisraEl? spreek JaHWeH. Het Ek JisraEl nie laat optrek uit die Aarde van Egipte en die Filistyne uit Kaftor en die Arameërs uit Kir nie?	",
"	8 Kyk, die oë van my Meester JaHWeH is gerig teen die wettelose koninkryk, en Ek sal haar van die aangesig van die Adamah[adamiet se Aarde] verdelg; maar Ek sal die huis van Jakob nie heeltemal verdelg nie, spreek JaHWeH.	",
"	9 Want kyk, Ek gee bevel en sal die huis van JisraEl onder al die nasies skud soos in ’n sif geskud word, maar daar sal geen korrel op die Aarde val nie.	",
"	10 Al die oortreders van My volk sal deur die swaard sterwe, die wat sê: Die besoedeling sal ons nie bereik en ons nie ontmoet nie.	",
"	11 In dié dag sal Ek die vervalle beskutting/takskuiling van Dawid weer oprig, en Ek sal sy breukplekke toemaak en sy puinhope herstel, en Ek sal hom opbou soos in die ou tyd;	",
"	12 sodat hulle in besit kan neem die oorblyfsel van Edom en al die nasies oor wie My Naam uitgeroep is, spreek JaHWeH wat dit doen.	",
"	13 Kyk, die dae kom, spreek JaHWeH, dat die ploeër die maaier inhaal, en die druiwetrapper die saadsaaier; en dat die berge van soetwyn sal drup, en al die heuwels daarvan oorvloei sal wees.	",
"	14 En Ek sal die lot van My volk JisraEl verander, en hulle sal die verwoeste stede bou en bewoon, ook sal hulle Wingerde plant en die wyn daarvan drink, en tuine aanlê en die vrugte daarvan eet.	",
"	15 En Ek sal hulle plant in hul Adamah [die adamiet se Aarde], en hulle sal nie meer uitgeruk word uit hul Adamah wat Ek hulle gegee het nie, sê JaHWeH jou Elohey.	",

]
},
{
book: 'Amos',
chapter: '10',
content: [

]
},
{
book: 'Amos',
chapter: '11',
content: [

]
},
{
book: 'Amos',
chapter: '12',
content: [

]
},
{
book: 'Amos',
chapter: '13',
content: [

]
},
{
book: 'Amos',
chapter: '14',
content: [

]
},
{
book: 'Amos',
chapter: '15',
content: [

]
},
{
book: 'Amos',
chapter: '16',
content: [

]
},
{
book: 'Amos',
chapter: '17',
content: [

]
},
{
book: 'Amos',
chapter: '18',
content: [

]
},
{
book: 'Amos',
chapter: '19',
content: [

]
},
{
book: 'Amos',
chapter: '20',
content: [

]
},
{
book: 'Amos',
chapter: '21',
content: [

]
},
{
book: 'Amos',
chapter: '22',
content: [

]
},
{
book: 'Amos',
chapter: '23',
content: [

]
},
{
book: 'Amos',
chapter: '24',
content: [

]
},
{
book: 'Amos',
chapter: '25',
content: [

]
},
{
book: 'Amos',
chapter: '26',
content: [

]
},
{
book: 'Amos',
chapter: '27',
content: [

]
},
{
book: 'Amos',
chapter: '28',
content: [

]
},
{
book: 'Amos',
chapter: '29',
content: [

]
},
{
book: 'Amos',
chapter: '30',
content: [

]
},
{
book: 'Amos',
chapter: '31',
content: [

]
},
{
book: 'Amos',
chapter: '32',
content: [

]
},
{
book: 'Amos',
chapter: '33',
content: [

]
},


];
