const jakobusChapters = [

{
book: 'Jakobus',
chapter: '1',
content: [

"	1 IN die geskiedenisse van die twaalf stamme van JisraEl was daar ene JôWjakim, ‘n baie ryk man.	",
"	1a en hy was gewoond om sy gawes dubbeld nader te bring en het gesê:	",
"	1b Wat uit my oorvloed is, sal gaan vir die hele volk, en wat vir my vergifnis van die oortredinge is, sal vir JaHWeH wees tot versoening vir my.	",
"	2 Toe het die groot dag van JaHWeH aangebreek en die kinders van JisraEl het hul gawes kom aanbied.	",
"	2a En Ruben het teen hom opgetree en gesê: Jy mag nie eerste jou gawes aanbied nie, aangesien jy geen nageslag in JisraEl verwek het nie.	",
"	3 En ek was baie bedroef en het na [die geslagsregisters van] die twaalf stamme van die volk gegaan en gesê:	",
"	3a Ek sal nakyk in die twaalf stamme [se registers] of ek die enigste is wat geen nageslag in JisraEl verwek het nie.	",
"	3b En hy het ondersoek ingestel en gevind dat alle regverdiges ‘n nageslag in JisraEl verwek het.	",
"	3c En hy het Abraham, die aartsvader, in herinnering gebring, dat Elohim hom in sy laaste dae ‘n seun geskenk het, naamlik Isak.	",
"	4 En JôWjakim was baie bedroef en het hom nie aan sy vrou vertoon nie, maar hom na die wildernis begewe en daar sy tent opgeslaan.	",
"	4a En hy het veertig dae en veertig nagte gevas en by homself gesê: Ek sal nie afgaan óf vir spyse óf vir drank totdat JaHWeH my Elohey my besoek het nie, en my gebed sal vir my spyse en drank wees.	",

]
},
{
book: 'Jakobus',
chapter: '2',
content: [
		
"	1 TOE het sy vrou Anna tweërlei klaaglied en tweërlei treursang aangehef en gesê: Ek wil my weduweeskap betreur … ek wil my kinderloosheid betreur!	",
"	2 En die groot dag van JaHWeH het aangebreek en Judit, haar diensmaagd, sê:	",
"	2a Hoe lank buig u u siel terneer? Kyk, die groot dag van JaHWeH het aangebreek en dan mag u nie treur nie,	",
"	2b maar neem hierdie krans wat my werkgeefster my gegee het; ek mag haar nie aansit nie, omdat ek maar ‘n diensmaagd is en sy ‘n koninklike voorkoms het. [Opregte 15:31-33 ; Spreuke 4:9]	",
"	3 En Anna sê: Gaan weg van my! Kyk, ek het niks gedoen nie, en JaHWeH het my grootliks verneder; miskien het ‘n slegte mens haar vir jou gegee en het jy gekom om my ‘n deelgenoot in jou oortreding te maak.	",
"	3a En Judit antwoord: Waarom sal ék u vervloek aangesien JaHWeH u moederskoot toegesluit het om u geen vrug te gee in JisraEl nie!  [Génesis 21:9]	",
"	4 En Anna was diep bedroef en het haar rouklere afgelê en haar hoof gewas en haar bruidsklere aangetrek, en omstreeks die negende uur het sy afgegaan na die tuin om daar te wandel.	",
"	4a En sy het ‘n lourierboom gesien en daaronder gaan sit en tot JaHWeH gebid en gesê: O Elohey van ons vaders, seën my en hoor my gebed net soos u die moederskoot van Sarah geseën en haar ‘n seun Isak gegee het.	",

]
},
{
book: 'Jakobus',
chapter: '3',
content: [
		
"	1 EN terwyl sy opkyk na die Hemele, sien sy ‘n mossienes in die lourierboom. En sy het by haarself ‘n klaaglied aangehef en gesê: Wee my, wie het my verwek? En watter moederskoot het my voortgebring?	",
"	3a Want ek het ‘n vloek geword voor die kinders van JisraEl, en ek is gesmaad, en hulle het my weggespot uit die Huis van JaHWeH!	",
"	2 Wee my, aan wie het ek gelyk geword? Nie aan die voëls van die Hemele het ek gelyk geword nie, want selfs die voëls van die Hemele is vrugbaar voor U, o JaHWeH!	",
"	2a Wee my, aan wie het ek gelyk geword? Nie aan die diere van die Aarde het ek gelyk geword nie, want selfs die diere van die Aarde is vrugbaar voor U, o JaHWeH!	",
"	3 Wee my, aan wie het ek gelyk geword? Nie aan hierdie waters het ek gelyk geword nie, want selfs hierdie waters is vrugbaar voor U, o JaHWeH!	",
"	3a Wee my, aan wie het ek gelyk geword? Nie aan hierdie Aarde het ek gelyk geword nie, want selfs die Aarde bring op tyd haar vrugte voort, en loof U o JaHWeH!	",

]
},
{
book: 'Jakobus',
chapter: '4',
content: [
	
"	1 EN kyk, daar staan ‘n Boodskapper van JaHWeH voor haar en sê: Anna, Anna, JaHWeH het jou smeekgebed gehoor, en jy sal ontvang en baar en oor jou saad sal in die hele wêreld gespreek word.	",
"	1a En Anna sê: So waaragtig as JaHWeH, my Elohey, leef, as ek baar, of dit manlik of vroulik is, ek sal dit bring as ‘n gawe aan JaHWeH, my Elohey, en sal Hom dien al die dae van my lewe. [Lukas 2:36-37]	",
"	2 En kyk, daar kom twee boodskappers wat vir haar sê: Kyk, JôWjakim, jou man, kom met sy kuddes.	",
"	2a Want ‘n Boodskapper van JaHWeH het tot hom afgekom en gesê: JôWjakim, JôWjakim, JaHWeH, jou Elohey het jou gebed gehoor; gaan dan af van hier, want kyk, jou vrou Anna sal ontvang.	",
"	3 En JôWjakim het afgedaal en sy herders geroep en gesê: Bring vir my hier tien lammers, raseg en sonder gebrek, en hulle sal wees vir JaHWeH my Elohey; en bring vir my twaalf jong kalwers, en hulle sal wees vir die priesters en die raad van die oudstes; en honderd bokke vir die hele volk.	",
"	4 En kyk, JôWjakim kom met sy kuddes, en Anna staan by die poort en sien JôWjakim kom, en sy hardloop en val hom om die hals en sê:	",
"	4a Nou weet ek dat JaHWeH my Elohey my grootliks geseën het, want kyk, die weduwee is geen weduwee meer nie en die kinderlose sal ontvang. En JôWjakim het die eerste dag in sy huis gerus.	",

]
},
{
book: 'Jakobus',
chapter: '5',
content: [
	
"	1 EN die volgende dag kom hy om sy gawes nader te bring en sê by homself: As JaHWeH my barmhartig is, sal die borstas van die priester dit aan my openbaar.	",
"	1a En JôWjakim het sy gawes aangebied en aandagtig gelet op die borstas van die priester toe hy opgaan na die altaar van JaHWeH, en hy het geen oortreding in homself gesien nie.	",
"	1b En JôWjakim sê: Nou weet ek dat JaHWeH my barmhartig is en al my oortredinge vergewe het. En hy het geregverdig uit die Huis van JaHWeH afgekom en na sy eie huis gegaan.	",
"	2 En haar maande is vervul en in die negende maand het Anna gebaar. En sy sê vir die vroedvrou: Wat het ek gebaar? En sy sê: ‘n Dogter!	",
"	2a Toe sê Anna: My siel verhef haar op hierdie dag! En sy het haar neergelê. En toe die dae verval is, het Anna haarself gesuiwer en die kind laat drink. En sy het haar Mirjam genoem.	",
		

]
},
{
book: 'Jakobus',
chapter: '6',
content: [
		
"	1 EN die kind het by die dag sterker geword en toe sy ses maande oud was, het haar moeder haar op die grond neergesit om te kyk of sy al kon staan, en sy het sewe stappe in die rondte gedoen en na haar skoot teruggekom.	",
"	1a En sy neem haar op en sê: So waaragtig as JaHWeH my Elohey leef, sal jy hierdie Aarde nie meer betree vóór ek jou na die Huis van JaHWeH bring nie.	",
"	1b En sy het ‘n aparte ruimte in haar slaapvertrek afgeskort en nie toegelaat dat sy iets gemeens of besoedelds inneem nie. En sy het die onbesoedelde dogters van die Hebreërs geroep en hulle het haar opgepas.	",
"	2 En toe sy ‘n jaar oud was, het JôWjakim ‘n groot feesmaal aangerig en hy het die priesters en die skrywers en die raad van oudstes en die hele volk van JisraEl uitgenooi.	",
"	2a En JôWjakim het die kind na die priesters gebring, en hulle het haar geseën en gesê: Elohey van ons vaders, seën hierdie kind en gee haar ‘n groot naam vir altyd onder alle geslagte.	",
"	2b En die hele volk het gesê: Mag dit so wees! Mag dit so wees! Amein!	",
"	2c En hulle bring haar toe na die hoëpriesters, en hulle seën haar en sê: O Elohey uit die hoogte, sien neer op hierdie kind en seën haar met die uiterste seën, waarná daar geen seën meer kom nie.	",
"	3 En haar moeder het haar geneem na die aparte ruimte van haar slaapvertrek en haar die bors gegee. En Anna het ‘n lied voor die Aangesig van JaHWeH haar Elohey gemaak en gesê:	",
"	3a Ek sal ‘n lied sing voor die Aangesig van JaHWeH my Elohey,	",
"	3b want Hy het my besoek en van my die smaad van my vyande weggeneem;	",
"	3c en JaHWeH het my gegee ‘n vrug van Sy Geregtigheid, eenvoudig en baie oorvloedig voor Hom.	",
"	3d Wie vertel dit aan die seuns van Ruben dat Anna laat drink? [Genèsis 31:7]	",
"	3e Hoor, hoor, twaalf stamme van JisraEl: Anna laat drink!	",
"	3f En sy lê haar te ruste in die aparte ruimte van haar slaapvertrek en gaan uit en bedien hulle. En toe die maaltyd beëindig was, het hulle verheug afgegaan en die Elohey van JisraEl geprys.	",

]
},
{
book: 'Jakobus',
chapter: '7',
content: [
	
"	1 EN aan die kind is haar maande toegevoeg.	",
"	1a En die kind het twee jaar oud geword en JôWjakim sê: Laat ons haar na die Tempel van JaHWeH bring, dat ons die geloftes kan betaal wat ons beloof het voordat JaHWeH na ons stuur en ons gawe onaanneemlik word.	",
"	1b Maar Anna sê: Laat ons wag tot die derde jaar sodat die kind nie na haar vader en moeder verlang nie.	",
"	1c Toe sê JôWjakim. Laat ons dan maar wag!	",
"	2 En toe die kind drie jaar oud geword het, sê JôWjakim: Roep die onbesoedelde dogters van die Hebreërs en laat elkeen ‘n lamp neem, en laat dié aan die brand wees sodat die kind nie omdraai en haar hart weggelok word uit die Huis van JaHWeH nie.	",
"	2a En so het hulle gedoen totdat hulle opgegaan het na die Huis van JaHWeH. En die priester het haar ontvang en gesoen en geseën en gesê: JaHWeH het jou naam groot gemaak onder alle geslagte, in jou sal JaHWeH in die laaste dae Sy Lossing openbaar aan die kinders van JisraEl.	",
"	3 En hy het haar laat sit op die derde trap van die altaar. En JaHWeH het grasie oor haar uitgestort en sy het gedans op haar voete, en die hele huis van JisraEl het haar liefgehad.	",

]
},
{
book: 'Jakobus',
chapter: '8',
content: [
	
"	1 EN haar ouers het afgekom en hulle verwonder en JaHWeH hulle Elohey geprys aangesien die kind haar nie agtertoe omgedraai het na hulle nie.	",
"	1a En Mirjam was in die Tempel van JaHWeH soos ‘n pikkende duifie en sy het voedsel ontvang uit die hand van ‘n Boodskapper.	",
"	2 Toe sy nou twaalf jaar oud geword het, het die priesters raad gehou en gesê: Kyk, Mirjam het twaalf jaar geword in die Huis van JaHWeH, wat sal ons nou met haar doen sodat sy nie die Apartheid van JaHWeH besoedel nie?	",
"	2a En hulle sê vir die hoëpriester: U staan voor die altaar van JaHWeH, gaan in en bid oor haar en wat JaHWeH ook al aan u openbaar, laat ons dit doen.	",
"	3 En die hoëpriester neem die [kleed met die] twaalf klokkies, tree die Apartheid van die Aparthede binne en bid oor haar.	",
"	3a En kyk, ‘n Boodskapper van JaHWeH verskyn en sê vir hom: ZekarJaH, ZekarJaH, gaan uit en maak die wewenaars van die volk bymekaar en laat elkeen van hulle ‘n staf meebring, en aan wie JaHWeH ‘n teken sal gee, sý vrou sal sy wees.	",
"	3b En die boodskappers het oor die Aarde rondom JeHûWdah uitgegaan, en die Ramshoring van JaHWeH het geklink en almal het daarheen geloop.	",

]
},
{
book: 'Jakobus',
chapter: '9',
content: [
	
"	1 EN JôWsef het sy byl neergegooi en uitgegaan om hulle te ontmoet.	",
"	1a En toe hulle saam vergader was, het hulle na die hoëpriester gegaan en hul stawwe saamgeneem.	",
"	1b Hy neem toe almal se stawwe en gaan in die Tempel en bid. En nadat hy sy gebed beëindig het, neem hy die stawwe en gaan na buite en gee dit aan hulle terug, en daar was geen enkele teken aan hulle nie.	",
"	1c JôWsef neem egter die laaste Staf in ontvangs, en kyk, ‘n duif kom uit die Staf te voorskyn en vlieg op die hoof van JôWsef.	",
"	1d En die priester sê vir JôWsef: Jy is deur die lot aangewys om die maagd van JaHWeH te neem en onder jou beskerming te hou.	",
"	2 Maar JôWsef het geweier en gesê: Ek het seuns en ek is ‘n ou man, maar sy is ‘n jong meisie; ek vrees dat ek uitgelag sal word deur die kinders van JisraEl.	",
"	2a En die priester sê vir JôWsef: Vrees JaHWeH, jou Elohey, en dink aan wat Elohim gedoen het aan Datan, Abiram en Korag, hoe die Aarde oopgeskeur het en hulle verslind is weens hul teëspraak. Vrees dus, JôWsef, dat dit nie jou huis oorkom nie.	",
"	3 En JôWsef het bevrees geword en haar onder sy bewaring geneem.	",
"	3a En JôWsef het vir Mirjam gesê: Kyk, ek het jou ontvang uit die Huis van JaHWeH en nou laat ek jou in my huis agter, en ek gaan weg om my bouery verder uit te voer en dan kom ek weer na jou toe. JaHWeH sal oor jou die wag hou!	",

]
},
{
book: 'Jakobus',
chapter: '10',
content: [
		
"	1 EN die priesters het beraadslaag en gesê: Laat ons ‘n voorhangsel maak vir die Tempel van JaHWeH.	",
"	1a En die priester sê: Roep vir my die onbesoedelde maagde uit die geslag van Dawid. En die dienaars het vertrek en gesoek en sewe maagde gevind.  [Exodus 35:35 ; 39:25 ; Henog 48:1]	",
"	1b En die priesters het gedink aan die meisie Mirjam dat sy uit die geslag van Dawid was en onbesoedeld voor Elohim. En die dienaars het gegaan en haar gehaal.	",
"	2 En hulle bring hulle in die Huis van JaHWeH. En die priester sê: Werp vir my die lot, wie die goud sal spin en die wit, en die fyn linne en die sy en die koningsblou en die skarlakenrooi en die egte koningsblou.	",
"	2a En die lot vir die egte koningsblou en die skarlakenrooi het op Mirjam geval, en sy het dit geneem en huis toe gegaan. Mirjam het toe die skarlaken geneem en begin spin.	",

]
},
{
book: 'Jakobus',
chapter: '11',
content: [
	
"	1 EN sy neem die kruik en gaan om haar met water te vul. En kyk, daar sê ‘n Stem: Wees gegroet, goedgunstige een! JaHWeH is met jou; geseënd is jy onder die vroue!	",
"	1a En sy kyk rond, na regs en na links, om te sien waar die Stem vandaan gekom het. En met bewing het sy weer na haar huis gegaan en die kruik weggesit, en sy het die koningsblou geneem, op haar stoel gaan sit en haar gespin.	",
"	2 En kyk, ‘n Boodskapper van JaHWeH staan voor haar en sê: Moenie vrees nie, Mirjam, want jy het Guns gevind by JaHWeH van alle dinge, en uit SY Woord sal jy swanger word.	",
"	2a En toe sy dit hoor, het sy by haarself getwyfel en gesê: Ai, sal ek swanger word van JaHWeH, die lewende El, en sal ek soos alle vrouens baar?	",
"	3 En die Boodskapper van JaHWeH sê: Nie só nie, Mirjam, want die Gees [Boodskap van Jakobus 14:2] van JaHWeH sal jou oorskadu, daarom ook sal die Aparte Een wat uit jou gebore word, Seun van die Hoogste El genoem word.	",
"	3a En jy sal Sy Naam JaHWèshua noem, want Hy sal Sy volk red van hul oortredinge. En Mirjam sê: Kyk, die diensmaagd van JaHWeH is voor Sy aangesig, laat dit met my gaan volgens U woord.  [Ode 19]	",

]
},
{
book: 'Jakobus',
chapter: '12',
content: [
	
"	1 EN sy het die koningsblou en die skarlaken klaar gemaak en dit na die priester gebring.	",
"	1a En die priester het haar geseën en gesê: Mirjam, JaHWeH jou Elohey het jou naam groot gemaak en jy sal geseënd wees onder al die nasies van die Aarde! [Génesis 18:18]	",
"	2 En met vreugde het Mirjam na haar bloedverwant EliSheba gegaan en aan die deur geklop. En toe EliSheba dit hoor, gooi sy die skarlaken neer en hardloop na die deur, en toe sy dit oopmaak en Mirjam sien, het sy haar geseën en gesê:	",
"	2a Vanwaar het dit my oorgekom dat die moeder van my Meester na my toe kom? Want kyk, wat in my is, het opgespring en jou geseën.	",
"	2b Maar Mirjam het die geheimenisse vergeet waaroor die Hoofboodskapper GabriEl tot haar gespreek het, en sy het opgekyk na die Hemele en gesê: Wie is ek, JaHWeH, dat al die geslagte van die Aarde my seën?	",
"	3 En sy het drie maande by EliSheba gebly. Van dag tot dag het haar buik egter in omvang toegeneem.	",
"	3a Toe het sy bevrees geword en huis toe gegaan en haarself verberg vir die kinders van JisraEl. Mirjam was sestien jaar oud toe hierdie geheimenisse plaasgevind het.	",

]
},
{
book: 'Jakobus',
chapter: '13',
content: [
	
"	1 EN sy was in haar sesde maand en kyk, JôWsef keer terug van sy bouwerke en toe hy sy huis binnetree, vind hy haar ver heen in swangerskap.	",
"	1a En hy slaan homself op sy aangesig en werp homself neer op die Aarde in roukleed en ween bitterlik en sê: Met hoe ‘n gesig sal ek opkyk na JaHWeH my Elohey? En wat sal ek bid ten opsigte van daardie meisie? Want ek het haar as ‘n maagd ontvang uit die Tempel van JaHWeH en ek het haar nie bewaak nie.	",
"	1b Wie is hy wat my bedrieg het? Wie het hierdie slegte ding gedoen in my huis en hierdie maagd besoedel? Word die geskiedenis van Adam tog nie by my herhaal nie? Want soos Adam in die uur van sy gebed afwesig was en Nagash/slang gekom en Eva alleen aangetref en bedrieg het, so het dit my ook oorgekom.	",
"	2 En JôWsef het opgestaan van sy roukleed en Mirjam geroep en vir haar gesê: O jy, wat die voorwerp van Elohim se tere sorg was, waarom het jy dit gedoen en JaHWeH jou Elohey vergeet?	",
"	2a Waarom het jy jou siel verlaag, jy wat opgevoed is in die Apartheid deur apartes en voedsel ontvang het uit die hand van ‘n Boodskapper?	",
"	3 Maar sy het bitterlik geween en gesê: Ek is skoon en ken geen man nie.	",
"	3a En JôWsef sê vir haar: Vanwaar kom dit dan wat in jou skoot is?	",
"	3b En sy sê: So waaragtig as JaHWeH my Elohey leef, ek weet nie vanwaar dit tot my gekom het nie.	",

]
},
{
book: 'Jakobus',
chapter: '14',
content: [
	
"	1 EN JôWsef het bevrees geword en haar alleen gelaat. En hy het oorweeg wat hy met haar sou doen.	",
"	1a En JôWsef het [by homself] gesê: As ek haar oortreding verberg, dan sal ek bevind word as een wat stry teen die Wet van JaHWeH.	",
"	1b Maar as ek haar [oortreding] openbaar maak aan die kinders van JisraEl, dan vrees ek dat wat in haar is, miskien van ‘n Boodskapper afkomstig kan wees, en dan sal ek bevind word as een wat onskuldige bloed aan die doodstraf oorlewer.	",
"	1c Wat sal ek dan met haar doen? In die geheim sal ek haar van my laat weggaan. En die nag het hom oorval.	",
"	2 En kyk, ‘n Boodskapper van JaHWeH verskyn aan hom in ‘n droom en sê: Moenie vrees aangaande hierdie kind nie, want wat in haar is, is van die Gees van die Apartheid; en sy sal ‘n Seun baar en jy sal hom JaHWèshua noem, want Hy sal Sy volk van hul oortredinge verlos.	",
"	2a En JôWsef het opgestaan uit sy slaap en die Elohey van JisraEl geprys wat hom hierdie Barmhartigheid betoon het, en hy het oor haar gewaak.	",

]
},
{
book: 'Jakobus',
chapter: '15',
content: [
	
"	1 EN Annas, die skrywer, het na hom gekom en vir hom gesê; Waarom het jy nie in ons vergadering verskyn nie?	",
"	1a En JôWsef sê vir hom: Omdat ek moeg was van my reis en die eerste dag uitgerus het. En Annas draai hom om en merk dat Mirjam swanger is.	",
"	2 En hy het haastig na die priester gehardloop en vir hom gesê: JôWsef, vir wie jy ingestaan het [dat hy regverdig is], het swaar oortree. En die priester sê: Hoe so?	",
"	2a En hy sê: Die maagd wat hy uit die Huis van JaHWeH ontvang het, het hy besoedel en stilletjies met haar getrou, en hy het dit nie aan die kinders van JisraEl gesê nie.	",
"	2b En die priester antwoord en sê: Het JôWsef dit gedoen?	",
"	2c En Annas, die skrywer, sê: Stuur dienaars en julle sal vind dat die maagd swanger is.	",
"	2d En die dienaars het gegaan en dinge gevind soos hy gesê het en hulle het haar met JôWsef voor die gerig gebring.	",
"	3 En die priester sê: Mirjam, waarom het jy dit gedoen? En waarom het jy jou siel verlaag en JaHWeH jou Elohey vergeet? Jy wat opgevoed is in die Apartheid deur apartgesteldes en voedsel uit die hand van ‘n Boodskapper ontvang het, en die lofsange gehoor en voor Sy aangesig gedans het, waarom het jy dit gedoen?  [Spreuke 8:30-31]	",
"	3a En sy het bitterlik geween en gesê: So waaragtig as JaHWeH my Elohey leef, ek is skoon voor Hom en ek het geen man beken nie.	",
"	4 En die priester sê vir JôWsef: Waarom het jy dit gedoen?	",
"	4a En JôWsef antwoord: So waaragtig as JaHWeH leef, ek is skoon ten opsigte van haar.	",
"	4b En die priester sê: Gee geen valse getuienis nie, maar spreek die waarheid! Jy het met haar die huwelik voltrek en dit nie aan die kinders van JisraEl te kenne gegee nie, en jy het jou hoof nie onder die magtige Hand [van Elohim] gebuig sodat jou nageslag geseën sou word nie! En JôWsef het stilgebly.	",

]
},
{
book: 'Jakobus',
chapter: '16',
content: [
	
"	1 EN die priester sê: Gee terug die maagd wat jy uit die Huis van JaHWeH ontvang het.	",
"	1a En JôWsef het in trane uitgebars. En die priester sê: Ek sal jou die toetswater van JaHWeH laat drink en dit sal jou oortredinge voor jou oë openbaar maak. [Númeri 5:17‑28]	",
"	2 En die priester neem dit en laat JôWsef dit drink en stuur hom heen na die gebergte. En hy het gesond teruggekeer.	",
"	2a En hy het Mirjam ook laat drink en haar na die gebergte gestuur. En sy het gesond teruggekeer.	",
"	2b En die hele volk het hulle daaroor verwonder dat geen oortreding by hulle geblyk het nie.	",
"	3 En die priester sê: As JaHWeH julle oortredinge nie geopenbaar het nie, dan oordeel ek julle ook nie. En hy het hulle laat gaan.	",
"	3a En JôWsef het Mirjam saamgeneem en met blydskap na sy huis gegaan en die El van JisraEl geprys.	",

]
},
{
book: 'Jakobus',
chapter: '17',
content: [
	
"	1 EN ‘n bevel het uitgegaan van keiser Augustus dat almal wat in Betlehem in JeHûWdah behoort het, ingeskrywe moes word.	",
"	1a En JôWsef sê: Ek sal my seuns laat inskryf, maar hierdie meisie, wat sal ek met haar maak? Hoe sal ek haar laat inskryf? As my vrou? Maar ek is skaam! As my dogter? Maar al die kinders van JisraEl weet dat sy nie my dogter is nie. Die dag van JaHWeH self sal dit bewerk soos JaHWeH dit wil.	",
"	2 En hy het die eselin opgesaal en haar daarop laat sit, en sy seun het haar gelei en JôWsef het gevolg.	",
"	2a En hulle het tot op drie myl [van Betlehem] genader en JôWsef het hom omgedraai en gesien dat sy treurig was, en hy sê by homself: Miskien is dit wat in haar is wat haar terneerdruk.	",
"	2b En JôWsef draai hom weer om en hy sien haar lag. En hy sê vir haar: Mirjam, wat is dit dat ek jou gesig nou laggend en dan weer treurig sien?’	",
"	2c En Mirjam sê vir JôWsef: Omdat my oë twee volke sien; een wat ween en rouklaag en ‘n ander wat jubel en vreugde bedryf.  [Génesis 25:23]	",
"	3 En toe hulle halfpad kom, sê Mirjam vir hom: Tel my af van die eselin, want wat in my is, pers my omdat dit te voorskyn wil kom.	",
"	3a En hy het haar van die esel afgeneem en hy sê vir haar: Waarheen sal ek jou nou neem om jou skande te verberg? Want die plek is verlate!	",
		

]
},
{
book: 'Jakobus',
chapter: '18',
content: [

"	1 EN hy vind daar ‘n grot en bring haar daarin en laat sy seuns by haar, en hy het uitgegaan en ‘n vroedvrou in die omgewing van Betlehem gaan soek.	",
"	2 En ek, JôWsef, het rondgeloop, en ook nie rondgeloop nie. Ek kyk op in die lug en ek sien die lug verstar.	",
"	2a En ek kyk op na die hemelgewelf en ek sien hom stilstaan, en die voëls van die Hemele bewegingloos.	",
"	2b En ek kyk na die Aarde en ek sien ‘n voedselskottel staan en arbeiders wat daaromheen aansit, en hul hande was uitgesteek na die skottel; en hulle wat gekou het, het nie gekou nie; en hulle wat voedsel geneem het, het nie geneem nie; en hulle wat dit na hul mond gebring het, het dit nie na hul mond gebring nie.	",
"	2c En almal se aangesigte was na bo gerig.	",
"	2d En kyk, daar was skape wat voortgedryf is, en die skape het stilgestaan, en die herder het sy hand opgelig om hulle te slaan en sy hand het opgerig bly staan.	",
"	2e En ek kyk na die stromende rivier en ek sien die bekke van die bokkies op die water en tog drink hulle nie... En ineens het alle dinge weer hul natuurlike loop geneem.	",

]
},
{
book: 'Jakobus',
chapter: '19',
content: [
	
"	1 EN ek sien ‘n vrou afkom van die gebergte, en sy sê vir my: Man, waar gaan jy heen?	",
"	1a En ek sê: Ek soek ‘n Hebreeuse vroedvrou! En sy antwoord en sê vir my: Is jy uit JisraEl? En ek sê vir haar: Ja!	",
"	1b En sy sê: En wie is sy wat daar in die grot geboorte gee?	",
"	1c En ek sê: Sy wat aan my verloof is.	",
"	1d En sy sê vir my: Is sy nie jou vrou nie?	",
"	1e En ek sê vir haar: Dit is Mirjam wat in die Huis van JaHWeH opgevoed is en deur die lot aan my as vrou toegewys is, tog is sy nie my vrou nie, maar sy het ontvang van die Gees van die Apartheid.	",
"	1f En die vroedvrou sê vir hom: Is dit waar?	",
"	1g En JôWsef sê vir haar: Kom kyk! En die vroedvrou het met hom saamgegaan.	",
"	2 Hulle staan toe op die plek van die grot, en kyk, ‘n ligtende Wolkkolom oorskadu die grot.	",
"	2a En die vroedvrou sê: Vandag is my siel groot gemaak omdat my oë wonderlike dinge aanskou het, want Lossing is vir JisraEl gebore.	",
"	2b En meteens trek die Wolkkolom weg van die grot en daar verskyn ‘n groot Lig in die grot, sodat hul oë haar nie kon verdra nie.	",
"	2c En geleidelik het daardie Lig verminder totdat die Kindjie te voorskyn kom en die bors van Sy moeder Mirjam neem.	",
"	2d En die vroedvrou roep uit en sê: Vandag is dit ‘n groot dag vir my deurdat ek hierdie ongewone skouspel gesien het.	",
"	3 En toe die vroedvrou uit die grot gaan, ontmoet Salóme haar. En sy sê vir haar: Salóme, Salóme, ek het ‘n buitengewone skouspel om aan jou te vertel.	",
"	3a ‘n Maagd het geboorte gegee ‑ iets wat haar natuur tog nie toelaat nie.	",
"	3b En Salóme sê: So waaragtig as JaHWeH my Elohey leef, as ek my vinger nie in haar steek en haar natuurlike toestand ondersoek nie, sal ek nie glo dat ‘n maagd geboorte gegee het nie. [Odes van Salomo 19:9]	",

]
},
{
book: 'Jakobus',
chapter: '20',
content: [

"	1 EN die vroedvrou het na binne gegaan en vir Mirjam gesê: Maak jouself reg, want daar het geen geringe stryd oor jou ontbrand nie.	",
"	1a En Salóme het haar vinger in haar skoot gesteek en ‘n skreeu gegee en gesê: Wee my oor my ongeregtigheid en my ongeloof omdat ek die lewende El versoek het, en kyk, my hand is aan die brand en wil afval!	",
"	2 En sy buig haar knieë voor die Aangesig van JaHWeH en sê: O Elohey van my vaders, onthou dat ek ‘n nakomeling is van Abraham, Isak en Jakob, stel my nie tot ‘n voorbeeld vir die kinders van JisraEl nie,	",
"	2a maar gee my terug aan die armes, want U weet, o JaHWeH, dat ek in U Naam my dienste [aan hulle] verrig en van U my loon ontvang.	",
"	3 En kyk, ‘n Boodskapper van JaHWeH verskyn en sê vir haar: Salóme, Salóme, JaHWeH het jou verhoor, neem die Kind in jou hand en dra Hom en jy sal genesing en Vreugde verkry.	",
"	4 En Salóme het nader getree en Hom opgeneem en gesê: Ek sal Hom vereer omdat ‘n groot Koning vir JisraEl gebore is.	",
"	4a En kyk, onmiddellik is Salóme genees en sy het geregverdig uit die grot gegaan. En kyk, ‘n stem sê [vir haar]: Salóme, Salóme, moenie vertel watter wonderlike dinge jy gesien het voordat die Kind in Jerusalem kom nie.	",

]
},
{
book: 'Jakobus',
chapter: '21',
content: [
		
"	1 EN kyk, JôWsef het hom klaargemaak om na JeHûWdah te gaan. En daar het ‘n groot opskudding in Betlehem in JeHûWdah ontstaan.	",
"	1a Want wyse manne het aangekom en gesê: Waar is die pasgebore Koning van JeHûWdah? Want ons het Sy Ster in die Ooste gesien en gekom om Hom te vereer.	",
"	2 En toe Herodes dit hoor, het hy vreesbevange geraak en dienaars na die wyse manne gestuur. En hy het die hoëpriesters ontbied en by hulle navraag gedoen en gesê: Hoe staan daar geskryf oor die Gesalfde? Waar word Hy gebore?	",
"	2a Hulle antwoord hom: In Betlehem, in JeHûWdah, want so staan dit geskrywe. En hy laat hulle gaan.	",
"	2b En toe het hy by die wyse manne navraag gedoen, en vir hulle gesê: Watter Teken het julle gesien aangaande die gebore Koning?	",
"	2c En die wyse manne antwoord: Ons het ‘n besonder groot Ster gesien wat tussen hierdie Sterre skitter en hulle verduister sodat die [gewone] Sterre nie skyn nie, en daardeur het ons geweet dat daar vir JisraEl ‘n Koning gebore is en ons het gekom om Hom te vereer.	",
"	2d En Herodes sê: Gaan en soek na Hom en as julle [Hom] gevind het, laat my weet sodat ek ook kan kom en Hom hulde bewys.	",
"	3 En die wyse manne het vertrek. En kyk, die Ster wat hulle in die Ooste gesien het, het voor hulle uitgegaan totdat hulle by die grot gekom het en Hy het bo die dak van die grot bly staan.	",
"	3a En die wyse manne het die Kindjie met Sy moeder Mirjam gesien en het uit hul reissak geskenke te voorskyn gebring, goud en wierook en mirre. [Wysheid van Sirah 24:15; Klaagliedere 4:1-2]	",
"	4 En, gewaarsku deur ‘n Boodskapper om nie na JeHûWdah [terug] te gaan nie, het hulle langs ‘n ander pad na hul deel van die Aarde gereis.	",

]
},
{
book: 'Jakobus',
chapter: '22',
content: [
		
"	1 TOE Herodes egter sien dat hy deur die wyse manne om die bos gelei is, het hy woedend geword en moordenaars gestuur en vir hulle gesê	",
"	1a Maak dood die kinders van twee jaar oud en jonger.	",
"	2 En toe Mirjam hoor dat die kindertjies vermoor word, het sy bang geword en sy het die Kindjie geneem en Hom in doeke gewikkel en in ‘n beeskrip neergelê.	",
"	3 Maar toe EliSheba hoor dat JeHôWganan gesoek word, het sy hom geneem en na die gebergte opgegaan en rondgekyk waar sy hom kon wegsteek, maar daar was geen skuilplek nie.	",
"	3a En EliSheba het gesteun en met luide stem gesê: Berg van Elohim, neem moeder en kind tog op! En meteens het die berg oopgegaan en haar opgeneem. En daar het ‘n Lig vir hulle geskyn, want ‘n Boodskapper van JaHWeH was met hulle en het hul beskerm. [Openbaring 12:16 ; Boekrol van die Opregte 67:55-58]	",

]
},
{
book: 'Jakobus',
chapter: '23',
content: [
	
"	1 TOE soek Herodes vir JeHôWganan en stuur na ZekarJaH dienaars wat sê: Waar het jy jou seun versteek?	",
"	1a En hy antwoord en sê vir hulle: Ek is ‘n dienaar van Elohim en verkeer gedurig in die Huis van JaHWeH, ek weet nie waar my seun is nie.	",
"	2 En die dienaars het vertrek en dit alles aan Herodes vermeld.	",
"	2a En Herodes was woedend en het gesê: Sy seun sal koning wees in JisraEl! En hy stuur weer na hom en sê: Praat die waarheid, waar is jou seun? Jy weet tog dat ek jou lewe in my hand het!	",
"	3 En ZekarJaH sê: Ek is ‘n martelaar van Elohim as jy my bloed vergiet, want JaHWeH sal my gees ontvang omdat jy onskuldige bloed vergiet in die voorhof van die Huis van JaHWeH.	",
"	3a En teen dagbreek is ZekarJaH vermoor. Maar die kinders van JisraEl het nie geweet dat hy vermoor is nie. [MattithJaHûW 23:35]	",

]
},
{
book: 'Jakobus',
chapter: '24',
content: [
		
"	1 MAAR toe die priesters op die uur van begroeting kom, het hulle nie soos na gewoonte die seën van ZekarJaH ontvang nie.	",
"	1a En die priesters het gestaan en wag op ZekarJaH om hom met die gebed te begroet en die Hoogste El te loof en prys.	",
"	2 Maar toe hy nie opdaag nie, het almal bevrees geword.	",
"	2a En een van hulle het dit gewaag en na binne gegaan en hy sien gestolde bloed naas die altaar, en ‘n Stem sê: ZekarJaH is vermoor, en sy bloed sal nie uitgewis word totdat sy Wreker kom nie. En toe hy dié woord hoor, het hy bevrees geword en uitgegaan en dit aan die priesters bekend gemaak.	",
"	3 En hulle het dit gewaag om binne te gaan en het gesien wat gebeur het. En die panele van die Tempel het ‘n klaende geluid laat hoor, en hulle self het [hul klere] van bo na onder geskeur.	",
"	3a En hulle het die liggaam nie gevind nie, maar hulle het sy bloed gevind wat soos klip geword het. En bevrees het hulle na buite gegaan en aan die volk vertel dat ZekarJaH vermoor is.	",
"	3b En al die stamme van JisraEl het dit gehoor en het drie dae en drie nagte oor hom gerou en geweeklaag.	",
"	4 En na drie dae het die priesters beraadslaag wie hulle in sy plek sou aanstel, en die lot het op Simeon geval.	",
"	4a Want dit was hy wat ‘n openbaring van die Gees van die Apartheid ontvang het, dat hy die dood nie sou sien voordat hy die Gesalfde in die vlees gesien het nie.	",

]
},
{
book: 'Jakobus',
chapter: '25',
content: [
	
"	1 EN ek, Jakobus, wat hierdie geskiedenis geskrywe het, het my, toe daar by die dood van Herodes verwarring in Jerusalem ontstaan het, in die wildernis teruggetrek totdat die verwarring in Jerusalem beëindig is, en het JaHWeH my Elohey geprys wat my die gawe van die Wysheid gegee het om hierdie geskiedenis op skrif te stel.	",
"	2 En die Barmhartigheid sal wees met hulle wat onse Meester JaHWèshua die Gesalfde vrees, aan wie die Glansrykheid toekom tot in alle ewigheid. Amein.	",
]
}

];
