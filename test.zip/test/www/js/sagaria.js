const sagariaChapters = [

{
book: 'Sagaria',
chapter: '1',
content: [

"	1 IN die agtste maand, in die tweede jaar van Daríus, het die Woord van JaHWeH gekom tot ZekarJaH, die seun van BerekJaH[ûW], die seun van Iddo, die profeet, en gesê:	",
"	2 JaHWeH was baie vertoornd op julle vaders.	",
"	3 So moet jy dan aan hulle sê: So spreek JaHWeH van die skeppings-leërmag: Keer terug na My, spreek JaHWeH van die skeppings-leërmag, en Ek sal na julle terugkeer, sê JaHWeH van die skeppings-leërmag.	",
"	4 Moenie soos julle vaders wees nie, tot wie die vroeëre profete geroep en gesê het: So sê JaHWeH van die skeppings-leërmag: Bekeer julle tog van julle besoedelde weë en julle besoedelde werke; maar hulle het nie gehoor en na My nie geluister nie, spreek JaHWeH.	",
"	5 Julle vaders - waar is hulle? En sal die profete vir ewig lewe?	",
"	6 Maar My woorde en My Insettinge wat Ek My knegte, die profete, beveel het, het sy julle vaders nie ingehaal nie, sodat hulle tot inkeer gekom en gesê het: Soos JaHWeH van die skeppings-leërmag Hom voorgeneem het om aan ons te doen ooreenkomstig ons weë en ons werke, so het Hy met ons gedoen?	",
		
		
"	7 OP die vier-en-twintigste dag van die elfde maand, dit is die maand Sebat, in die tweede jaar van Daríus, het die Woord van JaHWeH tot die profeet ZekarJaH, die seun van BerekJaHûW, die seun van Iddo, gekom en gesê:	",
"	8 Ek het in die nag ’n gesig gesien - daar was ’n Man wat op ’n rooi perd ry, en hy het gestaan tussen die mirtebome wat in ‘n kloof was; en agter hom was daar perde: rooies, gespikkeldes en wittes.	",
"	9 Toe sê ek: Wat beteken dit, my meester? En die Boodskapper wat met my gespreek het, antwoord my: Ek sal jou toon wat dit beteken.	",
"	10 En die Man wat tussen die mirtebome gestaan het, het aangehef en gesê: Dit is Hulle wat JaHWeH gestuur het om die Aarde te deurkruis.	",
"	11 Daarop het Hulle die Boodskapper van JaHWeH, wat tussen die mirtebome gestaan het, toegespreek en gesê: Ons het die Aarde deurkruis, en kyk, die ganse Aarde is stil en rustig.	",
"	12 Daarop het die Boodskapper van JaHWeH aangehef en gesê: JaHWeH van die skeppings-leërmag, hoe lank nog bly U sonder Ontferming oor Jerusalem en oor die stede van JeHûWdah waarop U alreeds sewentig jaar vertoornd was?	",
"	13 Toe antwoord JaHWeH die Boodskapper wat met my gespreek het, suiwer woorde, troosvolle woorde.	",
"	14 Daarop sê die Boodskapper wat met my gespreek het: Roep en sê: So spreek JaHWeH van die skeppings-leërmag: Ek ywer oor Jerusalem en oor Sion met ’n groot ywer;	",
"	15 maar Ek is grootliks vertoornd oor die sorglose nasies wat, terwyl Ek ’n weinig vertoornd was, die besoedeling aangehelp het.	",
"	16 Daarom, so sê JaHWeH: Ek wend My met Ontferming tot Jerusalem; My Huis sal in haar gebou word, spreek JaHWeH van die skeppings-leërmag, en ’n meetsnoer sal oor Jerusalem gespan word.	",
"	17 Roep verder en sê: So spreek JaHWeH van die skeppings-leërmag: My stede sal weer oorstroom wees van suiwer dinge, en JaHWeH sal Sion weer vertroos, en Hy sal Jerusalem weer verkies.	",
		
		
"	18 EN ek het my oë opgeslaan en gekyk - daar was vier horings.	",
"	19 Toe sê ek aan die Boodskapper wat met my gespreek het: Wat beteken dit? En Hy antwoord my: Dit is die horings wat JeHûWdah, JisraEl en Jerusalem verstrooi het.	",
"	20 Daarop toon JaHWeH my vier graveerders.	",
"	21 Toe sê ek: Wat kom hulle maak? En Hy antwoord en sê: Dit is die horings wat JeHûWdah só verstrooi het dat niemand sy hoof opgehef het nie; maar hierdie [manne] het gekom om hulle skrik aan te jaag, om die horings van die nasies neer te werp wat die horing teen die Aarde van JeHûWdah opgesteek het om dit te verstrooi.	",

]
},
{
book: 'Sagaria',
chapter: '2',
content: [
		
"	1 EN ek het my oë opgehef en gekyk - daar was ’n Man met ’n meetsnoer in sy hand.	",
"	2 Toe sê ek: Waar gaan u heen? En hy antwoord my: Om Jerusalem te meet, om te sien wat haar breedte en wat haar lengte is.	",
"	3 En meteens kom die Boodskapper wat met my gespreek het, vorentoe; en ’n ander Boodskapper het te voorskyn gekom, hom tegemoet,	",
"	4 aan wie hy sê: Loop gou, spreek met hierdie jongman en sê: Jerusalem sal lê soos ’n oop Stad weens die menigte van adamiete en wilde wesens in haar midde.	",
"	5 En Ek sal vir haar wees, spreek JaHWeH, ’n Vurige Muur rondom, vir haar en tot Glansrykheid daar in haar midde. [Openbaring 21:17]	",
"	6 Op, op, vlug uit die Aarde van die Noorde, spreek JaHWeH! Want Ek het julle na die vier windstreke van die Hemele verstrooi, spreek JaHWeH.	",
"	7 Op, o Sion, red jouself, jy wat woon by die dogter van Babel!	",
"	8 Want so sê JaHWeH van die skeppings-leërmag: Hy het My gestuur agter glorie aan na die nasies wat julle uitgebuit het; want wie julle aanraak, raak Sy oogappel aan. [Boekrol van Henog 100:5]	",
"	9 Want kyk, Ek sal My Hand oor hulle swaai, sodat hulle ’n buit word vir hulle knegte. Dan sal julle weet dat JaHWeH van die skeppings-leërmag My gestuur het.	",
"	10 Jubel, en wees bly, o Dogter van Sion! Want kyk, Ek kom om in Jou midde te woon, spreek JaHWeH.	",
"	11 En baie nasies sal hulle in dié dag by JaHWeH aansluit, en hulle sal My tot ’n volk wees; en Ek sal in Jou midde woon. Dan sal Jy weet dat JaHWeH van die skeppings-leërmag My na Jou gestuur het.	",
"	12 En JaHWeH sal besit neem van JeHûWdah as Sy Erfdeel oor die Adamah [die adamiet se Aarde] van die Apartheid en Jerusalem weer verkies.	",
"	13 Swyg alle vlees voor die Aangesig van JaHWeH! Want Hy verhef Hom uit die woning van Sy Apartheid.	",

]
},
{
book: 'Sagaria',
chapter: '3',
content: [
		
"	1 DAARNA het Hy my JeHôWshua, die hoëpriester, laat sien, terwyl hy voor die Boodskapper van JaHWeH staan, en die Satan aan Sy regterhand staan om hom aan te klae.	",
"	2 Toe sê JaHWeH [aan] die Satan: Mag JaHWeH jou teregwys, o Satan! Ja, mag JaHWeH, wat Jerusalem verkies het, jou teregwys! Is hierdie een nie ’n brandhout wat uit die vuur geruk is nie?	",
"	3 En JeHôWshua was bekleed met vuil klere, terwyl hy voor die Boodskapper staan.	",
"	4 Daarop het Hy aangehef en gesê aan die wat voor Hom staan: Neem die vuil klere van hom weg. Toe sê Hy vir hom: Kyk, Ek het die skuld van jou ongeregtigheid weggeneem, en Ek beklee jou met feesklere. [Odes van Salomo 1]	",
"	5 Daarop sê ek: Laat hulle ’n suiwer tulband op sy hoof sit. En hulle het die suiwer tulband op sy hoof gesit en hom die klere aangetrek, terwyl die Boodskapper van JaHWeH daarby staan. [Exodus 28:36; Odes van Salomo 9:8 - 9; DaniEl 3:21]]	",
"	6 En die Boodskapper van JaHWeH het JeHôWshua plegtig verseker en gesê:	",
"	7 So sê JaHWeH van die skeppings-leërmag: As jy in My Weë wandel en as jy My Verordening onderhou, dan sal jy My Huis bestuur sowel as My voorhowe bewaak, en Ek sal jou vrye toegang verleen onder diegene wat [hier] staan.	",
"	8 Luister tog, o JeHôWshua, jy wat die hoëpriester is, jy en jou vriende wat voor jou sit - ja, wondertekens is hulle. Want kyk, Ek sal My Kneg, die Spruit, laat kom!	",
"	9 Want kyk, die Steen wat Ek voor JeHôWshua neergelê het - op die een Steen is daar sewe Oë; kyk, Ek sal haar gravering oopmaak, spreek JaHWeH van die skeppings-leërmag, en Ek sal die skuld van ongeregtigheid van hierdie Aarde op een dag uitdelg. [Exodus 28:38]	",
"	10 In dié dag, spreek JaHWeH van die skeppings-leërmag, sal julle mekaar uitnooi onder die Wingerdstok en onder die Vyeboom.	",

]
},
{
book: 'Sagaria',
chapter: '4',
content: [
	
"	1 EN die Boodskapper wat met my gespreek het, het teruggekom en my gewek soos ’n man wat uit die slaap opgewek word.	",
"	2 En hy het vir my gesê: Wat sien jy? Toe antwoord ek: Ek sien daar ’n kandelaar, alles van haar [is] van goud, en haar oliekan bo-oor haar en haar sewe lampe op haar; telkens sewe aanvoerpype loop na die lampe wat bo-oor haar is.	",
"	3 Ook twee Olyfbome teen haar, een aan die regterkant van die oliekan en een aan haar linkerkant. [Openbaring 11:4]	",
"	4 Daarop het ek begin spreek en aan die Boodskapper wat met my gespreek het, gesê: Wat beteken dit, my meester?	",
"	5 En die Boodskapper wat met my gespreek het, antwoord en sê vir my: Weet jy dan nie wat dit beteken nie? En ek het gesê: Nee, my meester.	",
"	6 Toe antwoord hy en sê vir my: Dit is die Woord van JaHWeH aan Serubbábel, naamlik: Nie deur krag of deur geweld nie, maar deur My Gees, sê JaHWeH van die skeppings-leërmag.	",
"	7 Wie is jy, groot berg? Voor Serubbábel sal jy tot ’n gelykte word! En hy sal die Hoofsteen te voorskyn bring onder uitroepe van: Barmhartigheid, Barmhartigheid vir haar!	",
"	8 En die Woord van JaHWeH het tot my gekom en gesê:	",
"	9 Die hande van Serubbábel het die fondament van hierdie Huis gelê, en sy hande sal hom voltooi; dan sal jy weet dat JaHWeH van die skeppings-leërmag My na julle gestuur het.	",
"	10 Want wie verag die dag van klein dinge, terwyl daardie sewe - die Oë van JaHWeH wat die ganse Aarde deurloop - met Blydskap die Steen wat smelt aanskou in die hand van Serubbábel?	",
"	11 Daarop het ek begin spreek en aan hom gesê: Wat beteken hierdie twee Olyfbome aan die regterkant van die kandelaar en aan haar linkerkant?	",
"	12 En ek het toe nogmaals gespreek en vir hom gesê: Wat beteken die twee Olyftakkies aan die kant van die twee goue pype wat goud uit hulle laat uitstroom?	",
"	13 Toe antwoord hy my en sê: Weet jy nie wat dit beteken nie? En ek het gesê: Nee, my meester.	",
"	14 En hy sê: Dit is die twee gesalfdes wat by My Meester van die ganse Aarde staan. [NegemJaH 9:20, 30; Openbaring 11]	",

]
},
{
book: 'Sagaria',
chapter: '5',
content: [
	
"	1 EN ek het my oë weer opgeslaan en gekyk - daar was ’n versluierde [Boek]rol. [JeshaJaH 25:7]	",
"	2 En hy het vir my gesê: Wat sien jy? Toe antwoord ek: Ek sien ’n versluierde [Boek]rol, haar lengte is twintig voorarm en haar breedte tien voorarm. [JeshaJaH 29:10 - 21]	",
"	3 Daarop sê hy vir my: Sy is die vervloeking wat uitgaan oor die ganse Aarde; want ooreenkomstig daarmee sal al die wat steel hiervandaan weggeruim word, en ooreenkomstig daarmee sal al die wat vals sweer hiervandaan weggeruim word. [TsefánJaH 3:13]	",
"	4 En laat haar uitgaan, spreek JaHWeH van die skeppings-leërmag, en sy sal kom in die huis van die wat steel en in die huis van hom wat vals sweer by My Naam; en sy [hierdie rol] sal binne-in sy huis vernag en hom verteer saam met sy hout en sy boustene. [ZekarJaH 9:15]	",
		
		
"	5 DAAROP kom die Boodskapper vorentoe wat met my gespreek het, en sê vir my: Slaan tog jou oë op, en kyk wat daar te voorskyn kom.	",
"	6 Toe sê ek: Wat beteken dit? En hy antwoord: Dit is die efa wat te voorskyn kom. Verder het hy gesê: So lyk hulle in die ganse Aarde.	",
"	7 En meteens word daar ’n talent lood opgelig, en daar was ’n vrou wat in die middel van die efa(houer met inhoudsmaat gelyk aan ‘n efa) sit.	",
"	8 En hy sê: Sy is die Besoedeling. En hy het haar binne-in die efa teruggewerp en die steen van lood oor haar mond gegooi. [JeségiEl 16:44]	",
"	9 Toe slaan ek my oë op en kyk - daar kom twee vroue te voorskyn met gees/wind in hulle Vleuels; en hulle het Vleuels gehad soos die Vleuels van ’n groot ooievaar, en hulle het die efa weggevoer tussen die Aarde en die Hemele.	",
"	10 Daarop sê ek aan die Boodskapper wat met my gespreek het: Waarheen bring hulle die efa?	",
"	11 En hy antwoord my: Om vir haar ’n huis te bou in die Aarde van Sínear; en is hy klaar, dan word sy daar op haar plek neergesit. [Boekrol van die Opregte 7:45; DaniEl 1:2]	",

]
},
{
book: 'Sagaria',
chapter: '6',
content: [
	
"	1 EN ek het weer my oë opgeslaan en gekyk - daar was vier strydwaens wat tussen die twee berge uit te voorskyn kom, en die berge was berge van koper.	",
"	2 Voor die eerste wa was perde met rooi vlekke, en voor die tweede wa swart perde,	",
"	3 en voor die derde wa wit perde en voor die vierde wa gespikkelde en bont perde.	",
"	4 Daarop het ek aangehef en aan die Boodskapper wat met my gespreek het, gesê: Wat beteken dit, my meester?	",
"	5 En die Boodskapper het geantwoord en vir my gesê: Dit is die vier Geeste van die Hemele wat uitgaan nadat hulle hul gestel het by My Meester van die ganse Aarde.	",
"	6 Dié swart perde trek uit na die Aarde van die noorde, en die wittes trek uit agter hulle aan; en die gespikkeldes trek uit na die Aarde van die suide.	",
"	7 En toe die bontes uittrek, het hulle begeer om weg te trek om die Aarde te deurkruis; en Hy het gesê: Trek weg, deurkruis die Aarde! En hulle het die Aarde deurkruis.	",
"	8 Toe het Hy my geroep en aan my dit gesê: Kyk, die wat uittrek na die Aarde van die noorde, hulle bring My Gees tot rus in die Aarde van die noorde.	",
"	9 En die Woord van JaHWeH het tot my gekom en gesê:	",
"	10 Neem aan van die ballinge, [uit die hand] van Heldai, TobiJaH en JedaJaH - kom jy op dieselfde dag en gaan na die huis van JoshiJaH, die seun van TsefánJaH, waar hulle uit Babel aangekom het -	",
"	11 neem dan aan silwer en goud, en maak ’n kroon en sit dit op die hoof van JeHôWshua, die seun van JeHôWtsadok, die hoëpriester,	",
"	12 en sê vir hom dit: So spreek JaHWeH van die skeppings-leërmag: Kyk, daar kom ’n Man wie se Naam is SPRUIT, en Hy sal uit Sy plek uitspruit, en Hy sal die Huis van JaHWeH bou.	",
"	13 Ja, Hy sal die Huis van JaHWeH bou, en Hy sal Majesteit verkry en sit en heers op Sy Troon; ook sal Hy ’n priester wees op Sy Troon, en die Raad van Vrede sal tussen hulle twee bestaan. [ZekarJaH 8:12]	",
"	14 En die kroon moet as herinnering bly aan Helem en TobiJaH en JedaJaH, en aan Hen die seun van TsefánJaH in die Huis van JaHWeH.	",
"	15 En die wat ver is, sal kom en aan die Huis van JaHWeH bou. Dan sal julle weet dat JaHWeH van die skeppings-leërmag my na julle gestuur het. En dit sal so wees, as julle nougeset luister na die Stem van JaHWeH julle Elohey.	",

]
},
{
book: 'Sagaria',
chapter: '7',
content: [
	
"	1 EN in die vierde jaar van koning Daríus het die Woord van JaHWeH tot ZekarJaH gekom, op die vierde dag van die negende maand, in [die maand] Kislew.	",
"	2 Bet-El het toe Saréser en Regem-Meleg met sy manne gestuur om die Aangesig van JaHWeH om Barmhartigheid te smeek	",
"	3 deur aan die priesters wat by die Huis van JaHWeH van die skeppings-leërmag was, en aan die profete die vraag te stel: Moet ek in die vyfde maand ween en myself afsonder soos ek nou al so baie jare gedoen het?	",
"	4 Daarop het die Woord van JaHWeH van die skeppings-leërmag tot my gekom en gesê:	",
"	5 Spreek tot die hele volk van die Aarde en tot die priesters dit: As julle, nou sewentig jaar lank, in die vyfde en in die sewende gevas en getreur het, het julle toe werklik ter wille van My gevas?	",
"	6 En as julle eet en as júlle drink, is dit dan nie júlle wat eet en júlle wat drink nie?	",
"	7 Is dit nie so met die woorde wat JaHWeH deur die diens van die vroeëre profete verkondig het nie, toe Jerusalem en haar omliggende stede nog bewoond en rustig was, en ook die Suidland en die Laeveld nog bewoond was?	",
"	8 Verder het die Woord van JaHWeH tot ZekarJaH gekom en gesê:	",
"	9 So het JaHWeH van die skeppings-leërmag gespreek en gesê: Spreek eerlike Reg uit en bewys medelye en barmhartigheid; soos ‘n man teenoor sy broer.	",
"	10 En moet nie die weduwee en die wees, die besoeker en die arme verdruk nie en besoedeling in julle hart teenoor mekaar bedink nie.	",
"	11 Maar hulle het geweier om te luister en wederstrewig die skouer afgewend en hulle ore toegestop om nie te hoor nie.	",
"	12 Ook het hulle hul hart soos ’n diamant gemaak, om nie die Wet te verneem nie en die woorde wat JaHWeH van die skeppings-leërmag deur Sy Gees, deur die diens van die vroeëre profete gestuur het nie. So het daar dan van JaHWeH van die skeppings-leërmag ’n groot Toorn gekom.	",
"	13 Daarom, soos Hy geroep en hulle nie gehoor het nie - so sal hulle roep, maar Ek nie hoor nie, het JaHWeH van die skeppings-leërmag gesê.	",
"	14 Maar Ek sal hulle verstrooi [met ‘n] warrelwind onder al die nasies wat hulle nie geken het nie, terwyl die Aarde agter hulle verwoes is, sodat niemand meer heen en weer trek nie. So het hulle dan die aangename Aarde tot ’n verskrikking gemaak.	",

]
},
{
book: 'Sagaria',
chapter: '8',
content: [
		
"	1 EN die Woord van JaHWeH van die skeppings-leërmag het gekom en gesê:	",
"	2 So spreek JaHWeH van die skeppings-leërmag: Ek ywer oor Sion met ’n groot ywer, ja, Ek ywer met groot Grimmigheid vir Haar.	",
"	3 So sê JaHWeH: Ek keer terug na Sion en sal midde-in Jerusalem woon; en Jerusalem sal genoem word: Die Stad van Waarheid, en die Berg van JaHWeH van die skeppings-leërmag; Berg van die Apartheid.	",
"	4 So sê JaHWeH van die skeppings-leërmag: Daar sal weer ou manne en ou vroue op die pleine van Jerusalem sit - elkeen met sy stok in sy hand vanweë die veelheid van hulle dae.	",
"	5 En die pleine van die Stad sal vol wees van seuntjies en dogtertjies wat op haar pleine speel.	",
"	6 So sê JaHWeH van die skeppings-leërmag: As sy te wonderbaar is in die oë van die oorblyfsel van hierdie volk in dié dae, sal sy ook in My oë te wonderbaar wees? spreek JaHWeH van die skeppings-leërmag.	",
"	7 So sê JaHWeH van die skeppings-leërmag: Kyk, Ek gaan My volk verlos uit die Aarde in die ooste en uit die Aarde in die weste	",
"	8 en hulle aanbring; en hulle sal midde-in Jerusalem woon. Dan sal hulle vir My ’n volk wees, en Ék sal vir hulle ’n Elohim wees, in beslistheid en Geregtigheid.	",
"	9 So sê JaHWeH van die skeppings-leërmag: Laat julle hande sterk wees, julle wat in hierdie dae sulke woorde gehoor het uit die mond van die profete op die dag toe die fondament gelê is van die Huis van JaHWeH van die skeppings-leërmag, die Tempel, om gebou te word.	",
"	10 Want vóór hierdie dae het die adamiete geen loon getrek nie, ook vir die wilde wesens was daar geen loon nie; en vir die wat uit- en ingaan, was daar weens die teëstander geen veiligheid nie; want Ek het al die adamiete die een teen die ander losgelaat.	",
"	11 Maar nou sal Ek vir die oorblyfsel van hierdie volk nie wees soos in vroeër dae nie, spreek JaHWeH van die skeppings-leërmag.	",
"	12 Want die Saad van Vrede, die Wingerdstok, sal Haar vrug gee, en die Aarde haar opbrengs lewer, en die Hemele sal sy Dou skenk; en die oorblyfsel van hierdie volk sal Ek al hierdie dinge laat beërwe. [Psalm 128:3; ZekarJaH 6:13; JeHôWganan 15; Openbaring 12:17]	",
"	13 En soos julle ’n vloek gewees het onder die nasies, o huis van JeHûWdah en huis van JisraEl, so sal Ek julle verlos, dat julle ’n seën kan wees. Wees nie bevrees nie, laat julle hande sterk wees.	",
"	14 Want so sê JaHWeH van die skeppings-leërmag: Soos Ek My voorgeneem het om julle kwaad aan te doen, toe julle vaders My vertoorn het, sê JaHWeH van die skeppings-leërmag, en Ek daar geen berou van gehad het nie -	",
"	15 so het Ek My weer voorgeneem om in hierdie dae goed te doen aan Jerusalem en die huis van JeHûWdah. Wees nie bevrees nie.	",
"	16 Dit is die dinge wat julle moet doen: Spreek die Waarheid met mekaar; beoefen Waarheid en ’n Regspraak van Vrede in julle Poorte!	",
"	17 En laat niemand van julle besoedeling teen jou naaste in jul hart bedink nie, en moenie ‘n valse eed liefhê nie. Want dit alles haat Ek, spreek JaHWeH.	",
"	18 En die Woord van JaHWeH van die skeppings-leërmag het tot my gekom en gesê:	",
"	19 So sê JaHWeH van die skeppings-leërmag: Die vasdag in die vierde en die vasdag in die vyfde en die vasdag in die sewende en die vasdag in die tiende [maand] moet vir die huis van JeHûWdah ’n Vreugde en Blydskap wees en suiwer Feestye, maar julle moet die Waarheid en die Vrede liefhê.	",
"	20 So sê JaHWeH van die skeppings-leërmag: Nog sal volke aankom en die inwoners van baie stede.	",
"	21 En die inwoners van die een [stad] sal gaan na die ander en sê: Kom, laat ons heengaan om die Aangesig van JaHWeH om Guns te smeek en om JaHWeH van die skeppings-leërmag te soek. Ek wil ook gaan!	",
"	22 So sal dan baie volke en magtige nasies kom om JaHWeH van die skeppings-leërmag in Jerusalem te soek en die Aangesig van JaHWeH om Barmhartigheid te smeek.	",
"	23 So sê JaHWeH van die skeppings-leërmag: In dié dae sal tien man uit al die tale van die nasies die slip van ’n man van JeHûWdah gryp en har vashou en sê: Ons wil met julle saamgaan, want ons het gehoor dat Elohim met julle is.	",

]
},
{
book: 'Sagaria',
chapter: '9',
content: [
		
"	1 DIE las van die Woord van JaHWeH teen die Aarde van Hadrag, en op Damaskus bly hy rus - want JaHWeH hou die Oog op die adamiete en op al die stamme van JisraEl.	",
"	2 En ook [teen] Hamat wat aan haar grens; [teen] Tirus saam met Sidon, want sy is baie slim.	",
"	3 Ja, Tirus het vir haar ’n vesting gebou; ook het sy silwer opgehoop soos stof en goud soos modder van die strate.	",
"	4 Kyk, My Meester sal haar in besit neem en haar skans in die see werp, en sy sal deur Vuur verteer word.	",
"	5 Askelon sal haar sien en vrees; ook Gasa, wat sal sidder van angs; ook Ekron, omdat haar verwagting teleurgestel het; en uit Gasa verdwyn die koning, en Askelon bly onbewoond;	",
"	6 en die baster sal in Asdod woon - so sal Ek dan aan die trotsheid van die Filistyn ’n einde maak -	",
"	7 en Ek sal die bloed uit sy mond verwyder en sy verfoeisels tussen sy tande uit; so sal hy dan ook vir onse Elohey oorbly en wees soos ’n vriend vir JeHûWdah, en Ekron soos ’n Jebusiet.	",
"	8 En Ek sal om My Huis ’n laer trek teen die leërmag, teen die wat heen en weer trek, sodat geen oorheerser hulle weer sal oorrompel nie; want nou het Ek dit met My eie oë gesien.	",
"	9 Verheug jou grootliks, o Dogter van Sion! Juig, o Dogter van Jerusalem! Kyk, Jou Koning kom na Jou; regverdig en ’n oorwinnaar is Hy, nederig en Hy ry op ’n esel - op ’n jong esel, die vul van ’n eselin. [2 Konings 4:22]	",
"	10 En Ek sal die strydwaens uit Efraim en die perde uit Jerusalem afsny, en die strydboog sal vernietig word. Dan sal Hy aan die nasies Vrede verkondig, en Sy heerskappy sal wees van see tot see, en van die rivier tot aan die eindes van die Aarde.	",
"	11 Ook sal Ek, wat jou betref, kragtens die bloed van jou Verbond jou gevangenes loslaat uit die put sonder water.	",
"	12 Keer terug na die vesting, o hoopvolle gevangenes! Ook kondig Ek vandag aan dat Ek jou dubbel sal vergoed.	",
"	13 Want Ek span JeHûWdah vir My as boog, lê Efraim as pyl daarop; en Ek vuur Jou seuns, o Sion, aan teen jou seuns, o Jawan(Griekeland), en Ek maak Jou soos die Swaard van ’n Magtige.	",
"	14 Dan sal JaHWeH oor hulle verskyn, en soos weerlig sal Sy pyl uitskiet; en My Meester JaHWeH sal met die ramshoring blaas en intrek met die storms uit die suide.	",
"	15 JaHWeH van die skeppings-leërmag sal hulle beskut; en hulle sal verslind, ja, boustene vertrap; ook sal hulle drink, ’n gedruis maak soos deur wyn en vol wees soos die sprinkelflesse, soos die hoeke van ’n altaar. [ZekarJaH 5:4]	",
"	16 En JaHWeH hulle Elohey sal hulle in dié dag verlos as die kudde wat Sy volk is; want [hulle] verhef die Bousteen van Separatisme soos ‘n banier oor Sy Adamah [die adamiet se Aarde]. [JeshaJaH 11:12; 18:3; JirmeJaH 4:5]	",
"	17 Want hoe groot is hulle voortreflikheid, en hoe groot hulle skoonheid! Die koring laat jongmanne en die druiwesap laat die maagde groei.	",

]
},
{
book: 'Sagaria',
chapter: '10',
content: [
		
"	1 VRA van JaHWeH reën in die tyd van die laat reëns; JaHWeH maak weerligte, en Hy sal aan hulle ’n stortreën gee, groenigheid aan elke man in die veld.	",
"	2 Want die huisidole spreek bedrog, en die waarsêers sien leuens en verkondig nietige drome, hulle troos met gees. Daarom het hulle weggeswerwe soos ’n kudde; hulle verkeer in verdrukking, omdat daar geen herder is nie.	",
"	3 Teen die herders het My Toorn ontvlam, en oor die voorbokke sal Ek besoeking bring; want JaHWeH van die skeppings-leërmag gee ag op Sy kudde, op die huis van JeHûWdah, en maak hulle tot Sy pragtige Perd in die stryd. [Openbaring 6:2-8]	",
"	4 Uit hom sal die Hoeksteen, uit hom die muurpen, uit hom die strydboog, uit hom die vorste almal saam uitgaan.	",
"	5 En hulle sal wees soos dapperes wat in die oorlog die modder van die strate vertrap; en hulle sal veg, want JaHWeH is met hulle; en die ruitery sal beskaamd uitkom.	",
"	6 En Ek sal die huis van JeHûWdah sterk maak en aan die huis van JôWsef hulp verleen en hulle ’n woonplek aanwys, want Ek ontferm My oor hulle; en hulle sal wees asof Ek hulle nie verwerp het nie, want Ek – JaHWeH hulle Elohey, en Ek sal hulle verhoor. [TsefánJaH 2:7; ZekarJaH 12:8]	",
"	7 En Efraim sal wees soos ’n dappere, en hulle hart sal vrolik wees soos deur wyn, en hulle kinders sal dit sien en hulle verbly, hulle hart sal juig in JaHWeH.	",
"	8 Ek wil vir hulle fluit en hulle vergader, want Ek het hulle losgekoop; en hulle sal net so talryk wees soos tevore. [Hebreërs 7:22]	",
"	9 En Ek sal hulle saai onder die volke, en in die verafgeleë streke sal hulle aan My dink; en hulle sal saam met hul kinders in die lewe bly en terugkom.	",
"	10 En Ek sal hulle terugbring uit die Aarde van Egipte en uit Assur hulle vergader en hulle na die Aarde van Gílead en die Líbanon bring; maar dit sal vir hulle nie voldoende wees nie.	",
"	11 En Hy sal deur die see van benoudheid trek en die golwe in die see slaan, en al die dieptes van die Nyl sal opdroog; ook sal die trotsheid van Assírië neergewerp word, en die septer van Egipte wyk.	",
"	12 En Ek sal hulle sterk maak in JaHWeH, en hulle sal in Sy Naam wandel, spreek JaHWeH.	",

]
},
{
book: 'Sagaria',
chapter: '11',
content: [
		
"	1 OPEN jou deure, o Líbanon, sodat vuur jou sederbome verteer!	",
"	2 Huil, o sipres, omdat die seder geval het, omdat die pragtige [bome] verwoes is! Huil, eike van Basan, omdat die ontoeganklike woud afgekap is.	",
"	3 Hoor! die gejammer van die herders, want hulle oorvloed is verwoes. Hoor! die geknor van die jong leeus, want die pronkbosse van die Jordaan is verwoes.	",
		
		
"	4 SO sê JaHWeH my Elohey: Wees Herder van die skape wat doodgemaak word - [JeségiEl 34]	",
"	5 hulle kopers maak hulle dood, sonder om skuldig te voel; hulle verkopers sê: Geloofd sy JaHWeH; ek word ryk! En hulle herders het geen medelye met hulle nie.	",
"	6 Want Ek sal met die inwoners van die Aarde geen Medelye meer hê nie, spreek JaHWeH; maar kyk, Ek gaan die adamiete oorlewer, elkeen in die hand van sy naaste en in die hand van sy koning; en hulle sal die Aarde verwoes, en Ek sal uit hulle hand nie red nie.	",
"	7 En Ek het die slagskape - waarlik ellendige skape! - opgepas; en Ek het vir My twee stawe geneem. Die een het Ek genoem: Lieflikheid, en die ander het Ek genoem: Samebinding; en Ek het die skape opgepas.	",
"	8 En Ek het die drie herders in een maan vernietig. Toe het My Siel ongeduldig geword oor hulle, terwyl hulle siel ook van My afkerig geword het.	",
"	9 Daarop het Ek gesê: Ek wil julle nie meer oppas nie - wat sterwend is, laat sterwe; en wat verlore gaan, laat verlore wees, en laat die wat oorbly, sy naaste se vleis verslind!	",
"	10 Toe het Ek My Staf Lieflikheid geneem en hom verbreek, om My Verbond wat Ek met al die volke gesluit het, te verbreek.	",
"	11 En hy is op dié dag verbreek. En so het die ellendiges onder die skape wat op My ag gegee het, bemerk dat dit die Woord van JaHWeH was.	",
"	12 Daarop sê Ek vir hulle: As dit goed is in julle oë, gee dan My loon; en so nie, laat dit dan staan. Toe het hulle My loon afgeweeg: dertig silwerstukke.	",
"	13 Hierop sê JaHWeH vir My: Gooi dit vir die pottebakker - die duursame prys waarmee Ek deur hulle gewaardeer is! En Ek het die dertig silwerstukke geneem en dit in die Huis van JaHWeH vir die pottebakker gegooi.	",
"	14 Toe het Ek My tweede Staf, Samebinding, verbreek, om die broederskap tussen JeHûWdah en JisraEl te verbreek.	",
"	15 Daarop sê JaHWeH vir My: Neem weer vir jou die gereedskap van ’n herder, van ’n dwase.	",
"	16 Want kyk, Ek sal ’n herder verwek in die Aarde; na wat verlore is, sal hy nie omkyk nie; wat verstrooi is, nie opsoek nie; en wat gebroke is, nie genees nie; en wat [nog] regop staan, nie versorg nie. Maar die vleis van die vettes sal hy eet en selfs hulle kloue afruk.	",
"	17 Wee die drek herder wat die skape in die steek laat! Mag die swaard sy arm tref en sy regteroog! Mag sy arm verdor en verdroog en sy regteroog verdof en verduister word!	",

]
},
{
book: 'Sagaria',
chapter: '12',
content: [
	
"	1 DIE las van die Woord van JaHWeH oor JisraEl. JaHWeH spreek, wat die Hemele uitsprei en die Aarde grondves en die gees van die adamiet in sy binneste formeer:	",
"	2 Kyk, Ek maak Jerusalem vir al die volke rondom tot ’n Beker van bedwelming, en ook teen JeHûWdah sal sy wees tydens die beleëring teen Jerusalem.	",
"	3 En in dié dag maak Ek Jerusalem tot ’n baie swaar Klip vir al die volke: elkeen wat haar optel, sal hom daarmee sekerlik seer maak; en al My nasies van die Aarde sal teen haar vergader word.	",
"	4 In dié dag, spreek JaHWeH, sal Ek al die perde met verwarring slaan en hulle ruiters met waansin; maar oor die huis van JeHûWdah sal Ek My Oë oophou, terwyl Ek al die perde van die volke met blindheid slaan.	",
"	5 Dan sal die stamhoofde van JeHûWdah in hulle hart sê: Die inwoners van Jerusalem is vir my ’n sterkte deur JaHWeH van die skeppings-leërmag, hulle Elohey.	",
"	6 In dié dag sal Ek die stamhoofde van JeHûWdah maak soos ’n pan met vuur onder ’n hoop hout en soos ’n brandende fakkel onder gerwe - hulle sal regs en links al die volke rondom verteer; maar Jerusalem sal nog bewoond wees op haar plek in Jerusalem.	",
"	7 En JaHWeH sal eers die tente van JeHûWdah verlos, sodat die roem van die huis van Dawid en die roem van die inwoners van Jerusalem dié van JeHûWdah nie sal oortref nie.	",
"	8 In dié dag sal JaHWeH die inwoners van Jerusalem rondom beskut, en die struikelende onder hulle sal in dié dag wees soos Dawid, en die huis van Dawid soos Elohim, soos die Boodskapper van JaHWeH voor hulle uit. [TsefánJaH 2:7; ZekarJaH 10:6]	",
"	9 Ook sal Ek in dié dag daarna soek om al die nasies wat teen Jerusalem aankom, te verdelg.	",
"	10 Maar oor die huis van Dawid en oor die inwoners van Jerusalem sal Ek uitgiet die Gees van Barmhartigheid en Smekinge; en hulle sal kyk na My vir wie hulle deurboor het, en hulle sal oor Hom rouklaag soos ’n iemand rouklaag oor ’n enigste Seun en bitterlik oor Hom ween soos ’n mens bitterlik ween oor ’n eersgebore Kind.	",
"	11 In dié dag sal die rouklag groot wees in Jerusalem, soos die rouklag van Hadad-Rimmon in die laagte van Megiddon.	",
"	12 En die Aarde sal treur, elke familie op sy eie; die familie van die huis van Dawid op sy eie, en hulle vroue op hul eie; die familie van die huis van Natan op sy eie, en hulle vroue op hul eie;	",
"	13 die familie van die huis van Levi op sy eie, en hulle vroue op hul eie; die familie van Simeï op sy eie, en hulle vroue op hul eie.	",
"	14 Al die ander families - elke familie op sy eie, en hulle vroue op hul eie.	",

]
},
{
book: 'Sagaria',
chapter: '13',
content: [
	
"	1 IN dié dag sal daar ’n geopende Fontein wees vir die huis van Dawid en vir die inwoners van Jerusalem teen oortreding en onsuiwerheid.	",
"	2 En in dié dag, spreek JaHWeH van die skeppings-leërmag, sal Ek die name van die idole uit die Aarde uitroei, sodat aan hulle nie meer gedink sal word nie; en ook die profete en die gees van besoedeling sal Ek uit die Aarde laat wegtrek.	",
"	3 En as iemand nog wil profeteer, sal sy vader en sy moeder wat hom verwek het, vir hom sê: Jy mag nie langer lewe nie, want jy het leuens in die Naam van JaHWeH verkondig; en sy vader en sy moeder wat hom verwek het, sal hom deurboor as hy wil profeteer.	",
"	4 En in dié dag sal elkeen van die profete, as hy profeteer, hom skaam oor sy visioen; en hulle sal die harige mantel nie aantrek om te lieg nie.	",
"	5 Maar hy sal sê: Ek is geen profeet nie, ek is ’n man wat die Adamah[adamiet se Aarde] bewerk; want iemand het my van my jeug af as slaaf gekoop.	",
"	6 En as iemand vir hom sê: Watter wonde is daardie tussen jou hande? dan sal hy antwoord: So is ek geslaan in die huis van my vriende.	",
"	7 Ontwaak, o swaard, teen My Herder, en teen die sterk man wat My metgesel is! spreek JaHWeH van die skeppings-leërmag. Slaan die Herder, sodat die skape verstrooi word; en Ek sal My Hand weer uitstrek oor die geringes.	",
"	8 En in die ganse Aarde, spreek JaHWeH - twee-derdes sal in haar uitgeroei word, sal sterwe, maar een-derde sal in haar oorbly. [Boekrol van die Opregte 9:39; JeshaJaH 10:23]	",
"	9 Dan sal Ek die derde deel in die vuur bring en hulle smelt soos ’n mens silwer smelt en hulle toets soos ’n mens goud toets. Hulle sal My Naam aanroep, en Ek sal hulle verhoor. Ek sê: Dit is My volk! En hulle sal sê: JaHWeH, my Elohey! [Levítikus 2:14; Boekrol van die Opregte 9:38]	",
		

]
},
{
book: 'Sagaria',
chapter: '14',
content: [
	
"	1 KYK, die dag van JaHWeH kom; dan sal wat van jou buitgemaak is, binne-in jou verdeel word.	",
"	2 Want Ek sal al die nasies versamel om oorlog te voer teen Jerusalem; en die Stad sal ingeneem en die huise geplunder en die vroue onteer word, en die helfte van die Stad sal uitgaan in ballingskap; maar die orige deel van die bevolking sal nie uit die Stad uitgeroei word nie.	",
"	3 En JaHWeH sal uittrek en stryd voer teen dié nasies soos op die dag van Sy stryd, die dag van oorlog.	",
"	4 En in dié dag sal Sy voete staan op die Berg van die Olywe wat voor Jerusalem lê, aan die oostekant; en die Berg van die Olywe sal middeldeur gesplyt word van oos na wes [tot] ’n baie groot dal; en die een helfte van die berg sal wegwyk na die noorde en die ander helfte na die suide.	",
"	5 En julle sal vlug in die dal van My berge - want die dal van die berge sal loop tot by Azel - en julle sal vlug soos julle gevlug het vir die aardbewing in die dae van UzziJaH, die koning van JeHûWdah. Dan sal JaHWeH my Elohey kom, en al die apartes saam met U!	",
"	6 En in dié dag sal daar geen Lig wees nie, die Sterre sal duister wees.	",
"	7 En dit sal ’n enige dag wees wat aan JaHWeH bekend is - geen dag en geen nag nie; maar teen die aand sal dit Lig word. [JeshaJaH 40:2]	",
"	8 En in dié dag sal daar lewende waters uit Jerusalem uitvloei, die een helfte daarvan na die Oostelike en die ander helfte daarvan na die Westelike See; somer en winter sal dit so wees.	",
"	9 En JaHWeH sal Koning wees oor die hele Aarde; in dié dag sal JaHWeH een wees, en Sy Naam een.	",
"	10 Die hele Aarde sal soos die Vlakte word, van Geba tot by Rimmon, suid van Jerusalem; maar sy sal onder haar hoog wees en woon op haar plek, van die Poort van Benjamin af tot by die plek van die vorige Poort, tot by die Hoekpoort, en van die toring GanánEl tot by die parskuipe van die koning.	",
"	11 En hulle sal in haar woon, en daar sal geen banvloek meer wees nie, en Jerusalem sal in veiligheid woon.	",
"	12 En sy sal die plaag wees waarmee JaHWeH al die volke sal tref wat opgetrek het om teen Jerusalem te veg: Hy sal hulle vlees laat wegteer, terwyl hulle nog op hul voete staan; en hulle oë sal wegteer in hulle holtes, en hulle tong wegteer in hulle mond. [TsefánJaH 1:11]	",
"	13 En in dié dag sal ’n groot verwarring van JaHWeH onder hulle kom, sodat die een die hand van die ander sal gryp, en die hand van die een hom sal verhef teen die hand van die ander. [JeshaJaH 19:2]	",
"	14 En JeHûWdah sal ook in Jerusalem veg, en die rykdom van al die nasies rondom sal ingesamel word: goud en silwer en klere - ’n groot hoeveelheid.	",
"	15 En soos hierdie plaag is, sal die plaag wees van die perde, die muile, die kamele en die esels en van al die diere wat in daardie laers is.	",
"	16 En almal wat oorbly uit al die nasies wat teen Jerusalem aangekom het, sal jaar na jaar optrek om neer te val voor Koning JaHWeH van die skeppings-leërmag, en om die Fees van die Takskuilings te vier.	",
"	17 En wie uit die stamme van die Aarde nie na Jerusalem optrek om voor My Meester JaHWeH van die skeppings-leërmag, neer te buig nie - hulle sal geen reën kry nie.	",
"	18 En as die familie van Egipte nie optrek en nie kom nie, op wie geen [reën] sal val nie, dan sal tog die plaag hulle tref waarmee JaHWeH die nasies tref wat nie opgaan om die Fees van die Takskuilings te vier nie.	",
"	19 Dit sal die straf van Egipte wees en die straf van al die nasies wat nie optrek om die Fees van die Takskuilings te vier nie.	",
"	20 In dié dag sal op die klokke van die perde staan: APARTHEID AAN JaHWeH! En die potte in die Huis van JaHWeH sal wees soos die sprinkelflesse voor die altaar.	",
"	21 Ja, al die potte in Jerusalem en JeHûWdah sal Apartheid aan JaHWeH van die skeppings-leërmag wees; en almal wat wil slag, sal kom en daarvan neem en daarin gaarmaak; en in dié dag sal daar geen Kanaäniet in die Huis van JaHWeH meer wees nie.	",

]
}

];
