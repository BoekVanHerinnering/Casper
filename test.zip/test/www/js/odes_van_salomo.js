const odes_van_salomoChapters = [

{
book: 'Odes_Van_Salomo',
chapter: '1',
content: [

"	1 JaHWeH is soos ‘n Krans op My hoof en Ek sal Hom nie verlaat nie. [Exodus 28:36; ZekarJaH 3:5; Openbaring 2:10]	",
"	2 Die Krans van Waarheid is vir My gevleg, en Sy het U takke binne My laat bot;	",
"	3 Want Sy is nie soos ‘n verwelkte krans wat nie uitbot nie: [Spreuke van Salomo 4:11]	",
"	4 Maar U is lewendig op My hoof en U het op My gebot.	",
"	5 U vrugte is vol en raseg: Hulle is vol Verlossing.	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '2',
content: [

]
},
{
book: 'Odes_Van_Salomo',
chapter: '3',
content: [
	
"	1 ...... Ek beklee.	",
"	2 MY ledemate is met Hom, ek hang aan Hom en Hy het my lief;	",
"	3 Want ek sou nie geweet het hoe om JaHWeH lief te hê as Hy my nie liefgehad het nie.	",
"	4 Wie kan die liefde verstaan, behalwe hy wat liefde ontvang?	",
"	5 Ek het die Uitverkorene lief, my siel het Hom lief; en waar Sy rus is, daar is ek ook.	",
"	6 Ek sal nie ‘n vreemdeling wees nie, want die Hoogste El en die barmhartige Meester koester geen wrok nie.	",
"	7 Ek is verenig met Hom, want die geliefde het die Geliefde Een gevind, omdat ek daardie Seun liefhet, sal ek ‘n seun word.	",
"	8 Want hy wat verbind is met Hom wat nie sterf nie, hy sal ook onsterflik word.	",
"	9 Hy wat in U glo, sal ‘n lewende wese word.	",
"	10 Sy is die Gees van Waarheid van JaHWeH wat die mense Sy Weë leer. [JeHôWganan 14:26 en 16:13]	",
"	11 Wees wys, en verstaan en wees opmerksaam. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '4',
content: [
	
"	1 GEEN sterfling verander U Apartheidsplek nie, o my Elohey, en daar is geeneen wat hom sal verander en op ‘n ander plek sit nie,	",
"	2 Want geeneen het enige gesag oor hom nie; want U het U Apartheidsplek bedink voordat U plekke gemaak het:	",
"	3 Wat ouer is, sal nie verander word deur die wat jonger as hy is nie. U het U Hart, o JaHWeH, aan U getroues gegee.	",
"	4 U sal nooit onbekwaam wees nie, ook sal U nie vrugteloos wees nie.	",
"	5 Want een uur van U Waarheid is beter as al die dae en jare.	",
"	6 Want wie sal hom beklee met U Guns en verwerp word?	",
"	7 Want U Seël is bekend, en U skepsele is bekend met Haar,	",
"	8 en die Leërskare hou Haar, en die uitverkore Hoofboodskappers is met Haar beklee.	",
"	9 U het vir ons gemeenskap met U gegee: Dit is nie asof U ons nodig het nie, maar eerder dat ons U nodig het.	",
"	10 Sprinkel U dan oor ons U Dou, en open U ryk Fonteine wat vloei met melk en heuning vir ons.	",
"	11 Want by U is geen berou, dat U berou sal hê oor enigiets wat U beloof het nie;	",
"	12 En die einde is aan U bekend.	",
"	13 Want wat U gee, skenk U mildelik, sodat U dit nie van nou af aan sal terugneem nie; want alles is aan U, as die Elohim, bekend,	",
"	14 en is van die begin af voor U gereed gemaak en U, my Elohey, het alles gemaak.	",
"	15 Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '5',
content: [
		
"	1 EK dank U, o JaHWeH, omdat Ek U liefhet.	",
"	2 0, Hoogste El, verlaat My nie, want U is My hoop.	",
"	3 Ek ontvang U Barmhartigheid vrylik: Ek sal deur Hom leef.	",
"	4 My agtervolgers sal kom, maar hulle sal My nie sien nie:	",
"	5 ‘n Donker wolk sal voor hul oë kom, en ‘n ondeursigtige mis sal donkerte oor hulle bring;	",
"	6 Hulle sal nie die Lig hê om te sien nie, sodat hulle My nie sal gryp nie.	",
"	7 Hulle plan sal dwaasheid word, en dit wat hulle saamgesweer het, sal terugkom op hul eie hoofde;	",
"	8 Want hulle het ‘n plan uitgedink, maar dit sal vir hulle tot niks kom nie;	",
"	9 Hulle het besoedelde planne gesmee, maar dis bevind dat dit tevergeefs was.	",
"	10 Want My hoop is gevestig op JaHWeH, en Ek sal nie vrees nie;	",
"	11 Omdat JaHWeH My redding is, sal Ek nie bevrees wees nie.	",
"	12 Hy is soos ‘n Kroon op My hoof, en Ek sal nie wankel nie;	",
"	13 Selfs as alles sou wankel, sal Ek vasstaan;	",
"	14 Selfs as alles wat sigbaar is, vergaan, sal Ek nie sterf nie:	",
"	15 Want JaHWeH is met My en Ek is met Hom.Halalu-JaHH/Prys jul JaHH!	",
	
]
},
{
book: 'Odes_Van_Salomo',
chapter: '6',
content: [
		
"	1 SOOS die wind oor die harp beweeg en die snare spreek,	",
"	2 so spreek die Gees van JaHWeH in my liggaamsdele, en ek spreek deur Haar Liefde.	",
"	3 Want Sy vernietig alles wat vreemd is en alles is van JaHWeH.	",
"	4 Want so was Sy van die begin af, en so sal Sy wees tot aan die einde;	",
"	5 Sodat niks Hom sal teëstaan nie, en niks teen Hom sal opstaan nie.	",
"	6 JaHWeH het die Kennis omtrent Homself vermeerder, en ywer dat die dinge bekend sal wees wat deur Sy Barmhartigheid aan ons gegee is.	",
"	7 Hy het vir ons Sy lofprysinge tot Sy Naam gegee: Ons gees prys Sy Gees van Apartheid.	",
"	8 Want ‘n stroom gaan uit en word ‘n groot en breë rivier, want hy verpletter en breek alles op en voer dit weg van die Tempel; [JeségiEl 45]	",
"	9 En die mense kan dit nie bedwing nie, ook nie die bedrewenheid van hulle wat water beheer nie;	",
"	10 Want hy kom oor die hele Aarde en vul alles op; [JeségiEl 47]	",
"	11 Almal wat dors op die Aarde het, drink en hulle dors hou op en is gelês;	",
"	12 Want dié drank kom van die Hoogste El.	",
"	13 Daarom, geseënd is die Bedieners van daardie drank, diegene wat toevertrou is met Sy water:	",
"	14 Hulle verkwik die droë lippe en dié wat nie meer wilskrag het nie, tel Hy op;	",
"	15 Die Siele van dié wat naby aan die dood is, hou hulle terug van die dood;	",
"	16 En ledemate wat neergeval het, trek Hy self weer reguit en rig hulle op:	",
"	17 Hy verleen krag aan hulle verskyning en Lig aan hul oë;	",
"	18 Want elkeen ken hulle in JaHWeH, en deur die waters lewe hulle vir ewig.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '7',
content: [
		
"	1 SOOS die verloop van toorn oor besoedeling, so is die verloop van Vreugde oor die Geliefde Een; en Hy bring van die vrugte in sonder teëstand.	",
"	2 My Vreugde is in JaHWeH, en My rigting is na Hom: Hierdie Weg van My is mooi;	",
"	3 Want Ek het ‘n Helper in JaHWeH. Hy maak Homself sonder teësinnigheid aan My bekend in Sy edelmoedigheid; want in Sy Suiwerheid sit Hy Sy Majesteit eenkant.	",
"	4 Hy het soos Ek geword, sodat Ek Hom sou aanvaar: In voorkoms het Hy soos Ek gelyk, sodat Ek My in Hom sou klee. [JeHôWganan 1:14]	",
"	5 En Ek het nie gebewe toe Ek Hom aanskou nie, want Hy het deernis met My gehad.	",
"	6 Hy het geword soos My natuur, sodat Ek Hom kon leer ken, en soos My gestalte, sodat Ek nie van Hom sou wegdraai nie. [JeHôWganan 1:14]	",
"	7 Die VADER van Kennis gee die Woord van Kennis:	",
"	8 HY wat Wysheid geskep het, is wyser as Haar werke;	",
"	9 en HY wat My geskape het voordat Ek ontstaan het, het geweet wat Ek sou doen wanneer Ek daar was.  [JeHôWganan 14:16]	",
"	10 Daarom het HY My jammer gekry deur SY groot Medelye, en het My toegelaat om van HOM te vra, en om van SY Slagdier te ontvang; [Hebreërs 10:12]	",
"	11 Want Hy is onverderfbaar, die voleinding van die eeue en hulle VADER.	",
"	12 HY het Hom toestemming verleen om te verskyn aan hulle wat Syne is, dat hulle Hom kon herken wat hulle gemaak het en sodat hulle nie dalk mag dink dat hulle deur hulself ontstaan het nie.	",
"	13 Want HY rig Sy Weg na Kennis: HY het haar lank en breed gemaak en haar raseg gemaak;	",
"	14 En HY het op haar die Voetsole van SY Lig geplaas, en Hy het van die begin tot die einde gegaan;	",
"	15 Want HY is deur Hom bedien, en HY het ‘n welbehae in die Seun.	",
"	16 En omrede van Sy Verlossing sal Hy besit neem van alles; Die Hoogste El sal geken word deur SY apartes,	",
"	17 om hulle wat psalms oor die koms van die Meester het, bekend te maak, sodat hul Hom tegemoet kan gaan en vir Hom mag sing, met vreugde en met die harp van vele klanke.	",
"	18 Die sieners sal voor Hom uitgaan, en voor Hom gesien word;	",
"	19 En hulle sal JaHWeH in Sy Liefde prys, want Hy is naby en Hy sien.	",
"	20 En haat sal van die Aarde verwyder word, en sal verdrink saam met afguns;	",
"	21 Want Dwaasheid is vernietig, omdat die Kennis van JaHWeH gekom het.  [Spreuke 9:13]	",
"	22 Diegene wat sing, sal sing van die Barmhartigheid van JaHWeH, die Hoogste El, en hulle sal hul psalms aanbied;	",
"	23 Hul hart sal soos die dag wees en die klank van hul stemme soos die wye skoonheid van JaHWeH. Niks wat lewe sal onkundig of stom wees nie;	",
"	24 Want Hy het aan Sy skepping ‘n Mond gegee, om die Stem van die Mond oop te maak en Hom te loof.	",
"	25 Loof Sy Krag en maak bekend Sy Barmhartigheid.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '8',
content: [
		
"	1 MAAK oop, maak oop julle harte met jubeling tot JaHWeH, en laat julle liefde oorvloei van die hart na die lippe,	",
"	2 om vrugte voort te bring vir JaHWeH, ‘n lewe van Apartheid, en om met waaksaamheid te spreek in SY Lig.	",
"	3 Rig julle op en staan orent, julle wat eens weggesink het:	",
"	4 Julle wat stil was, spreek, want julle Mond is geopen:	",
"	5 Julle wat verag was, rig julself van nou af aan op, want julle Geregtigheid is opgerig;	",
"	6 Want die Regterhand van JaHWeH is met julle en Hy is julle Helper: [2 Ezra 8:10]	",
"	7 En Vrede is vir julle voorberei, nog voor julle oorlog begin het.	",
"	8 Luister na die woord van Waarheid, en ontvang die Kennis van die Hoogste El.	",
"	9 Julle vlees sal nie weet wat Ek vir julle sê nie, ook nie julle kleding wat Ek aan julle bekend maak nie.	",
"	10 Bewaar My Verborgene, julle wat deur Haar onderhou word:	",
"	11 Bewaar My Geloof, julle wat deur Haar onderhou word; [Hebreërs 12]	",
"	12 En begryp My Kennis, julle wat My deur die Waarheid ken.	",
"	13 Wees lief vir My met toege-neentheid, julle wat bemin.	",
"	14 Want Ek wend nie My Aangesig af van hulle wat Myne is nie, omdat Ek hulle ken;	",
"	15 En voordat hulle ontstaan het, het Ek hulle waargeneem; en My Seël op hul aangesigte geplaas. [Exodus 28:36, 37]	",
"	16 Ek het hul liggaamsdele gefor-meer; en My borste het Ek vir hulle voorberei, sodat hulle My melk van Apartheid mag drink en daardeur mag lewe.	",
"	17 Hulle was vir My welbehaaglik en Ek skaam My nie vir hulle nie;	",
"	18 Want hulle is My eie werke, en die Krag van My denke.	",
"	19 Wie, derhalwe sal teen My werke opstaan? Of wie is hy wat nie onderdanig aan hulle is nie?	",
"	20 Ek het hulle verstand en hart geformeer. En hulle is Myne; en Ek het My uitverkorenes aan My regterhand geplaas.	",
"	21 En My Geregtigheid gaan voor hulle uit; hulle sal nie geskei word van My Naam nie, want Sy is met hulle.	",
"	22 Bid en gaan in alle erns voort in die Liefde van JaHWeH, julle wat geliefdes is, in die Geliefde Een; julle wat bewaar word, in Hom wat weer gelewe het; julle wat verlos is, in Hom wat verlos is;	",
"	23 En julle sal onverderfbaar bevind word deur al die eeue, vanweë die Naam van jul Vader.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '9',
content: [
		
"	1 OPEN julle ore en Ek sal tot julle spreek:	",
"	2 Gee julle siele aan My, sodat Ek ook Myself aan julle kan gee,	",
"	3 die Woord van JaHWeH en SY wil, die apartheidsdoel wat HY beplan het aangaande SY Gesalfde.	",
"	4 Want in die Wil van JaHWeH is julle lewe, en julle rasegtheid is onverderfbaar.	",
"	5 Word verryk in JaHWeH die Vader en ontvang die bewussyn van die Hoogste El: Wees sterk en wees verlos deur SY Barmhartigheid.	",
"	6 Want Ek verkondig Vrede aan julle, Sy rasegtes, sodat nie een van dié wat hoor in die oorlog sal val nie,	",
"	7 en dat hulle wat Hom geken het, nie mag vergaan nie, en dat hulle wat Hom ontvang het, nie beskaamd sal staan nie.	",
"	8 Waarheid is ‘n ewige Kroon; geseënd is diegene wat Haar op hul hoofde plaas, [Exodus 28:36, 37; ZekarJaH 3:5; Openbaring 2:10]	",
"	9 ‘n Steen van groot waarde; want die oorloë is as gevolg van die Kroon;	",
"	10 En Geregtigheid het Haar geneem, en Haar aan julle gegee. [JeshaJaH 60:17]	",
"	11 Sit die Kroon op in die ware Verbond van JaHWeH; en almal wat oorwin het, sal in Sy Boek opgeskryf word;  [Openbaring 21:27]	",
"	12 Want Sy Boek is die oorwinning wat julle s’n is; en Hy sien julle daarvoor en Hy begeer dat julle verlos word.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '10',
content: [
	
"	1 JaHWeH het My Mond deur SY Woord gerig, en My Hart deur SY Lig geopen,	",
"	2 en het teweeg gebring dat SY Ewige Lewe in My bly; en het My vergun om van SY vrugte van Vrede te vertel,	",
"	3 Om die siele van diegene wat na Hom wil kom, terug te bring, en om ‘n aansienlike groep gevangenes(siele) terug te lei na vryheid.	",
"	4 Ek het sterk en magtig geword, en het die Aarde se gevangenes gelei en hulle het vir My die Glansrykheid van die Hoogste El geword, ja, van JaHWeH, My VADER.	",
"	5 En die nasies wat verstrooi was, is versamel, en Ek is nie besoedel deur My skuld nie, omdat hulle My lof toegebring het op die hoë plekke. [Hebreërs 9:28]	",
"	6 En die voetspore van Lig is op hul harte geplaas, en hulle het gewandel in My lewe en is verlos, en het My volk geword, vir Ewig tot in Ewigheid.Halalu-JaHH/Prys jul JaHH!	",
		

]
},
{
book: 'Odes_Van_Salomo',
chapter: '11',
content: [
		
"	1 My hart is besny en haar blomme het verskyn, Barmhartigheid het in haar uitgespruit; en sy het vrugte gedra vir JaHWeH.	",
"	2 Want die Hoogste El het my besny met Sy Gees van Apartheid en my niere voor Hom blootgelê; en my gevul met Sy Liefde.	",
"	3 En Sy besnydenis het my Verlossing geword; en ek het op die Weg in Sy Vrede gehardloop en op die Weg van Waarheid:	",
"	4 Vanaf die begin tot die einde het ek Sy Kennis ontvang.	",
"	5 En ek is stewig gevestig op die Klip van Waarheid, waar Hy my geplaas het;	",
"	6 En waters wat spreek, het my lippe aangeraak van JaHWeH se Fontein, sonder terughouding;	",
"	7 En ek het gedrink en was bedwelm deur die lewende, onsterflike waters;	",
"	8 En my bedwelming was nie sonder Kennis nie, maar ek het Ydelheid verlaat.	",
"	9 En my gewend tot die Hoogste El, my Elohey, en het deur Sy Gawe verryk geword;	",
"	10 Ek het Dwaasheid laat staan, sy wat oor die Aarde uitgewerp is en ek het haar afgestroop en van my af weggewerp;	",
"	11 JaHWeH het my vernuwe met Sy kleed, en van my besit geneem met Sy Lig,	",
"	12 en my onverderfbare verkwikking van bo gegee, en ek het geword soos die Aarde wat laat uitspruit en haar verheug in haar vrugte,	",
"	13 En JaHWeH is soos die son op die aangesig van die Aarde:	",
"	14 Hy het my oë verlig en my gesig het die Dou ontvang;	",
"	15 My asemteue het behae gevind in die aangename geur van JaHWeH;	",
"	16 Hy het my gebring na Sy Paradys waar die rykdom van die genot van JaHWeH is. [Griekse invoeging] Ek het bome gesien, pragtig en wat vrugte dra, En hul kroon was natuurlike loof; Hul takke het gespruit, hul vrugte het gelag; Hul wortels was geplant in die onverganklike Adamah[adamiet se Aarde]. En die rivier van Vreugde het hul benat, en het om hul onverganklike Adamah[adamiet se Aarde] gevloei.	",
"	17 En ek het JaHWeH aanbid vanweë Sy Glansrykheid.	",
"	18 En ek het gesê, geseënd, o JaHWeH, is diegene wat in U Adamah[adamiet se Aarde] geplant is en diegene wat ‘n plek in U Paradys het,	",
"	19 en wat opgroei in die wasdom van U bome en wat van Donkerte na Lig beweeg het.	",
"	20 Kyk, al U diensknegte is voortreflik. Hulle wat suiwer werke doen,	",
"	21 van besoedeling draai na U Vreugde en die bitterheid van die bome is verander toe hulle in U Adamah[adamiet se Aarde] geplant is.	",
"	22 Alles het geword soos ‘n aandenking aan U en ‘n ewige herinnering aan U getroue diensknegte.	",
"	23 Want daar is baie plek in U Paradys, en daar is niks wat sonder voordeel is nie; maar alles dra vrug.	",
"	24 Eer aan U, o Elohim, die Vreugde wat in die ewige Paradys is.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '12',
content: [
		
"	1 HY het my gevul met die woorde van Waarheid, sodat ek van Hom mag spreek;	",
"	2 Waarheid het uit my mond gevloei soos ‘n stroom water, en my lippe het Haar vrugte bekend gemaak.	",
"	3 Sy het my laat oorloop met Haar Kennis, want die Mond van JaHWeH is die ware Woord, en die Poort van Sy Lig.	",
"	4 Die Hoogste El het Haar aan Sy wêrelde gegee, die vertolkers van Sy Prag, en die vertellers van Sy Glansrykheid, en die belyers van Sy denke, en die verkondigers van Sy gedagte, en die Apartheid van Sy werke.	",
"	5 Want van die vlugheid van Haar woord kan nie vertel word nie, en soos Haar vertelling, so ook is Haar snelheid en Haar spoed, en Haar rigting is onbeperk:	",
"	6 Sy val nooit, maar staan vas, en Sy ken nie Haar afkoms, nog Haar weg nie.	",
"	7 Want soos Haar werk is, so is Haar verwagting; want Sy is die Lig en sonsopkoms van gedagtes.	",
"	8 En deur Haar het die wêrelde met mekaar gepraat, en hulle wat stom was, het spraak bekom;	",
"	9 En deur Haar het vriendskap en samehorigheid ontstaan, en hulle het die een met die ander gespreek, dit wat hulle te sê gehad het;	",
"	10 En hulle is aangespoor deur die Woord; en hulle het Hom wat hulle gemaak het, geken, want hulle het saamgestem;	",
"	11 Want die Mond van die Hoogste El het met hulle gespreek, en deur Haar het Sy openbaring vrye teuels gehad.	",
"	12 Want die Woning van die Woord is die Seun van Adam. En die Waarheid is Sy Liefde.	",
"	13 Geseënd is hulle wat alles deur Haar verstaan het, en JaHWeH in Sy Waarheid geken het.Halalu-JaHH/Prys jul JaHH!	",
		

]
},
{
book: 'Odes_Van_Salomo',
chapter: '13',
content: [
		
"	1 KYK, JaHWeH is ons spieël: Open jou oë en sien hulle in HOM;	",
"	2 En leer hoe jou aangesig is en uiter lofprysinge aan SY Gees;	",
"	3 Vee die vuilheid van jou gesig af, en wees lief vir SY Apartheid en trek Haar aan;	",
"	4 En jy sal rassuiwer wees, al die tyd saam met hom. Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '14',
content: [
	
"	1 SOOS die oë van ‘n Seun gerig is op Sy VADER, so is My oë, o JaHWeH, voortdurend op U gerig;	",
"	2 Want saam met U is My Borste en My Vreugde. [Sirah 24:1]	",
"	3 Wend nie U Medelye van My af nie, o JaHWeH, en neem nie U Suiwerheid van My weg nie.	",
"	4 Strek U Regterhand voortdurend uit na My, o My Elohey en wees vir My ‘n Leidsman tot die einde, omdat Sy U Vreugde is.	",
"	5 Ek sal welgevallig voor U wees omrede van U Glansrykheid, en omrede van U Naam, sal Ek verlos word van die Besoedelde een;	",
"	6 U Teerheid, o JaHWeH, sal by My bly as die vrugte van U Liefde.	",
"	7 Leer My die psalms van U Waarheid, dat Ek in U vrug mag dra;	",
"	8 En open die Harp van U Gees van Apartheid vir My, sodat Ek U mag loof, o JaHWeH, met elke melodie.	",
"	9 En volgens die oorvloed van U Medelye; mag U My Haar so gun en haas U om Ons versoeke toe te staan.	",
"	10 En U voorsien voldoende aan al Ons behoeftes.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '15',
content: [

		
"	1 SOOS die son ‘n vreugde is vir diegene wat sy daglig soek, so is My vreugde JaHWeH.	",
"	2 Want Hy is My son, en Sy strale het My opgewek, en Sy Lig het al die donkerte van My gesig verdryf.  [2Nikodemus 5:3c]	",
"	3 Ek het deur Hom Oë verkry, en het Sy dag van Apartheid gesien.	",
"	4 Ore het Myne geword, en Ek het Sy Waarheid gehoor.	",
"	5 Die gedagte van Kennis het Myne geword, en Ek het My verheug deur Hom.	",
"	6 Ek het die dwaalweg verlaat, en Ek het na Hom gegaan, en het van Hom Verlossing sonder voorbehoud ontvang; [Hooglied van Salomo 1:6]	",
"	7 Volgens Sy gawe het Hy vir My gegee, en volgens Sy wonderskoonheid het Hy My gemaak.	",
"	8 Deur Sy Naam het Ek onverdorwenheid aangetrek, en deur Sy Barmhartigheid het Ek verganklikheid afgewerp.	",
"	9 Dood is voor My aangesig vernietig, en die Doderyk/Sheol is tot niks gebring deur SY Woord.	",
"	10 Ewige Lewe het verrys in die Adamah [die adamiet se Aarde] van JaHWeH, en Sy het aan Sy getroues bekend geword, en is mildelik gegee aan almal wat op Hom vertrou.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '16',
content: [
		
"	1 SOOS die werktuig van die ploeër die ploegskaar is, en die werk van die stuurman om te stuur, so ook is My werk die psalm van JaHWeH in SY lofprysinge.	",
"	2 My ambag en beroep is in SY lofprysinge. Omdat SY Liefde My hart gevoed het en SY Vrug na My lippe gebring het.	",
"	3 Want My liefde is JaHWeH, daarom sal Ek tot HOM sing;	",
"	4 Want Ek word sterk gemaak deur SY lofprysinge en Ek het vertroue in HOM.	",
"	5 Ek sal My mond open, en SY Gees sal in My verklaar die Glansrykheid van Elohim en SY skoonheid,	",
"	6 die werke van SY Hande, en wat SY Vingers gemaak het,	",
"	7 vir SY menigvuldige Medelye en vir die Krag van SY Woord.	",
"	8 Want die Woord van JaHWeH speur na dit wat onsigbaar is en neem SY gedagtes waar;	",
"	9 Want die Oog sien SY werke en die Oor hoor SY gedagtes.	",
"	10 HY het die Aarde uitgespan, en die waters in die see daar gestel:	",
"	11 HY het die Hemele uitgesprei en die Sterre in hul ordes gestel;	",
"	12 En die skepping georden en dit gevestig; en HY het gerus van SY werke.	",
"	13 En die dinge wat geskep is, loop in hul bane en verrig hul take. En weet nie hoe om stil te staan en ledig te wees nie;	",
"	14 En die Leërskare is onderhorig aan SY Woord.	",
"	15 Die skatkamer van die Lig is die son, en die skatkamer van die Duisternis is die nag;	",
"	16 En Hy het die son vir die dag gemaak, sodat hy helder kan wees. En nag bring Duisternis oor die hele Aarde.	",
"	17 Hulle neem oor, die een van die ander; hulle verkondig die skoonheid van Elohim.	",
"	18 En daar is niks wat afsonderlik van JaHWeH is nie, want HY was daar voordat enigiets ontstaan het.	",
"	19 En die Wêrelde het ontstaan deur SY Woord, en deur die gedagte van SY Hart.	",
"	20 Glansrykheid en ere aan SY Naam.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '17',
content: [
		
"	1 EK is gekroon deur My Elohim en My Kroon is die Lewende Een;	",
"	2 Ek is geregverdig deur My Meester, en My Verlossing is onverganklik:	",
"	3 Ek is bevry van nuttelose dinge, en Ek is nie ‘n veroordeelde man nie.	",
"	4 My bande is verbreek deur SY Hande: Ek het die gesig en gedaante van ‘n nuwe adamiet ontvang; en Ek het in HOM gewandel en is verlos.	",
"	5 Die gedagte aan Waarheid het My gelei; en Ek het Haar nagestreef en nie afgedwaal nie.	",
"	6 Almal wat My gesien het, was verstom, en Ek was vir hulle soos ‘n vreemdeling.	",
"	7 HY wat My geken het en My grootgemaak het, is die Hoogste El in al SY rasegtheid; En HY het My hoog geag in SY Suiwerheid, en HY het My Verstand uitgelig tot die hoogste van Waarheid.	",
"	8 En daarvandaan het HY My die Weg van SY voetstappe gewys, en Ek het die Poorte wat toe was, geopen. [Génesis 3:24]	",
"	9 Ek het die tralies van yster in stukke gebreek; maar My kettings het warm geword en voor My gesmelt.	",
"	10 Dit was vir My asof niks gesluit was nie, want Ek was die Ingang van alles;	",
"	11 Ek het na al My gevangenes gegaan om hulle te bevry, sodat Ek geeneen gebonde moes laat nie. [2 Nikodémus 5; Psalm 30:3]	",
"	12 Ek het My Kennis sonder teësinnigheid gegee, en My gebed was met liefde.	",
"	13 Ek het My vrugte in harte gesaai, en Ek het hulle in Myself herskep.	",
"	14 Hulle het My Seën ontvang en gelewe, en is by My versamel en verlos,	",
"	15 want hulle het My lede geword, en Ek is hulle Hoof.Glansrykheid aan U, Ons Hoof, o Ons Meester, ons Gesalfde, Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '18',
content: [
		
"	1 My Hart is opgetel deur die Liefde van die Hoogste El, en is verruim, sodat ek HOM kan prys deur My Naam.	",
"	2 My Ledemate is versterk, sodat Hulle nie sal wegkeer van SY Krag nie:  [Markus 9:9]	",
"	3 Siektes het gewyk van My liggaam, en dit het opgestaan vir JaHWeH, omdat HY dit gewil het, want SY koninkryk is standvastig.	",
"	4 0 JaHWeH, sal U U Woord van My wegneem, as gevolg van hulle wat Kennis van U kortkom?	",
"	5 Ook nie as gevolg van hul werke, sal U U volmaaktheid van My weerhou nie.	",
"	6 Die Lig sal nie deur Duisternis oorwin word nie, ook sal Waarheid nie wegvlug van die Leuen nie.	",
"	7 U Regterhand sal Ons Verlossing laat seëvier, en U sal van elke plek ontvang, en sal behoed elkeen wat vasgehou word deur besoedeling.	",
"	8 U is My Elohim; die Leuen en Dood is nie in My mond nie. Maar U wil is volmaaktheid;	",
"	9 U ken nie Ydelheid nie, want dit ook, ken Ek nie,	",
"	10 U ken nie oortredinge nie, want dit ook, ken Ek nie.	",
"	11 Dwaasheid het verskyn soos fyn stof en soos die skuim van die see.	",
"	12 Verwaande mense het oor haar gedink dat sy uitmuntend was: hulle het ook begin om ‘n ooreenkoms met haar te toon, en het nutteloos geword.	",
"	13 Diegene wat Kennis het, het verstaan en gedink, en was nie besoedel in hul gedagtes nie.	",
"	14 Want hulle was in die gedagtes van die Hoogste El, en hulle het gelag vir dié wat in die leuen gewandel het:	",
"	15 Maar hulle het die Waarheid gespreek deur die inspirasie wat die Hoogste El in hulle geblaas het.	",
"	16 Glorie en groot eerbetoon aan SY Naam.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '19',
content: [
	
"	1 ‘N BEKER saad was My aangebied, en Ek het hom ingeneem as die soetheid van die Suiwerheid van JaHWeH.	",
"	2 Die Seun is die Beker en HY wat getap is, is die VADER, en Sy wat HOM getap het, is die Gees van Apartheid;	",
"	3 Want SY saadorgaan was vol, en dit was nie wenslik dat SY saad sonder rede afgeskei word nie;	",
"	4 Die Gees van Apartheid het Haar skoot geopen en die saad vanuit die twee saadselle van die VADER vermeng, [Lukas 2:21]	",
"	5 en het die Mengsel aan die wêreld gegee sonder dat hulle daarvan bewus was; en hulle wat Hom ontvang, is in die volheid van die Regterhand.	",
"	6 Die baarmoeder van die maagd het Hom omhels en sy het swanger geword en gebaar.	",
"	7 Die maagd het ‘n moeder met groot deernis geword;	",
"	8 Sy was in barensweë en het ‘n Seun gebaar sonder om pyn te voel, omdat Hy nie sonder ‘n rede ontstaan het nie;	",
"	9 Sy het nie ‘n vroedvrou verlang nie, want HY het haar verlos. [Boodskap van Jakobus 19:3]	",
"	10 Sy het gebaar, soos dit is, ‘n Man, deur die Wil van Elohim, en het Hom gebaar en Hom bekend gemaak, en het Hom in groot Krag verkry;	",
"	11 En sy het Hom liefgehad met die bevalling, en Hom bewaak met minsaamheid en Hom in grootheid bekend gemaak. Halalu-JaHH/Prys jul JaHH! [Boekrol van Henog 62:7]	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '20',
content: [
		
"	1 EK is ‘n Priester van JaHWeH en tot HOM verrig Ek dienswerk as Priester,	",
"	2 Aan HOM slag Ek die slagdier van SY gedagte.	",
"	3 Want nie soos die wêreld nie, en ook nie soos die vlees is SY denke nie, ook nie soos diegene wat bedien op ‘n vleeslike wyse nie.	",
"	4 Die Slagdier van JaHWeH is Regverdigheid, en suiwerheid van hart en lippe. [Hebreërs 10:12]	",
"	5 Offer jou niere vlekkeloos, en moenie dat jou ingewande ‘n ander se ingewande kwel nie, en moet ook nie dat jou siel ‘n ander se siel kwel nie.	",
"	6 Jy mag nie ‘n baster verwek deur die bloed van jou siel nie, ook mag jy nie probeer om jou naaste te bedrieg nie, ook mag jy hom nie die bedekking van sy naaktheid ontneem nie.	",
"	7 Maar beklee jou met die Barmhartigheid van die gewillige Meester; en kom na die Paradys. En maak vir jouself ‘n Krans vir versiering van Sy Boom, [Spreuke 4:9]	",
"	8 plaas haar op jou hoof en verlustig jou in haar, en leun op haar kalmte.	",
"	9 Sy Glansrykheid sal jou vooruitgaan, en jy sal van Sy Minsaamheid en Suiwerheid ontvang, en vet word in die Glansrykheid van Sy Apartheid.	",
"	10 Glansrykheid en Eer aan Sy Naam.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '21',
content: [
		
"	1 EK het My arms opgehef na die Medelye van JaHWeH,	",
"	2 Want Hy het My bande weggewerp; en My helpers het My opgerig tot Sy Medelye en Verlossing. [Hooglied van Salomo 2:9]	",
"	3 Ek het die Duisternis afgelê en My met Lig beklee.	",
"	4 My Siel het lede verkry, waarin daar geen pyn was nie, ook nie ellende of lyding nie.	",
"	5 En net wat gerusstellend was, het My gedagtes aan JaHWeH laat bly, en aan Sy onverganklike gemeenskap.	",
"	6 Ek was in Sy Lig opgehef, en Ek het voor Sy Aangesig verbygegaan; [Hooglied van Salomo 5:6]	",
"	7 Ek het naby aan Hom gekom, terwyl Ek Hom geloof en gedank het.	",
"	8 Hy het My Hart laat oorloop en Hy is in My Mond gevind en Hy het verskyn op My Lippe,	",
"	9 die jubeling van JaHWeH en SY lofprysing het My Aangesig verlig.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '22',
content: [
		
"	1 HY wat My van die hoogtes [Hemele] afgebring het, en My van die onderwêreld [Doderyk/Sheol] af opgehef het.	",
"	2 HY wat die dinge wat in die middel was, versamel het, en dit vir My laag gemaak het,	",
"	3 HY wat My vyande verstrooi het, asook My teëstanders;	",
"	4 HY wat My mag gegee het oor bande, sodat Ek hulle kan losmaak;	",
"	5 HY wat deur My Hande die Draak met sewe koppe oorwin het, en U wat My gestel het oor sy wortel, sodat Ek sy saad tot niet mag maak. [Openbaring 13; Openbaring 17; DaniEl 14:23-42]	",
"	6 Dit is U: U was daar en het My gehelp, en in elke plek is U Naam deur My geloof. [JeHôWganan 17:6]	",
"	7 U Regterhand het sy besoedelde gif vernietig; en U Hand het die Weg gelyk gemaak vir die wat in U glo,	",
"	8 en het hulle uit die grafte uitverkies, en hulle apartgestel van die dooies:	",
"	9 Sy het dooie beendere geneem en hul met liggame bedek;	",
"	10 Hulle was bewegingloos, en Sy het hulle lewenskrag verleen om te lewe. [JeségiEl 37:10]	",
"	11 U Weg en U Persoon was onverderflik, U het U wêreld tot verdorwenheid gebring, sodat alles kon vergaan en vernuwe word.	",
"	12 En sodat U Rots die fondament van alles kon wees; en op Hom het U U Koninkryk gebou; En U het die Woonplek van die Apartes geword.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '23',
content: [
		
"	1 BLYDSKAP behoort aan die apartes, en wie sal met Haar beklee word, behalwe hulle?	",
"	2 Barmhartigheid behoort aan die uitverkorenes, en wie sal Hom ontvang, behalwe hulle wat van die begin af op Hom vertrou het?	",
"	3 Liefde behoort aan die uitverkorenes, en wie sal met Haar beklee word, behalwe hulle wat Haar van die begin af besit het?	",
"	4 Wandel in die Kennis van die Hoogste El, en jy sal die Guns van JaHWeH, sonder teësinnigheid, ken: SY jubeling en die Suiwerheid van SY Kennis.	",
"	5 SY gedagtes was soos ‘n Boekrol, SY Wil het neergekom van omhoog; [JeshaJaH 5:28]	",
"	6 En hy is gestuur soos ‘n pyl uit ‘n boog, wat afgevuur word met krag; [Openbaring 6:2; Psalm 127:4]	",
"	7 En vele hande het afgepyl op die Boekrol om hom te gryp en hom te neem en hom te lees;	",
"	8 En hy het uit hulle vingers ontsnap; en hulle was vol vrees vir hom en vir die Seël wat op hom was. [JeshaJaH 29:10-12]	",
"	9 Want hulle was nie toegelaat om sy Seël te verbreek nie, want die Krag wat op die Seël was, was groter as hulle.	",
"	10 Maar hulle wat hom gesien het, het agter die Boekrol aangegaan, sodat hulle kon weet waar sy bestemming was, en wie hom sou lees, en wie hom sou hoor. [JeshaJaH 29:18-21; Maleagi 3:16]	",
"	11 Maar ‘n wiel het hom ontvang, en sy het op hom neergedaal;	",
"	12 Tesame met hom was ‘n Teken van Koningskap en van Heerskappy.	",
"	13 Alles wat voor die wiel beweeg het, het hy gemaai en afgesny; [JeshaJaH 41:15; Miga 4:13]	",
"	14 Hy het ‘n menigte van teëstanders versamel; en Hy het riviere bedek; [Odes van Salomo 39:1Openbaring 12:15]	",
"	15 Hy het oorgegaan en baie volke ontwortel en ‘n breë Pad gemaak.	",
"	16 Die Hoof het neergedaal na die Voete, want sover as die Voete gaan het die wiel gerol saam met hom wat op haar was. [JeségiEl 1:19; JeshaJaH 60:14-17]	",
"	17 Hy was ‘n Boekrol en ‘n Bevel, want alle plekke is byeengebring.	",
"	18 Op sy hoof het die Hoof verskyn wat geopenbaar is, en die Seun van die Waarheid van die Hoogste El VADER. [JeségiEl 1:26; 2 Ezra 7:26]	",
"	19 Hy het van alles besit geneem en hom ontvang; en die denke van vele het tot niks gekom nie. [MattithJaHûW 5:17-18]	",
"	20 En almal wat op ‘n dwaalspoor gelei is, het ontsnap en gevlug en hulle wat vervolg het, is vernietig en uitgewis.	",
"	21 Maar die Boekrol het ‘n groot Plaat van Herinnering geword, wat geheel en al geskryf is deur die Vinger van Elohim; en die Naam van die VADER was op hom, en van die Seun, en van die Gees van Apartheid, om te regeer vir Ewig tot in Ewigheid.Halalu-JaHH/Prys jul JaHH! [Maleagi 3:16; Openbaring 14:1; Exodus 28:36-37]	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '24',
content: [
		
"	1 DIE Duif het afgevlieg op die hoof van ons Meester, ons Gesalfde, want Hy was Haar hoof.	",
"	2 Sy het oor Hom gesing, en Haar Stem is gehoor. [MattithJaHûW 3:16-17]	",
"	3 Die bewoners het gevrees, en die verbasterdes het gesidder.	",
"	4 Die vlieënde wesens het opgevlieg en al die reptiele is dood in hulle gate.	",
"	5 En die Afgrond is geopen en weer toegemaak, en hulle het die Gesalfde gesoek soos diegene in barensnood;	",
"	6 Maar Hy is nie aan hulle gegee as voedsel nie, want Hy was nie hulle s’n nie.	",
"	7 Maar die dieptes is gedompel in die indompeling van JaHWeH, en diegene wat van ouds bestaan het, het omgekom in daardie gedagte;	",
"	8 Want hulle het van die begin af verdorwe geraak, en die voltooiing van hulle barensnood was lewe.	",
"	9 Elkeen van hulle, by wie ontbreek het, het omgekom, omdat hulle geen woord gehad het om te sê nie, om daardeur agter te bly nie.	",
"	10 Elohim het die gedagtes vernietig van hulle met wie die Waarheid nie was nie;	",
"	11 Want hulle het Wysheid kortgekom, hulle wat trots van hart was.	",
"	12 En hulle is verwerp, want die Waarheid was nie met hulle nie,	",
"	13 Omdat Elohim SY Weg bekend gemaak het, en SY Barmhartigheid uitgebrei het.	",
"	14 En hulle wat Hom bemerk het, ken SY Apartheid.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '25',
content: [
		
"	1 EK het ontsnap uit My boeie, en na U het Ek gevlug, o My Elohim,	",
"	2 Want U Regterhand was ‘n Verlossing, en My Helper.	",
"	3 U het hulle wat teen My opgestaan het, teëgehou, en Ek sal hulle nie weer aanskou nie,	",
"	4 Want U Seun was met My, wat My gered het deur U Barmhartigheid.	",
"	5 Maar Ek is verag en verwerp in die oë van baie, en Ek was in hulle oë soos lood.  [Hooglied 1:6]	",
"	6 En Krag van U is aan My gegee, en Hulp.	",
"	7 U het ‘n Lamp vir My opgestel, aan My regterhand en aan My linkerhand, sodat daar niks binne My sonder Lig sou wees nie.	",
"	8 En Ek is bedek met die bedekking van U Gees, en U het My klere van vel verwyder,	",
"	9 want U Regterhand het My opgehef, en het gewil dat siekte van My verwyder word.	",
"	10 Ek het magtig in die Waarheid geword en apart in U Geregtigheid.	",
"	11 Almal wat teen My was, het My gevrees, en Ek het JaHWeH s’n geword, in die Naam van JaHWeH.	",
"	12 Ek is geregverdig deur Sy Suiwerheid; en Sy rus vir ewig.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '26',
content: [
		
"	1 EK het lof tot JaHWeH uitgestort, omdat Ek Syne is.	",
"	2 Ek sal Sy psalm van Apartheid voordra, omdat My Hart met Hom is;	",
"	3 Want Sy harp is in My Hande, en die psalms van Sy rus sal nie swyg nie.	",
"	4 Ek sal tot Hom roep met My hele Hart: Ek sal Hom prys en verhoog met al My Ledemate;	",
"	5 Want van die ooste tot die weste is die lofprysinge Syne.	",
"	6 En van die noorde tot die suide is die danksegging Syne.	",
"	7 En van die kruin van die hoogtes, tot by hulle verste punt is Suiwerheid Syne.	",
"	8 Wie kan die psalms van JaHWeH skryf, of wie kan hulle voordra?	",
"	9 Of wie kan Sy siel lewenslank onderrig, sodat Sy siel verlos mag word?	",
"	10 Of wie kan op die Hoogste El rus, sodat hy deur SY Mond kan spreek?	",
"	11 Wie is in staat om die wonders van JaHWeH te vertolk? want hy wat vertolk, sal vernietig word, en wat vertolk moet word, sal oorbly.	",
"	12 Want dit is voldoende om te weet en te rus; want die psalmiste bly in rus;	",
"	13 Soos ‘n rivier wat ‘n oorvloedige bron het, en vloei tot hulp van hulle wat dit soek.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '27',
content: [
		
"	1 EK het My hande uitgebrei, en My Elohey apart gestel;	",
"	2 Want die uitstrek van My hande is SY Teken, [Odes van Salomo 29:7]	",
"	3 En My uitstrekking is die regop hout [folterpaal].Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '28',
content: [
		
"	1 SOOS die vlerke van ‘n duif oor haar kleintjies en die bekke van die kleintjies gerig is na hulle [moeders se] bekke, so ook is die Vleuels van die Gees oor My Siel. [Hooglied van Salomo 3:11, 6:9]	",
"	2 My Siel is verheug en spring op van vreugde, soos die kindjie wat in Sy Moeder se baarmoeder opspring.	",
"	3 Ek het geglo: daarom was Ek rustig, want HOM in wie Ek geglo het, is getrou.	",
"	4 HY het My ryklik geseën en My hoof is tot HOM gerig; en geen swaard sal My van HOM skei nie, ook geen lem nie;	",
"	5 Want Ek is gereedgemaak voordat vernietiging gekom het, en Ek is neergesit op SY onverderfbare Vleuels,	",
"	6 Ewige Lewe het My omhels en My gekus.	",
"	7 Deur Haar is die Gees binne My en Sy kan nie sterf nie, want Sy lewe.	",
"	8 Die wat My aanskou het, het gewonder, want Ek is vervolg;	",
"	9 Hulle het gedink dat Ek verswelg is, want Ek het vir hulle voorgekom as een van diegene wat tot niet gaan,	",
"	10 maar My verdrukking het My Verlossing geword.	",
"	11 En Ek het vir hulle ‘n gruwel geword, omdat daar geen afguns in My was nie;	",
"	12 Omdat Ek goed gedoen het aan elke adamiet, is Ek gehaat;	",
"	13 Hulle het My omsingel soos dol honde wat onwetend hulle meesters aanval, [Psalm 69]	",
"	14 Omdat hulle verstand verdorwe is en hulle intellek verdraaid.	",
"	15 Maar Ek het waters in My regterhand gehou, en Ek het hulle bitterheid verduur deur My soetheid;	",
"	16 En Ek het nie vergaan nie, want Ek was nie hul broer nie, nog was My geboorte soos hulle s’n. [Odes van Salomo 10]	",
"	17 En hulle het My dood gesoek, maar was nie suksesvol nie, want Ek was ouer as hulle geheue en vergeefs het hulle My aangeval.	",
"	18 Diegene wat agter My aan was, het tevergeefs probeer om die herinnering aan Hom wat voor My was, te vernietig;	",
"	19 Want die denke van die Hoogste El word nie gefnuik nie, en SY Hart is beter as alle Wysheid.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '29',
content: [
		
"	1 JaHWeH is My hoop: Ek sal nie in HOM beskaamd wees nie.	",
"	2 Want volgens SY Glansrykheid het HY My gemaak; en volgens SY Suiwerheid het HY aan My gegee,	",
"	3 En volgens SY deernis het HY My opgerig; en volgens SY uitmuntende skoonheid het HY My verhef;	",
"	4 HY het My opgebring vanuit die dieptes van die Doderyk/Sheol; en uit die kake van die Dood het HY My getrek. [2 Nikodémus 5]	",
"	5 HY het My vyande verneder en HY het My in Sy Barmhartigheid geregverdig;	",
"	6 Want Ek het in JaHWeH se Gesalfde geglo en dit was vir My duidelik dat Hy die Gesalfde was.	",
"	7 en Hy het My Sy Teken gewys en My in Sy Lig gelei; [Odes van Salomo 27]	",
"	8 En Hy het die Staf van Sy sterkte aan My gegee, sodat Ek die gedagtes van Sy volk mag onderdruk en die krag van magtige manne kan platdruk;	",
"	9 Om oorlog te voer deur Sy Woord en om die oorwinning te behaal deur Sy Krag.	",
"	10 JaHWeH het My vyand neergevel deur SY Woord en hulle het geword soos kaf wat deur die wind weggevoer word. [Hebreërs 4:12]	",
"	11 Ek het die Hoogste El geloof, want HY het SY Kneg en die Seun van SY Diensmaagd groot gemaak.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '30',
content: [
		
		
"	1 SKEP vir julself water van die Lewende Fontein van JaHWeH, want Sy is vir julle geopen. [Openbaring 21:6]	",
"	2 En kom, almal julle wat dors het en neem ‘n teug, en rus by die Fontein van JaHWeH,	",
"	3 Want Sy is voortreflik en suiwer en verskaf rus aan die siel. [Hebreërs 4:9]	",
"	4 Want Haar waters is meer genotvoller as heuning, en die heuningkoek van bye is nie met Haar te vergelyk nie; [Hooglied 4:11]	",
"	5 Want Sy kom van die Lippe van JaHWeH en van die Hart van JaHWeH is Haar Naam. [Wysheid van Sirah 24:3; Wysheid van Salomo 7:25]	",
"	6 Sy het ongehinderd en ongesiens gekom, en totdat Sy in hulle midde geplaas is, het die mense nie van Haar geweet nie. [2 Ezra 7:26]	",
"	7 Geseënd is dié wat van Haar gedrink het, en deur Haar verfris is. Halalu-JaHH/Prys jul JaHH! [Wysheid van Sirah 6:32; 15:5]	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '31',
content: [
		
"	1 DIE Afgrond het voor JaHWèshua gesmelt en Duisternis is met Sy verskyning vernietig.	",
"	2 Oortreding het gedwaal en voor Hom tot niet gegaan, en Dwaasheid het onaktief geword, en sy het gesink vanweë die Waarheid van JaHWeH.	",
"	3 Hy het Sy Mond geopen en Barmhartigheid en Vreugde gespreek, en ‘n nuwe lied van lof tot SY NAAM geuiter;	",
"	4 Hy het Sy stem opgehef tot die Hoogste El, en HY het daardie seuns wat ontstaan het deur HOM aan Hom aangegee;	",
"	5 En Sy persoon is geregverdig, omdat Sy VADER van Apartheid dit aan Hom gegee het dat dit so sou wees.	",
"	6 Kom nader, julle wat verdruk was en ontvang Vreugde;	",
"	7 En neem deur Barmhartigheid van julle siele besit, en neem vir julself Ewige Lewe.	",
"	8 En hulle het My verdoem toe Ek opgestaan het, Ek wat nie te veroordeel was;	",
"	9 En hulle het My buit verdeel, alhoewel niks hulle toegekom het nie.	",
"	10 Maar Ek het dit verdra en was stil en rustig, sodat Ek nie deur hulle beweeg sou word nie;	",
"	11 Maar Ek het onbeweeglik gestaan soos ‘n vaste Rots wat deur die golwe geslaan word, en tog bly voortbestaan;	",
"	12 En Ek het hulle bitterheid as gevolg van vernedering verdra, ten einde My volk te kon verlos en van haar besit te neem,	",
"	13 Sodat Ek nie die beloftes aan die aartsvaders leeg sou bewys nie, wie se saad Ek beloof het om te verlos.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '32',
content: [
		
"	1 DIE geseëndes het blydskap vanuit hulle hart, en Lig van Hom wat in hulle woon,	",
"	2 en die Woord van die Waarheid wat van Homself was;	",
"	3 Omdat Hy sterk geword het in die Krag van Apartheid van die Hoogste El, en onwrikbaar sal bly vir Ewig tot in Ewigheid.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '33',
content: [
		
"	1 MAAR weer eens het Barmhartigheid padgegee en Verdorwenheid agtergelaat, en op Hom neergedaal om Hom tot niet te maak.	",
"	2 Hy het voor HOM totale vernietiging aangerig, en al Sy werke bederf.	",
		
		
"	3 HY het op ‘n hoë piek gestaan en sy stem laat hoor, van een uiteinde van die Aarde tot die ander;	",
"	4 En hy het na hóm aangetrek, almal wat hom gehoorsaam het en hy het nie voorgekom as die Besoedelde een nie.	",
		
		
"	5 MAAR ‘n Volmaakte Maagd het gestaan, en aangekondig en uitgeroep en gesê,	",
"	6 Draai om, julle seuns van adam, en julle, hulle dogters, kom,	",
"	7 En verlaat die weë van verdor-wenheid en kom na My;	",
"	8 En Ek sal julle binnedring en julle uit vernietiging haal en julle wys maak in die Weë van Waarheid.	",
"	9 Moenie verdorwe raak nie, en moenie tot niet gaan nie.	",
"	10 Luister na My en word verlos. Want Ek verkondig aan julle die Barmhartigheid van Elohim.	",
"	11 Deur My sal julle verlos word en geseënd word: Ek is jul Regter.	",
"	12 En diegene wat hulle met My beklee, sal nie verwerp word nie, maar sal Onverdorwenheid in die nuwe wêreld verkry.	",
"	13 0 My uitverkorenes, wandel in My! En Ek sal My Weë bekend maak aan hulle wat My soek, en maak dat hulle in My Naam sal vertrou.Halalu-JaHH/Prys jul JaHH! [Wysheid van Sirah 15:1-10]	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '34',
content: [
		
"	1 DAAR is geen sware weg waar daar ‘n eenvoudige hart is nie, ook nie ‘n belemmering in opregte gedagtes nie;	",
"	2 Ook nie ‘n storm in die diepte van ‘n ingeligte denke nie.	",
"	3 Waar die man wat deugsaam is, aan elke kant omring is, is daar in hom geen wanklank nie.	",
"	4 Die gelykenis wat benede is, is van HOM wat bo is.	",
"	5 Want alles is van bo en van benede is niks nie. Maar daar word veronderstel dat daar iets is, deur hulle wat geen Kennis besit nie.	",
"	6 Barmhartigheid is geopenbaar vir julle Verlossing: Glo, en leef, en wees verlos.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '35',
content: [
		
"	1 DIE Dou van JaHWeH het My oorskadu in rus, en HY het die Wolkkolom van Vrede bo My Hoof gestel	",
"	2 wat My voortdurend behoed het, en My Verlossing geword het.	",
"	3 Alle dinge is geskud en in beroering gebring, en rook en oordeel het van Hulle uitgegaan.	",
"	4 Ek was rustig in die Krygsmag van JaHWeH, en HY was vir My meer as Dou en meer as ‘n fondament.	",
"	5 Ek is soos ‘n Kind deur Sy Moeder gedra, en Sy het vir My die Dou van JaHWeH as melk gegee;	",
"	6 Ek het grootgeword volgens Haar gawe, en Ek het gerus in HAAR Suiwerheid;	",
"	7 Ek het My hande uitgebrei in die opvaart van My Siel, en het opreg gestaan teenoor die Hoogste El, en is deur HOM verlos.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '36',
content: [
		
"	1 DIE Gees van JaHWeH rus op My en Sy hef My op;	",
"	2 En Sy laat My op My Voete op JaHWeH se hoogtes staan, voor SY Suiwerheid en SY Glansrykheid, terwyl Ek besig is om HOM te loof in die toonsetting van psalms.	",
"	3 Sy dra My voor die Aangesig van JaHWeH; en alhoewel Ek ‘n Seun van die Adam is, word Ek genoem die Glansende Een, die Seun van Elohim,	",
"	4 terwyl Ek geprys is tussen hulle wat geprys word en groot is tussen die grotes;	",
"	5 Want volgens die grootheid van die Hoogste El, maak Sy My. Ooreenkomstig SY hernuwing, vernuwe Sy My.	",
"	6 En HY salf My uit SY Suiwerheid, en Ek word een van hulle wat naby HOM is.	",
"	7 En My Mond is geopen soos ‘n wolk met Dou, en My Hart borrel oor, soos ‘n Fontein van Geregtigheid;	",
"	8 My toegang tot HOM is in Vrede, en Ek is gevestig in die Gees van Voorsienigheid.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '37',
content: [
		
"	1 EK het My hande uitgebrei tot My Meester en tot die Hoogste El het Ek My Stem verhef;	",
"	2 Ek het gespreek met die Lippe van My hart, en HY het My gehoor toe My Stem HOM bereik.	",
"	3 SY Woord het tot My gekom, wat My die vrugte van My arbeid gegee het,	",
"	4 En My rus gegee het deur die Barmhartigheid van Elohim.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '38',
content: [
		
"	1 EK gaan op in die Lig van Waar-heid soos in ‘n strydwa, en Waarheid lei my en bring my,	",
"	2 en Sy neem my oor die afgronde en skeure, en  Sy red my van kranse en valleie;	",
"	3 Sy word vir my ‘n hawe van Verlossing, en plaas my neer op die arms van die Ewige Lewe:	",
"	4 En Sy gaan saam met my en gee my rus, en laat my nie oortree nie, want Sy is Waarheid.	",
"	5 Ek is in geen gevaar nie, want ek wandel met Haar, en ek oortree in niks nie, want ek gehoorsaam Haar;	",
"	6 Want dwaling wyk van Haar, en ontmoet Haar nie.	",
"	7 Maar Waarheid gaan op ‘n reguit Weg en alles wat ek nie weet nie, wys Sy my,	",
"	8 Selfs al die bedwelminge van oortreding, en al die kastydings van die dood, wat gereken word as soetheid.	",
"	9 Die Verderwer van verdorwenheid het ek gesien, terwyl ’n bruid wat verdorwe is, besig was om haarself te tooi; selfs ’n bruidegom wat verlei en bedorwe is;	",
"	10 En ek het Waarheid gevra: Wie is hierdie? En Sy het vir my gesê, hy is die Bedrieër en sy is die Dwaling;	",
"	11 Hulle boots die Geliefde Een en Sy Bruid na, en veroorsaak dat die wêreld dwaal, en verderwe haar; [Openbaring Hfs. 13, 17 & 18]	",
"	12 En hulle nooi baie uit na ‘n feesmaal en gee aan hulle die wyn van hul dronkenskap om te drink,	",
"	13 Hulle maak dat hulle hul wysheid en insig braak en hulle bewys hulself as dwaas;	",
"	14 Dan verlaat Sy hulle; maar hulle gaan rond, rasende en bedorwende, want hulle is sonder Insig, omdat hulle Haar ook nie soek nie. [JeshaJaH 14:14]	",
"	15 Ek het verstandig opgetree, sodoende het ek nie in die hande van die Bedrieër geval nie. En ek het myself voorspoed toegewens, omdat Waarheid my vergesel het.	",
"	16 Ek het sterk geword, en geleef, en is verlos. My fondamente is gelê naby JaHWeH; want Hy het my geplant.	",
"	17 Want Hy het die Wortel vasgestel en Sy vrugte sal vir altyd wees.	",
"	18 Hulle gaan diep af en groei hoog op en sprei uit, en word vol en oorvloedig.	",
"	19 En JaHWeH alleen is Geloof vir Sy Aanplanting en Sy Verbouing, [JeHôWganan 15:1]	",
"	20 Vir Sy sorg en vir die seëning van Sy Lippe, vir die pragtige Plantling van Sy Regterhand,	",
"	21 En vir die ontdekking van Sy Aanplanting, en vir die skranderheid van Sy Verstand.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '39',
content: [
		
"	1 MAGTIGE riviere is hulle wat die Krag van JaHWeH verag, hulle wat blindelings beweeg, [Openbaring 12:15]	",
"	2 En hulle treë verdraai, en hulle driwwe verwoes,	",
"	3 En hulle liggame gryp, en hulle siele vernietig;	",
"	4 Want hulle is sneller as weerlig en vinniger.	",
"	5 Maar hulle wat hul in die Geloof kruis, sal nie geskud word nie.	",
"	6 En diegene wat in rassuiwerheid oor hulle loop, sal nie verontrus word nie;	",
"	7 Omdat JaHWeH ‘n Teken in hulle is, en die Teken word die Weg van hulle wat [die rivier] oorsteek in die NAAM van JaHWeH.	",
"	8 Beklee jou dus met die NAAM van die Hoogste El, en ken HOM, en jy sal oor kruis sonder gevaar, want die riviere sal aan jou onderdanig wees.	",
"	9 JaHWeH het hulle deur SY Woord oorbrug, en Hy het geloop en hulle te voet oorgesteek;	",
"	10 En Sy Voetspore bly op die waters agter en is nie uitgewis nie, maar is soos ‘n stuk hout wat stewig vasgemaak is: [JeshaJaH 60:14]	",
"	11 Aan hierdie en daardie kant staan die golwe omhoog, maar die voetspore van ons Meester, die Gesalfde bly,	",
"	12 En is nie uitgewis nie, of tot niet gemaak nie;	",
"	13 En ‘n Weg is vasgestel vir hulle wat agter Hom kon oorgaan, en vir hulle wat volg in die voetspore van Sy Geloof, en ere aan SY NAAM bring.Halalu-JaHH/Prys jul JaHH! [Psalm 5:8; 18:30]	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '40',
content: [
		
		
"	1 SOOS heuning van die bye se heuningkoek drup, en melk vloei van die Vrou wat Haar Kinders liefhet,	",
"	2 Net so is My hoop op U, o My Elohey. Soos U Fontein Haar waters voortbring, so bring My Hart lof van JaHWeH te voorskyn, en My Lippe uiter lofprysinge tot Hom.	",
"	3 My tong is soet in Sy lofsange, en My ledemate dy uit in Sy psalms;	",
"	4 En My Aangesig verbly hom in Sy jubeling, en My Gees roem in Sy liefde, en My Siel skyn in Hom.	",
"	5 Hy wat vreesagtig is, sal op Hom vertrou en Verlossing sal in Hom tot stand gebring word;	",
"	6 Sy wins is ‘n onsterflike lewe, en hulle wat Hom ontvang, is onverderfbaar.Halalu-JaHH/Prys jul JaHH!	",

]
},
{
book: 'Odes_Van_Salomo',
chapter: '41',
content: [
		
"	1 AL SY kinders sal JaHWeH loof, en hulle sal die Waarheid van SY Geloof ontvang;	",
"	2 SY seuns sal aan HOM bekend wees: Laat Ons daarom sing in SY liefde.	",
"	3 Ons lewe in JaHWeH deur SY Barmhartigheid, en Ons ontvang lewe deur SY Verlosser.	",
"	4 Want ‘n groot dag het op Ons geskyn, en wonderbaarlik is HY wat vir Ons van SY lofprysinge gegee het.	",
"	5 Laat Ons dus almal saam verenig in die Naam van JaHWeH, en laat Ons HOM in SY Suiwerheid Eer betoon;	",
"	6 Laat Ons aangesigte in SY Lig skyn, laat Ons harte peins in SY liefde, dag en nag:	",
"	7 Laat Ons jubel oor die jubeling van JaHWeH.	",
"	8 Almal wat My sien, sal hulle verwonder, want Ek is van ‘n ander ras;	",
"	9 Want die VADER van Waarheid het My onthou - HY wat My van die begin af besit het;	",
"	10 Want SY rykdom het aan My geboorte geskenk en die gedagte van SY hart.	",
"	11 En SY Woord is met Ons al langs die Weg. Die Verlosser wat aan Ons nuwe lewe skenk, verwerp nie Ons siele nie	",
"	12 Die Man wat verneder was en opgehef is in SY Geregtigheid.	",
"	13 Die Seun van die Hoogste El het verskyn in die Suiwerheid van Sy VADER;	",
"	14 En die Lig het van die Woord af uitgegaan, wat vantevore reeds in Hom was.	",
"	15 Die Gesalfde is Een in Waarheid, en was bekend van voor die grond-legging van die Aarde af,	",
"	16 Sodat Hy vir ewig nuwe lewe kan gee aan siele in die Waarheid van Sy Naam. Laat daar ‘n nuwe loflied aan JaHWeH wees, van diegene wat HOM liefhet.Halalu-JaHH/Prys jul JaHH!	",
		

]
},
{
book: 'Odes_Van_Salomo',
chapter: '42',
content: [
		
"	1 EK het My hande uitgebrei, en genader tot My Elohim, want die uitstrek van My hande is SY Teken,	",
"	2 en My uitgebreide hande is die eenvoudige hout wat opgerig is op die Weg van die Opregte Een.	",
"	3 En Ek het nutteloos geword vir hulle wat My geken het, sodat Ek verskuil sou wees van hulle wat My nie vasgegryp het nie.	",
"	4 Ek sal met hulle wees wat My liefhet.	",
"	5 Al My vervolgers het gesterf; en hulle wat op My vertrou het, het My gesoek, want Ek lewe;	",
"	6 Ek het opgestaan en is met hulle, en Ek sal deur hulle monde spreek.	",
"	7 Want hulle het diegene verwerp wat hulle vervolg het, en het op hulle die juk van My liefde gelê.	",
"	8 Soos die arm van die Bruidegom op die Bruid, so is My juk op hulle wat My ken;	",
"	9 Soos die bed wat berei is in die Bruidskamer, so is My liefde oor hulle wat in My glo.	",
"	10 Ek was nie verwerp nie, selfs al was dit so aanvaar, en Ek het nie vergaan nie, selfs al het hulle dit van My geglo.	",
"	11 Doderyk/Sheol het My gesien en sy was bedroef, en Dood het My teruggegee en baie saam met My:	",
"	12 Ek was asyn en bitterheid vir hom, en Ek het saam met hom afgedaal, so ver as wat diepte strek;	",
"	13 en hy het voete en hoof los laat hang, omdat hulle nie My Aangesig kon verduur nie.	",
"	14 Ek het lewende adamiete byeen laat kom tussen sy dooies, en Ek het tot hulle gespreek met lewende lippe, sodat My Woord nie sonder trefkrag sou wees nie.	",
"	15 En hulle wat gesterf het, het na My gehardloop, en het uitgeroep en gesê: Wees ons barmhartig, Seun van die Elohim!	",
"	16 Handel met ons volgens U Medelye, bring ons uit die bande van Duisternis,	",
"	17 en open vir ons die Poort sodat ons saam met U daardeur kan uitkom, want ons sien dat ons dood U nie aanraak nie.	",
"	18 Mag ons ook saam met U verlos word? Want U is ons Verlosser. [2 Nikodémus 5]	",
"	19 Ek het hulle stem gehoor, en hulle Geloof in My Hart geplaas,	",
"	20 en Ek het My Naam op hul hoofde gedruk, want hulle is vrye adamiete en is Myne.Halalu-JaHH/Prys jul JaHH! [Openbaring 14:1-3]	",

]
}
];
