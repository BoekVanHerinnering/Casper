const nikodémus_deel_2Chapters = [

{
book: 'Nikodémus_deel_2',
chapter: '1',
content: [

"	1 JÔWSEF sê: En waarom verwonder julle julle daaroor dat JaHWèshua weer opgestaan het? Dit is nie wonderlik nie. Maar dit is wonderlik dat Hy nie alléén opgestaan het nie, maar dat Hy baie ander dodes ook opgewek het wat in Jerusalem aan baie adamiete verskyn het.	",
"	1a En as julle die ander nie ken nie, dan [ken julle] ten minste tog vir Simeon wat JaHWèshua in sy arms geneem het, en sy twee seuns, wat Hy opgewek het. Vir hulle, ten minste, ken julle, want ons het hulle maar kort gelede begrawe. En nou word hul grafte oop en leeg gesien, maar hulle self is lewend en woon in Arimathéa. [Lukas 2:25]	",
"	1b Hulle stuur toe manne uit en vind hul grafte oop en leeg. JôWsef sê: Laat ons na Arimathéa gaan en ons sal hulle kry!	",
"	2 Toe staan die hoëpriesters Annas en Kájafas op, en JôWsef en Nikodémus en GamaliEl en ander saam met hulle, en vertrek na Arimathéa en vind hulle van wie JôWsef gepraat het.	",
"	2a Toe het hulle ‘n gebed gedoen en mekaar gegroet.	",
"	2b Daarop kom hulle met hulle na Jerusalem, en bring hulle in die sinagoge en sluit die deure en plaas die Ou Wet van die manne van JeHûWdah in hul midde, en die hoëpriesters sê vir hulle:	",
"	2c Ons wil dat julle sweer by die Elohey van JisraEl en by die Meester, en so die Waarheid vertel hoe julle opgestaan het en wie julle uit die dode opgewek het.”	",
"	3 Toe hulle wat opgestaan het, dit hoor, sê hulle vir die hoëpriesters: Gee vir ons papier en pen en ink.” Hulle bring dit toe vir hulle. En hulle het gaan sit en aldus geskrywe:	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '2',
content: [
	
"	1 O MEESTER JaHWèshua die Gesalfde, die Opstanding en Lewe van die wêreld, gee ons Barmhartigheid dat ons mag vertel van U opstanding en die wondere wat U in die Doderyk/Sheol verrig het! [JeshaJaH 9:2]	",
"	1a Ons was dan in die Doderyk/Sheol saam met hulle almal wat ontslaap het van die begin af aan.	",
"	1b En in die middernagtelike uur het daar oor dié donker plekke [‘n lig] soos die lig van die son deurgebreek en geskyn, en ons almal is verlig en het mekaar gesien.	",
"	1c En meteens is ons vader Abraham saam met die patriarge en profete verenig in vreugde, en hulle sê vir mekaar: Hierdie Lig is afkomstig van die groot Verligting.	",
"	1d Die profeet JeshaJaHûW, wat ook daar teenwoordig was, sê toe: Hierdie Lig is uit die Vader en uit die Seun en uit die Gees van Apartheid.	",
"	1e Daarvan het ek toe ek nog in lewe was, geprofeteer: Die Aarde van Sebulon en die Aarde van Náftali, die volk wat in Duisternis gesit het, het ‘n groot Lig gesien!” [JeshaJaH 9:1-2]	",
"	2 Daarop tree ‘n ander na vore, ‘n askeet uit die woestyn, en die patriarge sê vir hom: Wie is jy?	",
"	2a En hy sê: Ek is JeHôWganan, die laaste van die profete, wat die Paaie van die Seun van Elohim reguit gemaak het, en aan die volk bekering gepreek het tot vergewing van oortredinge.	",
"	2b En die Seun van Elohim het na my gekom, en toe ek Hom van ver af sien, sê ek vir die volk:	",
"	2c Daar is die Lam van Elohim wat die oortreding van die wêreld wegneem! En met my hand het ek Hom in die Jordaanrivier gewas/gedoop, en toe sien ek die Gees van Apartheid soos ‘n duif op Hom neerdaal	",
"	2d en hoor ek ook die Stem van Elohim wat aldus sê: ‘Dit is My geliefde Seun in wie Ek ‘n welbehae het.	",
"	2e En daarom het Hy my ook na julle gestuur om te verkondig dat die eniggebore Seun van Elohim hierheen kom, sodat elkeen wat in Hom glo, gered sal word, en elkeen wat nie in Hom glo nie, veroordeel sal word.	",
		

]
},
{
book: 'Nikodémus_deel_2',
chapter: '3',
content: [
		
"	1 EN toe JeHôWganan so besig was om die wat in die Doderyk/Sheol was, te onderrig, het die eersgeskapene en voorvader Adam dit ook gehoor en vir Set, sy seun gesê:	",
"	1a My seun, ek wil dat jy aan die voorvaders van die adamitiese geslag en aan die profete sê waarheen ek jou gestuur het toe ek [my] neergelê het om te sterwe.	",
"	1b Toe sê Set: Profete en patriarge, luister! My vader Adam, die eersgeskapene het, toe hy hom op ‘n sekere tydstip neergelê het om te sterwe, my tot naby die Poort van die Paradys gestuur om ‘n versoek tot Elohim te rig	",
"	1c dat Hy my deur Sy Boodskapper na die Boom van Barmhartigheid sou lei, en dat ek van die olie sou neem en my vader met haar salf, sodat hy van sy krankheid sou kon opstaan.	",
"	1d Dit het ek dan ook gedoen. En na my gebed het ‘n Boodskapper van Elohim gekom en aan my gesê: Wat begeer jy, Set?	",
"	1e Vra jy vanweë die siekte van jou vader om die olie wat krankes oprig, of om die Boom wat daardie olie laat vloei?	",
"	1f Op hierdie tydstip is sy nie te vind nie. Gaan dan maar weer en sê aan jou vader dat nadat vyfduisend-vyfhonderd jaar vervul is ná die skepping van die wêreld,	",
"	1g die eniggebore Seun van Elohim adamiet sal word en na die Aarde sal kom, en Hy sal Hom met daardie olie salf en Hy sal opstaan, en met water en die Gees van Apartheid sal Hy Hom was en die wat van Hom afstam.	",
"	1h En dan sal Hy van alle siekte genees wees, maar noú is dit onmoontlik dat dit kan geskied.	",
"	1i En toe die patriarge en profete hierdie dinge hoor, het hulle hul grootliks verbly.	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '4',
content: [
		
"	1 EN terwyl hulle almal so vreugdevol was, kom Satan, die heerser oor die duisternis, en sê vir die Doderyk/Sheol:	",
"	1a Allesverslindende en Onversadigbare, luister na my woorde! [Spreuke 30:16]	",
"	1b Daar is iemand uit die geslag van die manne van JeHûWdah, JaHWèshua, wat Homself die Seun van Elohim noem, maar Hy is ‘n adamiet en met ons medewerking het die Jode Hom gefolter.	",
"	1c En noudat Hy dood is, maak jou klaar sodat ons Hom hier in bewaring kan neem.	",
"	1d Want ek weet dat Hy ‘n adamiet is en ek het Hom hoor sê: My Siel is uitermate bedroef, ja, tot die dood toe.	",
"	1e En Hy het my baie kwaad aangedoen in die bowe‑wêreld onderwyl Hy tussen die adamiete verkeer het.	",
"	1f Want oral waar Hy my dienaars gekry het, het Hy hulle vervolg; en soveel adamiete as wat ek gebreklik of blind of lam of melaats of so iets gemaak het,	",
"	1g dié het Hy deur ‘n enkele woord genees, en baie wat ek vir die graf gereed gemaak het, het Hy weer met ‘n enkel woord lewendig gemaak.	",
"	2 Doderyk/Sheol sê: En is Hy inderdaad so magtig dat Hy sulke dinge kan doen deur een enkele woord? Of kan jy Hom, as Hy so is, weerstaan?	",
"	2a Dit lyk vir my niemand sal Hom kan weerstaan nie. Maar as jy sê dat jy gehoor het dat Hy die Dood vrees, het Hy dit seker maar gesê om jou te bespot en uit te lag, terwyl Hy met ‘n Sterke Hand op jou wil toeslaan. En wee, wee jou vir ewig!”	",
"	2b Satan sê: Allesverslindende en onversadigbare Doderyk/Sheol, het jy so bang geword noudat jy van ons gemeenskaplike vyand gehoor het?	",
"	2c Ek het Hom nie gevrees nie, maar ek het die Jode aangesit en hulle het Hom gefolter en Hom ook gal gemeng met asyn gegee om te drink.	",
"	2d Maak jou dus klaar om Hom, wanneer Hy kom, met krag te oorweldig.”	",
"	3 Doderyk/Sheol antwoord: Vors van die Duisternis, Seun van die verderf, jy het net nou vir my gesê dat Hy baie van hulle wat jy vir die graf gereed gemaak het, met ‘n enkele woord weer lewendig gemaak;	",
"	3a as Hy dan baie ander van die graf bevry het, hoe en met watter mag sal Hy deur ons vasgehou word?	",
"	3b Self het ek ‘n tydjie gelede ‘n sekere dode met die naam van El-Azer (Lazurus) ingesluk, en kort daarna het Iemand uit die lewendes hom weer deur ‘n enkele woord uit my ingewande met geweld teruggeruk. [JeHôWganan 11]	",
"	3c Nou glo ek dat dit Hy is van wie jy praat. As ons Hom dus hier opneem, vrees ek dat ons miskien in gevaar verkeer ten opsigte van die ander [dodes] ook.	",
"	3d Want ek het alle adamiete van die begin af ingesluk, en kyk, ek merk dat hulle onrustig word en ek voel pyn in my ingewande;	",
"	3e en hierdie El-Azer wat reeds vroeër van my af weggeruk is, lyk vir my nie na ‘n goeie teken nie, want hy het van my af weggevlieg, nie soos ‘n dooie adamiet nie, maar soos ‘n arend, só haastig het die Aarde hom uitgewerp.	",
"	3f Daarom besweer ek jou by jou gawes en by my eie dat jy Hom nie hierheen bring nie, want ek glo dat Hy hierheen kom om al die dodes op te wek.	",
"	3g En dit sê ek vir jou by die buitenste Duisternis, as jy Hom hierheen bring, sal nie een van al die dodes in my agterbly nie.	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '5',
content: [
		
"	1 TERWYL Satan en Doderyk/Sheol besig was om so met mekaar te praat, klink daar ‘n groot Stem, soos van donder, wat sê:	",
"	1a Hef op jul poorte, o vorste, en verhef julle, ewige deure, en die Erekoning sal binnetree! [Psalm 30:3; Odes van Salomo 17:9-11]	",
"	1b Toe Doderyk/Sheol dit hoor, sê sy vir Satan: Gaan buitentoe as jy kan en weerstaan Hom.	",
"	1c Satan het toe buitentoe gegaan. Voorts het Doderyk/Sheol vir haar demone gesê: Verseker goed en stewig die koperpoorte en die ystergrendels en verseker my slotte, en staan reg en bewaak alle punte, want as Hy hierheen kom, sal Weë ons oorval! [Psalm 107:16]	",
"	2 Toe die voorvaders dit hoor, begin hulle haar almal te hoon en te sê: Allesverslindende en Onversadigbare! maak oop dat die Erekoning kan binnekom.	",
"	2a Die profeet Dawid sê: Weet jy nie, blinde, dat toe ek op die Aarde geleef het, ek daardie woord geprofeteer het nie: Hef op jul poorte, o vorste?	",
"	2b JeshaJaHûW sê: Deur die Gees van Apartheid het ek dit vooruitgesien en geskrywe: Die dodes sal opstaan, en die wat in die grafte is, sal herlewe, en die wat op die Aarde is, sal jubel, en weer: O Dood waar is jou prikkel? O Doderyk/Sheol, waar is jou oorwinning?	",
"	3 Toe kom daar weer eens ‘n Stem wat sê: Hef op die poorte!	",
"	3a Toe Doderyk/Sheol vir die tweede keer die stem hoor, antwoord sy asof sy naamlik niks bemerk het nie, en sê: Wie is die Erekoning? [Psalm 24:10]	",
"	3b Die Boodskapper van JaHWeH sê: JaHWeH, geweldig en magtig! JaHWeH magtig in die stryd! [Psalm 24;8]	",
"	3c En ineens, saam met die woord, is die koperpoorte tot stukke verbreek en die ystergrendels verkrummel, en al die gebonde dodes is bevry van hul boeie, en ons met hulle, en die Erekoning het binnegekom, in gedaante soos ‘n adamiet; en al die donker plekke van die Doderyk/Sheol verlig. [Odes van Salomo 29:4]	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '6',
content: [
		
"	1 ONMIDDELLIK het Doderyk/Sheol uitgeroep: Ons is oorwin, wee ons! Maar wie is U wat so ‘n groot vermoë en mag het?	",
"	1a En watter soort adamiet is U wat sonder oortreding hierheen kom, U wat gering voorkom en groot dinge kan doen, wat nederig is en verhewe, slaaf en Meester, krygsman en Koning, wat mag het oor die dodes en die lewendes?	",
"	1b U was aan die folterpaal genael en in die graf neergelê, en nou het U vry geword en al ons mag vernietig.	",
"	1c Is U dan dié JaHWèshua van wie Satan, die owerste, vir ons gesê het dat U deur die folterpaal en dood die hele wêreld sou beërwe?	",
"	2 Toe gryp die Erekoning vir Satan, die owerste, aan sy kop en oorhandig hom aan die Boodskappers en sê:	",
"	2a Bind sy hande en sy voete, sy nek en sy mond met ysterboeie! Daarop gee Hy hom aan Doderyk/Sheol oor en sê: Neem hom en bewaar hom veilig tot by My wederkoms!	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '7',
content: [
		
"	1 EN toe Doderyk/Sheol Satan vat, sê sy vir hom: Beëlsebul, erfgenaam van vuur en straf, vyand van die apartes, wat het jou daartoe gedryf om te bewerk dat die Erekoning gefolter word, sodat Hy hierheen kom en ons van ons mag beroof?	",
"	1a Draai jou om en sien dat geen enkele dode in my agtergebly het nie, maar al wat jy deur die Boom van Kennis in jou mag gekry het, dit het jy weer alles deur die Boom van die Folterpaal verloor.	",
"	1b En al jou Vreugde is in droefheid verander. En toe jy die Erekoning wou doodmaak, het jy jouself doodgemaak, want aangesien ek jou ontvang het om in veilige bewaring te hou, sal jy deur ervaring leer hoeveel besoedeling ek teen jou sal onderneem.	",
"	1c O aartsduiwel, begin van die Dood, wortel van Ongeregtigheid en uiterste van alle besoedeling! Watter besoedeling het jy in JaHWèshua gevind dat jy Sy ondergang bewerk het?	",
"	1d Hoe het jy so ‘n groot besoedelde daad durf doen? Hoe het jy begeer om so iemand in hierdie Duisternis binne te bring, waardeur jy nou beroof is van almal wat van die begin af gesterwe het?	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '8',
content: [
		
"	1 EN terwyl Doderyk/Sheol op hierdie wyse met Satan praat, strek die Erekoning Sy regterhand uit en vat aan ons voorvader Adam en wek hom op, en	",
"	1a daarop draai Hy Hom na die ander en sê:	",
"	1b Kom hierheen met My, julle almal wat die dood deurgemaak het deur die Boom wat hierdie man aangeraak het.	",
"	1c Want kyk, deur die Boom van die Folterpaal wek Ek julle almal weer op.	",
"	1d Daarna dryf Hy hulle almal na buite, en ons voorvader Adam is gesien vol blydskap van siel en hy het gesê: Ek bring dank aan U grootheid, o JaHWeH, dat U my opgevoer het uit die dieptes van die Doderyk/Sheol!	",
"	1e En so het al die profete en apartes ook gesê: Ons dank U, Gesalfde, Verlosser van die wêreld, dat U ons lewe uit die verderf uitgelei het.	",
"	2 En nadat hulle dit gesê het, seën die Verlosser vir Adam en so het Hy ook gedoen aan al die patriarge en profete en martelaars en voorvaders.	",
"	2a En Hy neem hulle en snel uit die Doderyk/Sheol na bo. En terwyl Hy heengaan, het die apartheidsvaders wat Hom gevolg het, lofsange gesing en gesê:	",
"	2b Geseënd is Hy wat kom in die Naam van JaHWeH! Aan Hom kom toe al die Glansrykheid van al die apartes! [Psalm 49:15]	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '9',
content: [
		
"	1 EN terwyl Hy na die Paradys gaan, neem Hy Adam by die hand en gee hom en al die apartes oor aan die Hoof-Boodskapper MikaEl.	",
"	1a En toe hulle die Poort van die Paradys binnetree, ontmoet twee ou manne hulle, aan wie die apartheidsvaders sê: Wie is u wat die dood nie gesien het en in die Doderyk/Sheol nie neergedaal het nie, maar met u liggame sowel as u siele in die Paradys woon?	",
"	1b Een van hulle antwoord en sê: Ek is Henog wat JaHWeH behaag het en hierheen oorgeplaas is.	",
"	1c En hierdie een is EliJaHûW die Thisbiet, en ons sal leef tot aan die einde van die wêreld, maar dan sal ons deur JaHWeH gestuur word om die vals gesalfde teen te staan,	",
"	1d en ons sal deur hom doodgemaak word en na drie dae weer opstaan en weggeruk word in die Wolkkolom om Elohim tegemoet te gaan.	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '10',
content: [
		
"	1 En terwyl hulle hierdie dinge spreek, kom daar ‘n ander man, nederig van voorkoms, wat ‘n folterpaal op sy skouers dra en die apartheidsvaders sê aan hom:	",
"	1a Wie is jy wat die voorkoms van ‘n rower het, en watter folterpaal is dit wat jy op jou skouer dra?’	",
"	1b Hy antwoord: Ek was, soos julle sê, ‘n rower en ‘n dief op Aarde, en daarom het die Jode my gevange geneem en aan die dood van die folterpaal oorgegee saam met ons Meester JaHWèshua die Gesalfde. [Lukas 23:43]	",
"	1c En toe Hy aan die folterpaal hang, het ek die tekens gesien wat daar geskied en ek het in Hom geglo en tot Hom gebid en gesê:	",
"	’Meester, wanneer U Koning sal wees, vergeet my tog nie!’	",
"	1d En dadelik het Hy aan my gesê: Voorwaar, [voorwaar,] Ek sê vir jou, vandag sal jy met My in die Paradys wees!	",
"	1e Derhalwe het ek, terwyl ek my folterpaal dra, na die Paradys gegaan en toe ek die Hoof-Boodskapper MikaEl vind, sê ek vir hom:	",
"	1f Ons Meester JaHWèshua, die gefolterde, het my hierheen gestuur. Bring my dus in die Poort van Eden.	",
"	1g En toe die Vlammende Swaard die folterpaal sien, het Hy vir my oopgemaak en ek het binne gegaan.  [Genésis 3:24]	",
"	1h Daarop sê die Hoof-Boodskapper vir my: Vertoef ‘n bietjie, want Adam, die voorvader van die adamitiese geslag, kom met die regverdiges sodat hulle ook na binne kan gaan.	",
"	1i En noudat ek julle sien, het ek gekom om julle te ontmoet.	",
"	1j En toe die apartes dit hoor, roep hulle met ‘n groot stem uit: Groot is onse Elohey en groot is Sy Krag!	",

]
},
{
book: 'Nikodémus_deel_2',
chapter: '11',
content: [
		
"	1 Dit alles het ons gesien en gehoor ‑ ons, die twee broers wat ook deur die Hoof-Boodskapper MikaEl gestuur is en die opdrag ontvang het om die opstanding van JaHWèshua te verkondig,	",
"	1a maar om eers na die Jordaan te gaan en gewas/gedoop te word, waarheen ons ook gegaan het en gewas/gedoop is saam met die ander dodes wat opgestaan het.	",
"	1b Daarna het ons na Jerusalem gegaan en die Pasga van die opstanding volbring.	",
"	1c Maar nou vertrek ons, want ons kan nie hier vertoef nie.	",
"	1c En mag die liefde van JaHWeH die Vader, en die Barmhartigheid van ons Meester JaHWèshua die Gesalfde, en die gemeenskap van die Gees van Apartheid met julle almal wees. Amein!	",
"	1d Nadat hulle hierdie dinge neergeskrywe en hul geskrifte verseël het, gee hulle die een helfte aan die hoëpriesters en die ander helfte aan JôWsef en Nikodémus, en hulle self het ineens verdwyn.	",
"	1e Tot die Glansrykheid van ons Meester JaHWèshua die Gesalfde. Amein.	",

]
}

];
