const markusChapters = [

{
book: 'Markus',
chapter: '1',
content: [

"	1 DIE begin van die goeie tyding van JaHWèshua, die Gesalfde, die Seun van die Elohim.	",
"	2 KYK, Ek stuur My boodskapper wat die Weg voor My uit sal baan. [Maleagi 3:1]	",
"	3 ’n Stem van een wat roep in die wildernis: Berei die Weg van JaHWeH; maak gelyk [in die woestyn ’n grootpad vir onse Elohey!]. [JeshaJaH 40:3]	",
"	4 JeHôWganan het gekom en was besig om in die wildernis te was/doop en het die wassing/doop van bekering tot vergifnis van oortredinge verkondig.	",
"	5 En die hele Aarde van JeHûWdah en die inwoners van Jerusalem het uitgegaan na hom toe, en almal is deur hom gewas/gedoop in die Jordaanrivier met belydenis van hulle oortredinge.	",
"	6 En JeHôWganan was gekleed met kameelhare en ’n leergord om sy heupe, en hy het sprinkane en wilde heuning geëet.	",
"	7 En hy het verkondig en gesê: Hy wat sterker is as ek, kom na my, en ek is nie waardig om neer te buk en Sy skoenriem los te maak nie.	",
"	8 Ek het julle wel in water gewas/gedoop, maar Hy sal julle vervul met die Gees van die Apartheid.	",
		
		
"	9 EN in daardie dae het JaHWèshua van Násaret in Galiléa gekom en is deur JeHôWganan in die Jordaan gewas/gedoop.	",
"	10 En dadelik toe Hy opklim uit die water, sien Hy die Hemele skeur en die Gees soos ’n duif op Hom neerdaal.	",
"	11 En daar het ’n Stem uit die Hemele gekom: U IS MY GELIEFDE SEUN IN WIE EK ‘N WELBEHAE HET. [Odes van Salomo 24:1-2]	",
"	12 En dadelik het die Gees Hom uitgedryf in die wildernis.	",
"	13 En Hy was daar in die wildernis veertig dae lank, terwyl Hy deur die Satan versoek is; en Hy was saam met die wilde diere, en die Boodskappers het Hom gedien.	",
		
		
"	14 EN nadat JeHôWganan oorgelewer was, het JaHWèshua in Galiléa gekom en die goeie tyding van die Koninkryk van die Elohim verkondig	",
"	15 en gesê: Die tyd is vervul en die Koninkryk van die Elohim het naby gekom; bekeer julle en glo die goeie tyding.	",
"	16 En terwyl Hy langs die see van Galiléa loop, sien Hy Simon en Andréas, sy broer, besig om ’n net in die see uit te gooi; want hulle was vissers.	",
"	17 En JaHWèshua sê vir hulle: Kom agter My aan, en Ek sal maak dat julle vissers van adamiete word.	",
"	18 En dadelik het hulle hul nette laat staan en Hom gevolg.	",
"	19 En toe Hy daarvandaan ’n bietjie verder gaan, sien Hy Jakobus, die seun van Sebedéüs, en JeHôWganan, sy broer, wat besig was om die nette in die skuit heel te maak.	",
"	20 En dadelik het Hy hulle geroep, en hulle het hul vader Sebedéüs met die gehuurde mense in die skuit laat staan en Hom gevolg.	",
		
		
"	21 EN hulle het in Kapérnaüm gekom, en dadelik op die Sabbat het Hy in die vergadering ingegaan en begin leer.	",
"	22 En hulle was verslae oor Sy Leer, want Hy het hulle geleer soos een wat gesag het en nie soos die skrywers nie.	",
"	23 En daar was in hulle vergadering ’n man met ’n gees van besoedeling; en hy het uitgeskreeu	",
"	24 en gesê: Hou op! Wat het ons met U te doen, JaHWèshua, Nasaréner? Het U gekom om ons te verdelg? Ek ken U, wie U is: die Aparte Een van die Elohim!	",
"	25 En JaHWèshua het hom bestraf en gesê: Bly stil en gaan uit hom uit!	",
"	26 En die gees van besoedeling het hom stuiptrekkings laat kry en met ’n groot stem geskreeu en uit hom uitgegaan.	",
"	27 En almal was verbaas, sodat hulle onder mekaar vra en sê: Wat is dit? Watter nuwe leer is dit, dat Hy met gesag ook aan die geeste van besoedeling bevel gee en hulle Hom gehoorsaam is?	",
"	28 En die gerug aangaande Hom is dadelik versprei in die hele omtrek van Galiléa.	",
		
		
"	29 EN dadelik toe hulle uit die vergadering uitgegaan het, kom hulle saam met Jakobus en JeHôWganan in die huis van Simon en Andréas.	",
"	30 En die skoonmoeder van Simon het siek gelê aan die koors; en dadelik het hulle Hom van haar gesê.	",
"	31 Daarop gaan Hy na haar, neem haar hand en rig haar op, en dadelik het die koors haar verlaat, en sy het hulle bedien.	",
"	32 En toe dit aand geword het en die son onder was, het hulle na Hom gebring almal wat ongesteld en van demone besete was.	",
"	33 En die hele stad het by die deur saamgekom.	",
"	34 En baie wat aan allerhande siektes gely het, het Hy gesond gemaak en baie demone uitgedryf en die demone nie toegelaat om te praat nie, omdat hulle Hom geken het.	",
"	35 En vroeg in die môre, nog diep in die nag, het Hy opgestaan en uitgegaan en na ’n eensame plek vertrek en daar gebid.	",
"	36 En Simon en die wat by Hom was, het Hom gevolg.	",
"	37 En toe hulle Hom vind, sê hulle vir Hom: Almal soek U.	",
"	38 En Hy sê vir hulle: Laat ons na die naburige dorpe gaan, sodat Ek ook daar kan verkondig; want daarvoor het Ek uitgegaan.	",
"	39 En Hy het die hele Galiléa deur in hulle vergaderings verkondig en die demone uitgedryf.	",
		
		
"	40 EN daar kom ’n melaatse na Hom toe wat Hom smeek en voor Hom op die knieë val en vir Hom sê: As U wilen U die mag het om te suiwer, kan U my suiwer maak.	",
"	41 En JaHWèshua het vir hom innig jammer gevoel en die hand uitgesteek en hom aangeraak en vir hom gesê: Ek wil, word gesuiwer!	",
"	42 En toe Hy dit sê, het die melaatsheid hom dadelik verlaat, en hy is gesuiwer.	",
"	43 En nadat Hy hom ernstig aangespreek het, stuur Hy hom dadelik weg	",
"	44 en sê vir hom: Pas op dat jy aan niemand iets vertel nie, maar gaan vertoon jou aan die priester en bring nader vir jou wassing wat Moshè voorgeskryf het, tot ’n getuienis vir hulle.	",
"	45 Maar hy het uitgegaan en begin om baie dinge rond te verkondig en die saak rugbaar te maak, sodat Hy nie meer openlik in ’n stad kon ingaan nie; maar Hy was buite in verlate plekke, en hulle het van alle kante na Hom gekom.	",

]
},
{
book: 'Markus',
chapter: '2',
content: [
		
"	1 EN ná ’n paar dae het Hy weer in Kapérnaüm gekom, en die mense het gehoor dat Hy in die huis was.	",
"	2 En dadelik het baie saamgekom, sodat daar selfs by die deur nie meer plek was nie; en Hy was besig om aan hulle die Woord te verkondig.	",
"	3 En daar kom mense na Hom met ’n verlamde man wat deur vier gedra word.	",
"	4 En toe hulle vanweë die skare nie naby Hom kon kom nie, maak hulle die dak oop waar Hy was, en nadat hulle dit oopgebreek het, het hulle die bed waar die verlamde op lê, laat afsak.	",
"	5 En toe JaHWèshua hulle Geloof sien, sê Hy vir die verlamde: Seun, jou oortredinge is jou vergewe!	",
"	6 En sommige van die skrywers het daar gesit en in hulle harte geredeneer:	",
"	7 Waarom praat hierdie man sulke lasterlike dinge? Wie kan oortreding uitvee behalwe EEN, naamlik JaHWeH? [JeshaJaH 43:25]	",
"	8 En JaHWèshua het dadelik in Sy Gees geweet dat hulle by hulleself so redeneer, en Hy sê vir hulle: Wat redeneer julle oor hierdie dinge in jul harte?	",
"	9 Wat is makliker, om vir die verlamde te sê: Die oortredinge is jou vergewe! of om te sê: Staan op en neem jou bed op en loop?	",
"	10 Maar dat julle kan weet dat die Seun van die Adam mag het om op die Aarde oortredinge te vergewe - sê Hy vir die verlamde man:	",
"	11 Ek sê vir jou: Staan op, neem jou bed op en gaan na jou huis toe.	",
"	12 En dadelik staan hy op en neem sy bed op en gaan voor die oë van almal uit, sodat almal verbaas was en Elohim vereer en sê: So iets het ons nog nooit gesien nie!	",
		
		
"	13 EN Hy het weer uitgegaan langs die see, en die hele skare het na Hom gekom, en Hy het hulle geleer.	",
"	14 En toe Hy verbygaan, sien Hy Levi, die seun van Alféüs, by die tolhuis sit en sê vir hom: VOLG MY. En hy het opgestaan en Hom gevolg.	",
"	15 En terwyl Hy in sy huis aan tafel was, kom daar baie tollenaars en oortreders saam met JaHWèshua en Sy studente aan tafel; want daar was baie, en hulle het Hom gevolg.	",
"	16 En toe die skrywers en die Fariseërs Hom saam met die tollenaars en oortreders sien eet, sê hulle vir Sy studente: Wat is dit dat Hy saam met die tollenaars en oortreders eet en drink?	",
"	17 En toe JaHWèshua dit hoor, sê Hy vir hulle: Die wat gesond is, het die geneesheer nie nodig nie, maar die wat ongesteld is. Ek het nie gekom om regverdiges te roep nie, maar oortreders tot bekering.	",
		
		
"	18 EN die studente van JeHôWganan en dié van die Fariseërs was besig om te vas. Toe kom hulle en sê vir Hom: Waarom vas die studente van JeHôWganan en dié van die Fariseërs, maar U studente vas nie?	",
"	19 En JaHWèshua sê vir hulle: Kan die seuns wat die Bruidskamer voorberei dan vas terwyl die Bruidegom by hulle is? So lank as hulle die Bruidegom by hulle het, kan hulle nie vas nie.	",
"	20 Maar daar sal dae kom wanneer die Bruidegom van hulle weggeneem word, en dan sal hulle vas, in daardie dae.	",
"	21 En niemand werk ’n nuwe stuk lap op ’n ou kleed nie; anders skeur sy nuwe aangelapte stuk van die oue af, en daar kom ’n erger skeur.	",
"	22 En niemand gooi nuwe wyn in ou leersakke nie; anders sal die nuwe wyn die sakke laat bars, en die wyn loop uit en die sakke vergaan. Maar nuwe wyn moet in nuwe sakke gegooi word.	",
		
		
"	23 EN terwyl Hy op die Sabbat deur die gesaaides loop, het Sy studente al gaande are begin pluk.	",
"	24 Toe sê die Fariseërs vir Hom: Kyk, waarom doen hulle op die Sabbat wat nie geoorloof is nie?	",
"	25 En Hy sê vir hulle: Het julle nooit gelees wat Dawid gedoen het nie - toe hy in die nood was, en hy en die wat by hom was, honger gehad het -	",
"	26 hoe hy in die Huis van die Elohim gegaan het in die tyd van Abjater, die hoëpriester, en die toonbrode geëet het wat vir niemand behalwe die priesters geoorloof is om te eet nie; en ook aan die wat saam met hom was, gegee het? [1 ShemuEl 21:6; Levítikus 24:5-9]	",
"	27 En Hy sê vir hulle: Die Sabbat is gemaak vir die adamiet, nie die adamiet vir die Sabbat nie.	",
"	28 Daarom is die Seun van die Adam Meester ook van die Sabbat.	",

]
},
{
book: 'Markus',
chapter: '3',
content: [
		
"	1 EN Hy het weer in die vergadering gegaan, en dáár was ’n man met ’n verdorde hand.	",
"	2 En hulle het Hom in die oog gehou, of Hy hom op die Sabbat gesond sou maak, sodat hulle Hom kon aankla.	",
"	3 En Hy sê vir die man met die verdorde hand: Staan op in hul midde.	",
"	4 Daarop sê Hy vir hulle: Is dit geoorloof om op die Sabbat goed of kwaad te doen, ’n siel te red of dood te maak? Maar hulle het stilgebly.	",
"	5 En nadat Hy hulle rondom met toorn aangekyk het en tegelykertyd bedroef was oor die hardheid van hulle hart, sê Hy vir die man: Steek jou hand uit! En hy het haar uitgesteek, en sy hand is herstel, gesond soos die ander een.	",
"	6 Toe gaan die Fariseërs uit en hou dadelik raad met die Herodiane teen Hom, sodat hulle Hom sou kan ombring.	",
"	7 En JaHWèshua het met Sy studente teruggegaan na die see toe, en ’n groot menigte het Hom gevolg uit Galiléa en JeHûWdah	",
"	8 en Jerusalem en Iduméa en van oorkant die Jordaan af. En die wat om Tirus en Sidon gewoon het, ’n groot menigte, het na Hom gekom toe hulle hoor wat Hy alles doen.	",
"	9 En Hy het aan Sy studente gesê dat ’n skuitjie altyd vir Hom moes klaar lê vanweë die skare, sodat hulle Hom nie miskien sou verdring nie.	",
"	10 Want Hy het baie gesond gemaak, sodat almal wat vol kwale was, op Hom toegeloop het om Hom aan te raak.	",
"	11 En elke keer as die geeste van besoedeling Hom sien, het hulle voor Hom neergeval en geskreeu en gesê: U is die Seun van die Elohim!	",
"	12 En Hy het hulle herhaaldelik streng gebied om Hom nie bekend te maak nie.	",
		
		
"	13 EN Hy het op die berg geklim en na Hom geroep die wat Hy wou hê, en hulle het na Hom gekom.	",
"	14 En Hy het twaalf aangestel, sodat hulle saam met Hom kon wees en Hy hulle kon uitstuur om te verkondig	",
"	15 en mag te hê om siektes te genees en die demone uit te dryf.	",
"	16 En aan Simon het Hy die bynaam Petrus gegee;	",
"	17 en verder Jakobus, die seun van Sebedéüs, en JeHôWganan, die broer van Jakobus - aan hulle het Hy die bynaam Boanérges gegee, dit is, seuns van die donder -	",
"	18 en Andréas en Filippus, en Bartholoméüs en MattithJaHûW, en Thomas en Jakobus, die seun van Alféüs, en Thaddéüs en Simon Kananítes,	",
"	19 en Judas Iskáriot, hy wat Hom verraai het.	",
		
		
"	20 EN hulle het in ’n huis gegaan, en ’n skare het weer saamgekom, sodat hulle selfs nie brood kon eet nie.	",
"	21 Toe Sy mense dit hoor, gaan hulle uit om Hom in die hande te kry; want hulle het gesê: Hy is buite Sy sinne.	",
"	22 En die skrywers wat van Jerusalem af gekom het, het gesê: Hy het Beëlsebul! en: Deur die prins van die demone dryf Hy die demone uit.	",
"	23 En Hy het hulle na Hom geroep en vir hulle deur gelykenisse gesê: Hoe kan die Satan die Satan uitdryf?	",
"	24 En as ’n koninkryk teen homself verdeeld is, kan daardie koninkryk nie bly staan nie;	",
"	25 en as ’n huis teen homself verdeeld is, kan daardie huis nie bly staan nie;	",
"	26 en as die Satan teen homself opstaan en verdeeld is, kan hy nie bly staan nie, maar hy kom tot ’n einde.	",
"	27 Niemand kan in die huis van ’n magtige ingaan en sy goed roof as hy nie eers die magtige boei nie; en dan sal hy sy huis berowe.	",
"	28 Voorwaar Ek sê vir julle, al die oortredinge sal die kinders van die adamiete vergewe word en al die lasterlike spraak wat hulle ookal uitgespreek het;	",
"	29 maar wie teen die Gees van die Apartheid gelaster het, het geen vergifnis tot in ewigheid nie, maar is skuldig aan die ewige oordeel -	",
"	30 omdat hulle gesê het: Hy het ’n gees van besoedeling.	",
		
		
"	31 SY broers en Sy moeder het toe gekom, en terwyl hulle buite staan, stuur hulle na Hom om Hom te roep.	",
"	32 En ’n skare het rondom Hom gesit. Hulle sê toe vir Hom: U moeder en U broers soek U daarbuite.	",
"	33 En Hy antwoord hulle en sê: Wie is My moeder of My broers?	",
"	34 En Hy kyk rond na die wat rondom Hom sit, en sê: Dáár is My moeder en My broers!	",
"	35 Want elkeen wat die Wil van die Elohim doen, dié is My broer en My suster en moeder.	",
		

]
},
{
book: 'Markus',
chapter: '4',
content: [
		
"	1 EN Hy het nog ’n maal by die see begin leer; en ’n groot menigte het by Hom saamgekom, sodat Hy in die skuit geklim en op die see gaan sit het, en die hele skare was op die land by die see.	",
"	2 En Hy het hulle baie dinge geleer deur gelykenisse en vir hulle in Sy lering gesê:	",
"	3 Luister! ’n Saaier het uitgegaan om te saai.	",
"	4 En terwyl hy saai, het ’n deel langs die pad geval, en die voëls van die Hemele het gekom en hom opgeëet.	",
"	5 En ’n ander deel het op ’n rotsagtige plek geval waar hy nie baie grond gehad het nie; en dadelik het hy opgekom, omdat hy geen diepte van grond gehad het nie.	",
"	6 En toe die son opgaan, is hy verskroei; en omdat hy geen wortel gehad het nie, het hy verdroog.	",
"	7 En ’n ander deel het in die dorings geval, en die dorings het opgekom en hom verstik; en hy het geen vrug opgelewer nie.	",
"	8 En ’n ander deel het in die gesuiwerde Adamah [die adamiet se Aarde] geval, en hy het vrug opgelewer; want hy het opgekom, en gegroei, en hy het gedra: een dertig- en een sestig- en een honderdvoudig. [Génesis 26:12]	",
"	9 En Hy sê vir hulle: Wie ore het om te hoor, laat hom hoor.	",
		
		
"	10 EN toe Hy alleen was, het die wat saam met die twaalf rondom Hom was, Hom na die gelykenis gevra.	",
"	11 En Hy sê vir hulle: Aan julle is dit gegee om die verborgenheid van die Koninkryk van die Elohim te ken, maar vir hulle wat buite is, kom alles deur gelykenisse,	",
"	12 sodat hulle nie sien met hul oë en met hul ore nie hoor en hul hart nie verstaan nie, en hulle hul nie bekeer en gesond word nie. [JeshaJaH 6:9, 10]	",
"	13 En Hy sê vir hulle: Begryp julle nie hierdie gelykenis nie? En hoe sal julle al die gelykenisse verstaan?	",
"	14 Die saaier saai die Woord.	",
"	15 En dit is hulle wat langs die pad is - waar die Woord gesaai word, maar sodra hulle Hom gehoor het, kom die Satan dadelik en neem die Woord weg wat in hulle harte gesaai is.	",
"	16 Net so ook is hulle by wie op rotsagtige plekke gesaai word - wat, as hulle die Woord hoor, Hom dadelik met blydskap aanneem,	",
"	17 maar geen wortel in hulleself het nie; hulle is net vir ’n tyd. Later as daar verdrukking of vervolging kom ter wille van die Woord, struikel hulle dadelik.	",
"	18 En hulle by wie in die dorings gesaai word - dit is hulle wat die Woord hoor, [Spreuke 22:5]	",
"	19 en die sorge van hierdie tyd en die verleiding van die rykdom en die begeerlikhede in verband met die ander dinge kom in en verstik die Woord, en hy word onvrugbaar.	",
"	20 En dit is hulle by wie in die gesuiwerde Adamah [die adamiet se Aarde] gesaai is - hulle wat die Woord hoor en Hom aanneem en vrugte dra: een dertig- en een sestig- en een honderdvoudig.	",
		
		
"	21 EN Hy het vir hulle gesê: Die lamp kom tog nie om onder die maatemmer of onder die bed gesit te word nie. Is hy nie om op die staander gesit te word nie?	",
"	22 Want daar is niks verborge wat nie openbaar sal word nie, en daar is niks weggesteek nie of dit moet in die lig kom. [Boekrol van Henog 9:5]	",
"	23 As iemand ore het om te hoor, laat hom hoor.	",
"	24 En Hy het vir hulle gesê: Pas op wat julle hoor; met die maat waarmee julle meet, sal vir julle gemeet word, en daar sal bygevoeg word vir julle wat hoor.	",
"	25 Want wie het, vir hom sal gegee word; en wie nie het nie, van hom sal weggeneem word ook wat hy het.	",
		
		
"	26 EN Hy het gesê: So is die Koninkryk van Elohim, soos wanneer ’n adamiet die saad in die Adamah [die adamiet se Aarde] gooi;	",
"	27 en hy gaan slaap en staan op, nag en dag, en die saad spruit uit en word groot - hoe, weet hy self nie.	",
"	28 Want vanself bring die Aarde vrug voort, eers ’n halm, dan ’n aar, dan die volle koring in die aar.	",
"	29 En wanneer die vrug dit toelaat, steek hy die sekel dadelik in, omdat die oes daar is.	",
		
		
"	30 EN Hy het gesê: Waarmee moet ons die Koninkryk van die Elohim vergelyk, of met watter soort gelykenis moet ons haar voorstel?	",
"	31 Sy is soos ’n mosterdsaad, wat die kleinste is van al die soorte saad op die Aarde wanneer Sy in die Adamah [die adamiet se Aarde] gesaai is;	",
"	32 en wanneer Sy gesaai is, kom Sy op en word groter as al die groentesoorte en maak groot takke, sodat die voëls van die Hemele onder Haar skaduwee nes kan maak.	",
"	33 En met baie sulke gelykenisse het Hy die Woord tot hulle gespreek volgens wat hulle kon verstaan;	",
"	34 en sonder gelykenis het Hy tot hulle nie gespreek nie; maar afsonderlik het Hy vir Sy studente alles uitgelê.	",
		
		
"	35 EN toe dit aand geword het op daardie dag, het Hy vir hulle gesê: Laat ons oorvaar na die ander kant.	",
"	36 En hulle het die skare verlaat en Hom, net soos Hy was, saamgeneem in die skuit; en daar was ook ander skuitjies by Hom.	",
"	37 En ’n groot stormwind het opgekom, en die golwe het in die skuit geslaan, sodat sy al vol wou word.	",
"	38 Maar Hy was agter op die skuit aan die slaap op die kussing. En hulle het Hom wakker gemaak en vir Hom gesê: Meester, gee U nie om dat ons vergaan nie?	",
"	39 En Hy het opgestaan en die wind bestraf en vir die see gesê: Swyg, wees stil! En die wind het gaan lê, en daar het ’n groot stilte gekom. [Psalm 107:29]	",
"	40 Toe sê Hy vir hulle: Waarom is julle so bang? Hoe het julle dan geen Geloof nie?	",
"	41 En ’n groot Vrees het hulle oorweldig, en hulle het vir mekaar gesê: Wie is Hy tog, dat selfs die wind en die see Hom gehoorsaam is!	",
		

]
},
{
book: 'Markus',
chapter: '5',
content: [
		
"	1 EN hulle het aan die oorkant van die see gekom in die Aarde van die Gadaréners.	",
"	2 En toe Hy uit die skuit gaan, kom daar dadelik uit die grafte Hom tegemoet ’n man met ’n gees van besoedeling,	",
"	3 wat sy verblyf in die grafte gehad het. En niemand kon selfs met kettings hom bind nie;	",
"	4 want hy was dikwels met voetboeie en kettings gebind, en die kettings is deur hom uitmekaar geruk en die voetboeie stukkend gebreek; en niemand was in staat om hom te tem nie.	",
"	5 En altyd, nag en dag, het hy aangehou om te skreeu op die berge en in die grafte en homself met klippe stukkend te slaan.	",
"	6 En toe hy JaHWèshua van ver af sien, hardloop hy en val voor Hom neer	",
"	7 en skreeu met ’n groot stem en sê: Wat het ek met U te doen, JaHWèshua, Seun van El die Hoogste El? Ek besweer U by Elohim om my nie te pynig nie.	",
"	8 Want Hy het vir hom gesê: Gees van besoedeling , gaan uit die man uit!	",
"	9 En Hy vra hom: Wat is jou naam? En hy antwoord en sê: Legio is my naam, want ons is baie.	",
"	10 Toe smeek hy Hom dringend om hulle nie uit die Aarde weg te stuur nie.	",
"	11 En dáár teen die berge het ’n groot trop varke gewei,	",
"	12 en al die geeste van besoedeling het Hom gesmeek en gesê: Stuur ons in die varke, sodat ons in hulle kan vaar.	",
"	13 En JaHWèshua het hulle dit dadelik toegelaat; en die geeste van besoedeling het uitgegaan en in die varke gevaar, en die trop - daar was omtrent tweeduisend - het van die krans af in die see gestorm en in die see verdrink.	",
"	14 En die wagters van die varke het gevlug en dit in die stad en in die buitewyke vertel; en hulle het uitgekom om te sien wat daar gebeur het.	",
"	15 Toe kom hulle by JaHWèshua en sien die besetene sit, gekleed en by sy verstand - die een wat die legioen gehad het. En hulle was bevrees.	",
"	16 Die wat dit gesien het, vertel toe aan hulle hoe dit met die besetene gegaan het, en ook van die varke.	",
"	17 En hulle het Hom begin smeek om weg te gaan uit hulle gebied.	",
"	18 En toe Hy in die skuit klim, het die man wat van die demone besete gewees het, Hom gesmeek om by Hom te kan bly.	",
"	19 Maar JaHWèshua het hom dit nie toegelaat nie, maar vir hom gesê: Gaan na jou huis na jou mense toe, en vertel hulle watter groot dinge JaHWeH aan jou gedoen het, en dat Hy jou barmhartig was.	",
"	20 En hy het weggegaan en in Dekápolis begin verkondig watter groot dinge JaHWèshua aan hom gedoen het, en almal was verwonderd.	",
		
		
"	21 EN toe JaHWèshua weer in die skuit oorgevaar het na die ander kant, het ’n groot menigte by Hom vergader. En Hy was by die see.	",
"	22 En daar kom een van die owerstes van die vergadering met die naam van Jaïrus; en toe hy Hom sien, val hy aan Sy voete neer	",
"	23 en smeek Hom dringend en sê: My dogtertjie is op haar uiterste; kom lê haar die hande op, sodat sy gesond kan word, en sy sal lewe.	",
"	24 En Hy het saam met hom gegaan. En ’n groot menigte het Hom gevolg en Hom verdring.	",
"	25 En ’n sekere vrou wat twaalf jaar lank bloedvloeiing gehad het	",
"	26 en veel onder baie geneeshere gely en al haar besittings uitgegee het sonder om enige baat te vind, maar eerder erger geword het,	",
"	27 het van JaHWèshua gehoor en onder die skare van agter gekom en Sy kleed aangeraak;	",
"	28 want sy het gesê: As ek maar Sy klere kan aanraak, sal ek gesond word.	",
"	29 En dadelik het die fontein van haar bloed opgedroog, en sy het aan haar liggaam bemerk dat sy van haar kwaal genees was.	",
"	30 En dadelik toe JaHWèshua in Homself die Krag gewaar word wat van Hom uitgegaan het, draai Hy Hom om onder die skare en sê: Wie het My klere aangeraak?	",
"	31 En Sy studente antwoord Hom: U sien dat die skare U verdring, en U sê: Wie het My aangeraak?	",
"	32 Toe kyk Hy rond om haar te sien wat dit gedoen het.	",
"	33 Die vrou, wat gevrees en gebeef het omdat sy wis wat met haar gebeur het, kom toe en val voor Hom neer en vertel Hom die hele waarheid.	",
"	34 En Hy sê vir haar: Dogter, jou Geloof het jou gered. Gaan in vrede en wees van jou kwaal genees.	",
"	35 Terwyl Hy nog spreek, kom daar mense van die owerste van die vergadering se huis en sê: U dogter is dood. Waarom val u die Meester nog lastig?	",
"	36 Maar dadelik, toe JaHWèshua die woord hoor wat gespreek is, sê Hy vir die owerste van die vergadering: Moenie vrees nie; glo net.	",
"	37 En Hy het niemand toegelaat om saam met Hom te gaan nie, behalwe Petrus en Jakobus en JeHôWganan, die broer van Jakobus.	",
"	38 En Hy kom in die huis van die owerste van die vergadering en sien ’n rumoer: mense wat baie ween en huil.	",
"	39 En toe Hy binnegaan, sê Hy vir hulle: Waarom gaan julle so te kere en ween julle? Die kind is nie dood nie, maar slaap.	",
"	40 En hulle het Hom uitgelag. Maar Hy het almal uitgedryf en die vader van die kind saamgeneem en die moeder en die wat by Hom was, en ingegaan waar die kind lê.	",
"	41 Toe gryp Hy die hand van die kind en sê vir haar: Talita, kuwm! wat, as dit vertaal [uit Aramees] word, beteken: Dogtertjie, Ek sê vir jou, staan op!	",
"	42 En die dogtertjie het dadelik opgestaan en begin rondloop, want sy was twaalf jaar oud. En hulle was uitermate verbaas.	",
"	43 En Hy het hulle met nadruk beveel dat niemand dit moes weet nie, en gesê dat daar vir haar iets te ete gegee moes word.	",

]
},
{
book: 'Markus',
chapter: '6',
content: [
		
"	1 EN Hy het daarvandaan weggegaan en in Sy vaderstad gekom, en Sy studente het Hom gevolg.	",
"	2 En toe dit Sabbat geword het, begin Hy in die vergadering te leer, en baie wat Hom gehoor het, was verslae en sê: Waar kry Hy hierdie dinge vandaan, en watter Wysheid is aan Hom gegee, dat ook sulke kragte deur Sy hande plaasvind?	",
"	3 Is Hy nie die timmerman, die seun van Mirjam, en die broer van Jakobus en Joses en Judas en Simon nie? En is Sy susters nie hier by ons nie? En hulle het aanstoot aan Hom geneem.	",
"	4 En JaHWèshua sê vir hulle: ’n Profeet is nie ongeëerd nie, behalwe in Sy vaderland en onder Sy familie en in Sy huis.	",
"	5 En Hy kon daar geen Krag doen nie, behalwe dat Hy ’n paar siekes die hande opgelê en hulle gesond gemaak het.	",
"	6 En Hy was verwonderd oor hulle wantroue. Daarop het Hy die dorpe rondom deurgegaan en geleer.	",
		
		
"	7 EN Hy het die twaalf na Hom geroep en hulle twee-twee begin uitstuur en het hulle mag gegee oor die geeste van besoedeling ,	",
"	8 en hulle bevel gegee om niks vir die pad saam te neem nie as net ’n stok alleen - geen reissak, geen brood, geen geld in die beurs nie,	",
"	9 maar skoene aan die voete; en: Julle moet nie twee kledingstukke aantrek nie. [Deuteronómium 22:11]	",
"	10 En Hy het vir hulle gesê: Waar julle ook al in ’n huis mag kom, bly dáár totdat julle daarvandaan vertrek.	",
"	11 En almal wat julle nie ontvang of na julle luister nie, gaan daarvandaan weg en skud die stof onder julle voete af tot ’n getuienis teen hulle. Voorwaar Ek sê vir julle, dit sal vir Sodom en Gomorra verdraagliker wees in die oordeelsdag as vir daardie stad.	",
"	12 En hulle het uitgegaan en verkondig dat die adamiete hulle moes bekeer.	",
"	13 En hulle het baie demone uitgedryf en baie siekes met olie gesalf en gesond gemaak.	",
		
		
"	14 TOE koning Herodes dit hoor - want Sy naam het bekend geword - het hy gesê: JeHôWganan die Wasser het uit die dode opgestaan, en daarom werk dié kragte in Hom.	",
"	15 Ander het gesê: Hy is EliJaHûW, en ander weer het gesê: Hy is ’n Profeet of soos een van die Profete.	",
"	16 Maar toe Herodes dit hoor, sê hy: JeHôWganan wat ek onthoof het, dit is hy; hy het uit die dode opgestaan.	",
"	17 Want Herodes self het gestuur en JeHôWganan gevange geneem en hom in die gevangenis geboei, vanweë Heródias, die vrou van Filippus, sy broer, omdat hy met haar getrou het.	",
"	18 Want JeHôWganan het aan Herodes gesê: Dit is u nie geoorloof om u broer se vrou te hê nie.	",
"	19 En Heródias het ’n oog op hom gehad en wou hom om die lewe bring en sy kon nie.	",
"	20 Want Herodes was bang vir JeHôWganan, omdat hy wis dat hy ’n regverdige en ’n man van Apartheid was, en hy het hom beskerm; en nadat hy hom gehoor het, het hy baie dinge gedoen en graag na hom geluister.	",
"	21 En op die geskikte dag, toe Herodes op sy verjaarsdag vir sy groot manne en die owerstes oor duisend en die vernaamstes van Galiléa ’n maaltyd gegee het;	",
"	22 en toe die dogter van dieselfde Heródias inkom en dans, en Herodes en die wat saam aan tafel was, behaag, sê die koning vir die meisie: Vra my net wat jy wil, en ek sal dit aan jou gee.	",
"	23 En hy het vir haar gesweer: Net wat jy my vra, sal ek jou gee, al was dit ook die helfte van my koninkryk.	",
"	24 Daarop gaan sy uit en sê vir haar moeder: Wat sal ek vra? Toe antwoord sy: Die hoof van JeHôWganan die Wasser.	",
"	25 En dadelik gaan sy haastig in na die koning en vra en sê: Ek wil hê dat u my op die daad die hoof van JeHôWganan die Wasser op ’n skottel gee.	",
"	26 Toe word die koning baie bedroef, maar ter wille van die eed en die wat saam aan tafel was, wou hy haar nie afwys nie.	",
"	27 En die koning stuur dadelik een van sy lyfwag met die bevel om sy hoof te bring; en hy het gegaan en hom in die gevangenis onthoof	",
"	28 en sy hoof op ’n skottel gebring en dit aan die meisie gegee, en die meisie het dit aan haar moeder gegee.	",
"	29 En toe sy studente dit hoor, het hulle gekom en sy lyk weggeneem en hom in ’n graf neergelê.	",
		
		
"	30 EN die Apostels het by JaHWèshua saamgekom en Hom alles vertel wat hulle gedoen sowel as wat hulle geleer het.	",
"	31 En Hy sê vir hulle: Kom julle self in die eensaamheid na ’n verlate plek en rus ’n bietjie. Want daar was baie wat kom en gaan, en hulle het selfs geen geskikte tyd gehad om te eet nie.	",
"	32 En hulle het met die skuit vertrek na ’n verlate plek in die eensaamheid.	",
"	33 En die skare het hulle sien weggaan, en baie het Hom herken en te voet van al die stede af daar saamgestroom en voor hulle uit gegaan en by Hom vergader.	",
"	34 En toe JaHWèshua uitklim, sien Hy ’n groot menigte, en Hy het vir hulle innig jammer gevoel, omdat hulle soos skape sonder herder was, en Hy het hulle baie dinge begin leer.	",
"	35 En toe dit reeds laat geword het, kom Sy studente na Hom en sê: Die plek is verlate en dit is reeds laat.	",
"	36 Stuur hulle weg, sodat hulle na die buitewyke en dorpe rondom kan gaan om brood vir hulleself te koop, want hulle het niks om te eet nie.	",
"	37 Maar Hy antwoord en sê vir hulle: Gee julle aan hulle iets om te eet. En hulle sê vir Hom: Moet ons gaan en vir tweehonderd pennings brood koop en aan hulle gee om te eet?	",
"	38 En Hy sê vir hulle: Hoeveel brode het julle? Gaan kyk. En toe hulle dit te wete gekom het, sê hulle: Vyf, en twee visse.	",
"	39 En Hy het hulle beveel om almal klompies-klompies op die groen gras te laat sit.	",
"	40 En hulle het gaan sit in groepe van honderd en van vyftig.	",
"	41 Hy neem toe die vyf brode en die twee visse, kyk op na die Hemele en dank; en Hy breek die brode en gee hom aan Sy studente om hom aan hulle voor te sit. Ook die twee visse het Hy onder almal verdeel.	",
"	42 En almal het geëet en versadig geword;	",
"	43 en hulle het van die brokstukke twaalf mandjies vol opgetel, en van die visse.	",
"	44 En die wat van die brood geëet het, was omtrent vyfduisend manne.	",
		
		
"	45 EN dadelik het Hy Sy studente gedwing om in die skuit te gaan en vooruit te vaar na die oorkant, na Betsáida, onderwyl Hy die skare sou wegstuur.	",
"	46 En nadat Hy van hulle afskeid geneem het, het Hy na die berg gegaan om te bid.	",
"	47 En toe dit aand geword het, was die skuit in die middel van die see en Hy alleen op die land.	",
"	48 En Hy het gesien dat hulle swaar kry met roei, want die wind was teen hulle. En omtrent die vierde nagwaak het Hy na hulle gekom, al wandelende op die see. En Hy wou by hulle verbygaan.	",
"	49 En toe hulle Hom op die see sien loop, het hulle gemeen dat dit ’n spook was en hard uitgeskreeu;	",
"	50 want hulle het Hom almal gesien en was ontsteld. Toe spreek Hy dadelik met hulle en sê vir hulle: Hou goeie moed, Ek Is; moenie vrees nie.	",
"	51 En Hy het by hulle in die skuit geklim, en die wind het gaan lê; en hulle was by hulleself uitermate verbaas en verwonderd.	",
"	52 Want hulle het by die wonder van die brode nie verstandig geword nie, omdat hulle hart verhard was.	",
"	53 En nadat hulle oorgevaar het, het hulle by die Aarde van Gennésaret aangekom en daar aan wal gaan lê.	",
"	54 En toe hulle uit die skuit gaan, het die adamiete Hom dadelik herken.	",
"	55 en hulle het in daardie hele omtrek rondgeloop en die wat ongesteld was, op bedde begin ronddra na die plek waar hulle hoor dat Hy is.	",
"	56 En waar Hy ook al ingegaan het in dorpe of stede of buitewyke, het hulle die wat ongesteld was, op die markpleine neergesit en Hom gesmeek om, al was dit maar die soom van Sy kleed, aan te raak; en almal wat Hom aangeraak het, het gesond geword.	",

]
},
{
book: 'Markus',
chapter: '7',
content: [
	
"	1 EN die Fariseërs en sommige van die skrywers wat van Jerusalem gekom het, het by Hom saamgekom;	",
"	2 en toe hulle sommige van Sy studente met vuil, dit is met ongewaste, hande sien brood eet, het hulle dit afgekeur.	",
"	3 Want die Fariseërs en al die Jode eet nie as hulle nie deeglik die hande gewas het nie, omdat hulle vashou aan die oorlewering van die oues.	",
"	4 En wanneer hulle van die mark kom, eet hulle nie as hulle nie gewas het nie; en baie ander dinge is daar wat hulle aangeneem het om te onderhou: die wassery van bekers en kanne en kopergoed en bedde.	",
"	5 Daarop stel die Fariseërs en die skrywers Hom die vraag: Waarom wandel U studente nie ooreenkomstig die oorlewering van die oues nie, maar eet brood met ongewaste hande?	",
"	6 En Hy antwoord en sê vir hulle: Tereg het JeshaJaHûW oor julle, tweegesigte, geprofeteer soos geskrywe is: Omdat hierdie volk nader kom met hulle mond en My eer met hulle lippe, terwyl hulle hul hart ver van My hou,	",
"	7 sodat hulle vrees vir My ’n aangeleerde gebod van sterflinge is. [JeshaJaH 29:13]	",
"	8 Want terwyl julle die Gebod van Elohim nalaat, hou julle aan die oorlewering van die sterflinge vas: die wassery van kanne en bekers, en ander dergelike dinge van dieselfde aard doen julle baie.	",
"	9 En Hy sê vir hulle: Julle verstaan dit goed om die Gebod van Elohim opsy te sit en so julle oorlewering te onderhou.	",
"	10 Want Moshè het gesê: Eer jou vader en jou moeder; en: Hy wat vader of moeder vloek, moet sekerlik sterwe. [Exodus 20:12, 21:17, Levítikus 20:9]	",
"	11 Maar julle sê: As ’n adamiet aan vader of moeder sê: Enige voordeel wat u van my mag geniet, is ‘n korban, dit is ’n bydrae -	",
"	12 dan laat julle hom nie meer toe om iets vir sy vader of sy moeder te doen nie.	",
"	13 So maak julle dan die Woord van Elohim kragteloos deur julle oorlewering wat julle onderhou het; en dergelike dinge van dieselfde aard doen julle baie.	",
"	14 En Hy het die hele skare na Hom geroep en vir hulle gesê: Luister almal na My en verstaan.	",
"	15 Daar is niks wat van buite af in die adamiet ingaan wat hom vuil kan maak nie; maar die dinge wat van hom uitgaan, dít is die dinge wat die adamiet vuil maak.	",
"	16 As iemand ore het om te hoor, laat hom hoor!	",
"	17 En toe Hy van die skare af in ’n huis gekom het, vra Sy studente Hom oor die gelykenis.	",
"	18 En Hy sê vir hulle: Is julle ook so sonder verstand? Begryp julle nie dat alles wat van buite af in die adamiet ingaan, hom nie vuil kan maak nie,	",
"	19 omdat dit nie ingaan in sy hart nie, maar in die maag, en dit gaan in die heimlikheid uit en suiwer al die voedsel ?	",
"	20 En Hy sê: Wat uit die adamiet uitgaan, dit maak die adamiet vuil.	",
"	21 Want van binne, uit die hart van die mense, kom die besoedelde gedagtes, vermenging, verbastering, moord,	",
"	22 diewery, hebsug, vuilheid, bedrog, ontug, ‘n besoedelde oog, laster [teen Elohim], hoogmoed, dwaasheid.	",
"	23 Al hierdie besoedeling kom van binne uit en sy maak die adamiet vuil.	",
		
		
"	24 EN Hy het opgestaan en daarvandaan na die gebied van Tirus en Sidon vertrek. En toe Hy in die huis gegaan het, wou Hy nie dat iemand dit sou weet nie; maar Hy kon nie verborge bly nie.	",
"	25 Want ’n vrou wie se dogtertjie ’n gees van besoedeling gehad het, het van Hom gehoor en gekom en voor Sy voete neergeval.	",
"	26 En sy was ’n Griekse vrou, ’n Siro-Feniciese van ras, en sy het Hom gevra om die demoon uit haar dogter uit te dryf.	",
"	27 Maar JaHWèshua sê vir haar: Laat eers die kinders versadig word; want dit is nie suiwer om die Brood van die kinders te neem en vir die honde te gooi nie.	",
"	28 En sy antwoord en sê vir Hom: Ja, Meester, maar die honde eet darem onder die tafel van die kinders se krummels.	",
"	29 En Hy sê vir haar: Ter wille van hierdie woord kan jy gaan; die demoon het uit jou dogter uitgevaar.	",
"	30 En toe sy huis toe gaan, vind sy dat die demoon uitgevaar het en dat haar dogter op die bed lê.	",
		
		
"	31 EN Hy het weer uit die gebied van Tirus en Sidon vertrek en na die see van Galiléa gegaan, deur die gebied van Dekápolis.	",
"	32 Toe bring hulle na Hom ’n dowe wat swaar praat, en smeek Hom om hom die hande op te lê.	",
"	33 En Hy neem hom opsy, weg van die skare, en steek Sy vingers in sy ore, en spuug en raak sy tong aan;	",
"	34 en nadat Hy opgekyk het na die Hemele, sug Hy en sê aan hom: Épathag, dit is: Gaan oop!	",
"	35 En dadelik het sy ore oopgegaan en die band van sy tong losgeraak, en hy het reg gepraat.	",
"	36 En Hy het hulle beveel om dit aan niemand te sê nie; maar hoe meer Hy hulle dit beveel, hoe meer het hulle dit verkondig.	",
"	37 En hulle was uitermate verslae en het gesê: Hy het alles goed gedoen: die dowes laat Hy hoor en die stommes praat.	",

]
},
{
book: 'Markus',
chapter: '8',
content: [
		
"	1 IN dié dae toe daar ’n baie groot menigte was en hulle niks gehad het om te eet nie, het JaHWèshua Sy studente na Hom geroep en vir hulle gesê:	",
"	2 Ek voel innig jammer vir die skare, omdat hulle al drie dae by My bly en niks het om te eet nie.	",
"	3 En as Ek hulle honger huis toe stuur, sal hulle op die pad beswyk, want sommige van hulle kom van ver.	",
"	4 En Sy studente antwoord Hom: Waarvandaan sal ’n mens hulle hier in die wildernis kan versadig met brood?	",
"	5 Toe vra Hy hulle: Hoeveel brode het julle? En hulle sê: Sewe.	",
"	6 En Hy gee aan die skare bevel om op die grond te gaan sit; daarop neem Hy die sewe brode, en nadat Hy gedank het, breek Hy hom en gee hom aan Sy studente om hom voor te sit; en hulle sit hom aan die skare voor.	",
"	7 Hulle het ook ’n paar vissies gehad; en nadat Hy gedank het, sê Hy dat hulle haar ook moet voorsit.	",
"	8 En hulle het geëet en versadig geword en die oorskot van die brokstukke opgetel, sewe mandjies vol.	",
"	9 En die wat geëet het, was omtrent vierduisend. En Hy het hulle weggestuur.	",
		
		
"	10 EN dadelik het Hy met Sy studente in die skuit geklim en in die streke van Dalmanúta gekom.	",
"	11 En die Fariseërs het uitgegaan en met Hom begin redetwis en van Hom ’n Teken uit die Hemele gevra om Hom te versoek.	",
"	12 Toe sug Hy swaar in Sy gees en sê: Waarom begeer hierdie saadlyn ’n teken? Voorwaar Ek sê vir julle, aan hierdie saadlyn sal sekerlik geen teken gegee word nie.	",
"	13 En Hy het hulle verlaat en weer in die skuit geklim en na die oorkant gegaan.	",
"	14 En hulle het vergeet om brode saam te neem, en het net een Brood by hulle in die skuit gehad.	",
"	15 En Hy het hulle beveel en gesê: Pas op, wees op julle hoede vir die suurdeeg van die Fariseërs en die suurdeeg van Herodes.	",
"	16 Toe redeneer hulle onder mekaar en sê: Dit is omdat ons geen brode het nie.	",
"	17 En JaHWèshua merk dit en sê vir hulle: Waarom redeneer julle dat julle geen brode het nie? Begryp julle nie en verstaan julle nie? Het julle nog jul verharde hart?	",
"	18 Het julle oë en sien julle nie? En het julle ore en hoor julle nie?	",
"	19 En onthou julle nie toe Ek die vyf brode vir die vyfduisend gebreek het, hoeveel mandjies vol brokstukke julle opgetel het nie? Hulle sê vir Hom: Twaalf.	",
"	20 En die sewe vir die vierduisend - hoeveel mandjies vol brokstukke het julle opgetel? En hulle sê: Sewe.	",
"	21 Toe sê Hy vir hulle: Hoe verstaan julle dan nie!	",
		
		
"	22 EN Hy het in Betsáida gekom, en hulle het ’n blinde man na Hom gebring en Hom gesmeek om hom aan te raak.	",
"	23 Hy neem toe die blinde by die hand en lei hom uit buitekant die dorp; en nadat Hy in sy oë gespuug en hom die hande opgelê het, vra Hy hom of hy iets sien.	",
"	24 En hy kyk op en sê: Ek sien die mense, want ek sien hulle soos bome rondloop.	",
"	25 Daarna lê Hy weer die hande op sy oë en laat hom opkyk, en hy is herstel en het almal van ver af duidelik gesien.	",
"	26 En Hy het hom na sy huis gestuur en gesê: Moenie in die dorp gaan of dit aan iemand in die dorp vertel nie.	",
		
		
"	27 EN JaHWèshua en Sy studente het uitgegaan na die dorpe van Cesaréa-Filíppi; en op die pad vra Hy Sy studente en sê vir hulle: Wie sê die adamiete is Ek?	",
"	28 En hulle antwoord: JeHôWganan die Wasser, en ander: EliJaHûW, en ander: Een van die Profete.	",
"	29 En Hy sê vir hulle: Maar julle, wie sê julle is Ek? En Petrus antwoord en sê vir Hom: U is die Gesalfde.	",
"	30 En Hy het hulle streng beveel om niemand van Hom te vertel nie.	",
"	31 Toe het Hy hulle begin leer dat die Seun van die Adam baie moet ly en verwerp word deur die oudstes en owerpriesters en skrywers en gedood word en ná drie dae opstaan.	",
"	32 En hierdie woord het Hy ronduit gespreek. En Petrus het Hom opsy geneem en Hom begin bestraf.	",
"	33 Maar Hy het Hom omgedraai, en terwyl Hy Sy studente aankyk, het Hy Petrus bestraf en gesê: Gaan weg agter My, Satan! Want jy bedink nie die dinge vir die Elohim nie, maar dié van die adamiete.	",
		
		
"	34 EN toe Hy die skare saam met Sy studente na Hom geroep het, sê Hy vir hulle: Wie agter My aan wil kom, moet homself ontsê en sy folterpaal opneem en My volg.	",
"	35 Want elkeen wat sy siel wil red, sal haar verloor; maar elkeen wat sy siel om My ontwil en om die goeie tyding ontwil verloor, hy sal haar red.	",
"	36 Want wat sal dit ’n adamiet baat as hy die hele wêreld win en aan sy siel skade ly?	",
"	37 Of wat sal ’n adamiet gee as losprys vir sy siel?	",
"	38 Want elkeen wat hom vir My en My Woorde skaam in hierdie verbasterde en wettelose saadlyn, vir hom sal die Seun van die Adam Hom ook skaam wanneer Hy kom in die Glansrykheid van Sy VADER met Sy Boodskappers, die Apartes.	",

]
},
{
book: 'Markus',
chapter: '9',
content: [
	
"	1 EN Hy sê vir hulle: Voorwaar Ek sê vir julle, daar is sommige van die wat hier staan, wat die Dood sekerlik nie sal smaak voordat hulle die Koninkryk van Elohim met Krag sien kom het nie.	",
		
		
"	2 EN ná ses dae het JaHWèshua vir Petrus en Jakobus en JeHôWganan saamgeneem en hulle alleen op ’n hoë berg in die eensaamheid geneem; en Hy het voor hulle van gedaante verander,	",
"	3 en Sy klere het geglans, baie wit soos sneeu, wit soos geen bleiker op Aarde dit kan maak nie.	",
"	4 En daar het aan hulle verskyn EliJaHûW saam met Moshè, en hulle was in gesprek met JaHWèshua.	",
"	5 Toe spreek Petrus en sê vir JaHWèshua: my Meester, dit is goed dat ons hier is. Laat ons dan drie takskuilings maak: vir U een en vir Moshè een en vir EliJaHûW een.	",
"	6 Want hy het nie geweet wat om te sê nie, want hulle was heeltemal verskrik.	",
"	7 En daar kom die Wolkkolom wat hulle oordek; en uit die Wolkkolom kom ’n Stem wat sê: DIT IS MY GELIEFDE SEUN. LUISTER NA HOM!	",
"	8 En meteens kyk hulle rond en sien niemand meer by hulle nie, behalwe JaHWèshua alleen.	",
"	9 En onderwyl hulle van die berg afklim, gee Hy aan hulle bevel om aan niemand te vertel wat hulle gesien het voordat die Seun van die Adam uit die dode opgestaan het nie.	",
"	10 En hulle het die Woord vir hulleself gehou en onder mekaar gevra wat dit beteken om uit die dode op te staan.	",
"	11 En hulle vra Hom en sê: Waarom sê die skrywers dat EliJaHûW eers moet kom?	",
"	12 Toe antwoord Hy en sê vir hulle: Sy is die Waarheid, EliJaHûW kom eers om alles te herstel; en tog, hoe staan daar dan van die Seun van die Adam geskrywe dat Hy baie moet ly en verag word? [JeshaJaHûW 53:3]	",
"	13 Maar Ek sê vir julle dat EliJaHûW al gekom het, en hulle het aan hom gedoen alles wat hulle wou, soos van hom geskrywe is.	",
		
		
"	14 EN toe Hy by die studente kom, sien Hy ’n groot menigte om hulle, en skrywers wat met hulle redetwis.	",
"	15 En dadelik toe die hele skare Hom sien, was hulle baie verbaas en het na Hom gehardloop en Hom gegroet.	",
"	16 Daarop vra Hy die skrywers: Waarom redetwis julle met hulle?	",
"	17 En een uit die skare antwoord en sê: Meester, ek het my seun wat ’n stomme gees het, na U gebring;	",
"	18 en waar hy hom ook aangryp, skeur hy hom; en hy kry skuim in die mond, en hy kners met sy tande en word styf; en ek het U studente gevra om hom uit te dryf, en hulle kon nie.	",
"	19 Toe antwoord Hy hom en sê: o Ongelowige geslag, hoe lank sal Ek by julle wees, hoe lank sal Ek julle verdra? Bring hom na My toe.	",
"	20 En hulle bring hom na Hom toe; en toe hy Hom sien, laat die gees hom dadelik stuiptrekkings kry, en hy val op die Aarde neer en rol rond met skuim in die mond.	",
"	21 Daarop vra Hy sy vader: Hoe lank is dit al dat dit hom oorgekom het? En hy sê: Van sy kindsdae af;	",
"	22 en dikwels het hy hom selfs in die vuur en in die water gegooi om hom dood te maak. Maar as U iets kan doen, ontferm U oor ons en help ons.	",
"	23 En JaHWèshua sê vir hom: Wat dit betref - as jy kan glo, alle dinge is moontlik vir die een wat glo.	",
"	24 En dadelik roep die vader van die kind met trane uit en sê: Ek glo, Meester, kom my wantroue te hulp!	",
"	25 En toe JaHWèshua sien dat ’n skare bymekaar stroom, het Hy die gees van besoedeling bestraf en vir hom gesê: Jou stom en dowe gees, Ek gebied jou, gaan uit hom uit en kom nooit weer in hom nie.	",
"	26 En nadat hy geskreeu en hom baie stuiptrekkings laat kry het, het hy uitgegaan. En die seun het soos ’n dooie geword, sodat baie gesê het: Hy is dood.	",
"	27 Maar JaHWèshua het hom by die hand gegryp en hom opgerig; en hy het opgestaan.	",
"	28 En toe Hy in die huis kom, vra Sy studente Hom afsonderlik: Waarom kon ons hom nie uitdrywe nie?	",
"	29 En Hy sê vir hulle: Hierdie tipe [gees] kan deur niks anders uitgaan as deur gebed en vas nie.	",
		
		
"	30 EN hulle het daarvandaan weggegaan en verbygetrek deur Galiléa; en Hy wou nie hê dat iemand dit moes weet nie.	",
"	31 Want Hy het Sy studente geleer en vir hulle gesê: Die Seun van die Adam word oorgelewer in die hande van die mense, en hulle sal Hom doodmaak; en nadat Hy gedood is, sal Hy die derde dag opstaan.	",
"	32 En hulle het die gesegde nie verstaan nie en was bang om Hom uit te vra.	",
"	33 En Hy het in Kapérnaüm gekom; en toe Hy in die huis was, vra Hy hulle: Wat het julle op die pad met mekaar geredeneer?	",
"	34 Maar hulle het stilgebly; want hulle het op die pad met mekaar gepraat oor wie die grootste is.	",
"	35 En toe Hy gaan sit het, roep Hy die twaalf en sê vir hulle: As iemand die eerste wil wees, moet hy die laaste van almal en almal se dienaar wees.	",
"	36 En Hy neem ’n kindjie en laat hom in hul midde staan en slaan Sy arms om hom en sê vir hulle:	",
"	37 Elkeen wat een van sulke kindertjies ontvang in My Naam, ontvang My. En elkeen wat My ontvang, ontvang nie My nie, maar HOM wat My gestuur het.	",
		
		
"	38 TOE antwoord JeHôWganan Hom en sê: Meester, ons het iemand gesien wat in U Naam demone uitdryf en wat ons nie volg nie; en ons het hom belet, omdat hy ons nie volg nie.	",
"	39 Maar JaHWèshua sê: Moet hom nie belet nie, want daar is niemand wat ’n Krag in My Naam sal doen en gou van My sal kan kwaadspreek nie;	",
"	40 want wie nie teen ons is nie, is vir ons.	",
"	41 Want elkeen wat vir julle in My Naam ’n Beker water gee om te drink, omdat julle aan die Gesalfde behoort, voorwaar Ek sê vir julle, hy sal sy loon sekerlik nie verloor nie.	",
		
		
"	42 EN elkeen wat een van hierdie kleintjies wat in My glo, laat struikel, dit is beter vir hom as ’n meulsteen om sy nek gehang en hy in die see gegooi word.	",
"	43 En as jou hand jou laat struikel, kap haar af. Dit is beter vir jou om vermink die lewe in te gaan, as om twee hande te hê en in die hel te gaan in die onuitbluslike vuur,	",
"	44 waar hulle wurm nie sterf en die vuur nie uitgeblus word nie.	",
"	45 En as jou voet jou laat struikel, kap haar af. Dit is beter vir jou om kreupel die lewe in te gaan, as om twee voete te hê en in die hel gewerp te word in die onuitbluslike vuur,	",
"	46 waar hulle wurm nie sterf en die vuur nie uitgeblus word nie.	",
"	47 En as jou oog jou laat struikel, pluk haar uit. Dit is beter vir jou om met een oog die Koninkryk van die Elohim in te gaan, as om twee oë te hê en in die helse vuur gewerp te word,	",
"	48 waar hulle wurm nie sterf en die vuur nie uitgeblus word nie.	",
"	49 Want elkeen sal met Vuur gesout word en elke Slagdier sal met sout gesout word.	",
"	50 Die sout is goed, maar as die sout souteloos word, waarmee sal julle Hom smaaklik maak? Julle moet sout in julle hê en Vrede hou met mekaar. [Númeri 18:19; 25:12; 2 Kronieke 13:5]	",

]
},
{
book: 'Markus',
chapter: '10',
content: [
		
"	1 EN Hy het opgestaan en daarvandaan deur die oorkant van die Jordaan na die gebied van JeHûWdah gegaan; en weer het ’n skare by Hom vergader; en soos Hy gewoond was, het Hy hulle weer geleer.	",
"	2 Toe kom die Fariseërs na Hom; en om Hom te versoek, stel hulle Hom die vraag of dit ’n man geoorloof is om van sy vrou te skei?	",
"	3 Maar Hy antwoord en sê vir hulle: Wat het Moshè julle beveel?	",
"	4 En hulle sê: Moshè het toegelaat om ’n skeibrief te skrywe en van haar te skei.	",
"	5 En JaHWèshua antwoord en sê vir hulle: Vanweë die hardheid van julle harte het hy vir julle hierdie Gebod geskrywe,	",
"	6 maar van die begin van die skepping af het Elohim hulle man en vrou gemaak.	",
"	7 Om hierdie rede sal die man sy vader en moeder verlaat en sy vrou aankleef,	",
"	8 en hulle twee sal een vlees word, sodat hulle nie meer twee is nie, maar een vlees. [Genesis 2:24]	",
"	9 Wat Elohim dan saamgevoeg het, mag geen adamiet skei nie.	",
"	10 En in die huis het Sy studente Hom weer oor dieselfde saak gevra.	",
"	11 En Hy sê vir hulle: Elkeen wat van sy vrou skei en die ander een trou, pleeg [die oortreding van] vermenging teen haar; [Exodus 20:14]	",
"	12 en as ’n vrou van haar man skei en met die ander een trou, pleeg sy vermenging.	",
		
		
"	13 EN hulle het kindertjies na Hom gebring, dat Hy hulle kon aanraak; en die studente het die wat hulle gebring het, bestraf.	",
"	14 Maar toe JaHWèshua dit sien, het Hy hulle dit baie kwalik geneem en vir hulle gesê: Laat die kindertjies na My toe kom en verhinder hulle nie, want aan sulkes behoort die Koninkryk van die Elohim.	",
"	15 Voorwaar Ek sê vir julle, elkeen wat die Koninkryk van die Elohim nie soos ’n kindjie ontvang nie, sal nooit in haar ingaan nie.	",
"	16 En Hy het Sy arms om hulle geslaan, Sy hande op hulle gelê en hulle geseën.	",
		
		
"	17 EN toe Hy op die pad uitgaan, hardloop daar een na Hom toe en val voor Hom op die knieë en vra Hom: Goeie Meester, wat moet ek doen om die Ewige Lewe te beërwe?	",
"	18 En JaHWèshua sê vir hom: Waarom noem jy My goed? Niemand is goed nie, behalwe EEN, naamlik die Elohim.	",
"	19 Jy ken die Gebooie: Jy mag nie verbaster nie, Jy mag nie moor nie, Jy mag nie steel nie, jy mag geen valse getuienis teen jou naaste spreek nie, Jy mag jou [naaste nie verdruk] of beroof nie; eer jou vader en jou moeder. [Exodus 20: Levítikus 19:13, Deuteronómium 5]	",
"	20 Maar hy antwoord en sê vir Hom: Meester, al hierdie dinge het ek onderhou van my jeug af.	",
"	21 En JaHWèshua het hom aangekyk en hom liefgekry en vir hom gesê: Een ding kom jy kort - gaan verkoop alles wat jy het, en gee dit aan die armes, en jy sal ’n skat in die Hemele hê; kom dan hier, neem die folterpaal op en VOLG MY.	",
"	22 Maar hy het treurig geword oor dié Woord en bedroef weggegaan, want hy het baie besittings gehad.	",
"	23 Toe kyk JaHWèshua rond en sê vir Sy studente: Hoe beswaarlik sal hulle wat goed besit, in die Koninkryk van Elohim ingaan!	",
"	24 En die studente was verbaas oor Sy Woorde; maar JaHWèshua antwoord weer en sê vir hulle: Kinders, hoe swaar is dit vir die wat op hulle goed vertrou, om in die Koninkryk van die Elohim in te gaan!	",
"	25 Dit is makliker vir ’n skeepstou om deur die oog van ’n naald te gaan as vir ’n ryk man om in die Koninkryk van die Elohim in te gaan.	",
"	26 En hulle was uitermate verslae en het vir mekaar gesê: Wie kan dan gered word?	",
"	27 Maar JaHWèshua het hulle aangekyk en geantwoord: By mense is dit onmoontlik, maar nie by Elohim nie; want by Elohim is alle dinge moontlik.	",
"	28 Toe begin Petrus vir Hom te sê: Kyk, ons het alles verlaat en U gevolg.	",
"	29 En JaHWèshua antwoord en sê: Voorwaar Ek sê vir julle, daar is niemand wat huis of broers of susters of vader of moeder of vrou of kinders of grond ter wille van My en van die Goeie Boodskap verlaat het nie,	",
"	30 of hy ontvang nou in hierdie tyd honderd maal soveel: huise en broers en susters en moeders en kinders en grond, saam met vervolginge, en in die tyd wat kom, die Ewige Lewe.	",
"	31 Maar baie wat eerste is, sal laaste wees, en die wat laaste is, eerste.	",
		
		
"	32 EN hulle was op die pad terwyl hulle opgaan na Jerusalem, en JaHWèshua het voor hulle uit gegaan, en hulle was verbaas; en terwyl hulle volg, het hulle gevrees. En Hy het weer die twaalf by Hom geneem en aan hulle begin vertel die dinge wat met Hom sou gebeur.	",
"	33 Kyk, sê Hy, ons gaan op na Jerusalem, en die Seun van die Adam sal oorgelewer word aan die owerpriesters en die skrywers, en hulle sal Hom tot die dood veroordeel en Hom oorlewer aan die nasies;	",
"	34 en hulle sal Hom bespot en Hom gésel en op Hom spuug en Hom doodmaak; en op die derde dag sal Hy opstaan. [JeshaJaH 50:6]	",
"	35 En Jakobus en JeHôWganan, die seuns van Sebedéüs, het na Hom gekom en gesê: Meester, ons wil hê dat U vir ons moet doen wat ons U ook al mag vra.	",
"	36 En Hy sê vir hulle: Wat wil julle hê moet Ek vir julle doen?	",
"	37 En hulle antwoord Hom: Gee aan ons dat ons mag sit in U Glansrykheid, een aan U regter- en een aan U linkerhand.	",
"	38 Maar JaHWèshua sê vir hulle: Julle weet nie wat julle vra nie. Kan julle die Beker drink wat Ek drink, en gewas/gedoop word met die wassing/doop waarmee Ek gewas/gedoop word?	",
"	39 En hulle antwoord Hom: Ons kan. Maar JaHWèshua sê vir hulle: Dis waar, die Beker wat Ek drink, sal julle drink, en met die was/doop waarmee Ek gewas/gedoop word, sal julle gewas/gedoop word;	",
"	40 maar om te sit aan My regter- en aan My linkerhand, berus nie by My om te gee nie, maar dit is vir hulle vir wie dit berei is.	",
"	41 En toe die tien dit hoor, begin hulle verontwaardig te word oor Jakobus en JeHôWganan.	",
"	42 Maar JaHWèshua het hulle na Hom geroep en vir hulle gesê: Julle weet dat die wat gereken word as owerstes van die nasies, oor hulle heers, en dat hulle magtiges oor hulle gesag uitoefen;	",
"	43 maar so moet dit onder julle nie wees nie, maar elkeen wat onder julle groot wil word, moet julle dienaar wees.	",
"	44 En elkeen wat onder julle die eerste wil word, moet almal se dienskneg wees.	",
"	45 Want die Seun van die Adam het ook nie gekom om gedien te word nie, maar om te dien en Sy Siel te gee as ’n losprys vir baie.	",
		
		
"	46 EN hulle het in Jérigo gekom. En toe Hy en Sy studente en ’n aansienlike skare uit Jérigo uitgaan, sit die blinde man, Bartiméüs, die seun van Timéüs, langs die pad en bedel.	",
"	47 En toe hy hoor dat dit JaHWèshua die Nasaréner was, begin hy om uit te roep en te sê: Seun van Dawid, JaHWèshua, wees my barmhartig!	",
"	48 En baie het hom bestraf, dat hy moet stilbly; maar hy het al harder uitgeroep: Seun van Dawid, wees my barmhartig!	",
"	49 Toe gaan JaHWèshua staan en sê dat hy geroep moes word; en hulle roep die blinde man en sê vir hom: Hou goeie moed, staan op! Hy roep jou.	",
"	50 En hy gooi sy oorkleed af, staan op en kom na JaHWèshua toe.	",
"	51 En JaHWèshua antwoord en sê vir hom: Wat wil jy hê moet Ek vir jou doen? En die blinde man sê vir Hom: Rabbóni, dat ek mag sien.	",
"	52 En JaHWèshua sê vir hom: Gaan, jou Geloof het jou gered. En dadelik het hy gesien en JaHWèshua op die pad gevolg.	",

]
},
{
book: 'Markus',
chapter: '11',
content: [
		
"	1 EN toe hulle naby Jerusalem kom, by Bétfagé en Betánië, aan die Berg van die Olywe, stuur Hy twee van Sy studente uit	",
"	2 en sê vir hulle: Gaan na daardie dorp reg voor julle; en dadelik as julle in haar inkom, sal julle ’n eselsvul vind wat vasgemaak is, waar geen adamiet op gesit het nie. Maak hom los en bring hom.	",
"	3 En as iemand vir julle sê: Waarom doen julle dit? moet julle antwoord: Die Meester het hom nodig; en dadelik sal hy hom hierheen stuur.	",
"	4 En hulle het gegaan en die vul by die deur, buite op die straat, vasgemaak gevind en hom losgemaak.	",
"	5 Daarop sê sommige van die wat daar staan, vir hulle: Wat maak julle dat julle die vul losmaak?	",
"	6 En hulle antwoord hul soos JaHWèshua beveel het. Toe laat hulle hul begaan.	",
"	7 En hulle het die vul na JaHWèshua gebring en hulle klere daarop gelê, en Hy het op hom gaan sit.	",
"	8 Toe gooi baie mense hulle klere op die pad oop, en ander kap takke van die bome af en strooi dit op die pad.	",
"	9 En die wat voor geloop en die wat gevolg het, het uitgeroep en gesê: Jashà-na! Geseënd is Hy wat kom in die Naam van JaHWeH!	",
"	10 Geseënd is die Koninkryk wat kom in die Naam van JaHWeH, die koninkryk van ons vader Dawid! Jashà-na in die Hoogste El! [Psalm 118:25, 26]	",
"	11 En JaHWèshua het in Jerusalem gekom en in die Tempel. En nadat Hy alles rondom bekyk het, en omdat dit al aand was, het Hy met die twaalf uitgegaan na Betánië.	",
		
		
"	12 EN die volgende dag, onderwyl hulle uit Betánië gaan, het Hy honger gehad;	",
"	13 en toe Hy op ’n afstand ’n Vyeboom met blare sien, het Hy daarheen gegaan in die hoop om iets aan haar te vind; en toe Hy by haar kom, vind Hy niks as blare nie, want dit was nie die tyd van vye nie.	",
"	14 En JaHWèshua spreek en sê vir haar: Laat niemand ooit in der ewigheid van jou ’n vrug eet nie! En Sy studente het dit gehoor.	",
"	15 En hulle het in Jerusalem gekom; en toe JaHWèshua in die Tempel ingaan, begin Hy om die wat in die Tempel verkoop en koop, uit te jaag; en die tafels van die geldwisselaars en die stoele van die duiweverkopers het Hy omgegooi;	",
"	16 en Hy het niemand toegelaat om enige voorwerp deur die Tempel te dra nie.	",
"	17 En Hy het geleer en vir hulle gesê: Is daar nie geskrywe: My Huis sal ’n Huis van gebed genoem word vir al die stamme. Maar julle het hom ’n rowerspelonk gemaak. [JeshaJaH 56:7, JirmeJaH 7:11]	",
"	18 En die skrywers en die owerpriesters het dit gehoor en gesoek hoe hulle Hom kon ombring; want hulle was bang vir Hom, omdat die hele skare verslae was oor Sy leer.	",
"	19 En toe dit laat word, het Hy uitgegaan buitekant die stad.	",
"	20 En toe hulle vroeg in die môre verbygaan, sien hulle die Vyeboom, verdroog van die wortels af.	",
"	21 En Petrus het onthou en vir Hom gesê: My Meester, kyk, die Vyeboom wat U vervloek het, is verdroog.	",
"	22 JaHWèshua antwoord en sê vir hulle: Julle moet Geloof in die Elohim hê.	",
"	23 Want, voorwaar Ek sê vir julle dat elkeen wat vir hierdie berg sê: Hef jou op en werp jou in die see - en nie in sy hart twyfel nie, maar glo dat wat hy sê, sal gebeur - hy sal verkry net wat hy sê.	",
"	24 Daarom sê Ek vir julle: Alles wat julle in die gebed vra, glo dat julle dit sal ontvang, en julle sal dit verkry.	",
"	25 En wanneer julle staan en bid, vergeef as julle iets teen iemand het, sodat julle Vader wat in die Hemele is, ook julle oortredinge mag vergewe.	",
"	26 Maar as julle nie vergewe nie, sal julle Vader wat in die Hemele is, ook julle oortredinge nie vergewe nie.	",
		
		
"	27 EN hulle het weer in Jerusalem gekom. En terwyl Hy in die Tempel rondwandel, kom die owerpriesters en die skrywers en die oudstes na Hom	",
"	28 en sê vir Hom: Deur watter gesag doen U hierdie dinge, en wie het U dié gesag gegee om dit te doen?	",
"	29 En JaHWèshua antwoord en sê vir hulle: Ek sal julle ook een ding vra, en antwoord julle My, dan sal Ek julle vertel deur watter gesag Ek hierdie dinge doen.	",
"	30 Die wassing/doop van JeHôWganan, was dit uit die Hemele of uit mense? Antwoord My.	",
"	31 En hulle het by hulleself geredeneer en gesê: As ons sê: Uit die Hemele - sal Hy sê: Waarom het julle hom dan nie geglo nie?	",
"	32 Maar as ons sê: Uit mense - dan was hulle vir die volk bang, want almal het gedink dat JeHôWganan werklik ’n Profeet was.	",
"	33 En hulle antwoord en sê vir JaHWèshua: Ons weet nie. En JaHWèshua antwoord en sê vir hulle: Dan vertel Ek julle ook nie deur watter gesag Ek hierdie dinge doen nie.	",

]
},
{
book: 'Markus',
chapter: '12',
content: [
		
"	1 TOE begin Hy deur gelykenisse vir hulle te sê: ’n Man het ’n Wingerd geplant en ’n heining om Haar gesit en ’n parskuip gegrawe en ’n wagtoring gebou, en Hy het Haar aan landbouers verhuur en op reis gegaan.	",
"	2 En op die regte tyd het Hy ’n dienskneg na die landbouers gestuur om van die landbouers uit die vrug van die Wingerd te ontvang;	",
"	3 maar hulle het hom geneem en geslaan en hom met leë hande weggestuur.	",
"	4 En weer het Hy ’n ander dienskneg na hulle gestuur; en hom het hulle gestenig en aan die hoof gewond, hom skandelik behandel en teruggestuur.	",
"	5 En weer het Hy ’n ander een gestuur, en hom het hulle doodgemaak; ook baie ander - sommige het hulle geslaan en ander doodgemaak.	",
"	6 Hy het toe nog een Seun gehad, Sy Geliefde, en Hom die laaste na hulle gestuur en gesê: Hulle sal My Seun hoogag.	",
"	7 Maar daardie landbouers het by hulleself gesê: Hy is die Erfgenaam; kom laat ons Hom doodmaak, en die Erfdeel sal ons s’n wees.	",
"	8 En hulle het Hom geneem en doodgemaak en buitekant die Wingerd uitgewerp.	",
"	9 Wat sal die Eienaar van die Wingerd dan doen? Hy sal kom en die landbouers ombring en die Wingerd aan ander gee.	",
"	10 Het julle nie ook hierdie Skrifwoord gelees nie: Die Klip wat die bouers verwerp het, Sy het ’n Hoeksteen geword? [Psalm 118:22]	",
"	11 Sy het van JaHWeH gekom en is wonderbaar in ons oë.	",
"	12 En hulle het probeer om Hom in die hande te kry, maar was bang vir die skare, want hulle het begryp dat Hy die gelykenis met die oog op hulle uitgespreek het. Daarop het hulle Hom verlaat en weggegaan.	",
		
		
"	13 TOE stuur hulle na Hom sommige van die Fariseërs en van die Herodiane om Hom op ’n woord te betrap.	",
"	14 En hulle kom en sê vir Hom: Meester, ons weet dat U waaragtig is en U aan niemand steur nie; want U sien nie die persoon van mense aan nie, maar U leer die Weg van Elohim in Waarheid. Is dit geoorloof om aan die keiser belasting te betaal of nie? Moet ons betaal of moet ons nie betaal nie?	",
"	15 Maar Hy het hulle geveinsdheid geken en vir hulle gesê: Waarom versoek julle My? Bring vir My ’n penning, dat Ek dit kan sien.	",
"	16 En hulle het dit gebring. En Hy sê vir hulle: Wie se beeld en opskrif is dit? En hulle antwoord Hom: Die keiser s’n.	",
"	17 Toe antwoord JaHWèshua en sê vir hulle: Betaal aan die keiser wat die keiser toekom, en aan Elohim wat Elohim toekom. En hulle was verwonderd oor Hom.	",
		
		
"	18 TOE kom daar Sadduseërs na Hom, die wat sê dat daar geen opstanding is nie, en hulle vra Hom en sê:	",
"	19 Meester, Moshè het ons voorgeskrywe: As iemand se broer sterwe en ’n vrou agterlaat en geen kinders nalaat nie, moet sy broer sy vrou neem en ‘n nageslag vir sy broer verwek.	",
"	20 Nou was daar sewe broers, en die eerste het ’n vrou geneem en gesterwe sonder om ‘n nageslag na te laat.	",
"	21 En die tweede het haar geneem en gesterwe, en hy het ook geen nageslag nagelaat nie; en die derde net so.	",
"	22 En al sewe het haar geneem en geen nageslag nagelaat nie. Laaste van almal het die vrou ook gesterwe.	",
"	23 In die opstanding dan, wanneer hulle opstaan, wie van hulle se vrou sal sy wees? - want al sewe het haar as vrou gehad.	",
"	24 En JaHWèshua antwoord en sê vir hulle: Is dit nie daarom dat julle dwaal dat julle die Skrifte en ook die Krag van El nie ken nie?	",
"	25 Want wanneer hulle uit die dode opstaan, trou hulle nie en word hulle nie in die huwelik uitgegee nie, maar is soos Boodskappers wat in die Hemele is.	",
"	26 En wat die dode betref, dat hulle opstaan - het julle nie gelees in die boek van Moshè, in die gedeelte oor die doringbos, hoe Elohim vir hom gesê het: Ek [is] die Elohey van Abraham en die Elohey van Isak en die Elohey van Jakob nie? [Exodus 3:6]	",
"	27 Hy is nie ’n Elohey van dooies nie, maar ’n Elohey van lewendes. Julle dwaal dus grootliks.	",
		
		
"	28 EN toe een van die skrywers wat bygekom het, hulle hoor redetwis, en wis dat Hy hulle goed geantwoord het, vra hy vir Hom: Wat is die eerste Gebod van almal?	",
"	29 En JaHWèshua antwoord hom: Die eerste van al die Gebooie is: Hoor, JisraEl, JaHWeH, onse Elohey, JaHWeH [is] EEN; [Deuteronómium 6:4]	",
"	30 en jy moet JaHWeH jou Elohey liefhê uit jou hele hart en uit jou hele siel en uit jou hele verstand en uit jou hele krag. Sy is die eerste Gebod. [Deuteronómium 6:5]	",
"	31 En die tweede, hieraan gelyk, is dit: Jy moet jou naaste liefhê soos jouself. Daar is geen ander Gebod groter as sy nie. [Levítikus 19:18]	",
"	32 En die taalkundige sê vir Hom: Goed, Meester, U het met Waarheid gesê dat Elohey een is en daar geen ander is as Hy nie;	",
"	33 en om Hom lief te hê uit die hele hart en uit die hele verstand en uit die hele siel en uit die hele krag, en om die naaste lief te hê soos jouself, is meer as al die brandoffers en die slagdiere.	",
"	34 Toe JaHWèshua sien dat hy verstandig geantwoord het, sê Hy vir hom: Jy is nie ver van die Koninkryk van Elohim nie. En niemand het dit meer gewaag om Hom vrae te stel nie.	",
		
		
"	35 EN terwyl JaHWèshua in die Tempel leer, antwoord Hy en sê: Hoe sê die skrywers dat die Gesalfde die seun van Dawid is?	",
"	36 Want Dawid self het deur die Gees van die Apartheid gesê: JaHWeH het tot My Meester gespreek: Sit aan My regterkant totdat Ek U vyande gemaak het ’n Voetbank vir U voete. [Psalm 110:1]	",
"	37 Dawid self noem Hom dus Meester; waarvandaan is Hy dan sy seun? En die groot menigte het graag na Hom geluister.	",
		
		
"	38 EN Hy het aan hulle in Sy onderrig gesê: Pas op vir die skrywers wat graag in lang klere rondloop en van begroetinge op die markte hou	",
"	39 en van die voorste banke in die vergaderings en die voorste plekke by die maaltye -	",
"	40 hulle wat die huise van die weduwees opeet en vir die skyn lang gebede doen. Hulle sal ’n swaarder oordeel ontvang.	",
		
		
"	41 EN JaHWèshua het reg voor die skatkis gaan sit en gekyk hoe die skare geld in die skatkis gooi. En baie rykes het veel ingegooi.	",
"	42 En daar kom een arm weduwee en gooi twee geldstukkies in, dit is ’n oortjie.	",
"	43 Toe roep Hy Sy studente na Hom en sê vir hulle: Voorwaar Ek sê vir julle, hierdie arm weduwee het meer ingegooi as almal wat in die skatkis gegooi het.	",
"	44 Want hulle het almal uit hulle oorvloed ingegooi; maar sy het uit haar gebrek ingegooi alles wat sy gehad het, haar hele lewensonderhoud.	",
		

]
},
{
book: 'Markus',
chapter: '13',
content: [
		
"	1 EN toe Hy uit die Tempel uitgaan, sê een van Sy studente vir Hom: Meester, kyk watter klippe en watter geboue!	",
"	2 En JaHWèshua antwoord en sê vir hom: Sien jy hierdie groot geboue? Daar sal sekerlik nie een klip op die ander gelaat word wat nie afgebreek sal word nie!	",
"	3 En toe Hy gaan sit het op die Berg van die Olywe, regoor die Tempel, vra Petrus en Jakobus en JeHôWganan en Andréas Hom afsonderlik:	",
"	4 Vertel ons, wanneer sal hierdie dinge wees, en wat is die Teken wanneer al hierdie dinge volbring word?	",
"	5 En JaHWèshua antwoord hulle en begin te sê: Pas op dat niemand julle mislei nie.	",
"	6 Want baie sal onder My Naam kom en dit sê: Ek Is! En hulle sal baie adamiete mislei.	",
"	7 Maar wanneer julle hoor van oorloë en gerugte van oorloë, moet julle nie verskrik word nie, want dit moet kom. Maar dit is nog nie die einde nie.	",
"	8 Want die een nasie sal teen die ander opstaan, en die een koninkryk teen die ander; en daar sal aardbewings wees op verskillende plekke, en daar sal hongersnode wees en beroeringe. Hierdie dinge is ’n begin van die smarte.	",
"	9 Maar wees julle vir julleself op die hoede, want hulle sal julle oorlewer aan regbanke, en in vergaderings sal julle geslaan word en voor goewerneurs en konings gebring word om My ontwil, vir hulle tot ’n getuienis.	",
"	10 En die goeie tyding moet eers aan al die nasies verkondig word.	",
"	11 En wanneer hulle jul weglei om julle oor te lewer, moenie julle vooraf kwel oor wat julle sal spreek nie, en moenie daaroor dink nie; maar wat julle in dié uur gegee word, dit moet julle spreek; want dit is nie julle wat spreek nie, maar die Gees van die Apartheid.	",
"	12 En die een broer sal die ander tot die Dood oorlewer, en die vader sy kind, en die kinders sal teen hulle ouers opstaan en hulle doodmaak.	",
"	13 En julle sal deur almal gehaat word ter wille van My Naam. Maar wie volhard tot die einde toe, hy sal gered word.	",
		
		
"	14 EN wanneer julle die gruwel van die verwoesting, waarvan gespreek is deur die Profeet DaniEl, sien staan waar dit nie behoort nie - laat hom wat lees, oplet - dan moet die wat in JeHûWdah is, na die berge vlug;	",
"	15 en wie op die dak is, moet nie afkom in die huis en ook nie ingaan om iets uit sy huis weg te neem nie;	",
"	16 en wie op die grond is, moet nie omdraai na wat agter is om sy kleed weg te neem nie.	",
"	17 Maar wee die vroue wat swanger is en die wat nog soog, in daardie dae!	",
"	18 En bid dat julle vlug nie in die winter mag plaasvind nie.	",
"	19 Want daardie dae sal daar ’n verdrukking wees soos daar nie gewees het van die begin van die skepping af wat Elohim geskape het tot nou toe, en ook nooit sal wees nie.	",
"	20 En as JaHWeH dié dae nie verkort het nie, sou geen vlees gered word nie; maar ter wille van die uitverkorenes wat Hy uitverkies het, het Hy dié dae verkort.	",
"	21 En as iemand dan vir julle sê: Kyk, hier is die Gesalfde! of: Kyk, daar! - moet dit nie glo nie.	",
"	22 Want daar sal valse gesalfdes en valse profete opstaan, en hulle sal tekens en wonders doen om, as dit moontlik was, ook die uitverkorenes te mislei.	",
"	23 Maar julle moet op jul hoede wees. Kyk, Ek het alles vir julle vooruit gesê.	",
		
		
"	24 MAAR in daardie dae, ná dié verdrukking, sal die son verduister word, en die maan sal sy glans nie gee nie,	",
"	25 en die Sterre van die Hemele sal val, en die kragte wat in die Hemele is, sal geskud word. [JeshaJaH 24:20]	",
"	26 En dan sal hulle die Seun van die Adam op die Wolkkolom sien kom met groot Krag en Glansrykheid.	",
"	27 En dan sal Hy Sy Boodskappers uitstuur, en Hy sal Sy uitverkorenes uit die vier windstreke versamel, van die Einde van die Aarde af tot by die einde van die Hemele.	",
"	28 En leer van die Vyeboom hierdie gelykenis: Wanneer Haar tak al sag word en Haar blare uitbot, weet julle dat die somer naby is.	",
"	29 So weet julle ook, wanneer julle hierdie dinge sien gebeur, dat dit naby is, voor die deur.	",
"	30 Voorwaar Ek sê vir julle, hierdie saadlyn sal sekerlik nie tot niet gaan voordat al hierdie dinge gebeur het nie.	",
"	31 Die Hemele en die Aarde sal verbygaan, maar My Woorde sal nooit verbygaan nie.	",
"	32 Maar van daardie dag en dié uur weet niemand nie, ook nie die Boodskappers in die Hemele of die Seun nie, maar net die VADER.	",
		
		
"	33 PAS op, waak en bid, want julle weet nie wanneer die tyd daar is nie.	",
"	34 Dit is soos ’n man wat op reis is wat sy huis agtergelaat en sy diensknegte volmag gegee het, en vir elkeen sy werk, en aan die deurwagter bevel gegee het om te waak.	",
"	35 Waak dan, want julle weet nie wanneer die eienaar van die huis kom nie: in die aand of middernag of met die haangekraai of vroeg in die môre nie; [Psalm 102:14]	",
"	36 dat hy nie miskien skielik kom en julle aan die slaap vind nie.	",
"	37 En wat Ek vir julle sê, sê Ek vir almal: Waak!	",

]
},
{
book: 'Markus',
chapter: '14',
content: [
		
"	1 EN die Pasga en die Fees van die Ongesuurde Brode sou oor twee dae wees; en die owerpriesters en die skrywers het gesoek hoe hulle Hom met lis gevange kon neem en doodmaak.	",
"	2 Maar hulle het gesê: Nie op die Fees nie, sodat daar nie miskien ’n oproer onder die volk kom nie.	",
		
		
"	3 EN toe Hy in Betánië was, in die huis van Simon, die melaatse, terwyl Hy aan tafel was, kom daar ’n vrou met ’n albasterfles met egte, baie kosbare nardussalf; en sy breek die albasterfles en gooi haar op Sy hoof uit.	",
"	4 En daar was sommige wat by hulleself verontwaardig was en gesê het: Waarvoor het hierdie verkwisting van die salf plaasgevind?	",
"	5 Want sy kon vir meer as driehonderd pennings verkoop en die geld aan die armes gegee geword het. En hulle het teen haar uitgevaar.	",
"	6 Maar JaHWèshua sê: Laat haar staan; waarom val julle haar lastig? Sy het ’n goeie werk aan My gedoen.	",
"	7 Want die armes het julle altyd by julle, en wanneer julle wil, kan julle aan hulle goed doen; maar My het julle nie altyd nie.	",
"	8 Wat sy kon, het sy gedoen. Sy het vooruit al My liggaam vir die begrafnis gesalf.	",
"	9 Voorwaar Ek sê vir julle, oral waar hierdie goeie tyding oor die hele wêreld verkondig word, daar sal ook gespreek word van wat sy gedoen het, tot ’n gedagtenis aan haar.	",
		
		
"	10 EN Judas Iskáriot, een van die twaalf, het na die owerpriesters gegaan om Hom aan hulle oor te lewer.	",
"	11 En toe hulle dit hoor, was hulle bly en het belowe om hom geld te gee. En hy het na ’n goeie geleentheid gesoek om Hom oor te lewer.	",
		
		
"	12 EN op die dag voor die Fees van die Ongesuurde Brode, wanneer hulle gewoonlik die Pasga doodgebloei het, sê Sy studente vir Hom: Waar wil U hê moet ons hom gaan voorberei, dat U die Pasga kan eet?	",
"	13 En Hy stuur twee van Sy studente en sê vir hulle: Gaan na die stad toe; en ’n man wat ’n kruik water dra, sal julle tegemoetkom. Volg hom,	",
"	14 en waar hy ook mag ingaan, moet julle vir die eienaar van die huis sê: Die Meester laat weet: Waar is die kamer waar Ek met My studente die Pasga kan eet?	",
"	15 En hy sal julle ’n groot bo-vertrek wys, in gereedheid gebring. Daar moet julle vir ons klaarmaak.	",
"	16 En Sy studente het gegaan en in die stad gekom en dit gevind soos Hy vir hulle gesê het; en hulle het die Pasga gereedgemaak.	",
"	17 En toe dit aand geword het, kom Hy met die twaalf.	",
"	18 En terwyl hulle aan tafel was en eet, sê JaHWèshua: Voorwaar Ek sê vir julle, een van julle sal My verraai, een wat saam met My eet.	",
"	19 Toe het hulle begin om bedroef te word en een vir een aan Hom te sê: Is dit miskien ek? En ’n ander een: Is dit miskien ek?	",
"	20 En Hy antwoord en sê vir hulle: Dit is een van die twaalf wat saam met My sy hand in die skottel insteek.	",
"	21 Die Seun van die Adam gaan wel heen soos daar van Hom geskrywe is; maar wee daardie man deur wie die Seun van die Adam verraai word! Dit sou vir hom goed gewees het as daardie man nie gebore was nie.	",
"	22 En terwyl hulle eet, neem JaHWèshua Brood, en nadat Hy gedank het, breek Hy Hom en gee Hom aan hulle en sê: Neem, eet, Hy is My liggaam.	",
"	23 Toe neem Hy die Beker, en nadat Hy gedank het, gee Hy Haar aan hulle, en hulle het almal uit Haar gedrink.	",
"	24 En Hy sê vir hulle: Sy is My Bloed, die Bloed van die Nuwe Verbond, wat vir baie uitgestort word.	",
"	25 Voorwaar Ek sê vir julle, Ek sal nooit meer van die Vrug van die Wingerdstok drink nie, tot op daardie dag wanneer Ek Haar nuut sal drink in die Koninkryk van die Elohim.	",
"	26 En toe hulle die lofsang gesing het, het hulle uitgegaan na die Berg van die Olywe.	",
		
		
"	27 TOE sê JaHWèshua vir hulle: Julle sal almal in hierdie nag aanstoot neem aan My; want daar is geskrywe: Slaan die Herder, sodat die skape verstrooi word [en Ek sal My Hand weer uitstrek oor die geringes]. [ZekarJaH 13:7]	",
"	28 Maar nadat Ek opgestaan het, sal Ek voor julle uit na Galiléa gaan.	",
"	29 En Petrus sê vir Hom: Al sal almal ook aanstoot neem, dan tog nie ek nie.	",
"	30 Daarop sê JaHWèshua vir hom: Voorwaar Ek sê vir jou, vandag, in hierdie nag, voordat die haan twee maal gekraai het, sal jy drie maal teen My getuig.	",
"	31 Maar hy het nog baie meer aangehou en gesê: Al moes ek saam met U sterwe, ek sal nooit teen U getuig nie! En net so het almal ook gesê.	",
		
		
"	32 TOE kom hulle in ’n plek waarvan die naam Getsémané was. En Hy sê vir Sy studente: Sit hier onderwyl Ek gaan bid.	",
"	33 En Hy neem Petrus en Jakobus en JeHôWganan saam met Hom en begin ontsteld en benoud te word.	",
"	34 En Hy sê vir hulle: My Siel is diep bedroef tot die dood toe; bly hier en waak.	",
"	35 En toe Hy ’n bietjie verder gegaan het, val Hy op die grond en bid dat, as dit moontlik was, dié uur by Hom sou verbygaan.	",
"	36 En Hy sê: ABBA, VADER, alle dinge is vir U moontlik; neem hierdie Beker van My weg; nogtans nie wat Ek wil nie, maar wat U wil.	",
"	37 En Hy kom en vind hulle aan die slaap en sê vir Petrus: Simon, slaap jy? Was jy nie in staat om een uur te waak nie?	",
"	38 Waak en bid, dat julle nie in versoeking kom nie. Die gees is wel gewillig, maar die vlees is swak.	",
"	39 Hy gaan toe weer weg en bid dieselfde woorde.	",
"	40 En toe Hy terugkom, vind Hy hulle weer aan die slaap, want hulle oë was swaar; en hulle het nie geweet wat om Hom te antwoord nie.	",
"	41 En Hy kom vir die derde keer en sê aan hulle: Slaap maar voort en rus. Dit is genoeg; die uur het gekom. Kyk, die Seun van die Adam word oorgelewer in die hande van die oortreders.	",
"	42 Staan op, laat ons gaan; kyk, hy is naby wat My verraai.	",
		
		
"	43 EN dadelik, terwyl Hy nog spreek, verskyn Judas wat een van die twaalf was, en saam met hom ’n groot menigte met swaarde en stokke, gestuur deur die owerpriesters en die skrywers en die oudstes.	",
"	44 En Sy verraaier het ’n teken met hulle afgespreek en gesê: Die een wat ek sal soen - dit is Hy; gryp Hom en neem Hom met sekerheid weg.	",
"	45 En toe hy kom, gaan hy dadelik na Hom en sê: My Meester, my Meester! en soen Hom.	",
"	46 Daarop slaan hulle hul hande aan Hom en gryp Hom.	",
"	47 En een van die wat daar gestaan het, het sy swaard uitgetrek en die dienskneg van die hoëpriester geslaan en sy oor afgekap.	",
"	48 En JaHWèshua antwoord en sê vir hulle: Het julle soos teen ’n rower uitgetrek met swaarde en stokke om My gevange te neem?	",
"	49 Dag vir dag was Ek by julle in die Tempel besig om te leer, en julle het My nie gegryp nie. Maar die Skrifte moes vervul word.	",
"	50 Toe het almal Hom verlaat en gevlug.	",
"	51 En ’n sekere jongman met ’n linnedoek om sy naakte lyf het Hom gevolg; en die jongmanne het hom gegryp;	",
"	52 maar hy het die linnedoek laat staan en naak van hulle weggevlug.	",
		
		
"	53 EN hulle het JaHWèshua weggelei na die hoëpriester. En al die owerpriesters en die oudstes en die skrywers het by hom vergader.	",
"	54 En Petrus het Hom van ver af gevolg tot binne-in die paleis van die hoëpriester, en het saam met die dienaars gesit en hom by die vuur warm gemaak.	",
"	55 En die owerpriesters en die hele Raad het getuienis teen JaHWèshua gesoek om Hom dood te maak, en hulle het niks gevind nie;	",
"	56 want baie het vals teen Hom getuig en die getuienisse was nie eenders nie.	",
"	57 En sommige het opgestaan en vals teen Hom getuig en gesê:	",
"	58 Ons het Hom hoor sê: Ek sal hierdie Tempel wat met hande gemaak is, afbreek en in drie dae ’n ander een opbou wat nie met hande gemaak is nie.	",
"	59 En selfs so was hulle getuienis nie eenders nie.	",
"	60 Toe staan die hoëpriester in hul midde op en vra JaHWèshua en sê: Antwoord U niks nie? Wat getuig hierdie manne teen U?	",
"	61 Maar Hy het stilgebly en geen antwoord gegee nie. Weer stel die hoëpriester Hom die vraag en sê vir Hom: Is U die Gesalfde, die Seun van die Geseënde?	",
"	62 En JaHWèshua sê: Ek Is. En u almal sal die Seun van die Adam aan die regterkant van die Krag sien sit en kom met die Wolkkolom van die Hemele.	",
"	63 Toe skeur die hoëpriester sy klere en sê: Wat het ons nog getuies nodig!	",
"	64 Julle het die laster teen Elohim gehoor; wat dink julle? En hulle het almal Hom veroordeel dat Hy die dood skuldig was.	",
"	65 En sommige het begin om op Hom te spuug en Sy aangesig toe te maak en Hom met die vuis te slaan en vir Hom te sê: Profeteer! En die dienaars het Hom met stokke geslaan. [Psalm 129:3; JeshaJaH 50:6; Boodskap van Petrus 1:9; MattithJaHûW 27:30]	",
		
		
"	66 EN terwyl Petrus onder in die binneplaas was, kom daar een van die diensmeisies van die hoëpriester,	",
"	67 en toe sy Petrus sien, besig om hom warm te maak, kyk sy na hom en sê: Jy was ook by die Nasaréner, JaHWèshua.	",
"	68 Maar hy het dit ontken en gesê: Ek weet nie en begryp nie wat jy sê nie. En hy het buite na die voorplein gegaan; en die haan het gekraai.	",
"	69 En toe die diensmeisie hom weer sien, begin sy aan die wat daar staan, te sê: Hierdie man behoort by hulle.	",
"	70 Maar hy het dit weer ontken. En ’n bietjie later weer sê die wat daar staan vir Petrus: Waarlik, jy behoort by hulle, want jy is ook ’n Galiléër en jou spraak is net so.	",
"	71 Toe begin hy homself te verwens en te sweer: Ek ken nie daardie Man van Wie julle praat nie.	",
"	72 En vir die tweede keer het die haan gekraai; en Petrus het die woord onthou wat JaHWèshua vir hom gesê het: Voor die haan twee maal gekraai het, sal jy drie maal teen My getuig het. En hy het in trane uitgebars.	",
		

]
},
{
book: 'Markus',
chapter: '15',
content: [
		
"	1 EN dadelik, vroeg in die môre, het die owerpriesters saam met die oudstes en skrywers en die hele Raad ’n besluit geneem; en nadat hulle JaHWèshua geboei het, het hulle Hom weggelei en aan Pilatus oorgelewer.	",
"	2 En Pilatus het Hom gevra: Is U die Koning van die manne van JeHûWdah? En Hy het geantwoord en vir hom gesê: U sê dit.	",
"	3 En die owerpriesters het baie beskuldigings teen Hom ingebring.	",
"	4 En Pilatus het Hom weer gevra en gesê: Antwoord U niks nie? Kyk hoe baie getuienisse hulle teen U inbring.	",
"	5 Maar JaHWèshua het niks meer geantwoord nie, sodat Pilatus hom verwonder het.	",
"	6 En op die Fees was hy gewoond om een gevangene, die een wat hulle gevra het, vir hulle los te laat.	",
"	7 En daar was ’n sekere Barábbas wat met mede-oproermakers in die gevangenis was; en hulle het in die opstand ’n moord begaan.	",
"	8 En die skare het geskreeu en begin vra dat hy vir hulle sou doen soos altyd.	",
"	9 Toe antwoord Pilatus en sê vir hulle: Wil julle hê dat ek vir julle die Koning van die manne van JeHûWdah moet loslaat?	",
"	10 Want hy het geweet dat die owerpriesters Hom uit nydigheid oorgelewer het.	",
"	11 Maar die owerpriesters het die skare aangehits dat hy liewer Barábbas vir hulle moes loslaat.	",
"	12 Toe antwoord Pilatus weer en sê vir hulle: Wat wil julle dan hê moet ek doen met Hom wat julle Koning van die manne van JeHûWdah noem?	",
"	13 En hulle skreeu weer: Folter Hom!	",
"	14 Maar Pilatus sê vir hulle: Wat het Hy dan verkeerd gedoen? Hulle skreeu toe nog harder: Folter Hom!	",
"	15 En omdat Pilatus aan die skare hulle sin wou gee, het hy Barábbas vir hulle losgelaat; en nadat hy JaHWèshua laat gésel het, het hy Hom oorgelewer om gefolter te word.	",
"	16 Toe lei die soldate Hom weg in die binneplaas, dit is die goewerneur se paleis, en hulle roep die hele leërafdeling bymekaar	",
"	17 en trek Hom ’n purperkleed aan en vleg ’n kroon van dorings en sit haar vir Hom op;	",
"	18 en hulle begin Hom begroet: Wees gegroet, Koning van JeHûWdah!	",
"	19 En hulle slaan Hom met ’n riet op die hoof en spuug op Hom en val op die knieë en bring Hom hulde.	",
"	20 En toe hulle Hom bespot het, trek hulle Hom die purperkleed uit en trek Hom Sy eie klere aan; en hulle lei Hom weg om Hom te folter.	",
		
		
"	21 EN hulle het ’n sekere Simon van Ciréne wat van die veld af gekom het, die vader van Alexander en Rufus, gedwing om Sy folterpaal te dra.	",
"	22 En hulle het Hom gebring op die plek Ghulgholeth, dit is, as dit [uit Aramees] vertaal word: Plek van die Hoofskedel.	",
"	23 Toe gee hulle Hom wyn met mirre gemeng om te drink, maar Hy het dit nie geneem nie.	",
"	24 En nadat hulle Hom gefolter het, het hulle Sy klere verdeel deur die lot te werp oor wat elkeen moes kry.	",
"	25 En dit was die derde uur toe hulle Hom gefolter het.	",
"	26 En die opskrif van Sy beskuldiging was bokant Hom geskrywe: DIE KONING VAN DIE MANNE VAN JEHÛWDAH.	",
"	27 Hulle het ook twee rowers saam met Hom gefolter, een aan Sy regter- en een aan Sy linkerkant.	",
"	28 En die Skrif is vervul wat sê: [omdat Hy Sy siel uitgestort het in die Dood] en saam met die oortreders gereken was, terwyl Hy tog die skuld van baie gedra [en vir die opstandiges ingetree het]. [JeshaJaHûW 53:12]	",
"	29 En die verbygangers het Hom gesmaad, terwyl hulle hul hoof skud en sê: Ha, U wat die Tempel afbreek en in drie dae opbou,	",
"	30 verlos Uself en kom af van die folterpaal!	",
"	31 En so het ook die owerpriesters saam met die skrywers gespot en vir mekaar gesê: Ander het Hy verlos, Homself kan Hy nie verlos nie.	",
"	32 Laat die Gesalfde, die Koning van JisraEl, nou van die folterpaal afkom, sodat ons kan sien en glo! Ook die wat saam met Hom gefolter is, het Hom beledig.	",
"	33 En toe dit die sesde uur was, kom daar duisternis oor die hele Aarde tot die negende uur toe.	",
"	34 En die negende uur het JaHWèshua met ’n groot stem uitgeroep en gesê: Eli, Eli, LAMMA AZABAGTANI? wat, as dit [uit Aramees] vertaal word, beteken: My El, My El, waarom het U My verlaat? [Psalm 22:1]	",
"	35 En sommige van die wat daar staan, hoor dit en sê: Kyk, Hy roep na EliJaHûW.	",
"	36 Toe hardloop een en maak ’n spons vol asyn en sit dit op ’n riet en laat Hom drink; en hy sê: Wag, laat ons sien of EliJaHûW kom om Hom af te haal.	",
"	37 Maar JaHWèshua het met ’n groot stem geroep en die laaste asem uitgeblaas.	",
"	38 En die voorhangsel van die Tempel het in twee geskeur van bo tot onder.	",
"	39 En toe die hoofman oor honderd wat daar reg voor Hom staan, sien dat Hy so uitgeroep en die laaste asem uitgeblaas het, sê hy: Waarlik, Hy was die Seun van Elohim.	",
"	40 En daar was ook vroue wat van ver af dit aanskou het. Onder hulle was Mirjam die Migdalieth ook, en Mirjam, die moeder van Jakobus, die kleine, en van Joses, en Salóme -	",
"	41 hulle wat Hom gevolg en Hom gedien het toe Hy in Galiléa was - en baie ander vroue wat saam met Hom opgegaan het na Jerusalem.	",
		
		
"	42 EN toe dit aand geword het, omdat dit die voorbereiding was, dit is die dag voor die Sabbat,	",
"	43 kom daar ’n vername raadslid, JôWsef van Arimathéa, wat self ook die Koninkryk van die Elohim verwag het; en hy waag dit om na Pilatus in te gaan en die liggaam van JaHWèshua te vra.	",
"	44 En Pilatus was verwonderd dat Hy al dood was, en hy het die hoofman oor honderd geroep en hom gevra of Hy al lank dood was.	",
"	45 En toe hy dit van die hoofman oor honderd verneem het, het hy die liggaam aan JôWsef geskenk.	",
"	46 En hy het linne gekoop, en Hom afgehaal en in die linne toegedraai, en Hom neergelê in ’n graf wat in ’n rots uitgekap was. En hy het ’n steen teen die opening van die graf gerol.	",
"	47 En Mirjam die Migdalieth en Mirjam, die moeder van Joses, het gesien waar Hy neergelê word.	",
		

]
},
{
book: 'Markus',
chapter: '16',
content: [
		
"	1 EN toe die Sabbat verby was, het Mirjam die Migdalieth en Mirjam, die moeder van Jakobus, en Salóme reukwerk gekoop om Hom te gaan salf.	",
"	2 En baie vroeg op die eerste [dag] van die week, net na sonop, kom hulle by die graf.	",
"	3 En hulle sê vir mekaar: Wie sal vir ons die steen voor die opening van die graf wegrol?	",
"	4 En toe hulle opkyk, sien hulle dat die steen weggerol was, want sy was baie groot.	",
"	5 En toe hulle in die graf ingegaan het, sien hulle ’n jongman, met ’n lang wit kleed om, aan die regterkant sit, en hulle het baie geskrik.	",
"	6 En hy sê vir hulle: Moenie verskrik wees nie. Julle soek JaHWèshua die Nasaréner wat gefolter is. Hy het opgestaan. Hy is nie hier nie. Dáár is die plek waar hulle Hom neergelê het.	",
"	7 Maar gaan sê vir Sy studente en vir Petrus dat Hy voor julle uit gaan na Galiléa. Daar sal julle Hom sien soos Hy vir julle gesê het.	",
"	8 Toe gaan hulle haastig uit en vlug van die graf af weg. En bewing en ontsetting het hulle aangegryp. En hulle het vir niemand iets gesê nie, want hulle het gevrees.	",

]
}

];
