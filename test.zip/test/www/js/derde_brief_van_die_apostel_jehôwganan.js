const derde_brief_van_die_apostel_jehôwgananChapters = [

{
book: 'Derde_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '1',
content: [
	
"	1 DIE oudste aan die geliefde Gajus wat ek in Waarheid liefhet.	",
"	2 Geliefde, ek wens dat dit met jou in alles goed mag gaan en dat jy gesond is, soos dit met jou siel goed gaan;	",
"	3 want ek was baie bly as daar broers kom en van jou waarheid getuig, soos jy in die Waarheid wandel.	",
"	4 Ek het geen groter blydskap as dit nie, dat ek hoor dat my kinders in die Waarheid wandel.	",
"	5 Geliefde, jy handel getrou in alles wat jy doen vir die broers, en dit vir vreemdelinge	",
"	6 wat van jou liefde voor die gemeente getuig het. Jy sal goed doen as jy hulle voorthelp op ’n wyse wat waardig is.	",
"	7 Want vir Sy Naam het hulle uitgegaan sonder om iets van die nasies te neem.	",
"	8 Ons behoort dan sulke adamiete goed te ontvang, sodat ons mede-arbeiders van die Waarheid kan word.	",
"	9 EK het aan die gemeente geskrywe, maar Diótrefes1, wat onder hulle die eerste wil wees, steur hom nie aan ons nie.	",
"	10 Daarom, as ek kom, sal ek hom herinner aan die werke wat hy doen deur met besoedelde spraak teen ons uit te vaar; en hiermee nie tevrede nie, ontvang hy nie alleen self die broers nie gasvry nie, maar verhinder ook die wat dit wil doen en werp hulle uit die gemeente.	",
"	11 Geliefde, moenie navolg wat verdraaid is nie, maar wat suiwer is. Hy wat suiwer optree, is uit Elohim; maar hy wat besoedel optree, het Elohim nie gesien nie.	",
"	12 Van Demétrius is deur almal getuienis gegee en deur die Waarheid self; en ons getuig ook, en julle weet dat ons getuienis Waarheid is.	",
"	13 Ek het baie dinge gehad om te skrywe, maar ek wil nie met ink en pen aan jou skryf nie.	",
"	14 Maar ek hoop om jou gou te sien, en ons sal van mond tot mond spreek.	",
"	15 Vrede vir jou! Die vriende groet jou. Groet die vriende by naam.	",


]
}

];
