const sefanjaChapters = [

{
book: 'Sefanja',
chapter: '1',
content: [

"	1 DIE Woord van JaHWeH wat gekom het tot TsefánJaH, die seun van Kusi, die seun van GhedalJaH, die seun van AmárJaH, die seun van GizkiJaH, in die dae van JoshiJaHûW, die seun van Amon, koning van JeHûWdah.	",
"	2 Saamskraap, wegraap sal Ek alles vanaf die aangesig van die Adamah[adamiet se Aarde], spreek JaHWeH.	",
"	3 Ek sal wegraap adamiet en wilde wesens, Ek sal ‘n einde maak aan die vlieënde wesens in die lug en die visse van die see en die struikelblokke saam met die besoedelde, ja, Ek sal die adamiete uitroei van die aangesig van die Adamah[adamiet se Aarde] af, spreek JaHWeH.	",
"	4 En Ek sal My Hand uitsteek teen JeHûWdah en teen al die inwoners van Jerusalem; Ek sal die oorblyfsel van die Here (Baäl) afsny, die naam van die priesterhoofde saam met die priesters;	",
"	5 en hulle wat op die dakke vir die leër van die Hemele neerval; en hulle wat neerval en sweer by JaHWeH en sweer by Molog.	",
"	6 Ook die wat van JaHWeH afvallig word en wat JaHWeH nie soek en Hom nie raadpleeg nie.	",
"	7 Swyg voor My Meester JaHWeH! Want die dag van JaHWeH is naby; want JaHWeH het ’n Slagdier berei, Sy gaste aangewys.	",
"	8 En op die dag van die Slagdier van JaHWeH sal Ek besoeking doen oor die vorste en die prinse en oor almal wat gekleed is in volksvreemde mantels.	",
"	9 Ek sal ook op dié dag besoeking doen oor almal wat op die drumpel spring, wat die huis van hulle meesters vul met geweld en bedrog.	",
"	10 En op dié dag, spreek JaHWeH - ’n luide klank soos ‘n geskreeu kom van die Vispoort af en ’n getjank van die tweede, en ’n groot vernietiging van die heuwels!	",
"	11 Tjank, o inwoners van die Maktesh! want al die Kanaän-volke gaan te gronde, almal wat geldgierig is, word afgesny. [ZekarJaH 14:12]	",
"	12 En in dié tyd sal Ek Jerusalem met Lig deursoek en besoeking doen oor die manne wat bymekaargekom het op hulle afsaksel(drek), wat in hulle hart sê: JaHWeH doen geen goed en Hy doen geen kwaad nie.	",
"	13 En hulle rykdom sal geplunder word, en hulle huise verwoes word; en as hulle huise bou, sal hulle dit nie bewoon nie; en as hulle wingerde plant, sal hulle die wyn van haar nie drink nie.	",
"	14 Naby is die groot dag van JaHWeH, naby en baie haastig. Hoor! die dag van JaHWeH! Bitterlik skreeu die dappere daar.	",
"	15 Dié dag is ’n dag van wraak, ’n dag van benoudheid en angs, ’n dag van woestheid en verwoesting, ’n dag van Duisternis en onbekendheid, ’n dag van die Wolkkolom en digte donkerte,	",
"	16 ’n dag van ramshoring geklank en krygsgeskreeu teen die versterkte stede en teen die verhewe hoek [vestings].	",
"	17 En Ek sal die adamiete in benoudheid bring, en hulle sal rondloop soos blindes, omdat hulle teen JaHWeH oortree het; en hulle bloed sal vergiet word soos stof en hulle vlees soos drek.	",
"	18 Hulle silwer of hulle goud sal nie in staat wees om hulle op die dag van die wraak van JaHWeH te red nie, maar deur die verterende Vuur van Sy jaloersheid sal die hele Aarde verteer word; want Hy bring vernietiging, ja, ’n haastige einde oor die inwoners van die Aarde.	",

]
},
{
book: 'Sefanja',
chapter: '2',
content: [
		
"	1 VERGADER julleself, ja vergader. O nasie wat smag na die Insettinge, bring [haar] te voorskyn,	",
"	2 voor die dag verby is, soos kaf voor die gloeiende Vuur van JaHWeH se wraak kom, voordat die dag van JaHWeH se Woede kom.	",
"	3 Soek JaHWeH, o alle nederiges van die Aarde, wat Sy Regsprake onderhou; soek Geregtigheid, soek nederigheid - miskien sal julle verborge bly op die dag van die brandende Woede van JaHWeH. [JeségiEl 18]	",
"	4 Want Gasa sal verlate wees en Askelon tot verwoesting; Asdod sal op die helder middag verdryf word, en Ekron sal ontwortel word.	",
"	5 O ellende vir die inwoners van die kusstreke, die nasie van die Kretiërs! Die Woord van JaHWeH is teen julle, Kanaän, Aarde van die Filistyne - Ek verdelg jou, sodat daar geen inwoner meer sal wees nie.	",
"	6 En die kusstreke sal weiplekke en woonplekke wees vir herders en krale vir kuddes.	",
"	7 En sy sal ’n streek wees vir die oorblyfsel van die huis van JeHûWdah: hulle sal daarop wei; hulle sal in die huise van Askelon gaan lê en uittrek met sononder, want JaHWeH hulle Elohey sal hulle besoek en hulle uit ballingskap lei. [ZekarJaH 10:6; 12:8]	",
"	8 Ek het beledigings gehoor van Moab en die wekroep van die kinders van Ammon, waarmee hulle My volk in gevaar gestel het, en het hulself verhef om hulle grensgebied te vergroot.	",
"	9 Daarom, so waar as Ek leef, spreek JaHWeH van die skeppings-leërmag, die Elohey van JisraEl: Moab sal word soos Sodom en die kinders van Ammon soos Gomorra - ’n besitting van brandnekels en soutpanne en ’n verwoesting vir ewig; die oorblyfsel van My volk sal hulle totaal verderwe, en die oorblyfsel van My nasie sal hulle besit.	",
"	10 Dit oorkom hulle vir hul trotsheid, want hulle het [hulle] beledig, en hulself verhef teen die volk van JaHWeH van die skeppings-leërmag.	",
"	11 Verskriklik sal JaHWeH teen hulle wees, want Hy laat al die gode van die Aarde wegkwyn; sodat hulle voor Hom kan neerval elkeen uit Sy woonplek, al die eilande van die nasies.	",
"	12 Ook julle, o Kuwshiete(swartes), julle almal sal val deur My Swaard.	",
"	13 Dan sal Hy Sy Hand uitstrek teen die noorde, en Hy sal Assirië vernietig en Ninevé tot ’n verwoesting maak, dor soos die wildernis.	",
"	14 En in haar midde sal troppe lê en allerhande lewende wesens van die nasies, die pelikaan sowel as die krimpvarkie sal in haar kapitele vernag; geraas!, gesing kom vanuit die venster; verwoesting in die ingange, want hulle het die sterk sederwerk kaal gestroop.	",
"	15 Sy is die triomferende stad wat so ongestoord(veilig) gewoon het, wat in haar hart gesê het: Ek [is], en niemand [behalwe] My [is] nie! Hoe het sy ’n verwoesting geword, ’n lêplek vir wilde wesens! Almal wat daar verbytrek, sal sis, en hulle hande sal bewe.	",

]
},
{
book: 'Sefanja',
chapter: '3',
content: [
	
"	1 O ELLENDE vir haar wat vuil en verswart is, die verdrukkende Stad!.	",
"	2 Sy gehoorsaam nie die Stem wat sy ontvang het nie, sy neem geen teregwysing aan nie; in JaHWeH vertrou sy nie, tot haar Elohey soek sy nie toenadering nie.	",
"	3 Haar vorste binne-in haar is brullende leeus; haar regters is aandwolwe wat nie bene vir die môre oorlaat nie.	",
"	4 Haar profete is roekelose, geldgierige manne, haar priesters besoedel die Apartheid, hulle verkrag die Wet.	",
"	5 JaHWeH is regverdig binne-in haar, Hy doen geen ongeregtigheid nie; elke môre laat Hy Sy Reg aan die lig kom, Hy misluk nooit nie; maar die verderwers ken geen skaamte nie.	",
"	6 Ek het nasies afgesny, hulle hoekvestings is vernietig; hulle strate het Ek verlate gemaak, sodat niemand meer daar deur gaan nie; hulle stede is verlate gemaak, sodat daar geen man, geen inwoner in is nie.	",
"	7 Ek het gesê: Mag jy My maar vrees, aanvaar teregwysing; sodat haar woonplek nie afgesny word nie, sodat alles wat Ek teen haar bestel het nie plaasvind nie. Nogtans het hulle vroeg opgestaan om al hulle besoedelde handelinge voort te sit.	",
"	8 Daarom, verwag My, spreek JaHWeH, op die dag wat Ek My gereed maak vir die buit; want Hy is My Reg om nasies te versamel, koninkryke te vergader om My Grimmigheid oor hulle uit te stort, al die gloeiende vuur van My brandende Woede. Want die ganse Aarde sal deur die vuur van My jaloersheid verteer word!	",
"	9 Want dan sal Ek aan die volke suiwer lippe toebring, sodat hulle almal die Naam van JaHWeH hard sal uitroep en Hom met eenparigheid sal dien.	",
"	10 Van oorkant die riviere van Kuwsh [Ethiopië] vandaan sal My blye aanbidders, die Dogter van My Verstrooide, My bydrae bring. [JeshaJaH 18:1; Maleagi 3:16]	",
"	11 Op dié dag hoef jy jou nie te skaam weens al jou wrede dade waarmee jy teen My gerebelleer het nie; want dan sal Ek uit jou midde wegruim die wat in jou triomfantlik in hul hatigheid opgestaan het, en jy sal jou nie meer arrogant gedra in die Berg van My Apartheid nie.	",
"	12 En Ek sal tussen jou in laat oorbly ’n beproefde en behoeftige volk wat in die Naam van JaHWeH skuiling soek. [Psalm 22:26]	",
"	13 Die oorblyfsel van JisraEl sal nie wetteloos optree en sal geen leuentaal spreek nie, en in hulle mond sal geen bedrieglike tong gevind word nie; maar hulle sal wei en sonder vrees uitgestrek lê. [ZekarJaH 5:3]	",
"	14 Sing met Blydskap, o Dogter van Sion, skreeu, o JisraEl, verheug jou!, en verhef [lof/sang] uit die hele hart, o Dogter van Jerusalem!	",
"	15 JaHWeH het jou oordele weggewys, Hy het jou vyand uit die weg geruim; die Koning van JisraEl, JaHWeH is by jou, en jy sal geen besoedelde meer sien nie.	",
"	16 In dié dag sal aan Jerusalem gesê word: Vrees nie, o Sion, laat Jou hande nie slap word nie!	",
"	17 JaHWeH Jou Elohey is by Jou , [Hy] is magtig, Hy sal [Jou ] verlos. Hy verheug Hom oor Jou met Blydskap; Hy is stil (in Sy liefde); Hy sal juig oor Jou met Blydskap.	",
"	18 Hy vergader dié wat bedroef is - ver weg van die fees versamel Ek; hulle hoort by Jou , die smaad druk swaar op hulle.	",
"	19 Kyk, in dié tyd sal Ek handel met al die wat Jou verdruk het; en die wat geboë is, sal Ek red; en die wat verjaag is, versamel; en Ek sal hulle maak tot ’n lofprysing en tot ’n beroeming in die Aarde waar hulle tot skande gemaak was.	",
"	20 In dié tyd sal Ek julle aanbring, ja, in die tyd wanneer Ek julle uit ballingskap bring; want Ek maak julle tot ’n roem en tot ’n lof onder al die volke van die Aarde, wanneer Ek voor julle oë julle uit gevangeskap laat terugkeer, sê JaHWeH. [JirmeJaH 49:38]	",

]
}
];
