const eerste_brief_van_die_apostel_jehôwgananChapters = [

{
book: 'Eerste_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '1',
content: [


"	1 WAT van die begin af was, wat ons gehoor het, wat ons met ons oë gesien het, wat ons aanskou het en ons hande getas het aangaande die Woord van die Lewe -	",
"	2 en die Lewe is geopenbaar, en ons het Hom gesien, en ons getuig en verkondig aan julle die Ewige Lewe wat by die VADER was en aan ons geopenbaar is -	",
"	3 wat ons gesien en gehoor het, verkondig ons aan julle, sodat julle ook deel met ons kan hê; en ons deel is met die VADER en met SY Seun, JaHWèshua, die Gesalfde.	",
"	4 En ons skrywe hierdie dinge aan julle, sodat julle blydskap volkome kan wees.	",
"	5 EN dit is die verkondiging wat ons van Hom gehoor het en aan julle verkondig: Elohim is Lig, en geen Duisternis is in HOM nie.	",
"	6 As ons sê dat ons met HOM deel het en in die Duisternis wandel, dan lieg ons en doen nie die Waarheid nie.	",
"	7 Maar as ons in die Lig wandel soos Hy in die Lig is, dan het ons deel met mekaar; en die bloed van JaHWèshua die Gesalfde, SY Seun, was ons skoon van alle oortredinge van die Wet.	",
"	8 AS ons sê dat ons geen oortredinge het nie, mislei ons onsself en die Waarheid is nie in ons nie.	",
"	9 As ons ons oortredinge bely, Hy is getrou en regverdig om ons die oortredinge te vergewe en ons van alle Ongeregtigheid skoon te was.	",
"	10 As ons sê dat ons nie oortree nie, dan maak ons HOM tot ’n leuenaar en is SY Woord nie in ons nie.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '2',
content: [
		
"	1 MY kinders, ek skryf hierdie dinge aan julle, dat julle nie moet oortree nie; en as iemand oortree het, ons het ’n Voorspraak by die VADER, JaHWèshua die Gesalfde, die Regverdige.	",
"	2 En Hy is ’n versoening vir ons oortredinge, en nie alleen vir ons s’n nie, maar ook vir dié van die hele wêreld.	",
"	3 EN hieraan weet ons dat ons Hom ken: as ons Sy Gebooie onderhou.	",
"	4 Hy wat sê: Ek ken Hom - en Sy Gebooie nie onderhou nie - is ’n leuenaar en in hom is die Waarheid nie.	",
"	5 Maar elkeen wat Sy Woord onderhou, in hom het die volmaakte Liefde van Elohim waarlik vervolmaak. Hieraan weet ons dat ons in Hom is.	",
"	6 Hy wat sê dat hy in Hom bly, behoort self ook so te wandel soos Hy gewandel het.	",
"	7 Broers, sy is geen nuwe Gebod wat ek aan julle skryf nie, maar ’n ou Gebod wat julle van die begin af gehad het. Die ou Gebod is die Woord wat julle van die begin af gehoor het.	",
"	8 En tog skryf ek aan julle ’n nuwe Gebod wat Waarheid is in Hom en in julle, want die Duisternis gaan verby en die ware Lig skyn alreeds.	",
"	9 Hy wat sê dat hy in die Lig is en sy broeder haat, is in die Duisternis tot nou toe.	",
"	10 Wie sy broeder liefhet, bly in die Lig, en in hom is geen oorsaak van struikeling nie.	",
"	11 Maar hy wat sy broeder haat, is in die Duisternis en wandel in die Duisternis en weet nie waarheen hy gaan nie, omdat die Duisternis sy oë verblind het.	",
"	12 Ek skryf aan julle, my kinders, omdat die oortredinge julle vergewe is, om Sy Naam ontwil.	",
"	13 Ek skryf aan julle, vaders, omdat julle Hom ken wat van die begin af is. Ek skryf aan julle, jongmanne, omdat julle die besoedeling oorwin het. Ek skryf aan julle, kinders, omdat julle die VADER ken.	",
"	14 Ek het aan julle geskrywe, vaders, omdat julle Hom ken wat van die begin af is. Ek het aan julle geskrywe, jongmanne, omdat julle sterk is en die Woord van Elohim in julle bly en julle die besoedeling oorwin het.	",
"	15 Moenie die wêreld liefhê of die dinge wat in die wêreld is nie. As iemand die wêreld liefhet, dan is die Liefde van die VADER nie in hom nie.	",
"	16 Want alles wat in die wêreld is - die begeerlikheid van die vlees en die begeerlikheid van die oë en die grootsheid van die lewe - is nie uit die VADER nie, maar is uit die wêreld.	",
"	17 En die wêreld gaan verby en haar begeerlikheid, maar hy wat die wil van die Elohim doen, bly vir ewig.	",
"	18 KINDERS, dit is die laaste uur; en soos julle gehoor het dat die vals gesalfde kom, bestaan daar ook nou baie vals gesalfdes, waaruit ons weet dat dit die laaste uur is.	",
"	19 Hulle het van ons uitgegaan, maar hulle was nie van ons nie; want as hulle van ons was, sou hulle by ons gebly het; maar dit moes aan die lig kom dat hulle nie almal van ons is nie.	",
"	20 En julle het die Salwing van die Aparte Een en sal alles weet.	",
"	21 Ek het nie aan julle geskrywe omdat julle die Waarheid nie ken nie, maar omdat julle Haar ken en omdat geen leuen uit die Waarheid is nie.	",
"	22 Wie is die leuenaar, behalwe hy wat ontken dat JaHWèshua die Gesalfde is? Hy is ‘n valse gesalfde wat teen die VADER en die Seun getuig.	",
"	23 Elkeen wat teen die Seun getuig, het ook nie die VADER nie.	",
"	24 Wat julle dan van die begin af gehoor het, laat Sy in julle bly. As in julle bly wat julle van die begin af gehoor het, dan sal julle ook in die Seun en in die VADER bly.	",
"	25 En Hy is die Belofte wat HY ons beloof het, naamlik die Ewige Lewe.	",
"	26 Dit het ek aan julle geskrywe met betrekking tot die wat julle mislei.	",
"	27 En die Salwing wat julle van Hom ontvang het, bly in julle, en julle het nie nodig dat iemand julle leer nie; maar soos dieselfde Salwing julle aangaande alles leer, so is Sy ook die Waarheid en geen leuen nie; en soos Sy julle geleer het, so moet julle in Hom bly.	",
"	28 En nou, my kinders, bly in Hom, sodat ons vrymoedigheid kan hê wanneer Hy verskyn en nie beskaamd van Hom weggaan by Sy wederkoms nie.	",
"	29 As julle weet dat Hy regverdig is, dan weet julle dat elkeen wat die Geregtigheid doen, uit Hom gebore is.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '3',
content: [
		
"	1 KYK wat ’n groot Liefde die VADER aan ons bewys het, dat ons seuns van Elohim genoem kan word! Om hierdie rede ken die wêreld ons nie, omdat sy Hom nie geken het nie.	",
"	2 Geliefdes, nou is ons seuns van Elohim, en dit is nog nie geopenbaar wat ons sal wees nie; maar ons weet dat ons, as Hy verskyn, aan Hom gelyk sal wees, omdat ons Hom sal sien soos Hy is.	",
"	3 En elkeen wat hierdie hoop op Hom het, moet homself was/doop soos Hy gewas/gedoop is.	",
"	4 Elkeen wat die oortredinge doen, doen ook die ongeregtigheid, want die oortredinge is ongeregtigheid.	",
"	5 En julle weet dat Hy verskyn het om ons oortredinge weg te neem, en geen oortredinge is in Hom nie.	",
"	6 Elkeen wat in Hom bly, oortree nie. Elkeen wat oortree, het Hom nie gesien en Hom nie geken nie.	",
"	7 My kinders, laat niemand julle mislei nie: wie die Geregtigheid doen is regverdig soos Hy regverdig is.	",
"	8 Hy wat die oortredinge doen, is uit die Satan, want die Satan oortree van die begin af. Vir hierdie doel het die Seun van die Elohim verskyn, om die werke van die Satan te verbreek.	",
"	9 Elkeen wat uit Elohim gebore is, doen geen oortredinge nie, omdat SY saad in hom bly; en hy kan nie oortree nie, want hy is uit Elohim gebore.	",
"	10 Hierin is die kinders van die Elohim en die kinders van die Satan openbaar: elkeen wat die Geregtigheid nie doen nie, is nie uit Elohim nie, en hy ook wat sy broeder nie liefhet nie.	",
"	11 Want dit is die boodskap wat julle van die begin af gehoor het, dat ons mekaar moet liefhê;	",
"	12 nie soos Kain wat van die Besoedelde Een was en sy broer doodgeslaan het nie. En waarom het hy hom doodgeslaan? Omdat sy werke besoedel was en dié van sy broer regverdig.	",
"	13 Verwonder julle nie, my broers, as die wêreld julle haat nie.	",
"	14 Ons weet dat ons oorgegaan het uit die Dood in die lewe, omdat ons die broers liefhet. Hy wat sy broeder nie liefhet nie, bly in die Dood.	",
"	15 Elkeen wat sy broeder haat, is ’n moordenaar; en julle weet dat geen moordenaar die Ewige Lewe as iets blywends in hom het nie.	",
"	16 Hieraan het ons die Liefde leer ken, dat Hy Sy Siel vir ons afgelê het; en ons behoort ons siel vir die broers af te lê.	",
"	17 Maar wie die goed van die wêreld het en sy broeder sien gebrek ly en sy hart vir hom toesluit, hoe bly die Liefde van Elohim in hom?	",
"	18 My kinders, laat ons nie liefhê met woorde of met die tong nie, maar met die daad en in Waarheid.	",
"	19 En hieraan weet ons dat ons uit die Waarheid is; en ons sal ons harte voor HOM gerusstel,	",
"	20 want as ons hart ons veroordeel, Elohim is meer as ons hart, en HY weet alles.	",
"	21 Geliefdes, as ons hart ons nie veroordeel nie, dan het ons vrymoedigheid teenoor Elohim;	",
"	22 en wat ons ook al bid, ontvang ons van HOM, omdat ons SY Gebooie onderhou en doen wat welgevallig is voor HOM.	",
"	23 En dit is SY Gebod, dat ons in die Naam van SY Seun, JaHWèshua die Gesalfde, moet glo en mekaar liefhê soos Hy ons ’n Gebod gegee het.	",
"	24 En hy wat Sy Gebooie onderhou, bly in Hom, en Hy in hom. En hieraan weet ons dat Hy in ons bly: aan die Gees wat Hy ons gegee het.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '4',
content: [
		
"	1 GELIEFDES, glo nie elke gees nie, maar stel die geeste op die proef of hulle uit Elohim is, want baie valse profete het in die wêreld uitgegaan.	",
"	2 Hieraan ken julle die Gees van die Elohim: elke gees wat bely dat JaHWèshua die Gesalfde in die Vlees gekom het, is uit Elohim;	",
"	3 en elke gees wat nie bely dat JaHWèshua die Gesalfde in die Vlees gekom het nie, is nie uit Elohim nie; en sy is die gees van die vals gesalfde waarvan julle gehoor het dat sy kom, en sy is nou al in die wêreld.	",
"	4 Julle is uit Elohim, my kinders, en het hulle oorwin, omdat Sy wat in julle is, groter is as sy wat in die wêreld is.	",
"	5 Hulle is uit die wêreld; daarom praat hulle uit die wêreld, en die wêreld luister na hulle.	",
"	6 Ons is uit Elohim; hy wat Elohim ken, luister na ons; hy wat nie uit Elohim is nie, luister nie na ons nie. Hieruit ken ons die Gees van Waarheid en die gees van die dwaling.	",
"	7 GELIEFDES, laat ons mekaar liefhê; want die Liefde is uit Elohim, en elkeen wat liefhet, is uit Elohim gebore en ken Elohim.	",
"	8 Hy wat nie liefhet nie, het Elohim nie geken nie, want Elohim is Liefde.	",
"	9 Hierin is die Liefde tot ons geopenbaar, dat Elohim SY eniggebore Seun in die wêreld gestuur het, sodat ons deur Hom kan lewe.	",
"	10 Hierin is die Liefde: nie dat ons Elohim liefgehad het nie, maar dat HY ons liefgehad het en SY Seun gestuur het as ’n versoening vir ons oortredinge.	",
"	11 Geliefdes, as die Elohim ons so liefgehad het, behoort ons ook mekaar lief te hê.	",
"	12 Niemand het JaHWeH ooit aanskou nie. As ons mekaar liefhet, bly Elohim in ons en het Sy Liefde ons vervolmaak.	",
"	13 Hieraan weet ons dat ons in Hom bly en Hy in ons, dat Hy ons van Sy Gees gegee het.	",
"	14 En ons het aanskou en ons getuig dat die VADER die Seun as Verlosser van die wêreld gestuur het.	",
"	15 Elkeen wat bely dat JaHWèshua die Seun van Elohim is - Elohim bly in hom, en hy in Elohim.	",
"	16 En ons het die Liefde wat Elohim tot ons het, leer ken en geglo. Elohim is Liefde; en hy wat in die Liefde bly, bly in Elohim, en Elohim in hom.	",
"	17 Hierin het die Liefde ons vervolmaak, dat ons moed kan hê vir die oordeelsdag; want soos HY is, is ons ook in hierdie wêreld.	",
"	18 Daar is geen vrees in die Liefde nie; maar die volmaakte Liefde dryf die vrees buite, want die vrees sluit straf in, en hy wat vrees, is nie vervolmaak deur die Liefde nie.	",
"	19 Ons het Hom lief, omdat Hy ons eerste liefgehad het. [Openbaring 1:5]	",
"	20 As iemand sê: Ek het Elohim lief - en sy broeder haat, is hy ’n leuenaar; want wie sy broeder wat hy gesien het, nie liefhet nie, hoe kan hy Elohim liefhê wat hy nie gesien het nie?	",
"	21 En hierdie Gebod het ons van Hom dat hy wat Elohim liefhet, ook sy broeder moet liefhê.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Jehôwganan',
chapter: '5',
content: [
		
"	1 ELKEEN wat glo dat JaHWèshua die Gesalfde is, is uit Elohim gebore; en elkeen wat die VADER liefhet, het ook die een lief wat uit HOM gebore is.	",
"	2 Hieraan weet ons dat ons die kinders van Elohim liefhet: wanneer ons Elohim liefhet en SY Gebooie onderhou.	",
"	3 Want sy is die Liefde tot Elohim as ons SY Gebooie onderhou; en SY Gebooie is nie swaar nie.	",
"	4 Want alles wat uit Elohim gebore is, oorwin die wêreld; en Sy is die Oorwinning wat die wêreld oorwin het, naamlik ons Geloof.	",
"	5 Wie anders is dit wat die wêreld oorwin as hy wat glo dat JaHWèshua die Seun van die Elohim is?	",
"	6 Dit is Hy wat deur Water en Bloed gekom het, JaHWèshua die Gesalfde; nie deur die Water alleen nie, maar deur die Water en die Bloed; en Sy is die Gees wat getuig, want dié Gees is die Waarheid.	",
"	7 Want daar is drie wat getuig (Die uitgelate gedeelte kom nie in die oudste manuskripte voor nie naamlik: Codex Siniaticus, Vaticanus, Alexandrinus)	",
"	8 die Gees en die Water en die Bloed, en die drie is eenstemmig.	",
"	9 As ons die getuienis van die mense aanneem - die Getuienis van Elohim is groter, omdat Sy die Getuienis is van Elohim wat HY aangaande SY Seun getuig het.	",
"	10 Wie in die Seun van die Elohim glo, het dié Getuienis in homself. Hy wat die Elohim nie glo nie, het HOM tot leuenaar gemaak, omdat hy die Getuienis nie geglo het wat Elohim aangaande SY Seun getuig het nie.	",
"	11 En Sy is die Getuienis: dat Elohim ons die Ewige Lewe gegee het, en dié Lewe is in SY Seun.	",
"	12 Hy wat die Seun het, het dié Lewe; wie die Seun van die Elohim nie het nie, het nie dié Lewe nie.	",
"	13 Dit het ek geskrywe aan julle wat glo in die Naam van die Seun van Elohim, sodat julle kan weet dat julle die Ewige Lewe het en kan glo in die Naam van die Seun van die Elohim.	",
"	14 En dit is die vrymoedigheid wat ons teenoor HOM het, dat HY ons verhoor as ons iets vra volgens SY wil.	",
"	15 En as ons weet dat HY ons verhoor, dan weet ons dat, wat ons ook al vra, ons die bedes verkry wat ons van HOM gevra het.	",
"	16 As iemand sy broeder ’n oortreding sien doen wat nie tot die dood is nie, moet hy bid, en Hy sal hom die lewe gee - vir die wat nie ’n oortreding tot die dood doen nie. Daar is ‘n oortreding tot die dood; daarvoor sê ek nie dat hy moet bid nie.	",
"	17 Alle Ongeregtigheid is oortredinge, en daar is ‘n oortreding wat nie tot die dood is nie.	",
"	18 Ons weet dat elkeen wat uit Elohim gebore is, nie oortree nie; maar hy wat uit Elohim gebore is, bewaar homself, en die besoedeling het geen vat op hom nie.	",
"	19 Ons weet dat ons uit Elohim is en die hele wêreld in die mag van die besoedeling lê.	",
"	20 En ons weet dat die Seun van die Elohim gekom het en ons Verstand gegee het om die Ware te ken; en ons is in die Waarheid, in SY Seun, JaHWèshua die Gesalfde. Hy is die Ware Elohey en die Ewige Lewe.	",
"	21 My kinders, bewaar julleself van die idole. Amein.	",

]
}
];
