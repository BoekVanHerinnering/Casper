const maleagiChapters = [

{
book: 'Maleagi',
chapter: '1',
content: [

"	1 DIE las van die Woord van JaHWeH aan JisraEl deur die diens van Maleági.	",
"	2 Ek het julle liefgehad, sê JaHWeH. Nogtans vra julle: Waarin het U ons liefgehad? Is Esau nie die broer van Jakob nie? spreek JaHWeH. Tog het Ek Jakob liefgehad,	",
"	3 maar Esau het Ek gehaat en sy gebergte ’n verwoesting gemaak en sy erfdeel aan die jakkalse van die wildernis [prysgegee]. [Wysheid van Salomo 11:24; Wysheid van Sirah 15:11]	",
"	4 As Edom sê: Ons is wel verwoes, maar ons sal die puinhope weer opbou - dan sê JaHWeH van die skeppings-leërmag dit: Laat hulle bou, Ek breek haar tog af; en die mense sal haar noem: Grondgebied van besoedeling, en: Die volk waarop JaHWeH vertoornd is tot in ewigheid!	",
"	5 En julle oë sal haar aanskou, en julle sal sê: Groot is JaHWeH oor die gebied van JisraEl!	",
"	6 ’n Seun eer sy vader, en ’n slaaf sy eienaar. As Ek dan ’n Vader is, waar is My Eer? En as Ek die Meester is, waar is die Vrees vir My? sê JaHWeH van die skeppings-leërmag aan julle, o priesters, wat My Naam verag! Maar julle sê: Waardeur het ons U Naam verag?	",
"	7 Julle bring besoedelde Brood na My altaar, en dan vra julle: Waardeur het ons U besoedel? Deurdat julle sê: Die tafel van JaHWeH is veragtelik.	",
"	8 En as julle ’n blinde [dier] nader bring om te slag, is dit nie besoedel nie! En as julle ’n lam of ’n siek dier bring, is dit nie besoedel nie! Bring haar tog nader vir jou goewerneur! Sal hy ’n welgevalle aan jou hê of jou goedgesind wees? sê JaHWeH van die skeppings-leërmag.	",
"	9 Smeek dan nou tog die Aangesig van El, dat Hy Ons goedgunstig kan wees! Sulke dinge is deur julle gedoen - sal Hy dan om julle ontwil goedgesind wees? sê JaHWeH van die skeppings-leërmag.	",
"	10 Ag, was daar maar iemand onder julle wat die deure wou sluit, sodat julle nie tevergeefs vuur op My altaar kan aansteek nie! Ek het in julle geen welgevalle nie, sê JaHWeH van die skeppings-leërmag, en in ’n spysbydrae uit julle hand het Ek geen behae nie.	",
"	11 Want van die opgang van die son tot sy ondergang toe is My Naam groot onder die nasies; en in elke plek word tot Eer van My Naam reukwerk gebring en ’n suiwer spysbydrae; want My Naam is groot onder die nasies, sê JaHWeH van die skeppings-leërmag.	",
"	12 Julle daarenteen besoedel Hom as julle sê: Die tafel van my Meester is vermeng, en die opbrengs, selfs die vleis is veragtelik.	",
"	13 En julle sê: Kyk, wat ’n moeite! En julle verag hom, sê JaHWeH van die skeppings-leërmag; en julle bring geroofde en lam en siek [diere] - so bring julle dan die spysbydrae! Kan Ek haar met welgevalle uit julle hand aanneem? sê JaHWeH.	",
"	14 Vervloek is ook die bedrieër wat, terwyl daar onder sy kleinvee ’n manlike dier is, ’n Gelofte doen en tog iets wat vermink is, aan die Meester slag; want Ek is ’n groot Koning, sê JaHWeH van die skeppings-leërmag, en My Naam is gevrees onder die nasies.	",

]
},
{
book: 'Maleagi',
chapter: '2',
content: [
		
"	1 EN nou, priesters, tot julle kom hierdie Gebod.	",
"	2 As julle nie gehoor gee nie, en as julle dit nie ter harte neem om My Naam Eer te bewys nie, sê JaHWeH van die skeppings-leërmag, dan sal Ek die vloek onder julle stuur en julle seëninge in ’n vloek verander; ja, Ek het haar alreeds vervloek, omdat julle niks ter harte neem nie.	",
"	3 Kyk, Ek sal julle saad bedreig, en Ek sal mis op julle gesigte strooi, die mis van julle feeste; en hulle sal julle na die [mishoop] dra.	",
"	4 En julle sal gewaar word dat Ek julle hierdie Gebod gestuur het, dat sy My Verbond kan wees met Levi, sê JaHWeH van die skeppings-leërmag.	",
"	5 My Verbond met hom was die Lewe en die Vrede; en Ek het haar aan hom gegee tot Vrees; en hy het My gevrees en vir My Naam gebewe. [Númeri 25:12]	",
"	6 Die Wet van Waarheid was in sy mond, en onreg is op sy lippe nie gevind nie; in Vrede en Geregtigheid het hy met My gewandel, en baie het hy van ongeregtigheid teruggebring.	",
"	7 Want die lippe van ’n priester moet Kennis bewaar, en uit sy mond word die Wet gesoek, want hy is ’n boodskapper van JaHWeH van die skeppings-leërmag. [2 Ezra 1:40]	",
"	8 Maar júlle het van die Weg afgewyk, julle het baie teen die Wet laat struikel, julle het die Verbond met Levi verbreek, sê JaHWeH van die skeppings-leërmag.	",
"	9 So maak Ek julle dan ook veragtelik en gering by die hele volk, omdat julle My Weë nie hou nie en draai teen die Wet.	",
"	10 Het Ons nie almal een Vader nie? Het een El Ons nie geskape nie? Waarom handel Ons dan verraderlik met mekaar, deur die Verbond van Ons vaders te besoedel?	",
"	11 JeHûWdah het verraderlik gehandel, en 'n gruwel is in JisraEl en in Jerusalem gepleeg; want JeHûWdah het die Apartheid van JaHWeH, wat Hy liefhet, vermeng, en hy is besitter van die dogter van ’n volksvreemde god. [JirmeJaH 3:8]	",
"	12 Mag JaHWeH van die man wat so iets doen, uitroei hom wat roep en hom wat antwoord gee uit die tente van Jakob, en hom wat ’n spysbydrae aan JaHWeH van die skeppings-leërmag bring.	",
"	13 En boonop doen julle dit: julle bedek die altaar van JaHWeH met trane, met geween en versugting, omdat Hy Hom nie meer wend na die spysbydrae nie en haar van julle hand nie aanneem as welgevallig nie.	",
"	14 En julle vra: Waarom? Omdat JaHWeH getuie is tussen jou en die Vrou van jou jeug wie jy verraai het, terwyl sy tog jou metgesel is en die Vrou van jou Verbond.	",
"	15 Het Hy dan nie een [adamiet] gemaak nie, hoewel Hy gees oorgehad het? En waarom die een? Hy het ’n saadlyn van Elohim gesoek. Neem julle dan in ag ter wille van julle gees en verraai nie die Vrou van jou jeug nie. [Génesis 1:27]	",
"	16 Want Ek haat om weg te stuur, sê JaHWeH, die Elohey van JisraEl, en dat elkeen sy kleed met geweldpleging bedek, sê JaHWeH van die skeppings-leërmag. Neem julle dan in ag ter wille van julle gees en pleeg nie verraad nie.	",
"	17 Julle vermoei JaHWeH met julle woorde. Nogtans vra julle: Waarmee vermoei ons [Hom]? Deurdat julle sê: Elkeen wat besoedeling doen, is suiwer in die Oë van JaHWeH, en in hulle het Hy ’n behae; of waar is [anders] die Elohey van die Reg?	",

]
},
{
book: 'Maleagi',
chapter: '3',
content: [
	
"	1 KYK, Ek stuur My Boodskapper wat die Weg voor My uit sal baan; dan sal skielik na Sy Tempel kom die Meester na wie julle soek, naamlik die Boodskapper van die Verbond, na wie julle ’n begeerte het. Kyk, Hy kom, sê JaHWeH van die skeppings-leërmag. [JôWEl 2:23]	",
"	2 Maar wie kan die dag van Sy koms verdra? En wie kan standhou as Hy verskyn? Want Hy sal wees soos die vuur van die smelter en soos die loog van die wassers.	",
"	3 En Hy sal sit: ’n smelter en suiweraar van silwer, en Hy sal die seuns van Levi suiwer en hulle louter soos goud en soos silwer, sodat hulle aan JaHWeH in Geregtigheid ’n spysbydrae sal bring.	",
"	4 Dan sal die spysbydrae van JeHûWdah en Jerusalem vir JaHWeH aangenaam wees soos in die ou dae en soos in die jare van die voortyd.	",
"	5 En Ek sal tot julle nader om Regspraak te hou, en Ek sal ’n haastige getuie wees teen die towenaars en teen die wat vermeng en teen die meinediges en teen die wat die dagloner in sy loon, die weduwee en die wees verdruk; en teen die wat die besoeker wegstoot en My nie vrees nie, sê JaHWeH van die skeppings-leërmag.	",
"	6 Want Ek - JaHWeH, het nie verander nie; en julle, kinders van Jakob, is nie verteer nie.	",
"	7 Sedert die dae van julle vaders het julle van My Insettinge afgewyk en haar nie onderhou nie. Keer terug na My, en Ek wil na julle terugkeer, sê JaHWeH van die skeppings-leërmag. Maar julle vra: Waarin moet ons terugkeer?	",
"	8 Mag ’n adamiet Elohim beroof? Want julle beroof My, en julle sê: Waarin het ons U beroof? In die tiendes en die bydraes.	",
"	9 Met die vloek is julle belaai, en tog beroof julle My, julle, die hele nasie!	",
"	10 Bring die hele tiende na die skathuis, sodat daar spys in My Huis kan wees; en beproef My tog hierin, sê JaHWeH van die skeppings-leërmag, of Ek vir julle nie die vensters van die Hemele sal oopmaak en op julle ’n oorvloedige seën sal uitstort nie.	",
"	11 Ek sal ook die sprinkaan vir julle afweer, sodat hy die opbrengs van julle Adamah[adamiet se Aarde] nie sal verwoes nie; ook die wynstok op die land sal vir julle nie onvrugbaar wees nie, sê JaHWeH van die skeppings-leërmag.	",
"	12 En al die nasies sal julle geseënd noem, omdat julle Aarde Vreugdevol sal wees, sê JaHWeH van die skeppings-leërmag.	",
"	13 Vermetel is julle woorde teen My, sê JaHWeH. Maar julle vra: Wat het ons onder mekaar teen U gespreek?	",
"	14 Julle het gesê: Dit is tevergeefs om Elohim te dien, en watter wins is dit vir ons om Sy Verordening te onderhou en in rou voor die Aangesig van JaHWeH van die skeppings-leërmag te wandel?	",
"	15 En nou prys ons die hoogmoediges geseënd; ja hulle wat besoedeling bewerkstellig! [Hulle] tart Elohim en raak vry?	",
"	16 Toe het die wat JaHWeH vrees, met mekaar gespreek; en JaHWeH het dit opgemerk en gehoor, en daar is ’n Boek van Herinnering voor Sy Aangesig geskrywe vir die wat JaHWeH vrees en Sy Naam Eer. [Odes van Salomo 23; Boekrol van Henog 99:3; JeshaJaH 29:18, 23; 66:4; JeségiEl 4:13; 36:23; 38:7]	",
"	17 En hulle sal My tot ’n eiendom wees, sê JaHWeH van die skeppings-leërmag, op die dag wat Ek herstel, en Ek sal met hulle Medelye hê soos ’n man medelye het met sy seun wat hom dien.	",
"	18 Dan sal julle weer die onderskeid sien tussen die regverdige en die besoedelde, tussen die wat Elohim dien en die wat Hom nie dien nie.	",

]
},
{
book: 'Maleagi',
chapter: '4',
content: [
	
"	1 WANT kyk, die Dag kom, en hy brand soos ’n oond. Dan sal al die hoogmoediges en almal wat besoedeling bedrywe, ’n stoppel wees; en die Dag wat kom, sal hulle aan die brand steek, sê JaHWeH van die skeppings-leërmag; sodat sy vir hulle geen wortel of tak sal oorlaat nie.	",
"	2 Maar vir julle wat My Naam vrees, sal die son van Geregtigheid opgaan, en daar sal genesing onder Sy Vleuels wees; en julle sal uittrek en huppel soos kalwers uit die stal.	",
"	3 En julle sal die besoedelde vertrap, want hulle sal soos stof wees onder julle Voetsole op die dag wat Ek herstel, sê JaHWeH van die skeppings-leërmag.	",
"	4 Dink aan die Wet van Moshè, My kneg, wat Ek hom beveel het op Horeb vir die hele JisraEl - Insettinge en Regsprake.	",
"	5 Kyk, Ek stuur julle die profeet EliJaH[ûW] voordat die groot en ontsagwekkende dag van JaHWeH aanbreek.	",
"	6 En hy sal die hart van die vaders terugbring tot die kinders, en die hart van die kinders tot hulle vaders, sodat Ek nie hoef te kom en die Aarde met die ba	",


]
}

];
