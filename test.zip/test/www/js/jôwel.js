const jôwelChapters = [

{
book: 'JôWEl',
chapter: '1',
content: [



"	1 DIE Woord van JaHWeH wat na JôWEl, die seun van PethuEl, gekom het.	",
"	2 Hoor dit, o oudstes, en luister, alle inwoners van die Aarde! Het so iets ooit in julle dae of in die dae van julle vaders plaasgevind?	",
"	3 Vertel oor haar aan julle kinders, en julle kinders aan húlle kinders, en hulle kinders aan die volgende geslag:	",
"	4 Wat die sprinkaan laat oorbly het, het die treksprinkaan verslind; en wat die treksprinkaan laat oorbly het, het die jong sprinkaan verslind; en wat die jong sprinkaan laat oorbly het, het die kommandowurm verslind. [Boek van die Opregte 80:33, JôWEL 2:25]	",
"	5 Word wakker, julle dronkaards, en ween! En huil, al julle wyndrinkers! Oor die vars wyn, omdat hy van julle mond weggeruk is.	",
"	6 Want ’n sterk en ontelbare nasie het opgetrek oor My Aarde; sy tande is leeutande, en hy kan byt soos ’n sterk leeu.	",
"	7 Hy het My Wingerdstok verwoes en My Vyeboom versplinter: deur hulle te stroop word hulle ontbloot en weggegooi; die lote van Haar verblank.	",
"	8 Weeklaag soos ’n Maagd, wat oor die Bruidegom van Haar jeug, met ’n roukleed omgord is.	",
"	9 Spysbydrae en drank is afgesny aan die Huis van JaHWeH; die priesters, die dienaars van JaHWeH, treur.	",
"	10 Die veld is verwoes, haar Adamah[adamiet se Aarde] treur; want die koring is verwoes, die nuwe wyn het weggedroog, die olie het verdwyn.	",
"	11 Die landbouers staan beskaamd, die wynboere weeklaag oor die koring en oor die gars, omdat die oes op die Aarde verlore is.	",
"	12 Die Wingerdstok, Sy het verdor, en die Vyeboom het verwelk; die granaat, ook die palm en die appelboom, al die bome van die Aarde het verdor; want beskaamd is die Vreugde, weg van die seuns van adam [iete] af.	",
"	13 Omgord julle en klaag, o priesters! Huil, dienaars van die altaar! Kom, vernag in rouklere, dienaars van My Elohey! Want die spysbydrae en die drank is weerhou van die Huis van julle Elohey. [Openbaring 6:10-11]	",
"	14 Sonder ’n vastydperk af, roep ’n vergadering saam! Versamel die oudstes, alle inwoners van die Aarde in die Huis van JaHWeH julle Elohey, en roep tot JaHWeH.	",
"	15 Ag, die dag! Want naby is die dag van JaHWeH, en hy kom soos ’n verwoesting van die Almagtige.	",
"	16 Is die spys nie weggeruk voor ons oë nie, blydskap en gejuig weg uit die Huis van onse Elohey?	",
"	17 Die graankorrels het weggekrimp onder hulle kluite, die voorraadkamers is verwoes, die graanbakke afgebreek, want die koring het verdor.	",
"	18 Hoe sug die vee! Die troppe beeste is onrustig, want daar is geen weiveld vir hulle nie; ook die troppe kleinvee moet boet.	",
"	19 Tot U, o JaHWeH, roep ek, want ’n Vuur het die weivelde van die wildernis verteer, en ’n Vlam het al die bome van die veld aan die brand gesteek.	",
"	20 Selfs die diere van die veld smag na U; want die waterstrome het opgedroog, en ’n Vuur het die weivelde van die wildernis verteer.	",
	
]
},
{
book: 'JôWEl',
chapter: '2',
content: [


		
"	1 BLAAS die ramshoring in Sion, en ‘n oorlogskreet in die Berg van My Apartheid! Laat al die inwoners van die Aarde bewe, want die dag van JaHWeH kom, want hy is naby - [JeshaJaH 10:26]	",
"	2 ’n dag van Duisternis en donkerheid, ’n dag van die Wolkkolom en wolkenag; soos die môreskemering, uitgesprei oor die berge, [kom] met ’n talryke en groot volk, wat nog nie voorheen sy gelyke gehad het nie en dit hierna ook nie sal hê tot in die jare van geslag tot geslag nie.	",
"	3 Voor hom uit verteer ’n vuur, en agter hom brand ’n vlam; voor hom lyk die Aarde soos die Tuin van Eden, en agter hom is dit ’n verwoeste wildernis; ook kan niks daaraan ontkom nie. [Boekrol van Henog 53:3; 57:2]	",
"	4 Sy voorkoms is soos dié van perde, en net soos perde en ruiters so hardloop hulle.	",
"	5 Soos die gedruis van waens huppel hulle oor die bergtoppe, soos die geknetter van ’n vuurvlam wat die kaf verteer, soos ’n talryke volk wat vir die geveg opgestel is.	",
"	6 Voor sy aangesig, bewe die volke - alle aangesigte, versamel hulle gloeiende.	",
"	7 Soos krygsmanne hardloop hulle, soos manne van oorlog klim hulle op die muur, en elkeen gaan sy eie koers; hulle verander nie van pad nie.	",
"	8 En die een druk nie die ander nie; elke krygsman gaan sy eie pad; en tussen wapens deur val hulle; [maar] hulle bly in gelid.	",
"	9 Hulle oorval die Stad, hulle hardloop op die muur, hulle klim in die huise, hulle dring by die vensters in soos ’n dief.	",
"	10 Voor hulle bewe die Aarde, skud die Hemele; die son en die maan word swart, en die Sterre trek hulle glans terug.	",
"	11 En JaHWeH verhef Sy Stem voor Sy Leërmag uit; want geweldig groot is Sy Leër, ja, magtig die uitvoerder van Sy Woord. Want die dag van JaHWeH is groot en uitermate vreeslik, en wie kan hom verdra?	",
"	12 Maar selfs nou nog, spreek JaHWeH, bekeer julle tot My met julle hele hart, en met vas en geween en rouklag.	",
"	13 En skeur julle hart en nie julle klere nie, en bekeer julle tot JaHWeH julle Elohey; want Hy is goedgunstig en barmhartig, lankmoedig en groot in Medelye, en Een wat die besoedeling vergewe;	",
"	14 wie weet of dit Hom nie weer sal berou nie, sodat Hy ’n seën sal agterlaat vir spys en drank aan JaHWeH julle Elohey.	",
"	15 Blaas die ramshoring op Sion, sonder ’n vas af, roep ’n vergadering saam!	",
"	16 Versamel die volk, sonder die vergadering af, vergader die oudstes, versamel die kinders en hulle wat aan die bors drink! Laat die Bruidegom uit Sy kamer uitgaan en die Bruid uit Haar slaapvertrek. [2 Ezra 7:26; Job 28:20]	",
"	17 Laat die priesters, die dienaars van JaHWeH, tussen die voorportaal en die altaar ween en sê: O JaHWeH, spaar U volk, en gee U Erfdeel nie oor aan skande, dat die nasies hulle regeer nie; waarom sou hulle onder die volke sê: Waar is hulle Elohey? [Openbaring 6:10 - 11; 11:1]	",
"	18 Toe het JaHWeH jaloers geword op Sy Aarde en Medelye met Sy volk gehad.	",
"	19 En JaHWeH het geantwoord en aan Sy volk gesê: Kyk, Ek stuur vir julle koring en vars wyn en olie, sodat julle daarvan versadig word, en Ek maak julle nie meer tot ’n voorwerp van skande onder die nasies nie.	",
"	20 Ja, Ek sal hulle uit die noorde afkomstig, van julle af wegjaag en hom wegdrywe na ’n dor en woeste Aarde; sy voorhoede na die Oostelike See en sy agterhoede na die Westelike See toe. En sy stank sal opstyg, en ’n slegte reuk uit hulle opgaan; want hulle het alte groot dinge gedoen.	",
"	21 Wees nie bevrees nie, o Adamah[adamiet se Aarde], juig en wees bly, want JaHWeH doen groot dinge!	",
"	22 Wees nie bevrees nie, diere van die veld, want die weivelde van die wildernis spruit uit, want die bome dra hulle vrugte, die Vyeboom en die Wingerdstok lewer hulle drag!	",
"	23 En julle, kinders van Sion, juig en wees bly in JaHWeH julle Elohey, want Hy gee julle die Leraar tot Geregtigheid en laat op julle neerdaal die reën, die Leraar en die laat reëns, soos voorheen. [Maleági 3:1]	",
"	24 Dan sal die dorsvloere vol koring wees en die parskuipe van vars wyn en olie oorloop.	",
"	25 En Ek sal julle vergoed die jare wat die treksprinkaan, die jong sprinkaan, die kommandowurm en die sprinkaan verslind het - My groot Leërmag wat Ek teen julle gestuur het. [Boekrol van die Opregte 80:33; JôWEl 1:4]	",
"	26 Dan sal julle oorvloedig eet en versadig wees en die Naam van JaHWeH julle Elohey prys wat wonderbaar met julle gehandel het, en My volk sal in ewigheid nie beskaamd staan nie.	",
"	27 En julle sal weet dat Ek in die midde van JisraEl is, Ek - JaHWeH julle Elohey, en niemand anders nie; en My volk sal in ewigheid nie beskaamd staan nie.	",
"	28 En daarna sal Ek My Gees uitgiet op alle vlees, en julle seuns en julle dogters sal profeteer, julle oues drome droom, julle jongelinge visioene sien. [JeségiEl 13:11-13; MattithJaHûW 16:3]	",
"	29 En ook op die diensknegte en op die diensmaagde sal Ek in dié dae My Gees uitgiet. [JeségiEl 24:27]	",
"	30 En Ek sal wondertekens gee aan die Hemele en op die Aarde: bloed en vuur en pilare van rook.	",
"	31 Die son sal verander word in duisternis en die maan in bloed, voordat die groot en deurlugtige dag van JaHWeH kom.	",
"	32 En elkeen wat die Naam van JaHWeH aanroep, sal gered word; want op die Berg van Sion en in Jerusalem sal daar ontkoming wees soos JaHWeH gesê het, en onder die oorblyfsel van die wat JaHWeH sal roep.	",
	
]
},
{
book: 'JôWEl',
chapter: '3',
content: [


"   1 WANT kyk, in dié dae en in dié tyd wanneer Ek die lot van JeHûWdah en Jerusalem verander,	",
"	2 sal Ek al die nasies versamel en hulle na die vallei van JeHôWshafat laat aftrek, om daar met hulle ’n strafgerig te hou ter wille van My volk en My Erfdeel JisraEl wat hulle onder die nasies verstrooi het, en My Aarde wat hulle verdeel en geplunder het.	",
"	3 En oor My volk het hulle die lot gewerp en ’n jong Seun weggegee vir ’n hoer en ’n Dogter verkoop vir wyn dat hulle kan drink.	",
"	4 En ook, wat het julle met My [te doen], o Tirus en Sidon en al die landstreke van Filistéa? Wil julle met My ’n Vredesverbond sluit? of wil julle My vergoed, En as julle wil onderhandel sal Ek vinnig en haastig julle onderhandeling laat terugkeer oor julle hoof.	",
"	5 Want julle het My silwer en My goud geneem en My suiwer en lieflike dinge na julle tempels gebring. [Psalm 12:6; Klaagliedere 4:2]	",
"	6 Verder het julle die kinders van JeHûWdah en die kinders van Jerusalem aan die kinders van Jawan verkoop, om hulle ver van hul grondgebied te verwyder.	",
"	7 Kyk, Ek sal hulle laat opstaan uit die plek waarheen julle hulle verkoop het, en julle dade op julle hoof laat neerkom.	",
"	8 En Ek sal julle seuns en julle dogters aan die kinders van JeHûWdah verkoop, en dié sal hulle verkoop aan die Sabeërs, aan ’n verafgeleë volk; want JaHWeH het dit gespreek.	",
"	9 Roep dit uit onder die nasies, berei ’n oorlog! Wek die dapper manne op, laat al die manne van die oorlog opruk!	",
"	10 Smee van julle pikke swaarde en van julle snoeimesse spiese; laat die swakke sê: Ek is dapper.	",
"	11 Haas julle en kom aan, alle nasies rondom, en versamel julle. Laat U Sterkes, JaHWeH, daarheen aftrek!	",
"	12 Die nasies moet hulle klaarmaak en optrek na die dal van JeHôWshafat; want daar sal Ek sit om gerig te hou oor al die nasies rondom.	",
"	13 Steek die sekel in, want die oes is ryp! Kom trap, want die parskuip is vol, die kuipe loop oor! Want hulle besoedeling is groot. [Openbaring 14:15]	",
"	14 Menigtes, menigtes in die Vallei van Beslissing, want naby is die dag van JaHWeH in die Vallei van Beslissing!	",
"	15 Die son en die maan word duister, en die Sterre trek hulle glans terug.	",
"	16 En JaHWeH brul uit Sion, en uit Jerusalem verhef Hy Sy Stem, sodat Hemele en Aarde bewe. Maar JaHWeH sal ’n toevlug wees vir Sy volk en ’n laer vir die kinders van JisraEl.	",
"	17 Dan sal julle weet: Ek - JaHWeH julle Elohey, wat woon in Sion, die Berg van My Apartheid; dan sal daar in Jerusalem Apartheid wees, in haar sal geen verbasterdes meer deur trek nie. [Levítikus 11:44; Openbaring 21:27]	",
"	18 En op dié dag sal die berge drup van wyn en die heuwels vloei van melk en al die spruitjies van JeHûWdah stroom van water; en uit die Huis van JaHWeH sal daar ’n Fontein uitkom om die Vallei van Akasias te besproei. [JeségiEl 47:2]	",
"	19 Egipte sal ’n woesteny word, en Edom ’n verlate wildernis wees, weens die geweld wat hulle die kinders van JeHûWdah aangedoen het, dat hulle onskuldige bloed in hul Aarde vergiet het.	",
"	20 Maar JeHûWdah sal vir ewig bly, en Jerusalem van geslag tot geslag.	",
"	21 En Ek sal hulle bloed onskuldig verklaar, wat Ek [tevore] nie onskuldig verklaar het nie; en JaHWeH sal in Sion bly woon.	",

]
}
];
