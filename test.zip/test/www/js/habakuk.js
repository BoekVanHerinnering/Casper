const habakukChapters = [

{
book: 'Habakuk',
chapter: '1',
content: [

"	1 DIE las wat Hábakuk, die profeet, gesien het.	",
"	2 Hoe lank, o JaHWeH, roep Ek om hulp, maar U hoor nie; skreeu Ek tot U: Geweld! - maar U help nie?	",
"	3 Waarom laat U My onreg sien en aanskou U die moeite! Ja, verwoesting en geweld is voor My Oë; en daar is stryd, en twis begin.	",
"	4 Daarom die Wet; sy raak kragteloos, en die Reg kom nooit meer te voorskyn nie; want die besoedelde omsingel die regverdige, daarom kom die Reg verdraaid te voorskyn.	",
"	5 Aanskou onder die nasies en merk op, en staan verstom, verstom; want Ek gaan iets in julle dae doen wat julle nie sal glo as dit vertel word nie.	",
"	6 Want kyk, Ek gaan die Chaldeërs opwek, daardie kwaai en onstuimige nasie wat trek deur die wydtes van die Aarde, om tabernakels in besit te neem wat aan hom nie behoort nie.	",
"	7 Verskriklik en gedug is hy, van homself gaan sy reg en hoogheid uit.	",
"	8 En vinniger as luiperds is sy perde en gouer as aandwolwe; en op ’n galop kom sy ruiters, ja, sy ruiters! Van ver kom hulle aangevlieg net soos ’n arend wat op sy prooi neerskiet!	",
"	9 Hulle kom almal om geweld te pleeg; die rigting van hulle gesigte is vorentoe, sodat hy gevangenes versamel soos sand.	",
"	10 Ook dryf hy die spot met konings, en vorste is vir hom ’n belagging; hy lag om elke vesting; hy hoop grond [teen haar] op en neem haar in.	",
"	11 Dan gly hy verby, ’n gees, en trek verder - maar word skuldig, hy wie se krag sy godin is.	",
"	12 Is U dan nie uit die voortyd nie, o JaHWeH, My Elohey, My Aparte Een? Ons sal nie sterwe nie. JaHWeH, tot ’n Regspraak het U hom bestel en, o Rots, tot ’n tugroede het U hom bestem!	",
"	13 U, wat te suiwer is van Oë om die besoedeling aan te sien en die onreg nie kan aanskou nie - waarom aanskou U die verraaier, swyg U wanneer die besoedelde dié verslind wat regverdiger is as hy?	",
"	14 So maak U dan adamiete soos visse van die see, soos kruipende gediertes wat geen heerser oor hulle het nie.	",
"	15 Hy trek hulle almal op met die hoek, sleep hulle in sy net en vergader hulle in sy seën; daarom is hy vrolik en juig.	",
"	16 Daarom slag hy vir sy vangs en laat rook opgaan vir sy sleepnet; want deur hulle is sy aandeel vet en sy spys weelderig.	",
"	17 Sal hy daarom sy net uitskud en voortdurend nasies doodmaak sonder verskoning?	",

]
},
{
book: 'Habakuk',
chapter: '2',
content: [
	
"	1 OP My Wagtoring wil Ek gaan staan en op ’n skansmuur My stel, en Ek wil speur om te sien wat Hy in My sal spreek, en wat Ek op My klagte moet antwoord.	",
"	2 Toe antwoord JaHWeH my en sê: Skryf die gesig op en graveer hom op tafels, sodat hulle hom in die verbygaan kan lees.	",
"	3 Want die gesig sal nog duur tot op die vasgestelde tyd; maar hy spoed na die einde en sal nie teleurstel nie. As hy mag vertoef, wag daarop; want alte seker sal hy kom en nie versuim nie:	",
"	4 Kyk, sy siel is opgeblase in hom en nie opreg nie. Maar die regverdige, deur sy getrouheid sal hy lewe.	",
"	5 En bowendien, die wyn, bedrieg ’n trotse krygsman met gerustelling: hy wat sy siel wyd oopmaak soos die Doderyk/Sheol, en soos Dood is hy, so onversadelik - hy vergader vir homself al die nasies en maak vir hom al die volke bymekaar.	",
"	6 Sal hulle nie almal oor hom ’n spreuk, ’n spotlied aanhef nie, raaisels oor hom [maak] nie, en sê: Wee die man wat hom verryk met wat nie aan hom behoort nie - hoe lank? - en hom beswaar met verpande goed.	",
"	7 Sal die wat jou byt, nie skielik opstaan en jou skrikaanjaers nie opwaak, sodat jy vir hulle ’n prooi word nie?	",
"	8 Omdat jy baie nasies uitgebuit het, sal al die volke wat oorgebly het, jou uitbuit, weens die bloed van die adamiete en die geweld teen die Aarde, die stad en al haar inwoners.	",
"	9 Wee hom wat onregverdige wins deur besoedeling maak vir sy huis, om sy nes in die hoogte te bou, om homself te red uit die handpalms van besoedeling.	",
"	10 Jy adverteer skande vir jou huis: die uitroeiing van baie volke, en het jou siel verbeur.	",
"	11 Want die steen uit die muur roep, en die balk uit die timmerasie gee hom antwoord.	",
"	12 Wee hom wat ’n stad bou met bloed en ’n vesting stig deur onreg.	",
"	13 Kyk, kom dit nie van JaHWeH van die skeppings-leërmag dat volke arbei vir vuur en gemeenskappe hulle afmat vir niks nie?	",
"	14 Want die Aarde sal vol word met die Kennis van die Glansrykheid van JaHWeH soos die waters die seebodem oordek.	",
"	15 Wee hom wat aan sy naaste drank gee, met jou gif daarmee gemeng, en [hulle] ook dronk maak om hulle naaktheid te aanskou.	",
"	16 Jy het jou versadig met skandelikheid in plaas van met eer - drink jy ook nou, en wees maar onbesnede. Na jou toe sal die Beker van die Regterhand van JaHWeH omgaan, en skande tref jou eer.	",
"	17 Want die geweld aan die Líbanon gepleeg sal jou oordek; en die verwoesting waarmee die wilde wesens skrikgemaak is - weens die bloed van die adamiete en die geweld teen die Aarde, die stad en al haar inwoners.	",
"	18 Wat baat ’n gesnede beeld dat sy maker dit reggekap het, ’n gegote beeld, wat ’n skinker van ‘n leuenagtige gestalte is, dat die maker op sy eie maaksel vertrou, deur stomme drek te maak?	",
"	19 Wee hom wat vir ’n stuk hout sê: Word wakker! vir ’n dooie klip: Ontwaak! Kan hy [’n adamiet] leer? Kyk, hy is oorgetrek met goud en silwer, en daar is géén gees in sy binneste nie!	",
"	20 Maar JaHWeH is in die Tempel van Sy Apartheid - swyg voor Hom, o ganse Aarde!	",

]
},
{
book: 'Habakuk',
chapter: '3',
content: [
		
"	1 ’N GEBED van Hábakuk, die profeet, ‘n Liriese gedig.	",
"	2 JaHWeH, ek het die tyding aangaande U verneem, ek het gevrees! JaHWeH, roep U werk in die lewe in die midde van die jare; in die midde van die jare laat dit bekend word. In Toorn, dink aan Ontferming.	",
"	3 Elowahh kom van Teman en die Aparte Een van die berg Paran. Sela. Sy Majesteit bedek die Hemele, en die Aarde is vol van Sy lof.	",
"	4 En [Sy] Glans was soos die sonlig, helder strale het uit Sy Hand gekom; en dáár is die omhulsel van Sy mag.	",
"	5 Voor Hom uit loop die pes, en ’n koorsgloed trek uit agter Hom aan.	",
"	6 Hy staan en skud die Aarde, Hy kyk en die nasies bewe; verpletterd lê die ou berge, en die ou heuwels het gebuig voor Sy ewige Weg	",
"	7 Ek sien die tente van kuwshiete(swartes) met besoedeling oordek, en die gordyne van die Aarde van Mídian bewe.	",
"	8 Is dit teen riviere, o JaHWeH, teen die riviere, dat U Wraak ontvlam het? Of geld U Grimmigheid die see dat U ry met U perde, U waens van Verlossing?	",
"	9 Heeltemal ontbloot is U boog; besweer is die pyle deur die Woord. Sela. Tot riviere splyt U die Aarde.	",
"	10 Die berge sien U en bewe van angs, ’n wolkbreuk storm verby, die Afgrond verhef sy stem, steek sy hande omhoog.	",
"	11 Die son, die maan bly in [hulle] woonplek by die Lig van U pyle wat verbyskiet, by die glans van U flikkerende spies.	",
"	12 In Grimmigheid betree U die Aarde, in Toorn dors U die nasies.	",
"	13 U trek uit tot Lossing van U volk, tot Lossing met U Gesalfde. U verbrysel die hoof van die huis van die besoedelde en ontbloot die fondament tot by die nek. Sela.	",
"	14 U deurboor met sy eie pyle die hoof van sy leiers wat storm om my te verstrooi; wie se gejuig is asof hulle die ellendige in die skuilhoek wil verslind.	",
"	15 U betree die see met U perde, ’n hoop magtige waters.	",
"	16 Toe ek dit hoor, het my ingewande gebewe; my lippe het getril by die geluid, bederf het gekom in my gebeente, ja, ek het gebewe waar ek staan, omdat ek rustig moes wag op die dag van benoudheid dat dit aanbreek vir die volk wat op ons ’n aanval maak.	",
"	17 Alhoewel die Vyeboom nie sal bot en aan die Wingerdstokke geen vrug sal wees nie, die drag van die Olyfboom sal teleurstel en die saailande geen voedsel oplewer nie, die kleinvee uit die kraal verdwyn en geen beeste in die stalle sal wees nie -	",
"	18 nogtans sal ek jubel in JaHWeH, ek sal juig in die Elohey, van my Lossing.	",
"	19 My Meester JaHWeH is my sterkte, en Hy maak my voete soos dié van herte, en Hy laat my loop op my verhewe plek. Vir die musiekleier op snaarinstrumente.	",

]
}
];
