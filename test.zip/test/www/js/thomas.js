const thomasChapters = [

{
book: 'Thomas',
chapter: '1',
content: [

"	1EK, Thomas die JisraEliet, gaan aan julle vertel, ja, aan al die broers uit die nasies, en aan julle bekend maak die geskiedenisse van die kindertyd van ons Meester JaHWèshua die Gesalfde en Sy magtige dade wat Hy alles gedoen het toe Hy in ons deel van die Aarde gebore is. Die begin daarvan is as volg:	",

]
},
{
book: 'Thomas',
chapter: '2',
content: [
	
"	2 TOE die Kindjie JaHWèshua vyf jaar oud was, was Hy [na ‘n reent]] aan die speel by die drif van ‘n spruit. En die lopende water het Hy bymekaargekeer in damme en hulle onmiddellik helder laat word, op Sy blote woord het Hy hulle daartoe beveel. [JeségiEl 34:18]	",
"	2 En nadat Hy sagte klei gemaak het, het Hy uit haar twaalf mossies gevorm. En dit was op die Sabbat toe Hy dit gedoen het. En daar was ook baie ander kindertjies wat saam met Hom gespeel het.	",
"	3 En toe ‘n sekere man van JeHûWdah sien wat JaHWèshua gemaak het terwyl Hy op die Sabbatdag speel, het hy dadelik heengegaan en vir Sy vader JôWsef gesê: Kyk, jou Kind is by die spruit en Hy het klei geneem en van haar twaalf voëltjies gemaak en so die Sabbat geskend.	",
"	4 En JôWsef gaan na die plek en sien dit en hy roep na Hom en sê: Waarom doen Jy op die Sabbat hierdie dinge wat nie geoorloof is om te doen nie? Maar JaHWèshua het Sy hande geklap en na die mossies geroep en gesê: Gaan! en die mossies het opgevlieg en tjirpend weggegaan.	",
"	5 En toe die manne van JeHûWdah dit sien, was hulle verbaas en hulle het teruggegaan en aan hul owerstes vertel wat hulle JaHWèshua sien doen het.	",

]
},
{
book: 'Thomas',
chapter: '3',
content: [
	
"	3 MAAR die seun van Annas, die skrywer, het daar by JôWsef gestaan, en hy het ‘n wilgertak geneem en die waters laat wegvloei wat JaHWèshua bymekaargemaak het.	",
"	2 En toe JaHWèshua sien wat gebeur het, het Hy kwaad geword en vir hom gesê: Slegte, besoedelde en onnosele mens! Watter kwaad het die damme en die waters aan jou gedoen? Kyk, nou sal jy ook opdroog soos ‘n boom en jy sal g’n blare dra, of wortel of vrug nie!  [MattithJaHûW 21:19]	",
"	3 En onmiddellik het die seun heeltemal verdor, en JaHWèshua het vertrek en na JôWsef se huis gegaan. Maar die ouers van hom wat verdor is, het hom opgetel en sy jeug beween en hom na JôWsef gebring en hom uitgeskel: Omdat jy so ‘n kind het wat sulke dinge doen.	",

]
},
{
book: 'Thomas',
chapter: '4',
content: [
	
"	4 NA dit het Hy weer deur die dorp gegaan, en ‘n seun het aangehardloop en Hom teen die skouer gestamp. En JaHWèshua het Hom vererg en vir hom gesê: Jy sal nie jou loop voltooi nie! En onmiddellik het hy neergeval en gesterwe. En party van die wat dit sien gebeur het, het gesê: Vanwaar is hierdie Kind gebore dat elke woord van Hom ‘n volkome daad is? [JeshaJaH 8:14]	",
"	2 En die ouers van die gestorwene het na JôWsef gekom en hom beskuldig en gesê: Jy wat so ‘n kind het, kan nie by ons op die dorp bly woon nie! Of anders moet jy Hom leer om te seën en nie te vervloek nie, want Hy maak ons kinders dood!	",

]
},
{
book: 'Thomas',
chapter: '5',
content: [
		
"	5 EN JôWsef het die jong Seun eenkant toe geroep en vermaan en gesê: Waarom doen Jy sulke dinge dat hierdie mense moet ly en ons haat en vervolg? Maar JaHWèshua sê: Ek weet dat hierdie woorde van u nie u woorde is nie, nietemin sal Ek om u ontwil stilbly ‑ maar hulle sal hul straf dra! En ineens is hulle wat Hom aangekla het, met blindheid geslaan.	",
"	2 En dié wat dit gesien het, het baie bevrees geword en was dronkgeslaan en het aangaande Hom gesê: Elke woord wat Hy gespreek het, of dit goed was of sleg, was ‘n daad en het ‘n wonder geword. En toe JôWsef sien dat Hy so ‘n ding gedoen het, het hy opgestaan en Hom aan Sy oor beetgekry en dit hard getrek.	",
"	3 En die seun het toornig geword en vir hom gesê: Dit is vir u genoeg om te soek en nie te vind nie, en u het sekerlik nie wys gehandel nie. Weet u nie dat Ek aan u behoort nie? Bedroef My dan nie!  [JeHôWganan 10:38]	",

]
},
{
book: 'Thomas',
chapter: '6',
content: [
	
"	6 EN ‘n sekere leermeester, Saggéüs van naam, het daar rondgestaan en JaHWèshua hierdie dinge tot Sy vader hoor spreek en hy het hom grootliks daaroor verbaas dat Hy, wat maar ‘n jong kind was, sulke dinge geuiter het.	",
"	2 En na ‘n paar dae het hy na JôWsef gekom en vir hom gesê: Jy het ‘n Kind met Verstand en Hy het Insig.	",
"	2a Kom, gee Hom aan my sorg oor dat ek Hom letters kan leer. En ek sal Hom met die letters ook in alle kennis onderrig, hoe Hy alle oudstes moet begroet en hulle as voorvaders en vaders moet eer, en hoe Hy dié van Sy eie leeftyd moet liefhê.	",
"	3 En hy het Hom al die letters gesê, van alef [a] af tot by taw [T], duidelik en met presiesheid.	",
"	3a Maar Hy het Sy leermeester Saggéüs aangekyk en gesê: U wat nie eens die alef [a] na sy natuur ken nie, hoe kan u aan ander die beth [B] leer? Huigelaar, leer eers die alef [a] ‑ as u dit weet ‑en dan sal ons u glo wat die beth [B] betref.	",
"	3b En toe begin Hy die meester uit te vra oor die eerste letter, en hy kon nie volhou om Hom te antwoord nie.	",
"	4 En ten aanhore van baie sê die Seuntjie vir Saggéüs: Hoor, meester, die ordening van die eerste letter en gee ag daarop hoe dit lyne het en ‘n middelstreep wat, soos u sien, heengaan deur albei die lyne wat saam hoort; [lyne] wat saamgaan, hulle verhef, draaie maak, uit drie tekens bestaan, van dieselfde soort, ewewigtig en gelyk in maat. Daar het u die lyne van die alef. [a]	",

]
},
{
book: 'Thomas',
chapter: '7',
content: [
		
"	7 TOE die meester Saggéüs nou sulke en soveel simboliese voorstellinge van die eerste letter deur die jeugdige Kind hoor spreek, was hy verleë oor so ‘n antwoord en oor Sy groot onderrig. En hy sê vir die wat daar teenwoordig was: Wee my, ellendige wat ek is, ek is oorbluf! Ek het my skande op die hals gehaal deur hierdie Kind na my te laat bring.	",
"	2 Neem Hom dus weg, broer JôWsef, ek smeek jou! Ek kan nie die strengheid van Sy blik verdra nie, ek kan nie eenmaal Sy woord deurgrond nie. Hierdie kind is nie aards‑gebore nie, Hy is een wat selfs vuur kan tem. Moontlik is Hy een wat gebore is voordat die wêreld gemaak is.	",
"	2a Watter buik het Hom gedra, watter moederskoot het Hom gevoed? Ek weet dit nie! Wee my, my vriend, Hy bring my buite my sinne, ek kan Sy Verstand nie peil nie. Ek het myself bedrieg, ek, drie maal ellendige mens!	",
"	2b Ek het my beywer om ‘n leerling te werf en nou vind ek dat ek ‘n Leermeester gekry het!	",
"	3 Ek dink, my vriende, aan my skande dat ek, wat ‘n grysaard is, deur ‘n kind oorwin is. Daar bly niks vir my oor nie as om maar in te gee en om hierdie Kind ontwil te sterwe, want ek is nie in staat om Hom op hierdie uur in die gesig te kyk nie.	",
"	3a En as almal sê dat ek deur ‘n klein seuntjie oorwin is, wat kan ek dan sê? En wat kan ek verduidelik van die lyne van die eerste letter waaroor Hy met my gepraat het? Ek is onkundig, my vriende, want ek kan g’n begin of end daarvan uitmaak nie.	",
"	3b Daarom, broer JôWsef, neem Hom huis toe, smeek ek jou! Want Hy is iets groots, ‘n El of ‘n Boodskapper, of wat ek moet sê, weet ek nie!	",

]
},
{
book: 'Thomas',
chapter: '8',
content: [
"	8 EN toe die Jode vir Saggéüs wil bemoedig, lag die Knapie hardop en sê: Nou sal die onvrugbares vrug dra, en die wat blind van hart is, sal sien. Ek het van bo gekom dat Ek hulle kan vervloek en dat hulle kan roep tot die dinge wat daarbo is, soos HY beveel het wat My om julle ontwil gestuur het. [Psalm 69 ; Lukas 23:34]	",
"	2 En toe die Kind ophou om te praat, het almal onmiddellik gesond geword wat deur Sy vloek getref was. En niemand het daarna gewaag om Hom kwaad te maak nie, sodat Hy hom nie sou vervloek en hy vermink sou word nie.	",

]
},
{
book: 'Thomas',
chapter: '9',
content: [
	
"	9 EN na enkele dae het JaHWèshua bo-op die dak van ‘n sekere huis gespeel en een van die seuntjies wat met Hom speel, val bo van die dak af na onder en sterwe. En toe die ander kinders dit sien, hardloop hulle weg en JaHWèshua bly alleen staan.	",
"	2 En die ouers van die gestorwe seuntjie kom en beskuldig Hom dat Hy hom afgestoot het. En JaHWèshua sê: Ek het hom nie afgegooi nie! maar hulle het aangehou om Hom sleg te sê.	",
"	3 Toe spring JaHWèshua van die dak af en gaan staan by die liggaam van die seun en roep met ‘n harde stem uit en sê: Zeno [want so was sy naam], staan op en sê vir My, het Ek jou afgegooi?	",
"	3a En dadelik staan hy op en sê: Nee, Meester, U het my nie afgegooi nie, maar opgewek! En toe hulle dit sien, was hulle verskrik. En die ouers van die kindjie het Elohim geprys oor die Teken wat geskied het, en het aan JaHWèshua hulde bewys.	",

]
},
{
book: 'Thomas',
chapter: '10',
content: [
		
"	10 NA ‘n paar dae was ‘n sekere jong man besig om hout te kap in die omgewing, en die byl glip uit sy hande en kloof sy voetsool oop, en vanweë die groot bloedverlies het hy gesterf.	",
"	2 En toe daar ‘n opskudding en toeloop ontstaan, het die Seuntjie JaHWèshua ook daarheen gehardloop. En met geweld het Hy deur die skare gedring en die verwonde voet van die jong man gegryp, en dadelik het dit genees. Toe sê Hy vir die jong man: Staan nou op en kloof die hout en dink aan My!	",
"	Maar toe die skare sien wat gebeur het, het hulle die Kindjie vereer, en gesê: Waarlik, die Gees van Elohim woon in hierdie Kind!	",

]
},
{
book: 'Thomas',
chapter: '11',
content: [
	
"	11 TOE Hy ses jaar oud was, het Sy moeder Hom, nadat sy Hom ‘n waterkruik gegee het, gestuur om water te skep en huis toe te dra. In die gedrang het Hy haar egter [teen ‘n ander] gestamp, en die kruik het gebreek. [Prediker 12:6]	",
"	2 Maar JaHWèshua het die oorkleed wat Hy aangehad het, oopgesprei en hom met water gevul en hom so aan Sy moeder gebring. En toe Sy moeder die wonder sien wat geskied het, het sy Hom gesoen en in haar hart die geheimenisvolle dinge bewaar wat sy Hom sien doen het.	",

]
},
{
book: 'Thomas',
chapter: '12',
content: [
	
"	12 EN weer in die saaityd het die Knapie saamgegaan met Sy vader om koring in hul land te gaan saai. En terwyl Sy vader aan die saai was, het die Kind JaHWèshua ook één koringkorrel gesaai. [JehôWganan 12:24]	",
"	2 En toe Hy hom geoes en uitgedors het, het Hy honderd mud van hom gekry. En Hy het al die armes van die dorp na die dorsvloer geroep en hulle die koring gegee. En JôWsef het geneem wat daar van die koring oorgebly het. Hy [JaHWèshua] was agt jaar oud toe Hy hierdie Teken verrig het. [Genésis 26:12 ; Lukas 3:17]	",

]
},
{
book: 'Thomas',
chapter: '13',
content: [
	
"	13 SY vader was ‘n timmerman en het in dié tyd [hout‑] ploeë en jukke gemaak. Deur ‘n ryk man is dit toe aan hom opgedra om vir hom ‘n rusbank te maak. Maar omdat die een plank, wat die wisselplank genoem word, korter as die ander was en hy nie wis wat hy sou maak nie, het die Kind JaHWèshua aan Sy vader JôWsef gesê: Sit die twee stukke hout langs mekaar neer en maak hulle gelyk aan die punt naaste aan u.	",
"	2 En JôWsef het gedoen soos die Seuntjie gesê het. Toe gaan staan JaHWèshua aan die ander kant en gryp die kortste stuk hout en rek dit uit en maak dit gelyk aan die ander. En Sy vader JôWsef het dit gesien en hom verwonder, en hy omhels die Seuntjie en soen Hom en sê: Hoe geseënd is ek dat Elohim my hierdie Kindjie gegee het!  [JeségiEl 37:16]	",
	
]
},
{
book: 'Thomas',
chapter: '14',
content: [
	
"	14 EN toe JôWsef die verstand van die Kindjie sien op Sy leeftyd, dat Hy begin om volwasse te word, het hy weer by Homself gedink dat Hy nie onkundig moes bly wat die letters betref nie, en hy het Hom geneem en aan die sorg van ‘n ander leermeester oorgegee.	",
"	1a En die meester sê vir JôWsef: Eers sal ek Hom onderrig in die Griekse letters en daarna in die Hebreeuse. Want die meester het van die bekwaamheid van die Knapie geweet en het Hom gevrees. Nietemin het hy toe die alfabet neergeskryf en dit vir ‘n lang tyd met Hom behandel. Maar JaHWèshua het hom nie geantwoord nie.	",
"	2 Toe sê JaHWèshua vir hom: As u werklik ‘n leermeester is, en as u letters goed ken, sê dan vir My wat die krag is van alef [a], dan sal Ek u sê wat die krag is van beth [B].	",
"	2a Maar die meester het vererg geraak en Hom op Sy hoof geslaan. En die Knapie het seergekry en Hom vervloek, en ineens het hy flou geword en op sy gesig teen die Aarde geval.	",
"	3 Die Seuntjie het toe na die huis van JôWsef teruggekeer. En JôWsef was ontstem en het Sy moeder opdrag gegee dat sy Hom nie buite die deur moes laat uitgaan nie, omdat almal sterwe wat Hom tot toorn verwek.	",
		
]

},
{
book: 'Thomas',
chapter: '15',
content: [
		
"	15 EN ‘n tyd daarna het ‘n ander onderwyser, wat ‘n getroue vriend van JôWsef was, weer vir hom gesê:Bring die Kind na my in die skool. Miskien sal ek Hom met vriendelike woorde die letters kan leer.	",
"	1a En JôWsef sê vir hom: As jy die moed daartoe het, broer, neem Hom saam met jou. En hy het Hom onder vrese en bewing met hom saamgeneem. Maar die Knapie het plesierig met hom meegegaan.	",
"	2 En toe Hy moedig in die skool ingaan, vind Hy ‘n boek wat op die lessenaar lê, en Hy neem hom en lees nie die letters wat daarin staan nie, maar Hy open Sy mond en spreek deur die Gees van die Apartheid en onderrig die Wet aan hulle wat om Hom heen staan.	",
"	2a En ‘n groot menigte vergader en staan by en luister na Hom en verwonder hulle oor die rypheid van Sy onderrig en oor die gepastheid van Sy woorde en dat Hy, wat maar nog ‘n kind was, sulke dinge kon spreek.	",
"	3 En JôWsef het daarvan gehoor en gevrees en het hom na die skool gehaas, menende dat hierdie leermeester miskien ook onmagtig was, maar die meester sê vir JôWsef: Jy moet weet, my broer, dat ek hierdie Kind opgeneem het as ‘n leerling, maar Hy is vol van Barmhartigheid en Wysheid, en nou versoek ek jou, broer, neem Hom maar weer huis toe.	",
"	4 En toe die Knapie dit hoor, het Hy vir hom geglimlag en gesê: Aangesien u reg gesê het en ‘n regte getuienis afgelê het, sal hy wat getref is, om u ontwil weer gesond word. En onmiddellik is die ander leermeester genees. En JôWsef het die Seuntjie geneem en na sy huis vertrek.	",

]
},
{
book: 'Thomas',
chapter: '16',
content: [
	
"	16 JÔWSEF het sy seun Jakobus uitgestuur om hout bymekaar te maak en huis toe te dra. En die Knapie JaHWèshua het met hom saamgegaan. En terwyl Jakobus die dragte bymekaarmaak, byt ‘n slang Jakobus se hand.	",
"	2 En toe hy baie pyn verduur en op die punt was om te beswyk, het JaHWèshua na hom gekom en op die bytplek geblaas. En onmiddellik het die pyn bedaar, en die slang het oopgebars, en Jakobus was van dié oomblik af gesond.	",

]
},
{
book: 'Thomas',
chapter: '17',
content: [
	
"	17 EN na hierdie dinge het daar in die buurt van JôWsef ‘n kindjie siek geword en gesterwe, en sy moeder het bitterlik geween. En JaHWèshua hoor dat daar ‘n groot weeklag en rumoer ontstaan en	",
"	1a Hy hardloop daarheen en vind die kindjie dood. En Hy raak sy bors aan en sê: Kindjie, Ek sê vir jou, moenie sterwe nie, maar lewe en bly by jou moeder! En dadelik het hy opgekyk en gelag. En Hy sê vir die vrou: Tel hom op en gee hom melk, en dink aan My!	",
"	2 En die menigte wat daar by gestaan het, het dit gesien en was verwonderd en het gesê: Waarlik, hierdie jong Kind is óf El óf ‘n Boodskapper van Elohim, want elke woord van Hom is ‘n voltooide daad. En JaHWèshua het daarvandaan weggegaan en met ander kinders gaan speel.	",

]
},
{
book: 'Thomas',
chapter: '18',
content: [
		
"	18 En na ‘n tyd, terwyl daar ‘n huisbouery aan die gang was, het daar ‘n hele opskudding ontstaan en JaHWèshua het opgestaan en daarheen gegaan. En toe Hy ‘n man daar dood sien lê, vat Hy sy hand en sê: Man, Ek sê vir jou, staan op en doen jou werk! En onmiddellik het hy opgestaan en Hom hulde bewys. [1 Petrus 2:9]	",
"	2 En toe die menigte dit sien, was hulle verbaas en sê: Hierdie jong Kind is van die Hemele. Baie siele het Hy van die dood gered, en kan Hy Sy hele lewe lank red.	",

]
},
{
book: 'Thomas',
chapter: '19',
content: [
		
"	19 En toe Hy twaalf jaar oud was, het Sy ouers volgens gewoonte met hul reisgeselskap vir die Pasga na Jerusalem opgegaan. En na die Pasga het hulle teruggekeer huis toe. En terwyl hulle op pad terug was, het die Kind JaHWèshua na Jerusalem teruggegaan, maar Sy ouers het gemeen dat Hy by die reisgeselskap was.	",
"	2 En toe hulle ‘n dagreis ver gegaan het, het hulle onder hul familie na Hom gesoek, en toe hulle Hom nie vind nie, was hulle baie bekommerd en het na die Stad teruggekeer en Hom gaan soek.	",
"	2a En na die derde dag vind hulle Hom in die Tempel, waar Hy in die midde van die leraars na die Wet sit en luister en hulle ondervra.	",
"	2b En almal het op Hom ag gegee en gewonder hoe Hy, wat maar ‘n kind was, die monde van die oudstes en die leraars van die volk kon stop, terwyl Hy die hoofdele van die Wet en die gelykenisse van die profete uiteensit.	",
"	3 En Sy moeder Mirjam het nader gekom en vir Hom gesê: Kind, waarom het Jy ons dit aangedoen? Kyk, met smart het ons Jou gesoek! En JaHWèshua sê vir hulle: Waarom soek u My? Weet u nie dat Ek in die dinge van My Vader moet wees nie?	",
"	4 Toe sê die skrywers en Fariseërs: Is jy die moeder van hierdie Seuntjie? En sy sê: Ek is dit.	",
"	4a En hulle sê vir haar: Geseënd is jy onder die vroue, omdat Elohim die Vrug van jou skoot geseën het. Want sulke Glansrykheid en sulke Deug en Wysheid het ons nog nooit gesien of gehoor nie.	",
"	5 En JaHWèshua het opgestaan en Sy moeder gevolg en was aan Sy ouers onderdanig. Maar Sy moeder het alles wat gebeur het, [in haar hart] bewaar.	",
"	5a En JaHWèshua het toegeneem in Wysheid en Grootheid en Barmhartigheid. Aan Hom kom toe die Glansrykheid tot in alle ewigheid. Amein.	",

]
}


];
