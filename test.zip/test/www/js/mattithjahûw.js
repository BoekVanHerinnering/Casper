const mattithjahûwChapters = [

{
book: 'Mattithjahûw',
chapter: '1',
content: [

"	1 DIE genelyn van JaHWèshua die Gesalfde, die seun van Dawid, die seun van Abraham:	",
"	2 Abraham was die vader van Isak, en Isak die vader van Jakob, en Jakob die vader van JeHûWdah en sy broers;	",
"	3 en JeHûWdah was die vader van Peres en Serag by Tamar, en Peres was die vader van Hesron, en Hesron die vader van Ram,	",
"	4 en Ram die vader van Ammínadab, en Ammínadab die vader van Nagson, en Nagson die vader van Salmon,	",
"	5 en Salmon die vader van Boas by Ragab, en Boas die vader van Obed by Rut, en Obed die vader van Isai,	",
"	6 en Isai die vader van koning Dawid, en koning Dawid die vader van Salomo by die vrou van UriJaH,	",
"	7 en Salomo die vader van Rehábeam, en Rehábeam die vader van AbiJaH, en AbiJaH die vader van Asa,	",
"	8 en Asa die vader van JeHôWshafat, en JeHôWshafat die vader van JôWram, en JôWram die vader van UzziJaHûW,	",
"	9 en UzziJaHûW die vader van JôWtham, en JôWtham die vader van Agas, en Agas die vader van GizkiJaHûW,	",
"	10 en GizkiJaHûW die vader van Manasse, en Manasse die vader van Amon, en Amon die vader van JoshiJaHûW,	",
"	11 en JoshiJaHûW die vader van JeHôWjakim en sy broers in die tyd van die Babelse ballingskap.	",
"	12 En ná die Babelse ballingskap het JeHôWjakim die vader geword van ShealtiEl, en ShealtiEl was die vader van Serubbábel,	",
"	13 en Serubbábel die vader van Abíhud, en Abíhud die vader van El-Jakim, en El-Jakim die vader van Asor,	",
"	14 en Asor die vader van Sadok, en Sadok die vader van JôWkim, en JôWkim die vader van Elíhud,	",
"	15 en Elíhud die vader van El-Azar, en El-Azar die vader van Mattan, en Mattan die vader van Jakob,	",
"	16 en Jakob die vader van JôWsef, die man van Mirjam uit wie gebore is JaHWèshua wat die Gesalfde genoem word.	",
"	17 Al die geslagte dan van Abraham tot Dawid is veertien geslagte, en van Dawid tot die Babelse ballingskap veertien geslagte, en van die Babelse ballingskap tot die Gesalfde veertien geslagte.	",
		
		
"	18 DIE geboorte van JaHWèshua die Gesalfde was dan só: Toe Sy moeder Mirjam verloof was aan JôWsef, voordat hulle saamgekom het, is sy swanger bevind uit die Gees van die Apartheid.	",
"	19 En JôWsef, haar man, omdat hy regverdig was en onwillig was om haar openbaar te maak, het hom voorgeneem om in die geheim van haar te skei.	",
"	20 Maar terwyl hy dit in die gedagte gehad het, verskyn daar ’n Boodskapper van die Elohim in ’n droom aan hom en sê: JôWsef, seun van Dawid, wees nie bevrees om Mirjam, jou vrou, by jou te neem nie, want wat in haar verwek is, is uit die Gees van die Apartheid;	",
"	21 en sy sal ’n seun baar, en jy moet Hom JaHWèshua noem, want dit is Hy wat Sy volk van hulle oortredinge sal verlos.	",
"	22 En dit het alles gebeur, sodat die Woord vervul sou word wat JaHWeH deur die Profeet gespreek het:	",
"	23 Kyk, die maagd sal swanger word en ’n seun baar, en Hom ImmánuEl noem, dit is, as dit [uit Hebreeus] vertaal word: El met ons. [JeshaJaHûW 7:14]	",
"	24 En toe JôWsef uit die slaap wakker word, het hy gedoen soos die Boodskapper van JaHWeH hom beveel het en sy vrou by hom geneem;	",
"	25 en hy het haar nie beken totdat sy haar eersgebore Seun gebaar het nie; en hy het Hom JaHWèshua genoem.	",

]
},
{
book: 'Mattithjahûw',
chapter: '2',
content: [
		
"	1 EN toe JaHWèshua te Betlehem in JeHûWdah gebore is, in die dae van koning Herodes, het daar wyse manne uit die Ooste in Jerusalem aangekom	",
"	2 en gesê: Waar is die Koning van JeHûWdah, wat gebore is? Want ons het Sy Ster in die Ooste gesien en gekom om Hom hulde te bewys.	",
"	3 En toe koning Herodes dit hoor, was hy ontsteld en die hele Jerusalem saam met hom;	",
"	4 en hy het al die owerpriesters en die skrywers van die volk bymekaar laat kom en by hulle navraag gedoen waar die Gesalfde gebore sou word.	",
"	5 En hulle het vir hom gesê: Te Betlehem in JeHûWdah, want so is daar deur die Profeet geskrywe:	",
"	6 En jy, Betlehem Efrata, klein om te wees onder die duisende van JeHûWdah, uit jou sal daar vir MY een uitgaan wat ‘n Vors in JisraEl sal wees; en Sy uitgange is uit die voortyd, uit die dae van die ewigheid. [Miga 5:2]	",
"	7 Toe het Herodes die wyse manne in die geheim geroep en hulle na die tyd van die Ster se verskyning uitgevra;	",
"	8 en hy het hulle na Betlehem gestuur en gesê: Gaan doen noukeurig ondersoek na die Kindjie, en as julle Hom vind, laat my weet, sodat ek ook kan gaan en Hom hulde bewys.	",
"	9 En nadat hulle die koning aangehoor het, het hulle vertrek. En kyk, die Ster wat hulle in die Ooste gesien het, gaan voor hulle uit totdat Hy kom en bly staan bo-oor die plek waar die Kindjie was. [Boekrol van die Opregte 8:2]	",
"	10 En toe hulle die Ster sien, het hulle hul met baie groot blydskap verheug.	",
"	11 En hulle het in die huis gegaan en die Kindjie by Mirjam, Sy moeder, gevind en neergeval en Hom hulde bewys. Daarop maak hulle hul skatte oop en bring vir Hom geskenke: goud en wierook en mirre.	",
"	12 En omdat hulle in ’n droom ’n waarskuwing ontvang het om nie na Herodes terug te keer nie, het hulle met ’n ander pad na hul deel van die Aarde teruggegaan.	",
		
		
"	13 EN toe hulle teruggegaan het, verskyn daar ’n Boodskapper van JaHWeH in ’n droom aan JôWsef en sê: Staan op, neem die Kindjie en Sy moeder en vlug na Egipte, en bly daar totdat ek jou sê; want Herodes gaan die Kindjie soek om Hom dood te maak. [Boekrol van die Opregte 8:16]	",
"	14 Hy het toe opgestaan, die Kindjie en Sy moeder in die nag geneem en na Egipte vertrek.	",
"	15 En Hy was daar tot die dood van Herodes, sodat die Woord vervul sou word wat JaHWeH gespreek het deur die Profeet: Uit Egipte het Ek My Seun geroep. [Hoséa 11:1]	",
"	16 Toe Herodes sien dat hy deur die wyse manne mislei was, het hy baie woedend geword en gestuur en in Betlehem en in al die omstreke daarvan al die seuntjies van twee jaar en daaronder laat ombring, ooreenkomstig die tyd wat hy van die wyse manne uitgevra het.	",
"	17 Toe is vervul wat deur JirmeJaH, die Profeet, gespreek is toe hy gesê het:	",
"	18 ‘n Stem word gehoor in Rama, geklaag, bitter geween; Ragel ween oor haar kinders; sy weier om getroos te word oor haar kinders, omdat hulle daar nie is nie. [JirmeJaH 31:15]	",
		
		
		
"	19 EN ná die dood van Herodes het daar ’n Boodskapper van Elohim in ’n droom aan JôWsef in Egipte verskyn	",
"	20 en gesê: Staan op, neem die Kindjie en Sy moeder, en gaan na die Aarde van JisraEl; want hulle is dood wat die siel van die Kindjie gesoek het.	",
"	21 En hy het opgestaan, die Kindjie en Sy moeder geneem en in die Aarde van JisraEl gekom.	",
"	22 Maar toe hy hoor dat Archeláüs oor JeHûWdah koning was in die plek van sy vader Herodes, was hy bevrees om daarheen te gaan. En hy het ’n waarskuwing in ’n droom ontvang en na die streke van Galiléa teruggekeer.	",
"	23 En hy het gaan woon in ’n stad met die naam van Násaret, sodat vervul sou word wat deur die Profete gespreek is, dat Hy Nasaréner [of “netzer” wat loot beteken] genoem sou word. [JeshaJaH 11:1]	",

]
},
{
book: 'Mattithjahûw',
chapter: '3',
content: [
		
"	1 IN daardie dae het JeHôWganan die Wasser opgetree en in die wildernis van JeHûWdah verkondig en gesê:	",
"	2 Bekeer julle, want die Koninkryk van die Hemele het naby gekom.	",
"	3 Want dit is hy van wie deur die Profeet JeshaJaHûW gespreek is toe hy gesê het: Die stem van een wat roep in die wildernis: Maak gelyk in die woestyn ’n grootpad [vir onse Elohey]! [JeshaJaH 40:3]	",
"	4 En hy, JeHôWganan, het ’n kleed gedra van kameelhare en ’n leergord om sy heupe, en sy voedsel was sprinkane en wilde heuning.	",
"	5 En Jerusalem en die hele JeHûWdah en die hele omtrek van die Jordaan het uitgegaan na hom toe.	",
"	6 En hulle is deur hom in die Jordaan gewas/gedoop met belydenis van hulle oortredinge.	",
"	7 Maar toe hy baie van die Fariseërs en Sadduseërs na sy wassing/doopseremonie sien kom, sê hy vir hulle: Genetiese nageslag van Nagash/slang, wie het julle aangewys om te vlug vir die Toorn wat aan kom is?	",
"	8 Dra dan vrugte wat by die bekering pas.	",
"	9 En moenie dink om by julleself te sê: ons het Abraham as vader nie; want ek sê vir julle dat Elohim mag het om uit hierdie klippe kinders vir Abraham op te wek.	",
"	10 Maar die byl lê ook al teen die wortel van die bome. Elke Boom wat geen suiwer vrugte dra nie, word uitgekap en in die vuur gegooi.	",
"	11 Ek was/doop julle wel in water tot bekering; maar Hy wat ná my kom, is sterker as ek, Wie se skoene ek nie waardig is om aan te dra nie. Hy sal julle was/doop met die Gees van die Apartheid en met Vuur.	",
"	12 Sy skop is in Sy Hand, en Hy sal Sy dorsvloer deur en deur skoonmaak en Sy koring in die skuur saambring, maar die kaf sal Hy met onuitbluslike vuur verbrand. [Thomas 12:1]	",
		
		
"	13 TOE het JaHWèshua van Galiléa na die Jordaan, na JeHôWganan gekom om deur hom gewas/gedoop te word. [Levítikus 16:26]	",
"	14 Maar JeHôWganan het Hom ernstig teëgegaan en gesê: Ek het nodig om deur U gewas/gedoop te word, en kom U na my toe?	",
"	15 Maar JaHWèshua het geantwoord en vir hom gesê: Laat dit nou toe, dit kom Ons toe om alle Geregtigheid te vervul. Daarna het hy Hom toegelaat. [JeHôWganan 4:10]	",
"	16 En nadat hy JaHWèshua gewas/gedoop het, het Hy dadelik uit die water opgeklim, en meteens gaan die Hemele vir Hom oop, en Hy sien die Gees van Elohim soos ’n duif neerdaal en op Hom kom.	",
"	17 En daar kom ’n Stem uit die Hemele wat sê: DIT IS MY GELIEFDE SEUN IN WIE EK ‘N WELBEHAE HET. [Odes van Salomo 24:1-2; Profeet Miga 6:7]	",
	
]
},
{
book: 'Mattithjahûw',
chapter: '4',
content: [
		
"	1 TOE is JaHWèshua deur die Gees weggelei die wildernis in om versoek te word deur die Satan. [Levítikus 16:26]	",
"	2 En nadat Hy veertig dae en veertig nagte gevas het, het Hy naderhand honger geword.	",
"	3 En die versoeker het na Hom gekom en gesê: As U die Seun van die Elohim is, sê dat hierdie klippe brode word.	",
"	4 Maar Hy antwoord en sê: Daar is geskrywe: dat die adamiet nie van brood alleen lewe nie, maar dat die adamiet lewe van alles wat uit die Mond van JaHWeH uitgaan. [Deuteronómium 8:3]	",
"	5 Toe neem die Satan Hom saam na die Stad van die Apartheid en laat Hom op die dak van die Tempel staan	",
"	6 en sê vir Hom: As U die Seun van die Elohim is, werp Uself af; want daar is geskrywe: want Hy sal Sy Boodskappers aangaande U bevel gee om U te bewaar op al U Weë. Hulle sal U op die handpalms dra, sodat U U voet teen geen klip stamp nie. [Psalm 91:11,12]	",
"	7 JaHWèshua sê vir hom: Daar is óók geskrywe: Julle mag JaHWeH julle Elohey nie versoek [soos julle Hom by Massa versoek het] nie. [Deuteronómium 6:16]	",
"	8 Weer neem die Satan Hom saam na ’n baie hoë berg en wys Hom al die koninkryke van die wêreld en hulle glorie,	",
"	9 en sê vir Hom: Al hierdie dinge sal ek aan U gee as U neerval en my vereer.	",
"	10 Toe sê JaHWèshua vir hom: Gaan weg, Satan! want daar is geskrywe: Jy moet JaHWeH jou Elohey vrees en Hom dien; en by Sy Naam moet jy sweer. [Deuteronómium 6:13, 10:20]	",
"	11 Daarna het die Satan Hom laat staan, en daar het Boodskappers gekom en Hom gedien.	",
		
		
"	12 EN toe JaHWèshua hoor dat JeHôWganan in die gevangenis gesit was, het Hy na Galiléa teruggegaan.	",
"	13 En Hy het Násaret verlaat en gaan woon in Kapérnaüm aan die see, in die gebied van Sébulon en Náftali,	",
"	14 sodat vervul sou word wat gespreek is deur JeshaJaHûW, die Profeet, toe hy gesê het:	",
"	15 [In die eerste tyd het Hy] die Aarde van Sébulon en die Aarde van Naftáli in veragting gebring, en in die laaste tyd bring Hy tot eer die Weg na die see, die oorkant van die Jordaan, die streek van die nasies. [JeshaJaH 9:1]	",
"	16 DIE volk wat in Duisternis wandel, het ‘n groot Lig gesien; die wat woon in die Aarde van die doodskaduwee, oor hulle het ‘n Lig geskyn. [JeshaJaH 9:2]	",
"	17 Van toe af het JaHWèshua begin om te verkondig en te sê: Bekeer julle, want die Koninkryk van die Hemele het naby gekom.	",
"	18 En terwyl JaHWèshua langs die see van Galiléa loop, sien Hy twee broers, Simon wat genoem word Petrus, en Andréas, sy broer, besig om ’n net in die see uit te gooi; want hulle was vissers.	",
"	19 En Hy sê vir hulle: Kom agter My aan, en Ek sal julle vissers van adamiete maak.	",
"	20 En hulle het dadelik die nette laat staan en Hom gevolg.	",
"	21 En toe Hy daarvandaan verder gaan, sien Hy twee ander broers, Jakobus, die seun van Sebedéüs, en JeHôWganan, sy broer, in die skuit saam met hulle vader Sebedéüs, besig om hulle nette heel te maak; en Hy het hulle geroep.	",
"	22 En hulle het dadelik die skuit en hulle vader verlaat en Hom gevolg.	",
"	23 En JaHWèshua het deur die hele Galiléa rondgegaan en in hulle vergaderings geleer en die goeie tyding van die Koninkryk verkondig en elke siekte en elke kwaal onder die volk genees. [Exodus 15:26]	",
"	24 En die gerug aangaande Hom is versprei oor die hele Sírië; en hulle het na Hom gebring almal wat ongesteld was, wat gekwel was deur allerhande siektes en pyne en wat van demone besete was, en maansiekes en verlamdes; en Hy het hulle gesond gemaak.	",
"	25 En groot menigtes het Hom gevolg van Galiléa en Dekápolis en Jerusalem en JeHûWdah en van oorkant die Jordaan af.	",
		

]
},
{
book: 'Mattithjahûw',
chapter: '5',
content: [
		
"	1 EN toe Hy die skare sien, het Hy op die berg geklim; en nadat Hy gaan sit het, het Sy studente na Hom gekom;	",
"	2 en Hy het Sy mond geopen en hulle geleer en gesê:	",
"	3 Geseënd is die wat bedelaars van die Gees is, want aan hulle behoort die Koninkryk van die Hemele.[Prediker 1:17]	",
"	4 Geseënd is die wat treur, want hulle sal vertroos word.	",
"	5 Geseënd is die sagmoediges, want hulle sal die Aarde beërwe.	",
"	6 Geseënd is die wat honger en dors na die Geregtigheid, want hulle sal versadig word.	",
"	7 Geseënd is die barmhartiges, want aan hulle sal Barmhartigheid bewys word.	",
"	8 Geseënd is die wat suiwer van hart is, want hulle sal Elohim in verwondering sien.	",
"	9 Geseënd is die vredemakers, want hulle sal kinders van Elohim genoem word.	",
"	10 Geseënd is die wat vervolg word ter wille van die Geregtigheid, want aan hulle behoort die Koninkryk van die Hemele.	",
"	11 Geseënd is julle wanneer die mense julle beledig en vervolg en valslik allerhande besoedeling teen julle spreek om My ontwil. [Openbaring van Henog 13:85]	",
"	12 Verbly en verheug julle omdat julle loon groot is in die Hemele; want so het hulle die Profete vervolg wat voor julle gewees het. [Openbaring van Henog 13:45]	",
		
		
"	13 JULLE is die sout van die Aarde, maar as die sout laf geword het, waarmee sal sy gesout word? Sy deug nêrens meer voor as om buite gegooi en deur die mense vertrap te word nie. [Levítikus 2:11-13; Númeri 18:19; 2 Konings 2:20; 2 Kronieke 13:5; Markus 9:50]	",
"	14 Julle is die lig van die wêreld. ’n Stad wat bo-op ’n berg lê, kan nie weggesteek word nie;	",
"	15 en ’n mens steek ook nie ’n lamp op en sit hom onder die maatemmer nie, maar op die staander, en hy skyn vir almal wat in die huis is.	",
"	16 Laat julle lig só skyn voor die mense, dat hulle julle suiwer werke kan sien en julle Vader wat in die Hemele is, verhoog.	",
		
		
"	17 MOENIE dink dat Ek gekom het om die Wet of die Profete te ontbind nie. Ek het nie gekom om te ontbind nie, maar om te vervul.	",
"	18 Want voorwaar Ek sê vir julle, voordat die Hemele en die Aarde verbygaan, sal nie een jod[y]1 of een tittel[.] van die Wet ooit verbygaan totdat alles gebeur het nie. [Odes van Salomo 23:19]	",
"	19 Elkeen dus wat een van die minste van hierdie Gebooie breek en die adamiete só leer, sal die minste genoem word in die Koninkryk van die Hemele; maar elkeen wat haar doen en leer, hy sal groot genoem word in die Koninkryk van die Hemele.	",
"	20 Want Ek sê vir julle dat, as julle geregtigheid nie oorvloediger is as die van die skrywers en Fariseërs nie, julle nooit in die Koninkryk van die Hemele sal ingaan nie.	",
"	21 Julle het gehoor dat aan die adamiete van die ou tyd gesê is: Jy mag nie doodslaan nie, maar elkeen wat doodslaan, moet verantwoording doen voor die gereg.	",
"	22 Maar Ek sê vir julle dat elkeen wat vir sy broeder sonder rede kwaad is, verantwoording moet doen voor die Gereg; en elkeen wat vir sy broeder sê: Domkop! moet verantwoording doen voor die GROOT RAAD; en elkeen wat sê: Jou dwaas! moet verantwoording doen in die helse vuur.	",
"	23 As jy dan jou bydrae na die altaar bring en dit jou daar byval dat jou broeder iets teen jou het,	",
"	24 laat jou bydrae daar voor die altaar bly en gaan versoen jou eers met jou broeder, en kom dan en bring jou bydrae.	",
"	25 Wees gou goedgesind teenoor jou teëparty so lank as jy nog saam met hom op die pad is, sodat die teëparty jou nie miskien oorgee aan die Regter en die Regter jou oorgee aan die Geregsdienaar en jy in die Gevangenis gewerp word nie. [JeségiEl 9:1 ; Ode van Salomo 33:11]	",
"	26 Voorwaar Ek sê vir jou, jy sal daar sekerlik nie uitkom voordat jy die laaste oortjie betaal het nie.	",
"	27 Julle het gehoor dat aan die adamiete van die ou tyd gesê is: Jy mag nie vermeng nie. [Exodus 20:14, Deuteronómium 5:18]	",
"	28 Maar Ek sê vir julle dat elkeen wat na ’n vrou kyk om haar te begeer, reeds in sy hart met haar vermeng het.	",
"	29 As jou regteroog jou dan laat struikel, ruk haar uit en gooi haar weg van jou af; want dit is vir jou beter dat een van jou lede vergaan en nie jou hele liggaam in die hel gewerp word nie.	",
"	30 En as jou regterhand jou laat struikel, kap haar af en gooi haar weg van jou af; want dit is vir jou beter dat een van jou lede vergaan en nie jou hele liggaam in die hel gewerp word nie.	",
"	31 Daar is ook gesê: Elkeen wat van sy vrou skei, moet haar ’n brief van skeiding gee. [Deuteronómium 24:1]	",
"	32 Maar Ek sê vir julle dat elkeen wat van sy vrou skei, behalwe omrede van verbastering, maak dat sy vermeng, en elkeen wat die geskeie vrou trou, vermeng.	",
"	33 Verder het julle gehoor dat aan die adamiete van die ou tyd gesê is: Jy mag nie vals sweer nie, maar jy moet jou eed aan JaHWeH hou. [Númeri 30:2]	",
"	34 Maar Ek sê vir julle: Sweer hoegenaamd nie - nie by die Hemele nie, omdat hy die Troon van Elohim is;	",
"	35 ook nie by die Aarde nie, omdat sy die Voetbank van Sy voete is; ook nie by Jerusalem nie, omdat Sy die Stad is van die groot Koning; [1 Kronieke 28:2; JeshaJaH 66:1; Handelinge 7:49]	",
"	36 ook by jou hoof mag jy nie sweer nie, omdat jy nie een haar wit of swart kan maak nie.	",
"	37 Maar laat julle woord wees: Ja ja, nee nee. Wat meer as dit is, is uit die Besoedeling.	",
"	38 Julle het gehoor dat daar gesê is: Oog vir oog en tand vir tand. [Levítikus 24:19, 20, Deuteronómium 19:21]	",
"	39 Maar Ek sê vir julle dat julle ’n besoedelde adamiet nie moet weerstaan nie; maar as iemand jou op jou regterwang slaan, draai ook die ander een na hom toe.	",
"	40 En hy wat met jou na die gereg wil gaan en jou onderkleed wil neem, laat hom ook die bo-kleed kry.	",
"	41 En elkeen wat van jou een myl afdwing, loop met hom twee myl saam.	",
"	42 Gee aan hom wat jou iets vra, en wys hom nie af wat van jou wil leen nie.	",
"	43 Julle het gehoor dat daar gesê is: Jy moet jou volksgenote liefhê en jou teëstander moet jy haat.	",
"	44 Maar Ek sê vir julle: Julle moet jul teëstanders liefhê; seën die wat vir julle vervloek, doen goed aan die wat vir julle haat, en bid vir die wat julle beledig en julle vervolg; [Wysheid van Sirah 28:1]	",
"	45 sodat julle kinders kan word van julle Vader wat in die Hemele is; want Hy laat Sy son opgaan oor besoedeldes en suiweres, en Hy laat reën op regverdiges en onregverdiges.	",
"	46 Want as julle liefhet die wat vir julle liefhet, watter loon het julle? Doen die tollenaars nie ook dieselfde nie?	",
"	47 En as julle net jul vriende groet, wat besonders doen julle dan? Doen die tollenaars nie ook so nie?	",
"	48 Wees julle dan volmaak soos julle Vader in die Hemele volmaak is.	",

]
},
{
book: 'Mattithjahûw',
chapter: '6',
content: [
	
"	1 PAS OP dat julle nie jul liefdadigheid voor die adamiete bewys om deur hulle gesien te word nie; anders het julle geen loon by julle Vader wat in die Hemele is nie.	",
"	2 Wanneer jy dan liefdadigheid bewys, moenie ’n trompet voor jou blaas soos die tweegesigte in die vergaderings en op die strate doen, dat hulle deur die adamiete geëer kan word nie. Voorwaar Ek sê vir julle, hulle het hul loon weg.	",
"	3 Maar jy, as jy liefdadigheid bewys, laat jou linkerhand nie weet wat jou regterhand doen nie,	",
"	4 sodat jou liefdadigheid in die verborgene kan wees; en jou Vader wat in die verborgene sien, Hy sal jou in die openbaar vergelde.	",
"	5 En wanneer julle aanbid, moet jy nie wees soos die tweegesigte nie; want hulle hou daarvan om in die vergaderings en op die hoeke van die strate te staan en bid, om deur die adamiete gesien te word. Voorwaar Ek sê vir julle dat hulle hul loon weg het.	",
"	6 Maar julle, wanneer julle bid, gaan in jou binnekamer, sluit jou deur en bid jou Vader wat in die verborgene is; en julle Vader wat in die verborgene sien, sal jou in die openbaar vergelde.	",
"	7 En as julle bid, gebruik nie ’n ydele herhaling van woorde soos die inboorlinge nie, want hulle dink dat hulle deur hul baie woorde verhoor sal word.	",
"	8 Moet dan nie soos hulle word nie, want jul Vader weet wat julle nodig het voordat julle Hom vra.	",
"	9 Só moet julle dan bid: Onse VADER wat in die Hemele is, laat U Naam apart gestel word;	",
"	10 laat U Koninkryk kom; laat U wil geskied, soos in die Hemele net so ook op die Aarde;	",
"	11 gee ons vandag ons daaglikse Brood;	",
"	12 en vergeef ons ons skulde, soos ons ook ons skuldenaars vergewe;	",
"	13 en lei ons: Nie in versoeking nie, maar verlos ons van die besoedeling. Want aan U behoort die Koninkryk en die Krag en die Glansrykheid tot in ewigheid. Amein.	",
"	14 Want as julle die adamiete hulle oortredinge vergewe, sal julle Hemelse Vader julle ook vergewe.	",
"	15 Maar as julle die adamiete hulle oortredinge nie vergewe nie, sal julle Vader julle oortredinge ook nie vergewe nie.	",
"	16 En wanneer julle vas, moenie lang gesigte trek soos die tweegesigte nie; want hulle mismaak hul gesigte, sodat dit deur die adamiete gesien kan word dat hulle vas. Voorwaar Ek sê vir julle, hulle het hul loon weg.	",
"	17 Maar jy? as jy vas, salf jou hoof en was jou gesig,	",
"	18 sodat jy nie die adamiete laat sien dat jy vas nie, maar jou Vader wat in die verborgene is; en jou Vader wat in die verborgene sien, sal jou in die openbaar vergelde.	",
		
		
"	19 MOENIE vir julle skatte bymekaarmaak op die Aarde, waar mot en roes verniel en waar diewe inbreek en steel nie;	",
"	20 maar maak vir julle skatte bymekaar in die Hemele, waar geen mot of roes verniel nie en waar diewe nie inbreek en steel nie;	",
"	21 want waar julle skat is, daar sal julle hart ook wees.	",
"	22 Die lamp van die liggaam is die oog. As jou oog dan suiwer is, sal jou hele liggaam verlig wees.	",
"	23 Maar as jou oog besoedel is, sal jou hele liggaam donker wees. As dan die lig in jou donkerheid is, hoe groot is die donkerheid nie!	",
"	24 Niemand kan twee meesters dien nie; want òf hy sal die een haat en die ander liefhê, òf hy sal die een aanhang en die ander verag. Julle kan nie die Elohim én Mammon dien nie!	",
"	25 Daarom sê Ek vir julle: Moenie julle kwel oor jul siel - wat julle sal eet en wat julle sal drink nie; of oor jul liggaam - wat julle sal aantrek nie. Is die siel nie meer as die voedsel en die liggaam as die klere nie?	",
"	26 Kyk na die voëls van die Hemele; hulle saai nie en hulle maai nie en hulle bring nie bymekaar in skure nie, en tog voed julle Hemelse Vader hulle. Is julle nie baie meer werd as hulle nie?	",
"	27 Wie tog onder julle kan, deur hom te kwel, een voorarm by sy lengte voeg?	",
"	28 En wat kwel julle jul oor klere? Let op die lelies van die veld, hoe hulle groei; hulle arbei nie en hulle spin nie;	",
"	29 en Ek sê vir julle dat selfs Salomo in al sy glansrykheid nie bekleed was soos een van hulle nie.	",
"	30 As Elohim dan die gras van die veld, wat vandag daar is en môre in ’n oond gegooi word, so beklee, hoeveel te meer vir julle, kleingelowiges?	",
"	31 Daarom moet julle jul nie kwel en sê: Wat sal ons eet, of wat sal ons drink, of wat sal ons aantrek nie?	",
"	32 Want na al hierdie dinge soek die nasies; want julle Hemelse Vader weet dat julle al hierdie dinge nodig het.	",
"	33 Maar soek eers die Koninkryk van Elohim en Sy Geregtigheid, en al hierdie dinge sal vir julle bygevoeg word.	",
"	34 Kwel julle dus nie oor môre nie, want môre sal hom oor sy eie dinge kwel. Elke dag het genoeg aan sy eie besoedeling.	",

]
},
{
book: 'Mattithjahûw',
chapter: '7',
content: [

"	1 MOENIE oordeel nie, sodat julle nie geoordeel word nie.	",
"	2 Want met die oordeel waarmee julle oordeel, sal julle geoordeel word; en met die maat waarmee julle meet, sal weer vir julle gemeet word.	",
"	3 En waarom sien jy die splinter in die oog van jou broeder, maar die balk in jou eie oog merk jy nie op nie?	",
"	4 Of hoe sal jy vir jou broeder sê: Laat my toe om die splinter uit jou oog uit te haal, en kyk, in jou eie oog is die balk!	",
"	5 Tweegesig, haal eers die balk uit jou oog uit, en dan sal jy goed sien om die splinter uit die oog van jou broeder uit te haal.	",
"	6 Moenie wat van die Apartheid is, aan die honde gee nie; en gooi julle pêrels nie voor die varke nie, sodat hulle dit nie miskien met hulle pote vertrap en omdraai en julle verskeur nie. [Spreuke 5:15 - 17]	",
"	7 Vra, en vir julle sal gegee word; soek, en julle sal vind; klop, en vir julle sal oopgemaak word.	",
"	8 Want elkeen wat vra, ontvang; en hy wat soek, vind; en vir hom wat klop, sal oopgemaak word.	",
"	9 Of watter adamiet is daar onder julle wat, as sy seun hom brood vra, aan hom ’n klip sal gee;	",
"	10 en as hy ’n vis vra, aan hom ’n slang sal gee?	",
"	11 As julle wat besoedel is, dan weet om suiwer gawes aan julle kinders te gee, hoeveel te meer sal julle Vader wat in die Hemele is, suiwer dinge gee aan die wat Hom vra!	",
"	12 Alles wat julle dan wil hê dat die adamiete aan julle moet doen, net so moet julle aan hulle ook doen; want sy is die Wet en die Profete.	",
"	13 Gaan in deur die nou Poort, want breed is die poort en wyd is die pad wat na die verderf lei, en daar is baie wat deur hom ingaan.	",
"	14 Want die Poort is nou en die pad is smal wat na die lewe lei, en daar is min wat hom vind.	",
"	15 Maar pas op vir die valse profete wat in skaapsklere na julle kom en van binne roofsugtige wolwe is.	",
"	16 Aan hulle vrugte sal julle hulle ken. ’n Mens pluk tog nie druiwe van dorings of vye van distels nie!	",
"	17 So dra elke egte boom suiwer vrugte; maar ’n verbasterde boom dra besoedelde vrugte.	",
"	18 ’n Egte boom kan geen besoedelde vrugte dra nie, en ’n verbasterde boom ook geen suiwer vrugte nie.	",
"	19 Elke boom wat nie suiwer vrugte dra nie, word uitgekap en in die vuur gegooi.	",
"	20 So sal julle hulle dan aan hul vrugte ken.	",
"	21 Nie elkeen wat vir My sê: Meester, Meester! sal ingaan in die Koninkryk van die Hemele nie, maar hy wat die Wil doen van My VADER wat in die Hemele is.	",
"	22 Baie sal in daardie dag vir My sê: Meester, Meester, het ons nie in U Naam geprofeteer en in U Naam demone uitgedrywe en in U Naam baie kragte gedoen nie?	",
"	23 En dan sal Ek aan hulle sê: Ek het julle nooit geken nie. Gaan weg van My, julle wat die Ongeregtigheid bedryf!	",
"	24 Elkeen dan wat na hierdie Woorde van My luister en dit doen, hom sal Ek vergelyk met ’n verstandige Man wat Sy Huis op die Rots gebou het.	",
"	25 En die reën het geval en die waterstrome het gekom en die winde het gewaai en teen daardie Huis aangestorm, en Hy het nie geval nie, want Sy fondament was op die Rots. [Deuteronómium 32:4; Psalm 94:22]	",
"	26 En elkeen wat na hierdie Woorde van My luister en dit nie doen nie, sal vergelyk word met ’n dwase man wat sy huis op die sand gebou het. [Génesis 32:12]	",
"	27 En die reën het geval en die waterstrome het gekom en die winde het gewaai en teen daardie huis aangestorm en hy het geval, en sy val was groot.	",
"	28 En toe JaHWèshua hierdie woorde geëindig het, was die skare verslae oor Sy leer;	",
"	29 want Hy het hulle geleer soos een wat gesag het, en nie soos die skrywers nie.	",

]
},
{
book: 'Mattithjahûw',
chapter: '8',
content: [
		
"	1 EN toe Hy van die berg afkom, het groot menigtes Hom gevolg;	",
"	2 en daar het ’n melaatse man gekom en voor Hom neergeval en gesê: Meester, as U wil en U die mag het om te suiwer, kan U my suiwer maak.	",
"	3 Daarop steek JaHWèshua die hand uit en raak hom aan en sê: Ek wil; word gesuiwer! En dadelik is hy van sy melaatsheid gesuiwer.	",
"	4 En JaHWèshua sê vir hom: Pas op dat jy dit aan niemand vertel nie, maar gaan vertoon jou aan die priester en bring nader die bydrae wat Moshè voorgeskrywe het, tot ’n getuienis vir hulle.	",
		
		
"	5 EN nadat JaHWèshua in Kapérnaüm ingegaan het, kom daar ’n hoofman oor honderd na Hom toe en smeek Hom	",
"	6 en sê: Meester, my kneg lê tuis verlam en hy ly hewige pyne.	",
"	7 Daarop sê JaHWèshua vir hom: Ek sal kom en hom gesond maak.	",
"	8 En die hoofman oor honderd antwoord en sê: Meester, ek is nie werd dat U onder my dak inkom nie; maar spreek net ’n woord, en my kneg sal gesond word.	",
"	9 Want ek is ook ’n man onder gesag, en ek het soldate onder my. En vir hierdie een sê ek: Gaan! en hy gaan; en vir ’n ander een: Kom! en hy kom; en vir my dienskneg: Doen dit! en hy doen dit.	",
"	10 Toe JaHWèshua dit hoor, het Hy Hom verwonder en aan sy volgelinge gesê: Voorwaar Ek sê vir julle, selfs in JisraEl het Ek so ’n groot Geloof nie gevind nie.	",
"	11 Maar Ek sê vir julle dat baie sal kom van ooste en weste en saam met Abraham en Isak en Jakob sal aansit in die Koninkryk van die Hemele.	",
"	12 Maar die seuns van die Koninkryk sal uitgedryf word in die buitenste Duisternis. Daar sal geween wees en gekners van die tande.	",
"	13 Toe sê JaHWèshua vir die hoofman oor honderd: Gaan, en laat dit vir jou wees soos jy geglo het. En sy kneg het gesond geword in daardie uur.	",
		
		
"	14 EN toe JaHWèshua in die huis van Petrus kom, sien Hy sy skoonmoeder siek lê aan die koors.	",
"	15 En Hy het haar hand aangeraak, en die koors het haar verlaat, en sy het opgestaan en hulle bedien.	",
"	16 En toe dit aand geword het, het hulle baie na Hom gebring, wat van demone besete was; en Hy het die geeste met ’n woord uitgedrywe; en almal wat ongesteld was, het Hy gesond gemaak,	",
"	17 sodat vervul sou word wat gespreek is deur JeshaJaHûW, die Profeet, toe hy gesê het: Hy het ons krankhede op Hom geneem en ons smarte gedra. [JeshaJaH 53:4]	",
		
		
"	18 EN toe JaHWèshua groot menigtes rondom Hom sien, het Hy bevel gegee om te vertrek na die oorkant.	",
"	19 En ’n sekere skrywer het gekom en vir Hom gesê: Meester, ek sal U volg waar U ook al mag gaan.	",
"	20 En JaHWèshua sê vir hom: Die jakkalse het gate en die voëls van die Hemele neste, maar die Seun van die Adam het geen plek waar Hy Sy hoof kan neerlê nie.	",
"	21 En ’n ander een van Sy studente het vir Hom gesê: Meester, laat my toe om eers te gaan en my vader te begrawe.	",
"	22 Maar JaHWèshua sê vir hom: VOLG MY, en laat die dooies hul eie dooies begrawe.	",
		
		
"	23 EN toe Hy in die skuit klim, het Sy studente Hom gevolg. [Boekrol van die Opregte 6:31-32]	",
"	24 En daar het ’n groot storm op die see gekom, sodat die skuit toe was onder die golwe; maar Hy was aan die slaap.	",
"	25 Daarop kom Sy studente en maak Hom wakker en sê: Meester, red ons, ons vergaan!	",
"	26 En Hy sê vir hulle: Waarom is julle bang, kleingelowiges? Toe staan Hy op en bestraf die winde en die see, en daar het ’n groot stilte gekom.	",
"	27 En die manne het hulle verwonder en gesê: Wat vir ’n Adamiet is Hy, dat selfs die winde en die see Hom gehoorsaam is?	",
		
		
"	28 EN toe Hy aan die oorkant kom, in die Aarde van die Gergeséners, het twee wat van Satan besete was Hom ontmoet, wat uit die grafte uitgekom het en baie kwaai was, sodat niemand met daardie pad kon verbygaan nie.	",
"	29 En meteens skreeu hulle en sê: Wat het ons met U te doen, JaHWèshua, Seun van die Elohim? Het U hier gekom om ons voor die tyd te pynig?	",
"	30 En ver van hulle af het ’n groot trop varke gewei.	",
"	31 En die geeste van besoedeling het Hom gesmeek en gesê: As U ons uitdryf, laat ons toe om in die trop varke te vaar.	",
"	32 En Hy sê vir hulle: Gaan! Toe gaan hulle uit en vaar in die trop varke in; en daar storm die hele trop varke van die krans af die see in en kom in die water om.	",
"	33 En die wagters het gevlug; en toe hulle in die stad kom, het hulle alles vertel, ook wat met die besetenes gebeur het.	",
"	34 En kyk, die hele stad het uitgekom, JaHWèshua tegemoet; en toe hulle Hom sien, smeek hulle dat Hy uit hulle gebied moet weggaan.	",
		
		

]
},
{
book: 'Mattithjahûw',
chapter: '9',
content: [

"	1 EN nadat Hy in die skuit geklim het, het Hy oorgevaar en in Sy eie stad gekom.	",
"	2 En hulle het ’n verlamde man wat op ’n bed lê, na Hom gebring. En toe JaHWèshua hulle geloof sien, sê Hy aan die verlamde: Seun, hou goeie moed, jou oortredinge is jou vergewe.	",
"	3 En sommige van die skrywers het by hulleself gesê: Hierdie man praat lasterlik.	",
"	4 En toe JaHWèshua merk wat hulle gedagtes was, sê Hy: Waarom bedink julle besoedelde dinge in julle harte?	",
"	5 Want wat is makliker, om te sê: Jou oortredinge is jou vergewe, of om te sê: Staan op en loop?	",
"	6 Maar dat julle kan weet dat die Seun van die Adam mag het om op Aarde oortredinge te vergewe - toe sê Hy vir die verlamde man: Staan op, neem jou bed op en gaan na jou huis toe.	",
"	7 En hy het opgestaan en huis toe gegaan.	",
"	8 En toe die skare dit sien, was hulle verwonderd en het Elohim vereer wat so ’n mag aan die adamiete gegee het.	",
		
"	9 EN toe JaHWèshua daarvandaan verder gaan, sien Hy ’n man met die naam van MattithJaHûW by die tolhuis sit; en Hy sê vir hom: VOLG MY. En hy het opgestaan en Hom gevolg.	",
"	10 En terwyl Hy in die huis aan tafel was, het daar baie tollenaars en oortreders saam met JaHWèshua en Sy studente aan tafel gegaan.	",
"	11 En toe die Fariseërs dit sien, sê hulle vir Sy studente: Waarom eet julle Meester saam met tollenaars en oortreders?	",
"	12 Maar toe JaHWèshua dit hoor, sê Hy vir hulle: Die wat gesond is, het die geneesheer nie nodig nie, maar die wat ongesteld is.	",
"	13 Maar gaan leer wat dit beteken: Ek wil Medelye hê en nie in ‘n slagdier nie; want Ek het nie gekom om regverdiges te roep nie, maar die oortreders tot bekering. [Hoséa 6:6]	",
		
		
"	14 DAARNA kom die studente van JeHôWganan na Hom en sê: Waarom vas ons en die Fariseërs dikwels, maar U studente vas nie?	",
"	15 En JaHWèshua sê vir hulle: Kan die seuns wat die Bruidskamer voorberei dan treur so lank as die Bruidegom by hulle is? Maar daar sal dae kom wanneer die Bruidegom van hulle weggeneem word, en dan sal hulle vas.	",
"	16 En niemand sit ’n nuwe stuk lap op ’n ou kleed nie; want die aangelapte stuk skeur van die kleed af en daar kom ’n erger skeur.	",
"	17 ’n Mens gooi ook nie nuwe wyn in ou leersakke nie; anders bars die sakke en die wyn loop uit en die sakke vergaan. Maar ’n mens gooi nuwe wyn in nuwe sakke en altwee bly behoue.	",
		
		
"	18 TERWYL Hy vir hulle dit sê, kom daar ’n sekere owerste en val voor Hom neer en sê: My dogter het nou net gesterwe, maar kom en lê U hand op haar, en sy sal lewe.	",
"	19 En JaHWèshua het opgestaan en hom gevolg, en ook Sy studente.	",
"	20 En daar het ’n vrou wat twaalf jaar lank aan bloedvloeiing gely het, van agter gekom en die soom van Sy kleed aangeraak.	",
"	21 Want sy het by haarself gesê: As ek maar net Sy kleed kan aanraak, sal ek gesond word.	",
"	22 En JaHWèshua het omgedraai en haar gesien en gesê: Hou goeie moed, dogter, jou Geloof het jou gered. En die vrou het gesond geword van daardie uur af.	",
"	23 En toe JaHWèshua in die huis van die owerste kom en die fluitspelers sien, en die skare wat te kere gaan,	",
"	24 sê Hy vir hulle: Gaan weg, want die dogtertjie is nie dood nie, maar sy slaap. En hulle het Hom uitgelag.	",
"	25 En nadat die skare uitgedryf was, het Hy ingegaan en haar hand gegryp; en die dogtertjie het opgestaan.	",
"	26 En die gerug hiervan het deur daardie deel van die Aarde versprei.	",
		
		
"	27 EN toe JaHWèshua daarvandaan verder gaan, het twee blindes Hom gevolg, terwyl hulle uitroep en sê: Wees ons barmhartig, Seun van Dawid!	",
"	28 En nadat Hy in die huis gegaan het, kom die blindes na Hom toe. En JaHWèshua sê vir hulle: Glo julle dat Ek dit kan doen? Hulle antwoord Hom: Ja, Meester.	",
"	29 Toe raak Hy hulle oë aan en sê: Laat dit vir julle wees volgens julle geloof.	",
"	30 En hulle oë het oopgegaan. En JaHWèshua het hulle skerp aangespreek en gesê: Pas op, laat niemand dit te wete kom nie.	",
"	31 Maar hulle het heengegaan en Hom in daardie deel van die Aarde bekend gemaak.	",
"	32 En terwyl hulle weggaan, bring die adamiete ’n stom man wat van die demoon besete was, na Hom toe.	",
"	33 En nadat die demoon uitgedryf was, het die stomme gepraat. En die skare het hulle verwonder en gesê: So iets is nog nooit in JisraEl gesien nie!	",
"	34 Maar die Fariseërs het gesê: Deur die prins van die demone dryf Hy die demone uit.	",
		
		
"	35 EN JaHWèshua het by al die stede en dorpe rondgegaan en in hulle vergaderings geleer en die goeie tyding van die Koninkryk verkondig en elke siekte en elke kwaal onder die volk genees.	",
"	36 En toe Hy die skare sien, het Hy innig jammer gevoel vir hulle, omdat hulle moeg en uitgeput was, soos skape wat geen herder het nie. [JeségiEl 34:6]	",
"	37 Toe sê Hy vir Sy studente: Die oes is wel groot, maar die arbeiders min. [Spreuke 10:5]	",
"	38 Smeek dan die Meester van die oes, dat Hy arbeiders in Sy oes mag uitstuur.	",

]
},
{
book: 'Mattithjahûw',
chapter: '10',
content: [
		
"	1 EN Hy het Sy twaalf studente na Hom geroep en aan hulle mag gegee oor geeste van besoedeling, om hulle uit te dryf en om elke siekte en elke kwaal te genees.	",
"	2 En dit is die name van die twaalf Apostels: die eerste Simon wat Petrus genoem word, en Andréas, sy broer; Jakobus, die seun van Sebedéüs, en JeHôWganan, sy broer;	",
"	3 Filippus en Bartholoméüs; Thomas en MattithJaHûW, die tollenaar; Jakobus, die seun van Alféüs, en Lebbéüs wat genoem word Thaddéüs;	",
"	4 Simon Kananítes en Judas Iskáriot, die een wat Hom verraai het.	",
"	5 JaHWèshua het hierdie twaalf uitgestuur en hulle bevel gegee en gesê: Moenie gaan op die weg van die nasies nie, en moenie ingaan in ’n stad van die Samaritane nie;	",
"	6 maar gaan veel eerder na die verlore skape van die huis van JisraEl.	",
"	7 En gaan verkondig en sê: Die Koninkryk van die Hemele het naby gekom.	",
"	8 Maak siekes gesond, suiwer melaatses, wek dooies op, dryf demone uit. Julle het dit verniet ontvang, verniet moet julle dit gee.	",
"	9 Moenie vir julle goud of silwer of koper in julle beurse aanskaf nie;	",
"	10 geen reissak vir die pad of twee kledingstukke of skoene of ’n stok nie; want die arbeider is sy voedsel werd.	",
"	11 En in watter stad of dorp julle ook al mag ingaan, ondersoek wie in haar waardig is, en bly dáár totdat julle vertrek.	",
"	12 En as julle die huis ingaan, groet hom;	",
"	13 en as die huis dit waardig is, laat julle Vrede op hom kom, maar as hy nie waardig is nie, laat julle Vrede na julle terugkeer.	",
"	14 En as iemand julle nie ontvang nie en na julle woorde nie luister nie, gaan uit daardie huis of daardie stad uit en skud die stof van julle voete af.	",
"	15 Voorwaar Ek sê vir julle, dit sal vir die Aarde van Sodom en Gomorra verdraagliker wees in die oordeelsdag as vir daardie stad.	",
"	16 Kyk, Ek stuur julle soos skape onder die wolwe in; wees dan versigtig soos die slange en opreg soos die duiwe.	",
"	17 Maar pas op vir die mense; want hulle sal jul oorlewer aan regbanke, en in hulle vergaderings sal hulle julle gésel.	",
"	18 En ook voor goewerneurs en konings sal julle gebring word om My ontwil tot ’n Getuienis vir hulle en vir die nasies.	",
"	19 Maar wanneer hulle jul oorlewer, moenie julle kwel oor hoe of wat julle sal spreek nie, want dit sal julle in daardie uur gegee word wat julle moet spreek;	",
"	20 want dit is nie julle wat spreek nie, maar die Gees van julle Vader wat in julle spreek.	",
"	21 Maar die een broer sal die ander tot die dood oorlewer en die vader sy kind, en die kinders sal teen hulle ouers opstaan en hulle doodmaak.	",
"	22 En julle sal deur almal gehaat word ter wille van My Naam. Maar wie volhard tot die einde toe, hy sal gered word.	",
"	23 En wanneer hulle julle vervolg in die een stad, vlug na die ander toe. Want voorwaar Ek sê vir julle, julle sal met die stede van JisraEl sekerlik nie klaar kry voordat die Seun van die Adam kom nie.	",
"	24 ’n Leerling is nie bo die leermeester nie en ’n dienskneg ook nie bo sy werkgewer nie.	",
"	25 Dit is vir die leerling genoeg dat hy soos sy leermeester word en die dienskneg soos sy werkgewer. As hulle die Meester van die huis Beëlsebul(Satan) genoem het, hoeveel te meer sy huisgenote!	",
"	26 Vrees hulle dan nie; want daar is niks bedek wat nie ontdek sal word nie, en verborge wat nie bekend sal word nie.	",
"	27 Wat Ek vir julle in die donker sê, vertel dit in die lig; en wat julle in die oor hoor, verkondig dit op die dakke.	",
"	28 En moenie vrees vir die wat die liggaam doodmaak, maar die siel nie kan doodmaak nie; maar vrees Hom liewer wat die siel sowel as die liggaam kan verderwe in die hel.	",
"	29 Word twee mossies nie vir ’n stuiwer verkoop nie? En nie een van hulle sal op die Aarde val sonder julle Vader nie.	",
"	30 En van julle is selfs die hare van die hoof almal getel.	",
"	31 Wees dan nie bevrees nie: julle is meer werd as baie mossies.	",
"	32 Elkeen dan wat My sal bely voor die mense, hom sal Ek ook bely voor My VADER wat in die Hemele is.	",
"	33 Maar elkeen wat teen My getuig voor die mense, teen hom sal Ek ook getuig voor My VADER wat in die Hemele is.	",
"	34 Moenie dink dat Ek gekom het om vrede op die Aarde te bring nie. Ek het nie gekom om vrede te bring nie, maar die swaard.	",
"	35 Want Ek het gekom om tweedrag te verwek tussen ’n man en sy vader, en tussen ’n dogter en haar moeder, en ’n skoondogter en haar skoonmoeder.	",
"	36 En ’n adamiet se huisgenote sal sy vyande wees.	",
"	37 Wie vader of moeder bo My liefhet, is My nie waardig nie; en wie seun of dogter bo My liefhet, is My nie waardig nie.	",
"	38 En wie sy folterpaal nie neem en agter My volg nie, is My nie waardig nie.	",
"	39 Wie sy siel vind, sal haar verloor; en wie sy siel verloor om My ontwil, sal haar vind.	",
"	40 Wie julle ontvang, ontvang My; en wie My ontvang, ontvang HOM wat My gestuur het.	",
"	41 Wie ’n Profeet ontvang omdat hy ’n Profeet is, sal die loon van ’n Profeet ontvang; en wie ’n regverdige ontvang omdat hy ’n regverdige is, sal die loon van ’n regverdige ontvang.	",
"	42 En elkeen wat een van hierdie kleintjies net ’n Beker koue water laat drink, omdat hy ’n student is, voorwaar Ek sê vir julle, hy sal sy loon sekerlik nie verloor nie.	",

]
},
{
book: 'Mattithjahûw',
chapter: '11',
content: [
		
"	1 EN toe JaHWèshua klaar was om bevele aan Sy twaalf studente te gee, het Hy daarvandaan weggegaan om te leer en te verkondig in hulle stede.	",
"	2 En JeHôWganan het in die gevangenis gehoor van die werke van die Gesalfde, en twee van Sy studente gestuur	",
"	3 en vir Hom gesê: Is U die Een wat sou kom, of moet ons ’n ander een verwag?	",
"	4 En JaHWèshua het geantwoord en vir hulle gesê: Gaan vertel aan JeHôWganan wat julle hoor en sien:	",
"	5 blindes sien weer en kreupeles loop, melaatses word gesuiwer en dowes hoor, dooies word opgewek en aan armes word die goeie nuus verkondig.	",
"	6 En geseënd is elkeen wat aan My nie aanstoot neem nie.	",
"	7 En toe hulle vertrek, begin JaHWèshua vir die skare aangaande JeHôWganan te sê: Wat het julle uitgegaan om in die wildernis te aanskou? ’n Riet wat deur die wind beweeg word.	",
"	8 Maar wat het julle uitgegaan om te sien? ’n Adamiet met sagte klere aan? Kyk, die wat sagte klere dra, is in die huise van konings.	",
"	9 Maar wat het julle uitgegaan om te sien? ’n Profeet? Ja, Ek sê vir julle, ook baie meer as ’n profeet!	",
"	10 Want dit is hy van wie daar geskrywe is: Kyk, Ek stuur My boodskapper wat die Weg voor My uit sal baan. [JeshaJaH 40:3, Maleagi 3:1]	",
"	11 Voorwaar Ek sê vir julle, onder die wat uit vroue gebore is, het daar nie een opgestaan wat groter is as JeHôWganan die Wasser nie; maar die kleinste in die Koninkryk van die Hemele is groter as hy.	",
"	12 Maar van die dae van JeHôWganan die Wasser af tot nou toe word die Koninkryk van die Hemele bestorm, en bestormers gryp haar met geweld.	",
"	13 Want al die profete en die Wet het tot op JeHôWganan geprofeteer.	",
"	14 En as julle dit wil aanneem: hy is EliJaHûW wat sou kom.	",
"	15 Wie ore het om te hoor, laat hom hoor.	",
"	16 Maar waarmee sal Ek hierdie saadlyn vergelyk? Dit is net soos kindertjies wat op die markte sit en na hulle maats roep	",
"	17 en sê: Ons het vir julle op die fluit gespeel, en julle het nie gedans nie; ons het vir julle ’n klaaglied gesing, en julle het nie getreur nie.	",
"	18 Want JeHôWganan het gekom en nie geëet of gedrink nie, en hulle sê: Hy het ’n demoon.	",
"	19 Die Seun van die Adam het gekom - Hy eet en drink, en hulle sê: Dáár is ’n adamiet wat ’n vraat en ’n wynsuiper is, ’n vriend van tollenaars en oortreders. Maar die Wysheid is geregverdig deur Haar kinders.	",
		
		
"	20 TOE het Hy die stede waarin die meeste van Sy kragtige dade plaasgevind het, begin verwyt, omdat hulle hul nie bekeer het nie:	",
"	21 Wee jou, Górasin, wee jou, Betsáida! want as in Tirus en Sidon die kragtige dade plaasgevind het wat in julle plaasgevind het, sou hulle hul lankal in sak en as bekeer het.	",
"	22 Maar Ek sê vir julle, dit sal vir Tirus en Sidon verdraagliker wees in die oordeelsdag as vir julle.	",
"	23 En jy, Kapérnaüm, wat tot die Hemele toe verhoog is, jy sal tot die Doderyk/Sheol toe neergestoot word; want as in Sodom die kragtige dade plaasgevind het wat in jou plaasgevind het, sou hy bly staan het tot vandag toe.	",
"	24 Maar Ek sê vir julle dat dit vir die Aarde van Sodom verdraagliker sal wees in die oordeelsdag.	",
		
		
		
"	25 IN daardie tyd het JaHWèshua gespreek en gesê: Ek loof U, VADER, JaHWeH van die Hemele en die Aarde, dat U hierdie dinge verberg het vir wyse en geleerdes en dit aan kindertjies geopenbaar het.	",
"	26 Ja, VADER, want so was dit U welbehae.	",
"	27 Alles is aan My oorgegee deur My VADER, en niemand ken die Seun nie, behalwe die VADER; ook ken niemand die VADER nie, behalwe die Seun en elkeen aan wie die Seun dit wil openbaar.	",
"	28 Kom na My toe, almal wat vermoeid en belas is, en Ek sal julle rus gee.	",
"	29 Neem My juk op julle en leer van My, want Ek is sagmoedig en nederig van hart, en julle sal rus vind vir julle siele;	",
"	30 want My juk is sag en My las is lig.	",

]
},
{
book: 'Mattithjahûw',
chapter: '12',
content: [
		
"	1 IN daardie tyd het JaHWèshua op die Sabbat deur die gesaaides geloop, en Sy studente het honger geword en are begin pluk en eet.	",
"	2 Maar toe die Fariseërs dit sien, sê hulle vir Hom: Kyk, U studente doen wat nie geoorloof is om op die Sabbat te doen nie.	",
"	3 Maar Hy sê vir hulle: Het julle nie gelees wat Dawid gedoen het nie - toe hy en die wat saam met hom was, honger gehad het -	",
"	4 hoe hy in die Huis van die Elohim gegaan en die toonbrode geëet het wat vir hom en die wat saam met hom was, nie geoorloof was om te eet nie, maar net vir die priesters alleen?	",
"	5 Of het julle nie in die Wet gelees dat die priesters op die Sabbat in die Tempel die Sabbat skend en onskuldig is nie?	",
"	6 En Ek sê vir julle: Een wat groter is as die Tempel, is hier. [Psalm 50:12]	",
"	7 Maar as julle geweet het wat dit beteken: Want Ek het ’n behae in Medelye en nie in ‘n slagdier nie, sou julle die onskuldiges nie veroordeel het nie; [Hoséa 6:6]	",
"	8 want die Seun van die Adam is Meester óók van die Sabbat. [Génesis 2:3]	",
		
		
"	9 EN Hy het daarvandaan weggegaan en in hulle vergadering gekom.	",
"	10 En daar was ’n man met ’n verdorde hand, en hulle het Hom gevra en gesê: Is dit geoorloof om op die Sabbat gesond te maak? - sodat hulle Hom sou kan aankla.	",
"	11 Maar Hy sê vir hulle: Watter mens sal daar onder julle wees wat een skaap het, en as hy op die Sabbat in ’n sloot val, hom nie sal gryp en uithaal nie?	",
"	12 Hoeveel meer is ’n adamiet dan nie werd as ’n skaap nie! So is dit dan geoorloof om op die Sabbat goed te doen.	",
"	13 Toe sê Hy vir die man: Steek jou hand uit! En hy het haar uitgesteek, en sy is herstel, gesond soos die ander een.	",
"	14 Daarop het die Fariseërs uitgegaan en saam raad gehou teen Hom, sodat hulle Hom sou kan ombring.	",
"	15 Toe JaHWèshua dit bemerk, het Hy daarvandaan weggegaan, en groot menigtes het Hom gevolg, en Hy het hulle almal gesond gemaak,	",
"	16 en hulle ’n streng bevel gegee dat hulle Hom nie bekend moes maak nie,	",
"	17 sodat vervul sou word die Woord wat gespreek is deur JeshaJaHûW, die Profeet:	",
"	18 Kyk, My Kneg wat Ek ondersteun het, My Uitverkorene in wie My siel ’n welbehae het! Ek het My Gees op Hom gelê, Hy sal oordeel laat uitgaan na die nasies. [JeshaJaH 42:1]	",
"	19 Hy sal nie murmureer of uitroep of Sy stem op die straat laat hoor nie. [JeshaJaH 42:2]	",
"	20 Die geknakte riet sal Hy nie verbreek, en die dowwe lamppit nie uitblus nie, Hy sal deur Waarheid die Reg laat uitgaan. [JeshaJaH 42:3; Psalm 102:17]]	",
"	21 En vir Sy Naam sal die heidene vrees	",
		
		
"	22 TOE het hulle ’n satanbesetene wat blind en stom was, na Hom gebring; en Hy het hom gesond gemaak, sodat die blinde en stomme kon praat en sien.	",
"	23 En die hele menigte was verbaas en het gesê: Is Hy nie miskien die seun van Dawid nie?	",
"	24 Maar toe die Fariseërs dit hoor, sê hulle: Hy dryf die demone nie anders uit as deur Beëlsebul, die prins van die demone, nie.	",
"	25 Maar JaHWèshua het hulle gedagtes geken en vir hulle gesê: Elke koninkryk wat teen homself verdeeld is, word verwoes; en elke stad of huis wat teen homself verdeeld is, sal nie bly staan nie.	",
"	26 En as die Satan die Satan uitdryf, dan is hy teen homself verdeeld. Hoe sal sy koninkryk dan bly staan?	",
"	27 En as Ek deur Beëlsebul die demone uitdryf, deur wie dryf julle seuns hulle uit? Daarom sal hulle jul regters wees.	",
"	28 Maar as Ek deur die Gees van Elohim die demone uitdryf, dan het die Koninkryk van Elohim by julle gekom.	",
"	29 Of hoe kan iemand in die huis van ’n Magtige ingaan en sy goed roof, as hy nie eers die Magtige geboei het nie? En dan sal hy sy huis beroof.	",
"	30 Hy wat nie met My is nie, is teen My; en hy wat nie saam met My versamel nie, verstrooi.	",
"	31 Daarom sê Ek vir julle: Elke lastering en oortreding sal die adamiete vergewe word, maar die lastering teen die Gees sal die adamiete nie vergewe word nie. [Boekrol van Henog 12:5]	",
"	32 En elkeen wat ’n woord spreek teen die Seun van die Adam, dit sal hom vergewe word; maar elkeen wat spreek teen die Gees van die Apartheid, dit sal hom nie vergewe word nie, in hierdie tyd nie en ook in die toekomstige tyd nie.	",
		
		
"	33 JULLE moet òf die boom eg beskou en sy vrugte eg, òf julle moet die boom verbaster beskou en sy vrugte verbaster; want aan die vrugte word die boom geken.	",
"	34 Genetiese nageslag van Nagash/slang, hoe kan julle suiwer dinge praat terwyl julle besoedel is? Want uit die oorvloed van die hart praat die mond.	",
"	35 Die suiwer adamiet bring uit die suiwer skat van sy hart suiwer dinge te voorskyn, en die besoedelde adamiet bring uit die besoedelde skat besoedelde dinge te voorskyn.	",
"	36 Maar Ek sê vir julle dat van elke ydele woord wat die adamiete praat, daarvan moet hulle rekenskap gee in die oordeelsdag.	",
"	37 Want uit jou woorde sal jy geregverdig word, en uit jou woorde sal jy veroordeel word.	",
		
		
"	38 TOE spreek sommige van die skrywers en Fariseërs en sê: Meester, ons wil graag ’n Teken van U sien.	",
"	39 Maar Hy antwoord en sê vir hulle: ’n Besoedelde en verbasterde saadlyn soek na ’n teken, en geen teken sal aan hom gegee word nie, behalwe die Teken van die Profeet Jona.	",
"	40 Want soos Jona drie dae en drie nagte in die buik van die groot vis was, só sal die Seun van die Adam drie dae en drie nagte in die hart van die Aarde wees. [Profeet Jona 1:17; Boekrol van die Opregte 12:6]	",
"	41 Die manne van Ninevé sal in die oordeel opstaan saam met hierdie saadlyn en hom veroordeel; want hulle het hul op die prediking van Jona bekeer, en - meer as Jona is hier!	",
"	42 Die Koningin van die Suide sal in die oordeel opstaan saam met hierdie saadlyn en hom veroordeel; want Sy het gekom van die eindes van die Aarde af om die Wysheid van Salomo te hoor, en - meer as Salomo is hier! [Psalm 72:15]	",
"	43 En wanneer die gees van besoedeling uit die adamiet uitgegaan het, gaan hy deur waterlose plekke en soek rus en vind dit nie.	",
"	44 Dan sê hy: Ek sal teruggaan na my huis waar ek uitgegaan het. En hy kom en vind hom leeg, uitgevee en versier.	",
"	45 Dan gaan hy en neem sewe ander geeste meer besoedel as hy self met hom saam, en hulle kom in en woon daar; en die laaste van daardie adamiet word erger as die eerste. Só sal dit ook wees met hierdie besoedelde saadlyn.	",
		
		
"	46 EN terwyl Hy nog met die skare spreek, staan Sy moeder en broers daarbuite en wou graag met Hom praat.	",
"	47 Toe sê iemand vir Hom: Dáár staan U moeder en U broers buite en wil graag met U praat.	",
"	48 Maar Hy antwoord en sê vir die een wat Hom dit vertel het: Wie is My moeder? En wie is My broers?	",
"	49 En Hy steek Sy hand oor Sy studente uit en sê: Dáár is My moeder en My broers.	",
"	50 Want elkeen wat die wil doen van My VADER wat in die Hemele is, dié is My broer en suster en moeder.	",

]
},
{
book: 'Mattithjahûw',
chapter: '13',
content: [
		
"	1 EN op daardie dag het JaHWèshua uit die huis uitgegaan en by die see gaan sit.	",
"	2 En groot menigtes het by Hom vergader, sodat Hy in ’n skuit geklim en gaan sit het. En die hele skare het op die strand gestaan.	",
"	3 En Hy het baie dinge deur gelykenisse tot hulle gespreek en gesê: ’n Saaier het uitgegaan om te saai;	",
"	4 en terwyl hy saai, val ’n deel langs die pad, en die voëls het gekom en hom opgeëet.	",
"	5 En ’n ander deel het op rotsagtige plekke geval waar daar nie baie grond was nie; en dadelik het hy opgekom, omdat daar geen diepte van grond was nie;	",
"	6 maar toe die son opgaan, is hy verskroei, en omdat hy geen wortel gehad het nie, het hy verdroog.	",
"	7 En ’n ander deel het in die dorings geval, en die dorings het opgekom en hom verstik.	",
"	8 En ’n ander deel het in die gesuiwerde Adamah [die adamiet se Aarde] geval en vrug opgelewer: die een honderd-, die ander sestig-, die ander dertigvoudig.	",
"	9 Wie ore het om te hoor, laat hom hoor!	",
"	10 En die studente het gekom en vir Hom gesê: Waarom spreek U tot hulle deur gelykenisse?	",
"	11 Toe antwoord Hy en sê vir hulle: Omdat dit aan julle gegee is om die verborgenhede van die Koninkryk van die Hemele te ken, maar aan hulle is dit nie gegee nie.	",
"	12 Want hy wat het, aan hom sal gegee word, en hy sal oorvloed hê; maar hy wat nie het nie, van hom sal weggeneem word ook wat hy het.	",
"	13 Daarom spreek Ek tot hulle deur gelykenisse, omdat hulle, terwyl hulle sien, nie sien nie, en terwyl hulle hoor, nie hoor of verstaan nie.	",
"	14 En aan hulle word die profesie van JeshaJaHûW vervul wat sê: Met die gehoor sal julle hoor en glad nie verstaan nie, en julle sal kyk en kyk, en glad nie sien nie.	",
"	15 Want die hart van hierdie volk het stomp geword, en met die ore het hulle beswaarlik gehoor; en hul oë het hulle toegesluit, sodat hulle nie miskien met die oë sou sien en met die ore hoor en met die hart verstaan en hulle bekeer en Ek hulle genees nie. [JeshaJaH 6:9,10]	",
"	16 Maar julle oë is geseënd, omdat hulle sien; en julle ore, omdat hulle hoor.	",
"	17 Want, voorwaar Ek sê vir julle, baie profete en regverdiges het begeer om te sien wat julle sien, en het dit nie gesien nie, en om te hoor wat julle hoor, en het dit nie gehoor nie.	",
"	18 Luister julle dan na die gelykenis van die saaier.	",
"	19 As iemand die Woord van die Koninkryk hoor en nie verstaan nie, kom die besoedeling en roof wat in sy hart gesaai is - dit is hy by wie langs die pad gesaai is.	",
"	20 En by wie op rotsagtige plekke gesaai is - dit is hy wat die Woord hoor en Hom dadelik met blydskap aanneem;	",
"	21 maar hy het geen wortel in homself nie, dit is net vir ’n tyd, en as daar verdrukking en vervolging kom ter wille van die Woord, struikel hy dadelik.	",
"	22 En by wie in die dorings gesaai is - dit is hy wat die Woord hoor, maar die sorg van hierdie tyd en die verleiding van die rykdom verstik die Woord, en hy word onvrugbaar.	",
"	23 En by wie op die gesuiwerde Adamah [die adamiet se Aarde] gesaai is - dit is hy wat die Woord hoor en verstaan, wat dan ook vrug dra en oplewer: die een honderd-, die ander sestig-, die ander dertigvoudig.	",
		
		
"	24 ’N ANDER gelykenis het Hy hulle voorgehou en gesê: Die Koninkryk van die Hemele is soos ’n Man wat egte saad in Sy land gesaai het; [2 Ezra 8:44]	",
"	25 maar terwyl die adamiete slaap, het Sy vyand gekom en basterkoring [lyk soos koring, maar die korrel is swart en bitter] onder die koring gesaai en weggegaan.	",
"	26 En toe die spruitjies opgeskiet en vrug gevorm het, toe verskyn die basterkoring ook.	",
"	27 En die diensknegte van die Besitter het gekom en vir hom gesê: Meester, het U dan nie suiwer saad in U land gesaai nie? Waar kry sy dan die basterkoring vandaan?	",
"	28 En Hy antwoord hulle: ’n Vyandige man het dit gedoen. Toe sê die diensknegte vir Hom: Wil u dan hê dat ons hulle moet gaan bymekaarmaak?	",
"	29 Maar hy antwoord: Nee, dat julle nie miskien, as julle die basterkoring bymekaarmaak, die koring daarmee saam uittrek nie.	",
"	30 Laat altwee saam groei tot die oes toe, en in die oestyd sal Ek vir die maaiers sê: Maak eers die basterkoring bymekaar en bind hulle in bondels om hulle te verbrand, maar bring die koring bymekaar in My Skuur. [2 Ezra 4:32]	",
		
		
"	31 ‘N ANDER gelykenis het Hy hulle voorgehou en gesê: Die Koninkryk van die Hemele is soos ’n Mosterdsaad wat ’n Man neem en in Sy land saai;	",
"	32 wat wel die kleinste is van al die soorte saad, maar as Sy gegroei het, groter is as die groentesoorte en ’n Boom word, sodat die voëls van die Hemele kom en nes maak in Haar takke.	",
"	33 ’n Ander gelykenis het Hy hulle vertel: Die Koninkryk van die Hemele is soos suurdeeg wat ’n Vrou neem en in drie mate meel inwerk totdat sy heeltemal ingesuur is.	",
"	34 Al hierdie dinge het JaHWèshua deur gelykenisse vir die skare gesê, en sonder gelykenis het Hy vir hulle niks gesê nie;	",
"	35 sodat vervul sou word die Woord wat gespreek is deur die Profeet: Ek wil My Mond open met ‘n gelykenis, raaisels uit die voortyd laat borrel. [Psalm 78:2]	",
		
		
"	36 NADAT Hy die skare weggestuur het, het JaHWèshua huis toe gegaan; en Sy studente het na Hom gekom en gesê: Verklaar vir ons die gelykenis van die basterkoring in die saailand.	",
"	37 En Hy het geantwoord en vir hulle gesê: Hy wat die egte saad saai, is die Seun van die Adam,	",
"	38 en die saailand is die wêreld. Die egte saad - hulle is die seuns van die Koninkryk, en die basterkoring is die seuns van die besoedeling,	",
"	39 en die vyand wat hulle gesaai het, is die Satan. Die oes is die voleinding van die tyd, en die maaiers is die Boodskappers.	",
"	40 Net soos die basterkoring dan bymekaargemaak en met vuur verbrand word, so sal dit wees in die voleinding van hierdie tyd:	",
"	41 die Seun van die Adam sal Sy Boodskappers uitstuur, en hulle sal uit Sy Koninkryk bymekaarmaak al die struikelblokke en die wat ongeregtigheid doen,	",
"	42 en sal hulle in die vuuroond gooi. Daar sal geween wees en gekners van die tande.	",
"	43 Dan sal die regverdiges skyn soos die son in die Koninkryk van hulle Vader. Wie ore het om te hoor, laat hom hoor. [DaniEl 12:3, Openbaring 13:9]	",
		
		
"	44 VERDER is die Koninkryk van die Hemele soos ’n skat wat verborge is in ‘n saailand, wat ’n man kry en wegsteek; en uit blydskap daaroor gaan hy en verkoop alles wat hy het, en koop daardie saailand. [Boekrol van Henog 93:10]	",
"	45 Verder is die Koninkryk van die Hemele soos ’n handelaar wat egte pêrels soek;	",
"	46 en toe hy een baie kosbare pêrel kry, gaan hy weg en verkoop alles wat hy het, en koop haar.	",
"	47 Verder is die Koninkryk van die Hemele soos ’n net wat in die see gegooi word en van elke spesie bymekaarbring;	",
"	48 en as sy vol geword het, trek hulle haar op die strand uit en gaan sit en maak die suiweres in bakke bymekaar, maar gooi die besoedeldes weg.	",
"	49 So sal dit wees in die voleinding van die tyd: die Boodskappers sal uitgaan en die besoedelde mense onder die regverdiges uit afskei	",
"	50 en hulle in die vuuroond gooi. Daar sal geween wees en gekners van die tande.	",
"	51 JaHWèshua sê vir hulle: Het julle ál hierdie dinge verstaan? Hulle antwoord Hom: Ja, Meester!	",
"	52 Toe sê Hy vir hulle: Daarom is elke skrywer wat ’n student geword het in die Koninkryk van die Hemele, soos ’n eienaar wat uit sy skat nuwe en ou dinge te voorskyn bring.	",
		
		
"	53 EN toe JaHWèshua hierdie gelykenisse geëindig het, het Hy daarvandaan weggegaan.	",
"	54 En Hy het in Sy vaderstad gekom en hulle geleer in hul vergadering, sodat hulle verslae was en gesê het: Waar kry Hy hierdie Wysheid en Kragte vandaan?	",
"	55 Is Hy nie die seun van die timmerman nie? Is die naam van Sy moeder nie Mirjam en dié van Sy broers Jakobus en Joses en Simon en Judas nie?	",
"	56 En Sy susters, is hulle nie almal by ons nie? Waar kry Hy dan al hierdie dinge vandaan?	",
"	57 En hulle het aanstoot aan Hom geneem. Maar JaHWèshua sê vir hulle: ’n Profeet is nie ongeëerd nie, behalwe in sy vaderland en in sy huis.	",
"	58 En Hy het daar vanweë hulle wantroue nie baie kragtige dade gedoen nie.	",
		

]
},
{
book: 'Mattithjahûw',
chapter: '14',
content: [
		
"	1 EN in daardie tyd het Herodes, die viervors, die gerug van JaHWèshua gehoor	",
"	2 en aan sy knegte gesê: Hierdie man is JeHôWganan die Wasser. Hy het uit die dode opgestaan, en daarom werk dié kragte in hom.	",
"	3 Want Herodes het JeHôWganan gevang, hom geboei en in die gevangenis gesit vanweë Heródias, die vrou van Filippus, sy broer.	",
"	4 Want JeHôWganan het vir hom gesê: Dit is u nie geoorloof om haar te hê nie.	",
"	5 En hoewel hy hom wou doodmaak, het hy die skare gevrees, omdat hulle hom vir ’n Profeet gehou het.	",
"	6 Maar by die viering van die verjaarsdag van Herodes het die dogter van Heródias voor hulle gedans en Herodes behaag.	",
"	7 Daarom het hy met ’n eed beloof om haar enigiets te gee wat sy sou vra.	",
"	8 Toe sê sy, nadat sy deur haar moeder aangehits was: Gee my hier op ’n skottel die hoof van JeHôWganan die Wasser.	",
"	9 En die koning het treurig geword, maar ter wille van die eed en die feesgenote het hy beveel dat dit gegee moes word.	",
"	10 En hy het gestuur en JeHôWganan in die gevangenis onthoof.	",
"	11 Sy hoof is toe op ’n skottel gebring en aan die meisie gegee, en sy het dit na haar moeder gebring.	",
"	12 En sy studente het gekom en sy liggaam weggeneem en hom begrawe; en hulle het gegaan en dit aan JaHWèshua vertel.	",
"	13 En toe JaHWèshua dit hoor, het Hy daarvandaan in ’n skuit vertrek na ’n verlate plek alleen. En die skare het dit gehoor en Hom van die stede af te voet gevolg.	",
		
		
"	14 EN toe JaHWèshua uitgaan, het Hy ’n groot skare gesien en innig jammer vir hulle gevoel, en Hy het hulle siekes gesond gemaak.	",
"	15 En toe dit aand geword het, kom Sy studente na Hom en sê: Die plek is verlate, en dit is al oor die tyd; stuur die skare weg, sodat hulle na die dorpe kan gaan en vir hulle voedsel koop.	",
"	16 Maar JaHWèshua sê vir hulle: Hulle hoef nie weg te gaan nie; gee julle vir hulle iets om te eet.	",
"	17 Maar hulle antwoord Hom: Ons het hier net vyf brode en twee visse.	",
"	18 En Hy sê: Bring dit hier vir My.	",
"	19 Toe gee Hy die skare bevel om op die gras te gaan sit; en Hy neem die vyf brode en die twee visse, kyk op na die Hemele en dank; en nadat Hy die brode gebreek het, gee Hy dit aan die studente en die studente aan die skare.	",
"	20 En almal het geëet en versadig geword, en hulle het die oorskot van die brokstukke opgetel, twaalf mandjies vol.	",
"	21 En dit was omtrent vyfduisend manne wat geëet het, buiten die vroue en kinders.	",
		
		
"	22 EN JaHWèshua het dadelik Sy studente gedwing om in die skuit te gaan en voor Hom uit te vaar na die oorkant, terwyl Hy die skare wegstuur.	",
"	23 En nadat Hy die skare weggestuur het, klim Hy op die berg om in die eensaamheid te bid. En toe dit aand geword het, was Hy daar alleen.	",
"	24 En die skuit was al in die middel van die see, geteister deur die golwe; want die wind was teen hulle.	",
"	25 Maar in die vierde nagwaak het JaHWèshua na hulle gekom, al wandelende op die see.	",
"	26 En toe die studente Hom op die see sien loop, word hulle ontsteld en sê: Dit is ’n spook! En hulle het geskreeu van vrees.	",
"	27 Maar JaHWèshua het dadelik met hulle gespreek en gesê. Hou goeie moed, Ek Is! Moenie vrees nie.	",
"	28 En Petrus antwoord Hom en sê: Meester, as dit U is, beveel my om op die water na U te kom.	",
"	29 En Hy sê: Kom! Petrus klim toe van die skuit af en loop op die water om na JaHWèshua te gaan.	",
"	30 Maar toe hy die sterk wind sien, het hy bang geword; en toe hy begin sink, roep hy uit en sê: Meester, red my!	",
"	31 En JaHWèshua het dadelik Sy hand uitgesteek en hom gegryp en vir hom gesê: Kleingelowige, waarom het jy getwyfel?	",
"	32 Daarop klim hulle in die skuit, en die wind het gaan lê.	",
"	33 Toe kom die wat in die skuit was, en val voor Hom neer en sê: Waarlik, U is die Seun van Elohim!	",
"	34 En hulle het oorgevaar en in die landstreek van Gennésaret gekom.	",
"	35 En die manne van daardie plek het Hom herken en in daardie hele omtrek uitgestuur en almal wat ongesteld was, na Hom gebring;	",
"	36 en hulle het Hom gesmeek dat hulle net maar die soom van Sy kleed mag aanraak; en almal wat hom aangeraak het, het gesond geword.	",

]
},
{
book: 'Mattithjahûw',
chapter: '15',
content: [
		
"	1 TOE kom daar skrywers en Fariseërs van Jerusalem na JaHWèshua en sê:	",
"	2 Waarom oortree U studente die oorlewering van die oues? Want hulle was nie hul hande as hulle brood eet nie.	",
"	3 Maar Hy antwoord en sê vir hulle: Waarom oortree julle ook die Gebod van Elohim ter wille van julle oorlewering?	",
"	4 Want Elohim het Bevel gegee en gesê: Eer jou Vader en Moeder; en: Hy wat vader of moeder vloek, moet sekerlik gedood word. [Exodus 20:12; 21:17]	",
"	5 Maar julle sê: Elkeen wat aan vader of moeder sê: enige voordeel wat u van my sou kan geniet, is ’n bydrae - dié hoef sy vader of sy moeder glad nie te eer nie.	",
"	6 So het julle dan die Gebod van Elohim kragteloos gemaak ter wille van julle oorlewering.	",
"	7 Tweegesigte, tereg het JeshaJaHûW oor julle geprofeteer toe hy gesê het:	",
"	8 Omdat hierdie volk nader kom met hulle mond en My eer met die lippe, terwyl hulle hul hart ver van My hou,	",
"	9 sodat hulle vrees vir My ’n aangeleerde gebod van sterflinge is. [JeshaJaH 29:13]	",
"	10 En Hy het die skare na Hom geroep en vir hulle gesê: Luister en verstaan!	",
"	11 Nie wat in die mond ingaan, maak die adamiet vuil nie; maar wat uit die mond uitgaan, dit maak die adamiet vuil.	",
"	12 Daarop kom Sy studente nader en sê vir Hom: Weet U dat die Fariseërs, toe hulle hierdie woord hoor, aanstoot geneem het?	",
"	13 Maar Hy antwoord en sê: Elke plant wat My Hemelse VADER nie geplant het nie, sal ontwortel word.	",
"	14 Laat hulle staan; hulle is blinde leiers van blindes. En as ’n blinde ’n ander blinde lei, sal altwee in die sloot val.	",
"	15 En Petrus antwoord en sê vir Hom: Verklaar vir ons hierdie gelykenis.	",
"	16 Maar JaHWèshua sê: Is julle dan ook nog sonder verstand?	",
"	17 Begryp julle nog nie dat alles wat in die mond ingaan, in die maag kom en in die heimlikheid uitgewerp word nie?	",
"	18 Maar die dinge wat uit die mond uitgaan, kom uit die hart, en dit is dié wat die adamiet vuil maak.	",
"	19 Want uit die hart kom daar besoedelde gedagtes, moord, vermenging, hoerery, diewery, valse getuienis, lasterlike spraak tot Elohim.	",
"	20 Dit is hierdie dinge wat die adamiet vuil maak; maar om met ongewaste hande te eet, maak die adamiet nie vuil nie.	",
		
		
"	21 EN JaHWèshua het daarvandaan weggegaan en na die streke van Tirus en Sidon vertrek.	",
"	22 En ’n Kananese vrou het van daardie gebied gekom en na Hom geroep en gesê: Wees my barmhartig, Meester, Seun van Dawid! My dogter is erg van die Satan besete.	",
"	23 Maar Hy het haar nie ’n woord geantwoord nie. Toe kom Sy studente nader en vra Hom en sê: Stuur haar weg, want sy roep agter ons aan.	",
"	24 Maar Hy antwoord en sê: Ek is net gestuur na die verlore skape van die huis van JisraEl.	",
"	25 Daarop kom sy en val voor Hom neer en sê: Meester, help my!	",
"	26 Maar Hy antwoord en sê: Dit is nie suiwer om die Brood van die kinders te neem en Hom vir die honde te gooi nie.	",
"	27 En sy sê: Ja, Meester, maar die honde eet darem van die krummels wat van die tafel van hulle base afval.	",
"	28 Toe antwoord JaHWèshua en sê vir haar: o Vrou, groot is jou geloof; laat dit vir jou wees soos jy wil hê. En haar dogter het gesond geword van daardie uur af.	",
		
		
"	29 TOE gaan JaHWèshua daarvandaan weg en kom by die see van Galiléa; en Hy het op die berg geklim en daar gaan sit.	",
"	30 En ondertussen kom daar groot menigtes na Hom met kreupeles, blindes, stommes, gebreklikes en baie ander by hulle, en hulle het dié by die voete van JaHWèshua neergesit, en Hy het hulle gesond gemaak,	",
"	31 sodat die skare verbaas was om te sien dat stommes praat, gebreklikes gesond word, kreupeles loop en blindes sien; en hulle het die Elohey van JisraEl vereer.	",
"	32 Toe het JaHWèshua Sy studente na Hom geroep en gesê: Ek voel innig jammer vir die skare, omdat hulle al drie dae by My bly en niks het om te eet nie; en Ek wil hulle nie graag honger wegstuur nie, sodat hulle nie miskien op die pad beswyk nie.	",
"	33 En Sy studente sê vir Hom: Waar sal ons in die wildernis soveel brode vandaan kry om so ’n groot skare te versadig?	",
"	34 Toe sê JaHWèshua vir hulle. Hoeveel brode het julle? En hulle antwoord: Sewe, en ’n paar vissies.	",
"	35 En Hy het bevel gegee aan die skare om op die grond te gaan sit.	",
"	36 Toe neem Hy die sewe brode en die visse, en nadat Hy gedank het, breek Hy dit en gee dit aan Sy studente, en die studente aan die skare.	",
"	37 En hulle het almal geëet en versadig geword; en hulle het die oorskot van die brokstukke opgetel, sewe mandjies vol.	",
"	38 En die wat geëet het, was vierduisend manne buiten die vroue en kinders.	",
"	39 En nadat Hy die skare weggestuur het, het Hy in die skuit gegaan en in die gebied van Mágdala gekom.	",
		

]
},
{
book: 'Mattithjahûw',
chapter: '16',
content: [
		
"	1 EN die Fariseërs en Sadduseërs het nader gekom om Hom te versoek en het Hom gevra om hulle ’n Teken uit die Hemele te laat sien.	",
"	2 Maar Hy antwoord en sê vir hulle: In die aand sê julle: Mooi weer, want die lug is rooi.	",
"	3 En in die môre: Stormweer vandag, want die lug is donkerrooi. Tweegesigte, julle weet wel om die voorkoms van die lug te onderskei, en kan julle nie die tekens van die tye onderskei nie? [Profeet JôWEl 2:28]	",
"	4 ’n Besoedelde en verbasterde saadlyn soek na ’n teken, en geen teken sal aan hom gegee word nie, behalwe die Teken van Jona, die Profeet. En Hy het hulle verlaat en weggegaan.	",
"	5 En toe Sy studente na die oorkant gegaan het, het hulle vergeet om brode saam te neem.	",
"	6 Daarop sê JaHWèshua vir hulle: Pas op en wees op julle hoede vir die suurdeeg van die Fariseërs en Sadduseërs.	",
"	7 En hulle het onder mekaar geredeneer en gesê: Dit is omdat ons geen brode saamgeneem het nie.	",
"	8 Maar JaHWèshua het dit opgemerk en vir hulle gesê: Wat redeneer julle onder mekaar, kleingelowiges, dat julle geen brode saamgeneem het nie?	",
"	9 Begryp julle nog nie, en onthou julle nie die vyf brode van die vyfduisend, en hoeveel mandjiesvol julle opgetel het nie?	",
"	10 Of die sewe brode van die vierduisend, en hoeveel mandjiesvol julle opgetel het nie?	",
"	11 Hoe is dit dat julle nie begryp dat Ek nie in verband met brood vir julle gesê het om op te pas vir die suurdeeg van die Fariseërs en Sadduseërs nie?	",
"	12 Toe het hulle begryp dat Hy nie gesê het dat hulle moes oppas vir die suurdeeg van die brood nie, maar vir die leer van die Fariseërs en Sadduseërs.	",
		
		
"	13 EN toe JaHWèshua in die streke van Cesaréa-Filippi kom, vra Hy Sy studente en sê: Wie sê die adamiete is Ek, wat die Seun van die Adam, is?	",
"	14 En hulle antwoord: Sommige JeHôWganan die Wasser, en sommige EliJaHûW, en ander JirmeJaHûW of een van die Profete.	",
"	15 Hy sê vir hulle: Maar julle, wie sê julle is Ek?	",
"	16 En Simon Petrus antwoord en sê: U is die Gesalfde, die Seun van die lewende Elohim.	",
"	17 Toe antwoord JaHWèshua en sê vir hom: Geseënd is jy, Simon Bar-Jona, want vlees en bloed het dit nie aan jou geopenbaar nie, maar My VADER wat in die Hemele is.	",
"	18 En Ek sê ook vir jou: Jy is Petrus, en op hierdie rots van My sal Ek die gemeente bou, en die poorte van die Doderyk/Sheol sal hom nie oorweldig nie.	",
"	19 En Ek sal jou die sleutels van die Koninkryk van die Hemele gee; en wat jy ook op die Aarde mag bind, sal in die Hemele gebonde wees, en wat jy ook op die Aarde mag ontbind, sal in die Hemele ontbonde wees.	",
"	20 Daarop het Hy Sy studente bevel gegee dat hulle vir niemand moes sê dat Hy JaHWèshua die Gesalfde is nie.	",
"	21 Van toe af het JaHWèshua begin om Sy studente te toon dat Hy na Jerusalem moes gaan en veel van die oudstes en owerpriesters en skrywers moes ly, en gedood en op die derde dag opgewek word.	",
"	22 Toe neem Petrus Hom opsy en begin Hom bestraf en sê: Mag die Hemelse VADER dit verhoed, Meester, dit sal U nooit oorkom nie!	",
"	23 Maar Hy het omgedraai en vir Petrus gesê: Gaan weg agter My, Satan! Jy is vir My ’n struikelblok, omdat jy nie die dinge van die Elohim bedink nie, maar die dinge van die mense.	",
		
		
"	24 TOE sê JaHWèshua vir Sy studente: As iemand agter My aan wil kom, moet hy homself ontsê en sy folterpaal opneem en My volg.	",
"	25 Want elkeen wat sy siel wil red, sal haar verloor; maar elkeen wat sy siel om My ontwil verloor, sal haar vind.	",
"	26 Want wat baat dit ’n adamiet as hy die hele wêreld win, maar aan sy siel skade ly? Of wat sal ’n adamiet gee as losprys vir sy siel?	",
"	27 Want die Seun van die Adam staan gereed om met Sy Boodskappers in die Glansrykheid van Sy VADER te kom, en dan sal Hy elkeen vergeld volgens sy dade.	",
"	28 Voorwaar Ek sê vir julle, daar is sommige van die wat hier staan, wat die Dood sekerlik nie sal smaak voordat hulle die Seun van die Adam in Sy Koninkryk sien kom het nie.	",

]
},
{
book: 'Mattithjahûw',
chapter: '17',
content: [
		
"	1 EN ná ses dae het JaHWèshua vir Petrus en Jakobus en JeHôWganan, sy broer, saamgeneem en hulle op ’n hoë berg in die eensaamheid gebring.	",
"	2 En Hy het voor hulle van gedaante verander, en Sy Aangesig het geglans soos die son, en Sy klere het wit geword soos die Lig.	",
"	3 En kyk, daar verskyn aan hulle Moshè en EliJaHûW in gesprek met Hom.	",
"	4 Toe begin Petrus vir JaHWèshua te sê: Meester, dit is goed dat ons hier is; as U wil, laat ons hier drie takskuilings maak: vir U een en vir Moshè een en een vir EliJaHûW.	",
"	5 Terwyl hy nog spreek, oordek ’n helder-verligte Wolkkolom hulle meteens en daar sê ’n Stem uit die Wolkkolom: DIT IS MY GELIEFDE SEUN IN WIE EK ‘N WELBEHAE HET. LUISTER NA HOM!	",
"	6 En toe die studente dit hoor, het hulle op hul aangesig geval en was baie bevrees.	",
"	7 En JaHWèshua het nader gekom en hulle aangeraak en gesê: Staan op en moenie vrees nie.	",
"	8 Toe slaan hulle hul oë op en sien niemand meer nie, behalwe JaHWèshua alleen.	",
"	9 En onderwyl hulle van die berg afklim, het JaHWèshua hulle bevel gegee en gesê: Julle moet vir niemand iets van die gesig sê voordat die Seun van die Adam uit die dode opgestaan het nie.	",
"	10 En Sy studente vra Hom en sê: Waarom sê die skrywers dan dat EliJaHûW eers moet kom?	",
"	11 En JaHWèshua antwoord en sê vir hulle: Dit is die Waarheid, EliJaHûW kom eers en sal alles herstel; [1 Konings 17:21]	",
"	12 maar Ek sê vir julle dat EliJaHûW al gekom het, en hulle het hom nie erken nie, maar aan hom alles gedoen wat hulle wou. So sal die Seun van die Adam ook deur hulle ly. [1 Konings 17]	",
"	13 Toe verstaan die studente dat Hy met hulle van JeHôWganan die Wasser gespreek het.	",
		
		
"	14 EN toe hulle by die skare kom, gaan daar ’n man na Hom en val voor Hom op die knieë en sê:	",
"	15 Meester, ontferm U oor my seun, want hy is maansiek en ly swaar; want dikwels val hy in die vuur en dikwels in die water.	",
"	16 En ek het hom na U studente gebring, en hulle kon hom nie gesond maak nie.	",
"	17 Toe antwoord JaHWèshua en sê: o Ongelowige en vermengde geslag, hoe lank sal Ek by julle wees, hoe lank sal Ek julle verdra? Bring hom hier vir My.	",
"	18 Daarop bestraf JaHWèshua hom; en die demoon het van hom uitgegaan, en die seun het gesond geword van daardie uur af.	",
"	19 Toe kom die studente na JaHWèshua afsonderlik en sê: Waarom kon ons hom nie uitdryf nie?	",
"	20 En JaHWèshua antwoord hulle: Deur julle wantroue; want, voorwaar Ek sê vir julle, as julle Geloof het soos ’n mosterdsaad sal julle vir hierdie berg sê: Gaan weg hiervandaan daarnatoe! en hy sal weggaan, en niks sal vir julle onmoontlik wees nie.	",
"	21 Maar hierdie tipe [gees] gaan nie uit behalwe deur gebed en vas nie.	",
"	22 En terwyl hulle in Galiléa rondgaan, het JaHWèshua vir hulle gesê: Die Seun van die Adam sal oorgelewer word in die hande van die mense;	",
"	23 en hulle sal Hom doodmaak, en op die derde dag sal Hy opstaan. En hulle het baie bedroef geword.	",
		
		
"	24 EN toe hulle in Kapérnaüm kom, het die wat die tempelbelasting ontvang, na Petrus gegaan en gesê: Betaal julle Meester nie die tempelbelasting nie?	",
"	25 Hy antwoord: Ja. En toe hy in die huis inkom, was JaHWèshua hom voor en sê: Wat dink jy, Simon? Van wie neem die konings van die Aarde tol of belasting - van hulle seuns of van die vreemdelinge?	",
"	26 Petrus antwoord Hom: Van die vreemdelinge. JaHWèshua sê vir hom: Dan is die seuns vry.	",
"	27 Maar dat ons hulle geen aanstoot mag gee nie, gaan na die see toe, gooi ’n hoek uit en neem die eerste vis wat opkom; en as jy sy bek oopmaak, sal jy ’n geldstuk kry; neem dit en gee dit aan hulle vir My en vir jou.	",

]
},
{
book: 'Mattithjahûw',
chapter: '18',
content: [
		
"	1 IN daardie uur het die studente na JaHWèshua gekom en gesê: Wie is tog die grootste in die Koninkryk van die Hemele?	",
"	2 Toe roep JaHWèshua ’n kindjie na Hom en laat hom in hulle midde staan	",
"	3 en Hy sê: Voorwaar Ek sê vir julle, as julle nie verander en soos die kindertjies word nie, sal julle nooit in die Koninkryk van die Hemele ingaan nie!	",
"	4 Elkeen dan wat homself verneder soos hierdie kindjie, hy is die grootste in die Koninkryk van die Hemele.	",
"	5 En elkeen wat een van sulke kindertjies in My Naam ontvang, ontvang My;	",
"	6 maar elkeen wat een van hierdie kleintjies wat in My glo, laat struikel, dit is vir hom beter dat ’n meulsteen aan sy nek gehang word en hy wegsink in die diepte van die see. [Openbaring 18:21]	",
"	7 Wee die wêreld weens die struikelblokke! Want dit is noodsaaklik dat daar struikelblokke kom, maar wee die adamiet deur wie die struikelblok kom.	",
"	8 En as jou hand of jou voet jou laat struikel, kap haar af en gooi haar weg van jou af; dit is vir jou beter om in die lewe in te gaan, kreupel of vermink, as om twee hande of voete te hê en in die ewige vuur gewerp te word.	",
"	9 En as jou oog jou laat struikel, ruk haar uit en werp haar weg van jou af. Dit is vir jou beter om met een oog in die lewe in te gaan, as om twee oë te hê en in die helse vuur gewerp te word.	",
"	10 Pas op dat julle nie een van hierdie kleintjies verag nie; want Ek sê vir julle dat hulle Boodskappers in die Hemele altyd die Aangesig sien van My VADER wat in die Hemele is.	",
"	11 Want die Seun van die Adam het gekom om te red wat verlore is.	",
"	12 Wat dink julle? As ‘n man honderd skape het en een van hulle verdwaal, sal hy nie die nege-en-negentig laat staan en op die berge die verdwaalde een gaan soek nie?	",
"	13 En as hy hom kry, voorwaar Ek sê vir julle dat hy blyer is oor hom as oor die nege-en-negentig wat nie verdwaal het nie.	",
"	14 So is dit nie die Wil van julle Vader wat in die Hemele is, dat een van hierdie kleintjies verlore gaan nie.	",
		
		
"	15 EN as jou broeder teen jou oortree, gaan bestraf hom tussen jou en hom alleen. As hy na jou luister, dan het jy jou broeder gewin;	",
"	16 maar as hy nie luister nie, neem nog een of twee met jou saam, sodat in die mond van twee of drie getuies elke woord kan vasstaan.	",
"	17 En as hy na hulle nie luister nie, sê dit aan die gemeente; en as hy na die gemeente ook nie luister nie, laat hom vir jou wees soos die inboorling en die tollenaar.	",
"	18 Voorwaar Ek sê vir julle, alles wat julle op die Aarde bind, sal in die Hemele gebonde wees; en alles wat julle op die Aarde ontbind, sal in die Hemele ontbonde wees.	",
"	19 Weer sê Ek vir julle: As twee van julle saamstem op die Aarde oor enige saak wat hulle mag vra, dit sal hulle ten deel val van My VADER wat in die Hemele is.	",
"	20 Want waar twee of drie in My Naam vergader, daar is Ek in hul midde.	",
"	21 Toe kom Petrus na Hom en sê: Meester, hoe dikwels sal my broeder teen my oortree en ek hom vergewe? Tot sewe maal toe?	",
"	22 JaHWèshua antwoord hom: Ek sê vir jou, nie tot sewe maal toe nie, maar tot sewentig maal sewe toe.	",
"	23 Daarom word die Koninkryk van die Hemele vergelyk met ’n sekere meester wat met sy diensknegte wou afreken.	",
"	24 En toe hy begin afreken, word daar een na hom gebring wat tienduisend talente skuldig was.	",
"	25 En omdat hy nie kon betaal nie, gee sy meester bevel dat hy verkoop moet word, en sy vrou en sy kinders en alles wat hy het, en dat betaal moet word.	",
"	26 Toe val die dienskneg neer en buig voor hom en sê: meester wees lankmoedig met my, en ek sal u alles betaal.	",
"	27 En die meester van daardie dienskneg het innig jammer vir hom gevoel en hom losgelaat en hom die skuld kwytgeskeld.	",
"	28 Maar toe daardie dienskneg uitgaan en een van sy medediensknegte vind wat hom honderd pennings skuldig was, het hy hom aan die keel gegryp en gesê: Betaal my wat jy skuld.	",
"	29 Sy mededienskneg val toe voor sy voete neer en smeek hom en sê: Wees lankmoedig met my, en ek sal jou alles betaal.	",
"	30 En hy wou nie, maar het gegaan en hom in die gevangenis gewerp totdat hy die skuld sou betaal het.	",
"	31 En toe sy medediensknegte sien wat gebeur het, was hulle baie bedroef, en hulle het gegaan en aan hulle meester meegedeel alles wat gebeur het.	",
"	32 Daarop roep sy meester hom en sê vir hom: Jou besoedelde dienskneg, al daardie skuld het ek jou kwytgeskeld, omdat jy my gesmeek het;	",
"	33 moes jy nie jou mededienskneg ook barmhartig wees soos ek jou ook barmhartig gewees het nie?	",
"	34 En sy meester het hom in toorn oorgegee aan die pynigers totdat hy sou betaal het alles wat hy hom skuldig was.	",
"	35 So sal ook My Hemelse VADER aan julle doen as julle nie elkeen sy broeder van harte sy oortredinge vergewe nie.	",

]
},
{
book: 'Mattithjahûw',
chapter: '19',
content: [
		
"	1 EN toe JaHWèshua hierdie Woorde geëindig het, het Hy van Galiléa vertrek en in die gebied van JeHûWdah oorkant die Jordaan gekom.	",
"	2 En groot menigtes het Hom gevolg, en Hy het hulle daar gesond gemaak.	",
"	3 Toe kom die Fariseërs na Hom om Hom te versoek, en sê vir Hom: Is dit ’n man geoorloof om oor allerhande redes van sy vrou te skei?	",
"	4 En Hy antwoord hulle en sê: Het julle nie gelees dat Hy wat hulle gemaak het, hulle van die begin af man en vrou gemaak het nie,	",
"	5 en gesê het: Om hierdie rede sal die man sy vader en sy moeder verlaat en sy vrou aankleef, en hulle twee sal een vlees wees; [Génesis 2:24]	",
"	6 sodat hulle nie meer twee is nie, maar een vlees? Wat Elohim dan saamgevoeg het, mag geen adamiet skei nie.	",
"	7 Hulle sê vir Hom: Waarom het Moshè dan beveel om ’n skeibrief te gee en van haar te skei?	",
"	8 Hy antwoord hulle: Omdat Moshè weens die hardheid van jul harte julle toegelaat het om van julle vroue te skei; maar van die begin af was dit nie so nie.	",
"	9 Maar Ek sê vir julle, elkeen wat van sy vrou skei, behalwe oor verbastering, en die ander een trou, pleeg [die oortreding van] vermenging; en die wat die geskeie vrou trou, vermeng. [Exodus 20:14]	",
"	10 Sy studente sê vir Hom: As die saak van ’n man met ’n vrou so is, dan is dit nie wenslik om te trou nie.	",
"	11 Maar Hy sê vir hulle: Almal vat hierdie Woord nie, maar net dié aan wie dit gegee is.	",
"	12 Want daar is ontmandes wat onbekwaam is om te trou, wat van die moederskoot af so gebore is, en daar is ontmandes wat deur die mense onbekwaam gemaak is, en daar is ontmandes wat hulleself onbekwaam gemaak het ter wille van die Koninkryk van die Hemele. Wie dit kan vat, laat hom dit vat. [JeshaJaH 56:3]	",
		
		
"	13 TOE bring hulle kindertjies na Hom, dat Hy hulle die hande sou oplê en bid; en die studente het hulle bestraf.	",
"	14 Maar JaHWèshua sê: Laat die kindertjies staan en verhinder hulle nie om na My te kom nie; want aan sulkes behoort die Koninkryk van die Hemele.	",
"	15 En Hy het hulle die hande opgelê en daarvandaan vertrek.	",
		
		
"	16 EN daar kom een na Hom en sê vir Hom: Goeie Meester, watter goeie ding moet ek doen, dat ek die Ewige Lewe kan hê?	",
"	17 En Hy sê vir hom: Waarom noem jy My goed? Niemand is goed nie, behalwe EEN, naamlik die Elohim. Maar as jy in die lewe wil ingaan, onderhou die Gebooie. [NegemJaH 1:7]	",
"	18 Hy vra Hom: Watter? En JaHWèshua sê - dit: Jy mag nie moor nie, Jy mag nie vermeng nie, Jy mag nie steel nie, jy mag geen valse getuienis spreek nie; [Exodus 20:13, 14, 15, 16; Deuteronómium 5:17, 18, 20]	",
"	19 eer jou vader en moeder; en: Jy moet jou naaste liefhê soos jouself. [Exodus 20:13, Levítikus 19:18]	",
"	20 Die jongman sê vir Hom: Al hierdie dinge het ek onderhou van my jeug af. Wat kom ek nog kort?	",
"	21 JaHWèshua antwoord hom: As jy volmaak wil wees, gaan verkoop jou goed en gee dit aan die armes, en jy sal ’n skat in die Hemele hê; en kom hier, VOLG MY.	",
"	22 Maar toe die jongman dié Woord hoor, het hy bedroef weggegaan; want hy het baie besittings gehad.	",
"	23 En JaHWèshua sê vir Sy studente: Voorwaar Ek sê vir julle dat ’n ryk man beswaarlik in die Koninkryk van die Hemele sal ingaan.	",
"	24 En verder sê Ek vir julle, dit is makliker vir ’n skeepstou om deur die oog van ’n naald te gaan as vir ’n ryk man om in die Koninkryk van die Elohim in te gaan.	",
"	25 Toe Sy studente dit hoor, was hulle baie verslae en sê: Wie kan dan gered word?	",
"	26 Maar JaHWèshua het hulle aangekyk en vir hulle gesê: By mense is dit onmoontlik, maar by Elohim is alle dinge moontlik.	",
"	27 Daarop antwoord Petrus en sê vir Hom: Kyk, ons het alles verlaat en U gevolg. Wat sal daar dan vir ons wees?	",
"	28 En JaHWèshua sê vir hulle: Voorwaar Ek sê vir julle dat julle wat My gevolg het, in die wederoprigting van die wêreld wanneer die Seun van die Adam op Sy Glansryke Troon gaan sit, julle ook op twaalf trone sal sit en die twaalf stamme van JisraEl sal oordeel. [Psalm 122:5; Openbaring 4:11; 20:4]	",
"	29 En elkeen wat huise of broers of susters of vader of moeder of vrou of kinders of grond ter wille van My Naam verlaat het, sal honderd maal soveel ontvang en die Ewige Lewe beërwe.	",
"	30 Maar baie wat eerste is, sal laaste wees, en wat laaste is, eerste.	",

]
},
{
book: 'Mattithjahûw',
chapter: '20',
content: [
		
"	1 WANT die Koninkryk van die Hemele is soos ’n Man wat ‘n Eienaar is wat vroeg in die môre uitgegaan het om arbeiders vir Sy Wingerd te huur.	",
"	2 En nadat Hy met die arbeiders ooreengekom het vir ’n penning op ’n dag, stuur Hy hulle in Sy Wingerd.	",
"	3 En omtrent die derde uur gaan Hy uit en sien ander ledig op die mark staan.	",
"	4 En Hy sê vir hulle: Gaan julle ook in die Wingerd, en wat reg is, sal Ek aan julle gee. En hulle het gegaan.	",
"	5 Weer het Hy omtrent die sesde en die negende uur uitgegaan en net dieselfde gedoen.	",
"	6 En omtrent die elfde uur gaan Hy uit en vind ander ledig staan en sê vir hulle: Wat staan julle hier die hele dag ledig?	",
"	7 Hulle antwoord Hom: Omdat niemand ons gehuur het nie. Hy sê vir hulle: Gaan julle ook in die Wingerd, en wat reg is, sal julle ontvang.	",
"	8 En toe dit aand geword het, sê die Meester van die Wingerd vir Sy Opsigter: Roep die arbeiders en betaal hulle hul loon; en begin van die laastes af tot by die eerstes.	",
"	9 En die wat omtrent die elfde uur begin het, het gekom en elkeen ’n penning ontvang.	",
"	10 Die eerstes kom toe en dink dat hulle meer sal ontvang, en hulle het ook elkeen ’n penning ontvang.	",
"	11 En toe hulle dit ontvang, protesteer hulle by die Eienaar	",
"	12 en sê: Hierdie laastes het een uur gewerk, en U het hulle gelykop behandel met ons wat die las van die dag en die hitte gedra het.	",
"	13 Maar Hy antwoord en sê vir een van hulle: Vriend, Ek doen jou geen onreg aan nie. Het jy nie met My ooreengekom vir ’n penning nie?	",
"	14 Neem dan wat joune is, en gaan heen. Ek wil aan hierdie laaste een gee net soos aan jou.	",
"	15 Of staan dit My nie vry om met My eie goed te maak wat Ek wil nie? Of is jou oog besoedel, omdat Ek goed is?	",
"	16 So sal die wat laaste is, eerste wees, en die wat eerste is, laaste; want baie is geroep, maar min uitverkies.	",
		
		
"	17 EN toe JaHWèshua opgaan na Jerusalem, het Hy die twaalf studente op die pad alleen geneem en vir hulle gesê:	",
"	18 Kyk, ons gaan op na Jerusalem, en die Seun van die Adam sal oorgelewer word aan die owerpriesters en skrywers en hulle sal Hom tot die dood veroordeel	",
"	19 en Hom oorlewer aan die nasies om Hom te bespot en te gésel en te folter; en op die derde dag sal Hy opstaan.	",
"	20 Toe kom die moeder van die seuns van Sebedéüs met haar seuns na Hom en buig voor Hom neer om iets van Hom te vra.	",
"	21 En Hy sê vir haar: Wat wil jy hê? Sy antwoord Hom: Sê dat hierdie twee seuns van my in U Koninkryk mag sit, een aan U regter- en een aan U linkerhand.[Wysheid van Sirah 7:4]	",
"	22 Maar JaHWèshua antwoord en sê: Julle weet nie wat julle vra nie. Kan julle die Beker drink wat Ek aanstons gaan drink, en gewas/gedoop word met die wassing/doop waarmee Ek gewas/gedoop word? Hulle sê vir Hom: Ons kan.	",
"	23 En Hy sê vir hulle: Dit is die Waarheid, My Beker sal julle drink en met die wassing/doop waarmee Ek gewas/gedoop word, sal julle gewas/gedoop word; maar om te sit aan My regter- en aan My linkerhand berus nie by My om te gee nie, maar is vir hulle vir wie dit deur My VADER berei is.	",
"	24 En toe die tien dit hoor, was hulle verontwaardig oor die twee broers.	",
"	25 Maar JaHWèshua het hulle na Hom geroep en gesê. Julle weet dat die owerstes van die nasies oor hulle heers en die magtiges oor hulle gesag uitoefen;	",
"	26 maar só moet dit onder julle nie wees nie; maar elkeen wat onder julle groot wil word, moet julle dienaar wees.	",
"	27 En elkeen wat onder julle die eerste wil word, moet julle dienskneg wees;	",
"	28 net soos die Seun van die Adam nie gekom het om gedien te word nie, maar om te dien en Sy Siel te gee as ’n losprys vir baie.	",
		
		
"	29 EN toe hulle uit Jérigo uitgaan, het ’n groot menigte Hom gevolg.	",
"	30 En daar het twee blindes langs die pad gesit; en toe hulle hoor dat JaHWèshua verbygaan, roep hulle uit en sê: Wees ons barmhartig, Meester, Seun van Dawid!	",
"	31 En die skare het hulle bestraf, dat hulle moes stilbly; maar hulle het al harder geroep en gesê: Wees ons barmhartig, Meester, Seun van Dawid!	",
"	32 Toe gaan JaHWèshua staan en roep hulle en sê: Wat wil julle hê moet Ek vir julle doen?	",
"	33 Hulle antwoord Hom: Meester, dat ons oë geopen mag word.	",
"	34 En JaHWèshua het innig jammer vir hulle gevoel en hulle oë aangeraak, en dadelik het hulle oë gesien, en hulle het Hom gevolg.	",

]
},
{
book: 'Mattithjahûw',
chapter: '21',
content: [
		
"	1 EN toe hulle naby Jerusalem gekom en Bétfagé aan die Berg van die Olywe bereik het, stuur JaHWèshua twee studente uit en sê vir hulle:	",
"	2 Gaan na daardie dorp reg voor julle, en dadelik sal julle ’n eselin vind wat vasgemaak is, en ’n vul by haar. Maak haar los en bring hulle vir My.	",
"	3 En as iemand vir julle iets sê, moet julle antwoord: Die Meester het hulle nodig; en dadelik sal hy hulle stuur.	",
"	4 En dit het alles gebeur, sodat vervul sou word die Woord wat deur die Profeet gespreek is:	",
"	5 Sê vir die Dogter van Sion: Kyk, Jou Koning kom na Jou; regverdig en ’n oorwinnaar is Hy, nederig en Hy ry op ’n esel - op ’n jong esel, die vul van ’n eselin. [ZekarJaH 9:9]	",
"	6 En die studente het gegaan en gedoen soos JaHWèshua hulle beveel het;	",
"	7 hulle het die esel en die vul gebring en hulle klere daarop gelê, en Hy het daarop gaan sit.	",
"	8 En die grootste deel van die skare het hulle klere op die pad oopgegooi, en ander het takke van die bome afgekap en op die pad gestrooi.	",
"	9 En die skare wat voor geloop en die wat gevolg het, het uitgeroep en gesê: Jashà-na vir die Seun van Dawid! Geseënd is Hy wat kom in die Naam van JaHWeH! Jashà-na in die Hoogste El! [Psalm 118:26]	",
"	10 En toe Hy in Jerusalem inkom, het die hele Stad in opskudding geraak en gesê: Wie is hierdie man?	",
"	11 En die skare sê: Dit is JaHWèshua, die Profeet, van Násaret in Galiléa.	",
		
		
"	12 EN JaHWèshua het in die Tempel van die Elohim ingegaan en almal wat in die Tempel verkoop en koop, uitgejaag en die tafels van die geldwisselaars en die stoele van die duiweverkopers omgegooi.	",
"	13 En Hy sê vir hulle: Daar is geskrywe: My Huis sal ’n Huis van gebed genoem word. Maar julle het hom ’n rowerspelonk gemaak. [JeshaJaHûW 56:7, JirmeJaHûW 7:11]	",
"	14 En daar het blindes en kreupeles na Hom gekom in die Tempel, en Hy het hulle gesond gemaak.	",
"	15 En toe die owerpriesters en skrywers die wonderwerke sien wat Hy gedoen het, en die kinders wat in die Tempel uitroep en sê: Jashà-na vir die Seun van Dawid! was hulle verontwaardig	",
"	16 en sê vir Hom: Hoor U wat hulle daar sê? En JaHWèshua antwoord hulle: Ja, het julle nooit gelees: Uit die mond van kinders en suigelinge het U sterkte gegrondves [om U teëstanders ontwil, om die vyand en wraakgierige stil te maak]. [Psalm 8:2]	",
"	17 En Hy het hulle verlaat en uit die Stad uitgegaan na Betánië en daar vernag.	",
		
		
"	18 EN vroeg in die môre toe Hy teruggaan na die Stad, het Hy honger gehad;	",
"	19 en Hy sien ’n Vyeboom langs die pad en gaan daarnatoe; maar Hy het niks aan haar gevind nie as net blare alleen; en Hy sê vir haar: Laat daar uit jou tot in ewigheid nooit weer ’n vrug kom nie! En onmiddellik het die Vyeboom verdroog.	",
"	20 En toe die studente dit sien, was hulle verwonderd en sê: Hoe het die Vyeboom so onmiddellik verdroog?	",
"	21 Maar JaHWèshua antwoord en sê vir hulle: Voorwaar Ek sê vir julle, as julle Geloof het en nie twyfel nie, sal julle nie alleen doen wat met die Vyeboom gebeur het nie; maar al sê julle ook vir hierdie berg: Hef jou op en werp jou in die see - sal dit gebeur.	",
"	22 En alles wat julle in die gebed vra, sal julle ontvang as julle glo.	",
"	23 EN toe Hy in die Tempel gegaan het, kom die owerpriesters en die oudstes van die volk na Hom terwyl Hy besig was om te leer, en hulle sê: Deur watter gesag doen U hierdie dinge, en wie het U hierdie gesag gegee?	",
"	24 En JaHWèshua antwoord en sê vir hulle: Ek sal julle ook een ding vra, en as julle dit vir My sê, sal Ek julle ook vertel deur watter gesag Ek hierdie dinge doen.	",
"	25 Die wassing/doop van JeHôWganan, waar was dit vandaan, uit die Hemele of uit mense? En hulle het by hulleself geredeneer en gesê: As ons sê: Uit die Hemele - dan sal Hy ons vra: Waarom het julle hom dan nie geglo nie?	",
"	26 En as ons sê: Uit mense - dan moet ons oppas vir die menigte, want almal hou JeHôWganan vir ’n Profeet.	",
"	27 Toe antwoord hulle JaHWèshua en sê: Ons weet nie. Hy sê toe ook vir hulle: Dan vertel Ek julle ook nie deur watter gesag Ek hierdie dinge doen nie.	",
"	28 Maar wat dink julle? ’n Man het twee Kinders gehad, en Hy gaan na die eerste en sê: Kind, gaan werk vandag in My Wingerd.	",
"	29 En hy antwoord en sê: Ek wil nie; maar later het hy berou gekry en gegaan.	",
"	30 Toe het Hy na die tweede gegaan en vir hom net so gesê; en hy antwoord en sê: Ja, Vader. En hy het nie gegaan nie.	",
"	31 Wie van die twee het die wil van die Vader gedoen? Hulle antwoord Hom: Die eerste. JaHWèshua sê vir hulle: Voorwaar Ek sê vir julle, die tollenaars en die hoere gaan julle voor in die Koninkryk van die Elohim.	",
"	32 Want JeHôWganan het na julle gekom in die Weg van Geregtigheid, en julle het hom nie geglo nie; maar die tollenaars en die hoere het hom geglo. En julle het dit gesien en tog nie later berou gekry om hom te glo nie.	",
		
		
"	33 LUISTER na ’n ander gelykenis: Daar was ’n Man wat ‘n Eienaar van ‘n Huis was, wat ’n Wingerd geplant het; en Hy het ’n heining om Haar gesit en ’n parskuip in Haar gegrawe en ’n Wagtoring gebou, en Hy het Haar aan landbouers verhuur en op reis gegaan. [JeshaJaHûW 5]	",
"	34 En toe die vrugtetyd nader kom, stuur Hy Sy diensknegte na die landbouers om Sy vrugte te ontvang.	",
"	35 Maar die landbouers het Sy diensknegte geneem en een geslaan en ’n ander een doodgemaak en ’n ander een gestenig.	",
"	36 Weer het Hy ander diensknegte gestuur, meer as die eerstes, en hulle het met dié net so gemaak.	",
"	37 Oplaas het Hy Sy Seun na hulle gestuur en gesê: Hulle sal My Seun hoogag.	",
"	38 Maar toe die landbouers die Seun sien, het hulle onder mekaar gesê: Hy is die Erfgenaam; kom laat ons hom doodmaak en Sy Erfdeel in besit neem.	",
"	39 En hulle het Hom geneem en buitekant die Wingerd uitgewerp en doodgemaak.	",
"	40 Wanneer die Eienaar van die Wingerd dan kom, wat sal Hy met daardie landbouers doen?	",
"	41 Hulle antwoord Hom: Hy - Hy sal daardie verbasterde mense met ’n siekte vernietig en die Wingerd verhuur aan ander landbouers wat Hom die vrugte op die regte tyd sal gee.	",
"	42 JaHWèshua sê vir hulle: Het julle nooit in die Skrifte gelees nie: Die Klip wat die bouers verwerp het, Sy het ’n Hoeksteen geword. Sy het van JaHWeH gekom, Sy is wonderbaar in ons oë? [Psalm 118:22,23]	",
"	43 Daarom sê Ek vir julle: Die Koninkryk van die Elohim sal van julle weggeneem en aan ’n volk gegee word wat die vrugte van Haar sal dra.	",
"	44 En hy wat op hierdie Klip val, sal verpletter word; maar elkeen op wie Sy val, dié sal Sy verpoeier. [Deuteronómium 4:13 ; JeshaJaHûW 8:14,15]	",
"	45 En toe die owerpriesters en die Fariseërs Sy gelykenisse hoor, het hulle begryp dat Hy van hulle spreek.	",
"	46 En hulle het probeer om Hom in hulle mag te kry, maar hulle was bang vir die skare, omdat dié Hom vir ’n Profeet gehou het.	",
		

]
},
{
book: 'Mattithjahûw',
chapter: '22',
content: [
		
"	1 EN JaHWèshua het weer deur gelykenisse met hulle begin spreek en gesê:	",
"	2 Die Koninkryk van die Hemele is soos ’n Koning wat ’n Bruilof vir Sy Seun berei het	",
"	3 en Sy diensknegte uitgestuur het om die genooides na die Bruilof te roep, en hulle wou nie kom nie.	",
"	4 Weer het Hy ander diensknegte uitgestuur met die boodskap: Sê vir die genooides: Kyk, My maaltyd het Ek berei, My beeste en vetgemaakte vee is geslag en alles is gereed. Kom na die Bruilof.	",
"	5 Maar hulle het hul daaraan nie gesteur nie en weggegaan, een na sy eie stuk grond en ’n ander na sy handelsaak.	",
"	6 En die oorblyfsel het Sy diensknegte gegryp en mishandel en doodgemaak.	",
"	7 Toe die Koning dit hoor, het Hy kwaad geword en Sy manskappe gestuur en daardie moordenaars omgebring en hulle Stad aan die brand gesteek.	",
"	8 Daarop sê Hy vir Sy diensknegte: Die Bruilof is wel gereed, maar die genooides was haar nie werd nie.	",
"	9 Gaan dan op die paaie en nooi almal wat julle mag vind, na die Bruilof. [JirmeJaH 31:8; 2 Ezra 13:13]	",
"	10 En daardie diensknegte het uitgegaan op die Paaie en almal versamel wat hulle gevind het, besoedelde sowel as suiweres, en die Bruilofsaal het vol gaste geword.	",
"	11 En toe die Koning ingaan om na die gaste te kyk, sien Hy daar ‘n adamiet wat nie ’n bruilofskleed aan het nie.	",
"	12 En Hy sê vir hom: Vriend, hoe het jy hier ingekom sonder ’n bruilofskleed aan? En hy kon geen woord sê nie.	",
"	13 Toe sê die Koning vir Sy dienaars: Bind sy hande en voete, neem hom weg en werp hom in die buitenste Duisternis. Daar sal geween wees en gekners van die tande.	",
"	14 Want baie is geroep, maar min uitverkies.	",
		
		
"	15 TOE gaan die Fariseërs saam raad hou hoe om Hom in Sy woord te verstrik.	",
"	16 En hulle stuur hul studente saam met die Herodiane na Hom en sê: Meester, ons weet dat U waaragtig is en die Weg van Elohim in Waarheid leer en U aan niemand steur nie, want U sien nie die persoon van mense aan nie -	",
"	17 sê dan vir ons, wat dink U: Is dit geoorloof om aan die keiser belasting te betaal of nie?	",
"	18 Maar JaHWèshua het hulle verdorwenheid bemerk en gesê: Tweegesigte, waarom versoek julle My?	",
"	19 Wys My die belastingmunt. En hulle het vir Hom ’n penning gebring.	",
"	20 En Hy sê vir hulle: Wie se beeld en opskrif is dit?	",
"	21 Hulle antwoord Hom: Die keiser s’n. Daarop sê Hy vir hulle. Betaal dan aan die keiser wat die keiser toekom, en aan Elohim wat Elohim toekom.	",
"	22 En toe hulle dit hoor, was hulle verwonderd en het Hom verlaat en weggegaan.	",
		
		
"	23 DIESELFDE dag kom daar na Hom Sadduseërs, hulle wat sê dat daar geen opstanding is nie, en vra Hom	",
"	24 en sê: Meester, Moshè het gesê: As iemand sonder kinders sterwe, moet sy broer sy vrou trou en ’n nageslag grootmaak vir sy broer.	",
"	25 Nou was daar by ons sewe broers, en die eerste het getrou en gesterwe; en omdat hy geen nageslag gehad het nie, het hy sy vrou vir sy broer agtergelaat.	",
"	26 So ook die tweede en die derde tot die sewende toe.	",
"	27 En laaste van almal het die vrou ook gesterwe.	",
"	28 In die opstanding dan, van watter een van die sewe sal sy die vrou wees - want hulle almal het haar gehad?	",
"	29 Toe antwoord JaHWèshua en sê vir hulle: Julle dwaal, omdat julle die Skrifte nie ken nie en ook nie die Krag van Elohim nie.	",
"	30 Want in die opstanding trou hulle nie en word ook nie in die huwelik uitgegee nie, maar is soos Boodskappers van die Elohim in die Hemele. [Boekrol van Henog 15:7]	",
"	31 En wat die opstanding van die dode betref - het julle nie die Woord gelees wat tot julle deur die Elohim gespreek is nie:	",
"	32 Ek [is] die Elohey van Abraham die Elohey van Isak en Elohey van Jakob? En JaHWeH is nie ’n Elohey van dooies nie, maar ‘n Elohey van lewendes. [Exodus 3:6]	",
"	33 En toe die skare dit hoor, was hulle verslae oor Sy leer.	",
		
		
"	34 EN toe die Fariseërs hoor dat Hy die Sadduseërs die mond gestop het, het hulle almal saam vergader.	",
"	35 En een van hulle, ’n wetsvertolker, het ’n vraag gestel om Hom te versoek en gesê:	",
"	36 Meester, wat is die groot Gebod in die Wet?	",
"	37 En JaHWèshua antwoord hom: Jy moet jou Elohey liefhê met jou hele hart en met jou hele siel en met jou hele verstand.	",
"	38 Dit is die eerste en groot Gebod.	",
"	39 En die tweede wat hiermee gelykstaan: Jy moet jou naaste liefhê soos jouself.	",
"	40 Aan hierdie twee Gebooie hang die hele Wet en die Profete.	",
		
		
"	41 EN toe die Fariseërs saamgekom het, vra JaHWèshua hulle	",
"	42 en sê: Wat dink julle van die Gesalfde? Wie se seun is Hy? Hulle antwoord Hom: Dawid s’n.	",
"	43 Hy sê vir hulle: Hoe is dit dan dat Dawid Hom in die Gees my Meester noem as hy sê:	",
"	44 JaHWeH het tot my Meester gespreek: Sit aan My regterkant, totdat Ek U vyande maak ’n Voetbank vir U voete. [Psalm 110:1]	",
"	45 As Dawid Hom dan my Meester noem, hoe is Hy sy seun?	",
"	46 En niemand kon Hom ’n woord antwoord nie; ook het geeneen van daardie dag af dit meer gewaag om Hom vrae te stel nie.	",

]
},
{
book: 'Mattithjahûw',
chapter: '23',
content: [
		
"	1 TOE het JaHWèshua die skare en Sy studente toegespreek [JeségiEl 34]	",
"	2 en gesê: Die skrywers en die Fariseërs sit op die stoel van Moshè.	",
"	3 Alles wat hulle dan vir julle mag sê om te onderhou, onderhou en doen dit; maar volgens hulle werke moet julle nie doen nie, want hulle praat en doen nie.	",
"	4 Want hulle bind pakke saam wat swaar en moeilik is om te dra, en sit dit op die skouers van die mense, maar self wil hulle dit nie met hulle vinger verroer nie. [JirmeJaH 8:17]	",
"	5 En hulle doen al hul werke om deur die mense gesien te word, en hulle maak hul gedenkseëls breed en die some van hul klere groot.	",
"	6 En hulle hou van die voorste plekke by die maaltye en die voorste banke in die vergaderings	",
"	7 en die begroetinge op die markte en om deur die mense genoem te word: my Rabbi(leermeester), my Rabbi!	",
		
		
"	8 MAAR julle, laat julle jul nie my agbare noem nie, want een is julle leermeester: Die Gesalfde, en julle is almal broers.	",
"	9 En julle moet niemand op die Aarde julle vader noem nie, want een is julle Vader, Hy wat in die Hemele is. [Exodus 20:12]	",
"	10 Julle moet julle ook nie leermeesters laat noem nie, want een is julle leermeester: Die Gesalfde.	",
"	11 Maar die grootste van julle moet jul dienaar wees.	",
"	12 Wie homself verhoog, sal verneder word, en wie homself verneder, sal verhoog word.	",
		
		
"	13 MAAR wee julle, skrywers en Fariseërs, tweegesigte, want julle sluit die Koninkryk van die Hemele toe voor die adamiete, want julle gaan self nie in nie, en die wat sou ingaan, laat julle nie toe om in te gaan nie.	",
"	14 Wee julle, skrywers en Fariseërs, tweegesigte, want julle eet die huise van die weduwees op, en doen vir die skyn lang gebede. Daarom sal julle ’n swaarder oordeel ontvang.	",
"	15 Wee julle, skrywers en Fariseërs, tweegesigte, want julle trek rond oor see en Aarde om een bekeerling te maak; en as hy dit geword het, maak julle hom ’n kind van die hel, twee maal erger as julle self.	",
"	16 Wee julle, blinde leiers, julle wat sê: Elkeen wat sweer by die Tempel - dit is niks nie; maar elkeen wat sweer by die goud van die Tempel, hy is gebonde.	",
"	17 Julle dwase en blindes, want wat is meer: die goud, of die Tempel wat die goud wy?	",
"	18 En: Elkeen wat sweer by die altaar - dit is niks nie; maar elkeen wat sweer by die gawe daar bo-op, hy is gebonde.	",
"	19 Julle dwase en blindes, want wat is meer: die bydrae, of die altaar wat die bydrae wy?	",
"	20 Wie dan sweer by die altaar, sweer dáárby en by alles wat daarop is;	",
"	21 en wie sweer by die Tempel, sweer dáárby en by Hom wat daarin woon;	",
"	22 en wie sweer by die Hemele, sweer by die Troon van Elohim en by HOM wat daarop sit.	",
"	23 Wee julle, skrywers en Fariseërs, tweegesigte, want julle gee tiendes van kruisement en anys en koljander, en die swaarste van die Wet laat julle ná: die Reg en die Barmhartigheid en die Geloof. Hierdie dinge behoort julle te doen sonder om die ander na te laat.	",
"	24 Blinde leiers, julle wat die muggie uitsif, maar die kameel insluk!	",
"	25 Wee julle, skrywers en Fariseërs, tweegesigte, want julle suiwer die buitekant van die beker en die skottel, maar binnekant is sy vol roof en sonder selfbeheersing.	",
"	26 Blinde Fariseër, suiwer eers die binnekant van die beker en die skottel, sodat ook die buitekant van haar skoon kan word.	",
"	27 Wee julle, skrywers en Fariseërs, tweegesigte, want julle is net soos gewitte grafte wat van buite wel fraai lyk, maar van binne vol doodsbene en allerhande besmetlikheid is.	",
"	28 So lyk julle ook van buite vir die adamiete wel opreg, maar van binne is julle vol bedrog en ongeregtigheid.	",
"	29 Wee julle, skrywers en Fariseërs, tweegesigte, want julle bou die grafte van die profete en versier die grafstene van die regverdiges;	",
"	30 en julle sê: As ons in die dae van ons vaders geleef het, sou ons geen deel met hulle gehad het aan die bloed van die Profete nie.	",
"	31 Julle gee dus teen julself getuienis dat julle kinders is van die wat die Profete vermoor het.	",
"	32 Maak die maat van julle vaders dan vol!	",
"	33 Slange, genetiese nageslag van Nagash/slang, hoe sal julle die oordeel van die hel ontvlug?	",
"	34 Daarom, kyk, Ek stuur Profete en wyse manne en skrywers na julle toe, en julle sal sommige van hulle doodmaak en folter en sommige van hulle in jul vergaderings gésel en van die een stad na die ander vervolg,	",
"	35 sodat oor julle kan kom al die regverdige bloed, wat vergiet is op die Aarde, van die bloed van die regverdige Abel af tot op die bloed van ZekarJaH, die seun van BeregJah, wat julle vermoor het tussen die Tempel en die altaar. [2 Ezra 1:32]	",
"	36 Voorwaar Ek sê vir julle, al hierdie dinge sal oor hierdie saadlyn kom.	",
"	37 Jerusalem, Jerusalem, jy wat die Profete doodmaak en stenig dié wat na jou gestuur is, hoe dikwels wou Ek jou kinders bymekaarmaak net soos ’n hen haar kuikens onder die vlerke bymekaarmaak, en julle wou nie! [2 Ezra 1:30]	",
"	38 Kyk, julle Huis word vir julle woes gelaat!	",
"	39 Want Ek sê vir julle: Julle sal My van nou af sekerlik nie sien nie totdat julle sal sê: Geseënd is Hy wat kom in die Naam van JaHWeH! [Psalm 118:26]	",
		

]
},
{
book: 'Mattithjahûw',
chapter: '24',
content: [
		
"	1 EN JaHWèshua het uitgegaan en van die Tempel vertrek, en Sy studente het nader gekom om Hom die geboue van die Tempel te wys.	",
"	2 En JaHWèshua sê vir hulle: Sien julle al hierdie dinge? Voorwaar Ek sê vir julle, daar sal hier sekerlik nie een klip op die ander gelaat word, wat nie afgebreek sal word nie.	",
"	3 En toe Hy op die Berg van die Olywe gaan sit het, kom die studente alleen na Hom en sê: Vertel ons, wanneer sal hierdie dinge wees, en wat is die Teken van U koms en van die voleinding van die tyd?	",
"	4 En JaHWèshua antwoord en sê vir hulle: Pas op dat niemand julle mislei nie.	",
"	5 Want baie sal onder My Naam kom en sê: Ek is die Gesalfde! en hulle sal baie mislei.	",
"	6 En julle sal hoor van oorloë en gerugte van oorloë. Pas op, moenie verskrik word nie, want alles moet plaasvind, maar dit is nog nie die einde nie.	",
"	7 Want die een nasie sal teen die ander opstaan en die een koninkryk teen die ander; en daar sal hongersnode wees en pessiektes en aardbewings op verskillende plekke. [2 Ezra 6:24; 9:3]	",
"	8 Maar al hierdie dinge is ’n begin van die smarte. [Boekrol van Henog 1:1]	",
"	9 Dan sal hulle jul aan verdrukking oorgee en julle doodmaak; en julle sal deur al die nasies gehaat word ter wille van My Naam.	",
"	10 En dan sal baie tot struikel gebring word en mekaar verraai en mekaar haat.	",
"	11 En baie valse profete sal opstaan en baie mense mislei.	",
"	12 En omdat die ongeregtigheid vermeerder word sal die liefde van die meeste verkoel. [2 Ezra 5:2]	",
"	13 Maar wie volhard tot die einde toe, hy sal gered word. [2 Ezra 9:7]	",
"	14 En hierdie goeie tyding van die Koninkryk sal verkondig word in die hele wêreld tot ’n getuienis vir al die nasies; en dan sal die einde kom.	",
		
		
		
		
"	15 WANNEER julle dan die gruwel van die verwoesting, waarvan gespreek is deur die Profeet DaniEl, sien staan in die Apartheidsplek - laat hy wat lees, verstaan - [DaniEl 11:31]	",
"	16 dan moet die wat in JeHûWdah is, na die berge vlug;	",
"	17 wie op die dak is, moet nie afkom om iets uit sy huis weg te neem nie;	",
"	18 en wie op die land is, moet nie omdraai om sy klere weg te neem nie. [Ezra 16:43]	",
"	19 Maar wee die vroue wat swanger is en die wat nog soog, in daardie dae.	",
"	20 En bid dat julle vlug nie in die winter of op die Sabbat mag plaasvind nie.	",
"	21 Want dan sal daar groot verdrukking wees soos daar van die begin van die wêreld af tot nou toe nie gewees het en ook nooit sal wees nie.	",
"	22 En as daardie dae nie verkort was nie, sou geen vlees gered word nie; maar ter wille van die uitverkorenes sal daardie dae verkort word.	",
"	23 As iemand dán vir julle sê: Kyk, hier is die Gesalfde! of: Daar! - moet dit nie glo nie.	",
"	24 Want daar sal valse gesalfdes en valse profete opstaan, en hulle sal groot tekens en wonders doen om, as dit moontlik was, ook die uitverkorenes te mislei.	",
"	25 Kyk, Ek het dit vir julle vooruit gesê.	",
"	26 As hulle dan vir julle sê: Kyk, Hy is in die wildernis - moenie uitgaan nie; kyk, Hy is in die binnekamer - moet dit nie glo nie.	",
"	27 Want soos die weerlig uit die ooste uitslaan en tot in die weste skyn, so sal ook die koms van die Seun van die Adam wees.	",
"	28 Want oral waar die dooie liggaam lê, daar sal die aasvoëls saamkom.	",
		
		
"	29 EN dadelik ná die verdrukking van daardie dae sal die son verduister word, en die maan sal haar glans nie gee nie, en die Sterre sal van die Hemele val, en die kragte van die Hemele sal geskud word.	",
"	30 En dan sal die Teken van die Seun van die Adam in die Hemele verskyn, en dan sal al die stamme van die Aarde rou bedryf en die Seun van die Adam sien kom op die Wolkkolom van die Hemele met groot Krag en Glansrykheid. [JeségiEl 1 en 10]	",
"	31 En Hy sal Sy Boodskappers uitstuur met harde geluid van ramshoring, en hulle sal Sy uitverkorenes versamel uit die vier windstreke, van die een einde van die Hemele af tot die ander einde daarvan.	",
"	32 En leer van die Vyeboom hierdie gelykenis: Wanneer Haar tak al sag word en Haar blare uitbot, weet julle dat die somer naby is. [Númeri 17:8; Hooglied van Salomo 2:13]	",
"	33 So weet julle ook, wanneer julle ál hierdie dinge sien, dat sy naby is, voor die deur.	",
"	34 Voorwaar Ek sê vir julle, hierdie saadlyn sal sekerlik nie tot niet gaan voordat al hierdie dinge gebeur het nie.	",
"	35 Die Hemele en die Aarde sal verbygaan, maar My Woorde sal nooit verbygaan nie.	",
		
		
"	36 MAAR van dié dag en dié uur weet niemand nie, ook die Boodskappers van die Hemele nie, maar net My VADER alleen.	",
"	37 En net soos die dae van Noag was, so sal ook die koms van die Seun van die Adam wees. [Boekrol van Henog 83:9]	",
"	38 Want net soos hulle was in die dae voor die vloed toe hulle geëet en gedrink het, getrou en in die huwelik uitgegee het, tot op die dag dat Noag in die Ark gegaan het,	",
"	39 en dit nie verstaan het voordat die vloed gekom en almal weggevoer het nie, so sal ook die koms van die Seun van die Adam wees. [Boekrol van Henog 7:5]	",
"	40 Dan sal daar twee op die Aarde wees; die een word aangeneem en die ander word verlaat.	",
"	41 Twee vroue sal by die meul maal; die een word aangeneem en die ander word verlaat.	",
"	42 Waak dan, omdat julle nie weet watter uur julle Meester kom nie.	",
"	43 Maar weet dit: as die eienaar geweet het in watter nagwaak die dief sou kom, sou hy gewaak en nie toegelaat het dat in sy huis ingebreek word nie.	",
"	44 Daarom moet julle ook gereed wees, want die Seun van die Adam kom op ’n uur dat julle dit nie verwag nie.	",
		
		
"	45 WIE is dan die getroue en wyse dienskneg vir wie sy Meester oor Sy diensvolk aangestel het om hulle hul voedsel op tyd te gee?	",
"	46 Geseënd is daardie dienskneg vir wie sy Meester, as Hy kom, op hierdie manier besig sal vind.	",
"	47 Voorwaar Ek sê vir julle, Hy sal hom oor al Sy besittings aanstel.	",
"	48 Maar as daardie verdraaide dienskneg in sy hart sê: My Meester talm om te kom -	",
"	49 en hy sy medediensknegte begin slaan en saam met die dronkaards begin eet en drink,	",
"	50 dan sal die Meester van dié dienskneg kom op ’n dag dat hy dit nie verwag nie en op ’n uur dat hy dit nie weet nie;	",
"	51 en sal hom pynig en hom ’n deelgenoot van die tweegesigte maak. Daar sal geween wees en gekners van die tande.	",

]
},
{
book: 'Mattithjahûw',
chapter: '25',
content: [
		
"	1 DAN sal die Koninkryk van die Hemele wees soos tien maagde wat hulle lampe geneem en uitgegaan het om die Bruidegom te ontmoet. [Psalm 45:15]	",
"	2 En vyf van hulle was wys en vyf dwaas.	",
"	3 En toe die wat dwaas was, hul lampe neem, het hulle geen olie met hulle saamgeneem nie.	",
"	4 Maar die wyses het olie in hulle kanne saam met hul lampe geneem.	",
"	5 En terwyl die Bruidegom talm om te kom, het hulle almal vaak geword en aan die slaap geraak.	",
"	6 En middernag was daar ’n geroep: Daar kom die Bruidegom; gaan uit hom tegemoet!	",
"	7 Toe staan al daardie maagde op en maak hulle lampe gereed.	",
"	8 En die wat dwaas was, sê aan die verstandiges: Gee vir ons van julle olie, want ons lampe gaan uit.	",
"	9 Maar die verstandiges antwoord en sê: Miskien sal daar nie genoeg wees vir ons en vir julle nie. Maar gaan liewer na die verkopers en koop vir julleself.	",
"	10 En onderwyl hulle gaan om te koop, het die Bruidegom gekom. En die wat gereed was, het saam met hom ingegaan na die Bruilof, en die deur is gesluit.	",
"	11 Later toe kom die ander maagde ook en sê: Meester, Meester, maak vir ons oop!	",
"	12 Maar hy antwoord en sê: Voorwaar Ek sê vir julle, Ek ken julle nie.	",
"	13 Waak dan, omdat julle die dag en die uur nie weet waarop die Seun van die Adam kom nie. [Psalm 37:7]	",
		
		
"	14 WANT dit is soos ’n Man wat op reis wou gaan en Sy diensknegte roep en aan hulle Sy besittings toevertrou.	",
"	15 En aan die een gee Hy vyf talente en aan die ander twee en aan die ander een, aan elkeen na sy vermoë; en Hy het dadelik op reis gegaan.	",
"	16 En die een wat die vyf talente ontvang het, het daarmee gaan werk en vyf ander talente gewin.	",
"	17 Net so het die een wat die twee ontvang het, self ook twee ander verdien.	",
"	18 Maar hy wat die een ontvang het, het in die Aarde gaan grawe en die geld van sy Meester weggesteek.	",
"	19 En ná ’n lang tyd het die Meester van daardie diensknegte gekom en met hulle afgereken.	",
"	20 En die een wat die vyf talente ontvang het, kom en bring vyf ander talente en sê: Meester, vyf talente het U aan my toevertrou; hier het ek vyf ander talente daarby verdien.	",
"	21 En sy Meester sê vir hom: Mooi so, suiwer en getroue dienskneg, oor weinig was jy getrou, oor veel sal Ek jou aanstel. Gaan in in die Vreugde van jou Meester.	",
"	22 En die een wat die twee talente ontvang het, kom ook en sê: Meester, twee talente het U aan my toevertrou; hier het ek twee ander talente daarby verdien.	",
"	23 Sy Meester sê vir hom: Mooi so, suiwer en getroue dienskneg, oor weinig was jy getrou, oor veel sal Ek jou aanstel. Gaan in in die Vreugde van jou Meester.	",
"	24 En die een wat die een talent ontvang het, kom ook en sê: Meester, ek het U geken, dat U ’n harde Man is wat maai waar U nie gesaai het nie, en bymekaarmaak waar U nie uitgestrooi het nie;	",
"	25 omdat ek bang was, het ek gegaan en U talent in die Aarde weggesteek. Hier het U wat aan U behoort.	",
"	26 Maar sy Meester antwoord en sê vir hom: Jou besoedelde en luie dienskneg, jy het geweet dat Ek maai waar Ek nie gesaai het nie, en bymekaarmaak waar Ek nie uitgestrooi het nie.	",
"	27 Daarom moes jy My geld by die wisselaars gestort het, en Ek sou by My koms wat aan My behoort, met rente ontvang het.	",
"	28 Neem dan die talent van hom weg en gee dit aan die een wat die tien talente het;	",
"	29 want aan elkeen wat het, sal gegee word, en hy sal oorvloed hê; maar van hom wat nie het nie, van hom sal weggeneem word ook wat hy het.	",
"	30 En werp die nuttelose dienskneg uit in die buitenste Duisternis; daar sal geween wees en gekners van die tande.	",
		
		
"	31 EN wanneer die Seun van die Adam in Sy Glansrykheid kom en al die Apartes [en] Boodskappers saam met Hom, dan sal Hy op Sy glansryke Troon sit; [Boekrol van Henog 55:4; MattithJaHûW 28:18; JeHôWganan 5:22; Openbaring 20:11]	",
"	32 en voor Hom sal al die nasies versamel word, en Hy sal hulle van mekaar afskei soos die herder die skape van die bokke afskei;	",
"	33 en Hy sal die skape aan Sy regterkant en die bokke aan Sy linkerkant sit. [JeségiEl 34:20]	",
"	34 Dan sal die Meester vir die wat aan Sy regterkant is, sê: Kom, julle geseëndes van My VADER, beërf die Koninkryk wat vir julle berei is van die grondlegging van die wêreld af.	",
"	35 Want Ek het honger gehad, en julle het My te ete gegee; Ek het dors gehad, en julle het My te drinke gegee; Ek was ’n vreemdeling, en julle het My herberg gegee;	",
"	36 Ek was naak, en julle het My geklee; Ek was siek, en julle het My besoek; in die gevangenis was Ek, en julle het na My gekom.	",
"	37 Dan sal die regverdiges Hom antwoord en sê: Meester, wanneer het ons U honger gesien en gevoed; of dors, en te drinke gegee?	",
"	38 En wanneer het ons U ’n vreemdeling gesien, en herberg gegee; of naak, en geklee?	",
"	39 En wanneer het ons U siek gesien of in die gevangenis, en na U gekom?	",
"	40 En die Meester sal antwoord en vir hulle sê: Voorwaar Ek sê vir julle, vir sover julle dit gedoen het aan een van die geringstes van hierdie broers van My, het julle dit aan My gedoen.	",
"	41 Dan sal Hy ook vir dié aan Sy linkerhand sê: Gaan weg van My, julle vervloektes, in die ewige vuur wat berei is vir die Satan en sy boodskappers.	",
"	42 Want Ek het honger gehad, en julle het My nie te ete gegee nie; Ek het dors gehad, en julle het My nie te drinke gegee nie.	",
"	43 Ek was ’n vreemdeling, en julle het vir My nie herberg gegee nie; naak, en julle het My nie geklee nie; siek en in die gevangenis, en julle het My nie besoek nie.	",
"	44 Dan sal hulle Hom ook antwoord en sê: Meester, wanneer het ons U honger gesien of dors of ’n vreemdeling of naak of siek of in die gevangenis, en U nie gedien nie?	",
"	45 Dan sal Hy hulle antwoord en sê: Voorwaar Ek sê vir julle, vir sover julle dit nie gedoen het aan een van hierdie geringstes nie, het julle dit aan My ook nie gedoen nie.	",
"	46 En hulle sal weggaan in die ewige straf, maar die regverdiges in die Ewige Lewe.	",

]
},
{
book: 'Mattithjahûw',
chapter: '26',
content: [
		
"	1 EN toe JaHWèshua al hierdie Woorde geëindig het, sê Hy vir Sy studente:	",
"	2 Julle weet dat oor twee dae die Pasga kom, dan word die Seun van die Adam oorgelewer om gefolter te word.	",
"	3 Toe kom die owerpriesters en die skrywers en die oudstes van die volk bymekaar in die paleis van die hoëpriester wat Kájafas genoem word,	",
"	4 en hou saam raad om JaHWèshua met lis gevange te neem en om die lewe te bring.	",
"	5 Maar hulle het gesê: Nie op die Fees nie, sodat daar nie miskien oproer onder die volk kom nie.	",
		
		
"	6 EN toe JaHWèshua in Betánië was in die huis van Simon, die melaatse,	",
"	7 kom ’n vrou na Hom met ’n albasterfles met baie kosbare salf, en sy gooi haar op Sy hoof uit terwyl Hy aan tafel was.	",
"	8 En toe Sy studente dit sien, was hulle verontwaardig en sê: Waarvoor is hierdie verkwisting?	",
"	9 Want hierdie salf kon duur verkoop en die geld aan die armes gegee geword het.	",
"	10 Maar toe JaHWèshua dit merk, sê Hy vir hulle: Waarom val julle die vrou lastig? Want sy het ’n goeie werk aan My gedoen.	",
"	11 Want die armes het julle altyd by julle, maar My het julle nie altyd nie.	",
"	12 Want toe sy hierdie salf op My liggaam uitgegooi het, het sy dit gedoen met die oog op My begrafnis.	",
"	13 Voorwaar Ek sê vir julle, oral waar hierdie goeie tyding verkondig sal word in die hele wêreld, sal ook gespreek word van wat sy gedoen het, tot ’n gedagtenis aan haar.	",
		
		
"	14 TOE gaan een van die twaalf, met die naam van Judas Iskáriot, na die owerpriesters	",
"	15 en sê: Wat wil u my gee, en ek sal Hom aan u oorlewer? En hulle het vir hom dertig silwerstukke afgeweeg.	",
"	16 En van toe af het hy ’n goeie geleentheid gesoek om Hom oor te lewer.	",
		
		
"	17 EN voor die Fees van die Ongesuurde Brode kom die studente na JaHWèshua en sê vir Hom: Waar wil U hê moet ons vir U klaarmaak om die Pasga te eet?	",
"	18 En Hy antwoord: Gaan na die Stad na ’n sekere iemand en sê vir hom: Die Meester laat weet: My tyd is naby. By jou sal Ek die Pasga hou met My studente.	",
"	19 Daarop het die studente gedoen soos JaHWèshua hulle beveel het, en hulle het die Pasga berei.	",
"	20 En toe dit aand geword het, was Hy met die twaalf aan tafel.	",
"	21 En terwyl hulle eet, sê Hy: Voorwaar Ek sê vir julle, een van julle sal My verraai.	",
"	22 Toe word hulle baie bedroef en begin elkeen van hulle aan Hom te sê: Is dit miskien ek, Meester?	",
"	23 Toe antwoord Hy en sê: Hy wat saam met My sy hand in die skottel insteek, hy sal My verraai.	",
"	24 Die Seun van die Adam gaan wel heen soos daar van Hom geskrywe is, maar wee daardie man deur wie die Seun van die Adam verraai word! Dit sou vir hom goed gewees het as daardie man nie gebore was nie. [Psalm 69]	",
"	25 En Judas, wat Hom sou verraai, antwoord en sê: Is dit miskien ek, my Meester? Hy antwoord hom: Jy het dit gesê.	",
"	26 En terwyl hulle eet, neem JaHWèshua die Brood, en nadat Hy gedank het, breek Hy Hom en gee Hom aan Sy studente en sê: Neem, eet, Hy is My liggaam. [Boekrol van die Opregte 16:11]	",
"	27 Toe neem Hy die Beker, en nadat Hy gedank het, gee Hy Haar aan hulle en sê: Drink almal uit Haar.	",
"	28 Want Sy is My Bloed, die Bloed van die Nuwe Verbond, wat vir baie uitgestort word tot vergifnis van oortredinge. [Psalm 30:9]	",
"	29 Maar Ek sê vir julle: Ek sal van nou af nooit meer van hierdie Vrug van die Wingerdstok drink nie, tot op daardie dag wanneer Ek Haar met julle nuut sal drink in die Koninkryk van My VADER.	",
"	30 En nadat hulle die lofsang gesing het, het hulle uitgegaan na die Berg van die Olywe.	",
		
		
"	31 TOE sê JaHWèshua vir hulle: Julle sal almal in hierdie nag aanstoot neem aan My, want daar is geskrywe: Slaan die Herder, sodat die skape verstrooi word, [en Ek sal My Hand weer uitstrek oor die geringes]. [ZekarJaH 13:7]	",
"	32 Maar nadat Ek opgestaan het, sal Ek voor julle uit na Galiléa gaan.	",
"	33 Daarop antwoord Petrus en sê vir Hom: Al sal almal ook aanstoot aan U neem, ek sal nooit aanstoot neem nie.	",
"	34 JaHWèshua sê vir hom: Voorwaar Ek sê vir jou, in hierdie nag, voordat die haan gekraai het, sal jy drie maal teen My getuig.	",
"	35 Petrus sê vir Hom: Al moes ek ook saam met U sterwe, ek sal nooit teen U getuig nie! So het ook al die studente gesê.	",
		
		
"	36 TOE kom JaHWèshua met hulle in ’n plek met die naam van Getsémané, en Hy sê vir die studente: Sit hier onderwyl Ek daar gaan bid.	",
"	37 En Hy neem Petrus en die twee seuns van Sebedéüs saam en begin bedroef en benoud word.	",
"	38 Toe sê Hy vir hulle: My Siel is diep bedroef tot die dood toe; bly hier en waak saam met My.	",
"	39 En Hy het ’n bietjie verder gegaan en op Sy aangesig geval en gebid en gesê: My VADER, as dit moontlik is, laat hierdie Beker by My verbygaan; nogtans nie soos Ek wil nie, maar soos U wil.	",
"	40 En Hy kom by die studente en vind hulle aan die slaap, en Hy sê vir Petrus: So was julle dan nie in staat om een uur saam met My te waak nie?	",
"	41 Waak en bid, dat julle nie in versoeking kom nie. Die gees is wel gewillig, maar die vlees is swak.	",
"	42 Weer het Hy vir die tweede maal gaan bid en gesê: My VADER, as hierdie beker nie by My kan verbygaan sonder dat Ek haar drink nie, laat U wil geskied.	",
"	43 Toe kom Hy en vind hulle weer aan die slaap, want hulle oë was swaar.	",
"	44 En Hy het hulle met rus gelaat en weer vir die derde maal gaan bid en dieselfde Woorde gesê.	",
"	45 Daarop kom Hy by Sy studente en sê vir hulle: Slaap maar voort en rus. Kyk, die uur is naby, en die Seun van die Adam word oorgelewer in die hande van oortreders.	",
"	46 Staan op, laat ons gaan; kyk, hy is naby wat My verraai.	",
		
		
"	47 EN terwyl Hy nog spreek, daar kom Judas, een van die twaalf, en saam met hom ’n groot menigte met swaarde en stokke, gestuur deur die owerpriesters en oudstes van die volk.	",
"	48 En Sy verraaier het vir hulle ’n teken gegee en gesê: Die een wat ek sal soen, dit is Hy, gryp Hom!	",
"	49 En dadelik gaan hy na JaHWèshua en sê: Gegroet, my Meester! en hy het Hom gesoen.	",
"	50 Maar JaHWèshua sê vir hom: Vriend, waarvoor is jy hier? Toe kom hulle nader en slaan die hande aan JaHWèshua en gryp Hom.	",
"	51 En een van die wat saam met JaHWèshua was, het meteens sy hand uitgesteek en sy swaard getrek; en hy het die dienskneg van die hoëpriester geslaan en sy oor afgekap.	",
"	52 Toe sê JaHWèshua vir hom: Sit jou swaard in sy plek terug; want almal wat die swaard neem, sal deur die swaard vergaan.	",
"	53 Of dink jy dat Ek nie nou in staat is om My VADER te smeek en HY vir My meer as twaalf legioene van Boodskappers beskikbaar sal stel nie?	",
"	54 Hoe sou die Skrifte dan vervul word dat dit so moet gebeur?	",
"	55 In daardie uur het JaHWèshua vir die skare gesê: Het julle soos teen ’n rower uitgekom met swaarde en stokke om My gevange te neem? Dag vir dag het Ek by julle gesit en leer in die Tempel, en julle het My nie gegryp nie.	",
"	56 Maar dit het alles gebeur, dat die Skrifte van die Profete vervul sou word. Toe het al die studente Hom verlaat en gevlug. [Génesis 3:15]	",
		
		
"	57 EN die wat JaHWèshua gevange geneem het, het Hom weggelei na Kájafas, die hoëpriester, waar die skrywers en die oudstes vergader het.	",
"	58 En Petrus het Hom van ver af gevolg tot by die paleis van die hoëpriester, en hy het ingegaan en by die dienaars gaan sit om die einde te sien.	",
"	59 En die owerpriesters en die oudstes en die hele Raad het valse getuienis teen JaHWèshua gesoek om Hom dood te maak, en niks gevind nie.	",
"	60 En alhoewel daar baie valse getuies gekom het, het hulle niks gevind nie.	",
"	61 Maar oplaas kom daar twee valse getuies en sê: Hierdie man het gesê: Ek kan die Tempel van die Elohim afbreek en dit in drie dae opbou.	",
"	62 Daarop staan die hoëpriester op en sê vir Hom: Antwoord U niks nie? Wat getuig hierdie manne teen U?	",
"	63 Maar JaHWèshua het stilgebly. En die hoëpriester antwoord en sê vir Hom: Ek besweer U by die lewende Elohim dat U vir ons sê of U die Gesalfde, die Seun van die Elohim, is?	",
"	64 JaHWèshua antwoord hom: U het dit gesê. Maar Ek sê vir u almal: Van nou af sal u die Seun van die Adam sien sit aan die regterkant van die Krag, en kom met die Wolkkolom van die Hemele.	",
"	65 Toe verskeur die hoëpriester Sy klere en sê: Hy het lasterlike dinge tot Elohim gespreek, wat het ons nog getuies nodig? Kyk, nou het julle Sy besoedelde en oneervolle uitsprake gehoor!	",
"	66 Wat dink julle? En hulle antwoord en sê: Hy is die Dood skuldig.	",
"	67 Toe het hulle in Sy aangesig gespuug en Hom met die vuis geslaan,	",
"	68 en ander het Hom met stokke geslaan en gesê: Profeteer vir ons, Gesalfde! Wie is dit wat Jou geslaan het?	",
		
		
"	69 EN Petrus het buitekant gesit in die binneplaas van die paleis, en ’n sekere diensmeisie het na hom gekom en gesê: Jy was ook by JaHWèshua, die Galiléër!	",
"	70 Maar hy het dit voor almal ontken en gesê: Ek weet nie wat jy sê nie.	",
"	71 En terwyl hy uitgaan na die poort toe, sien ’n ander diensmeisie hom en sê aan die wat daar was: Hierdie een was ook by JaHWèshua, die Nasaréner.	",
"	72 En met ’n eed ontken hy dit weer: Ek ken die man nie.	",
"	73 Maar ’n bietjie later kom die wat daar staan, en sê vir Petrus: Waarlik, jy is ook een van hulle, want ook jou spraak maak jou bekend.	",
"	74 Toe begin hy homself te verwens en te sweer: Ek ken die man nie.	",
"	75 En dadelik het die haan gekraai, en Petrus het die Woord van JaHWèshua onthou wat Hy vir hom gesê het: Voor die haan kraai, sal jy drie maal teen My getuig. En hy het buitentoe gegaan en bitterlik geween.	",

]
},
{
book: 'Mattithjahûw',
chapter: '27',
content: [
		
"	1 En toe dit dag geword het, het al die owerpriesters en die oudstes van die volk saam raad gehou teen JaHWèshua om Hom dood te maak.	",
"	2 En hulle het Hom geboei en weggelei en Hom oorgelewer aan Pontius Pilatus, die goewerneur.	",
"	3 Daarna het Judas, Sy verraaier, toe hy sien dat Hy veroordeel was, berou gekry en die dertig silwerstukke teruggebring na die owerpriesters en die oudstes	",
"	4 en gesê: Ek het oortree deur onskuldige bloed te verraai. Maar hulle sê: Wat gaan dit ons aan? Jy kan toesien!	",
"	5 En hy het die silwerstukke in die Tempel neergegooi en weggeloop en homself gaan ophang.	",
"	6 En die owerpriesters het die silwerstukke geneem en gesê: Dit is nie geoorloof om dit in die skatkis te stort nie, omdat dit bloedgeld is.	",
"	7 En nadat hulle saam raad gehou het, het hulle die stuk grond van die pottebakker daarmee gekoop as ’n begraafplaas vir vreemdelinge.	",
"	8 Daarom is dié stuk grond genoem Bloedgrond, tot vandag toe.	",
"	9 Toe is vervul wat gespreek is deur ZekarJaH, die Profeet, toe hy gesê het: Toe het hulle My loon afgeweeg: dertig silwerstukke - die duursame prys waarmee Ek deur hulle gewaardeer is! - vanweë die kinders van JisraEl; [ZekarJaH 11:12,13]	",
"	10 en hulle het dit gegee vir die deel van die grond van die pottebakker, soos JaHWeH my beveel het. [ZekarJaH 11:13]	",
		
		
"	11 EN JaHWèshua het voor die goewerneur gestaan, en die goewerneur het Hom die vraag gestel en gesê: Is U die Koning van die JeHûWdah? En JaHWèshua antwoord hom: U sê dit.	",
"	12 En terwyl Hy deur die owerpriesters en die oudstes beskuldig word, het Hy niks geantwoord nie.	",
"	13 Toe sê Pilatus vir Hom: Hoor U nie hoe baie dinge hulle teen U getuig nie?	",
"	14 En Hy het hom op geen enkele woord geantwoord nie, sodat die goewerneur hom baie verwonder het.	",
"	15 En op die Fees was die goewerneur gewoond om een gevangene, die een wat hulle wou hê, vir die skare los te laat.	",
"	16 En in daardie tyd het hulle ’n berugte gevangene gehad met die naam van Barábbas. [Levítikus 16:16]	",
"	17 Nadat hulle dan byeengekom het, sê Pilatus vir hulle: Wie wil julle hê moet ek vir julle loslaat: Barábbas, of JaHWèshua wat genoem word die Gesalfde? [Levítikus 16]	",
"	18 Want hy het geweet dat hulle Hom uit nydigheid oorgelewer het.	",
"	19 En terwyl hy op die regbank sit, het sy vrou na hom gestuur en gesê: Moet tog niks te doen hê met dié regverdige Man nie, want ek het vandag in ’n droom baie gely om Sy ontwil.	",
"	20 Maar die owerpriesters en die oudstes het die skare oorgehaal dat hulle Barábbas moes kies en JaHWèshua ombring.	",
"	21 Toe antwoord die goewerneur en sê vir hulle: Wie van die twee wil julle hê moet ek vir julle loslaat? En hulle antwoord: Barábbas!	",
"	22 Pilatus sê vir hulle: Wat moet ek dan doen met JaHWèshua wat genoem word die Gesalfde? Hulle sê almal vir hom: Laat Hom gefolter word!	",
"	23 En die goewerneur sê: Wat het Hy dan verkeerd gedoen? Maar hulle skreeu nog harder en sê: Laat Hom gefolter word!	",
"	24 En toe Pilatus sien dat niks help nie, maar dat daar eerder ’n oproer kom, het hy water geneem en sy hande voor die skare gewas en gesê: Ek is onskuldig aan die bloed van hierdie regverdige Man; julle kan toesien!	",
		
		
"	25 EN die hele volk antwoord en sê: Laat Sy bloed op ons en op ons kinders kom!	",
"	26 Toe laat hy vir hulle Barábbas los, maar JaHWèshua het hy laat gésel en oorgelewer om gefolter te word.	",
"	27 Daarop neem die soldate van die goewerneur JaHWèshua met hulle saam in die goewerneur se paleis en bring die hele leërafdeling teen Hom bymekaar.	",
"	28 Toe trek hulle Sy klere uit en werp ’n rooi mantel om Hom;	",
"	29 en hulle vleg ’n kroon van dorings en sit haar op Sy hoof, en ’n riet in Sy regterhand; en hulle val op hul knieë voor Hom en bespot Hom en sê: Wees gegroet, Koning van die JeHûWdah!	",
"	30 En hulle spuug op Hom en neem die riet en slaan Hom op Sy hoof. [Psalm 129:3; JeshaJaH 50:6; Markus 14:65; Boodskap van Petrus 1:9]	",
"	31 En nadat hulle Hom bespot het, trek hulle Hom die mantel uit en trek Hom Sy klere aan en lei Hom weg om gefolter te word. [Psalm 22:13]	",
		
		
"	32 EN toe hulle uitgaan, kry hulle ’n man van Ciréne, met die naam van Simon; hom het hulle gedwing om Sy folterpaal te dra.	",
"	33 En hulle het gekom op ’n plek wat Ghulgholeth genoem word - dit beteken: Plek van die Hoofskedel -	",
"	34 en vir Hom wyn, met gal gemeng, gegee om te drink; en toe Hy dit proe, wou Hy nie drink nie.	",
"	35 En nadat hulle Hom gefolter het, het hulle Sy klere verdeel deur die lot te werp, sodat vervul sou word wat deur die Profeet gespreek is: Hulle verdeel My klere onder mekaar en werp die lot oor My gewaad. [Psalm 22:18]	",
"	36 En hulle het gaan sit en Hom daar bewaak.	",
"	37 En bokant Sy hoof het hulle Sy beskuldiging in skrif opgestel: DIT is JAHWÈSHUA, DIE KONING VAN DIE MANNE VAN JEHÛWDAH.	",
"	38 Toe word daar saam met Hom twee rowers gefolter, een aan die regter- en een aan die linkerkant.	",
"	39 En die verbygangers het Hom gesmaad terwyl hulle hul hoofde skud [Psalm 22:8]	",
"	40 en sê: U wat die Tempel afbreek en in drie dae opbou, red Uself! As U die Seun van Elohim is, kom af van die folterpaal!	",
"	41 En so het ook die owerpriesters saam met die skrywers en oudstes gespot en gesê:	",
"	42 Ander het Hy verlos, Homself kan Hy nie verlos nie. As Hy die Koning van JisraEl is, laat Hom nou van die folterpaal afkom, en ons sal in Hom glo.	",
"	43 Hy het Elohim vertrou; laat HY Hom nou verlos as HY behae in Hom het; want Hy het gesê: Ek is die Seun van die Elohim.	",
"	44 En op dieselfde manier het die rowers wat saam met Hom gefolter was, Hom ook beledig.	",
"	45 En van die sesde uur af het daar duisternis gekom oor die hele Aarde tot die negende uur toe;	",
"	46 en omtrent die negende uur het JaHWèshua met ’n groot stem geroep en gesê: Eli, Eli, LAMMA AZABAGTANI ? Dit is: My El, My El, waarom het U My verlaat? [Psalm 22:1; 143:7]	",
"	47 En sommige van die wat daar staan, hoor dit en sê: Hy roep EliJaHûW.	",
"	48 Toe hardloop daar dadelik een van hulle en neem ’n spons en maak dit vol asyn, en sit dit op ’n riet en laat Hom drink.	",
"	49 Maar die ander sê: Wag, laat ons sien of EliJaHûW kom om Hom te verlos.	",
"	50 Daarop het JaHWèshua weer met ’n groot stem geroep en die gees gegee.	",
"	51 En kyk, die voorhangsel van die Tempel het in twee geskeur, van bo tot onder, en die Aarde het gebewe en die rotse het geskeur; [Exodus 26:31 ; Hebreërs 10:10]	",
"	52 en die grafte het oopgegaan en baie liggame van die ontslape Apartes het opgestaan.	",
"	53 En ná Sy opstanding het hulle uit die grafte uitgegaan en in die Stad van Apartheid ingekom en aan baie verskyn.	",
"	54 En toe die hoofman oor honderd en die wat saam met hom JaHWèshua bewaak het, die aardbewing sien en die dinge wat daar gebeur, het hulle baie bevrees geword en gesê: Waarlik, Hy was die Seun van die Elohim.	",
"	55 En daar was baie vroue wat dit van ver af aanskou het, wat vir JaHWèshua van Galiléa af gevolg en Hom gedien het.	",
"	56 Onder hulle was daar Mirjam die Migdalieth2 en Mirjam, die moeder van Jakobus en Joses, en die moeder van die seuns van Sebedéüs.	",
		
		
"	57 EN toe dit aand geword het, het daar ’n ryk man van Arimathéa gekom met die naam van JôWsef, wat self ook ’n student van JaHWèshua was.	",
"	58 Hy het na Pilatus gegaan en die liggaam van JaHWèshua gevra. Toe beveel Pilatus dat die liggaam afgegee moes word.	",
"	59 En JôWsef het die liggaam geneem en dit met skoon linne toegedraai	",
"	60 en dit in sy nuwe graf gelê wat hy in die rots uitgekap het; en nadat hy ’n groot steen teen die opening van die graf gerol het, het hy weggegaan.	",
"	61 En Mirjam die Migdalieth was daar en die ander Mirjam, en hulle het reg voor die graf gesit.	",
"	62 Die volgende dag - dit is die dag ná die voorbereiding - kom die owerpriesters en die Fariseërs by Pilatus saam	",
"	63 en sê: My meester, ons herinner ons dat dié verleier, toe hy in die lewe was, gesê het: Oor drie dae staan Ek op.	",
"	64 Gee dan bevel dat die graf verseker word tot die derde dag toe, dat Sy studente nie miskien in die nag kom en Hom steel nie, en vir die volk sê: Hy het opgestaan uit die dode. En die laaste dwaling sal erger wees as die eerste.	",
"	65 Daarop sê Pilatus vir hulle: Julle sal ’n wag kry; gaan verseker dit soos julle dit verstaan.	",
"	66 En hulle het gegaan en die graf verseker deur die steen te verseël in teenwoordigheid van die wag.	",

]
},
{
book: 'Mattithjahûw',
chapter: '28',
content: [
		
"	1 EN laat ná die sabbat toe dit begin lig word, teen die eerste [dag] van die week, kom Mirjam die Migdalieth en die ander Mirjam om na die graf te gaan kyk.	",
"	2 En daar kom ’n groot aardbewing, want ’n Boodskapper van JaHWeH het uit die Hemele neergedaal en gekom en die steen van die opening weggerol en daarop gaan sit.	",
"	3 En sy gedaante was soos weerlig en sy kleding wit soos sneeu.	",
"	4 En uit vrees vir hom het die wagte gebewe en soos dooies geword.	",
"	5 Maar die Boodskapper antwoord en sê vir die vroue: Moenie vrees nie, want ek weet julle soek JaHWèshua wat gefolter is.	",
"	6 Hy is nie hier nie, want Hy het opgestaan soos Hy gesê het. Kom kyk na die plek waar die Meester gelê het;	",
"	7 en gaan haastig, sê vir Sy studente: Hy het opgestaan uit die dode en gaan voor julle uit na Galiléa. Daar sal julle Hom sien. Kyk, ek het julle dit gesê.	",
"	8 En hulle het haastig weggegaan van die graf met vrees en groot blydskap, en gehardloop om dit aan Sy studente te vertel.	",
"	9 En terwyl hulle op weg was om dit aan Sy studente te vertel, kom JaHWèshua hulle meteens teë en sê: Wees gegroet! Toe kom hulle nader aan Hom en val neer en gryp Sy voete.	",
"	10 En JaHWèshua sê vir hulle: Moenie vrees nie. Gaan heen en vertel My broers dat hulle na Galiléa moet gaan; en daar sal hulle My sien.	",
		
		
"	11 EN terwyl hulle op weg was, kom daar sommige van die wag in die stad en vertel die owerpriesters alles wat gebeur het.	",
"	12 En nadat hulle saam met die oudstes vergader en raad gehou het, het hulle die soldate baie geld gegee	",
"	13 en gesê: Julle moet sê: Sy studente het in die nag gekom en Hom gesteel terwyl ons aan die slaap was.	",
"	14 En as dit by die goewerneur gehoor word, sal ons hom tevrede stel en maak dat julle sonder sorg is.	",
"	15 Hulle het toe die geld geneem en gedoen soos hulle geleer was. En hierdie verhaal is versprei onder die Jode, tot vandag toe.	",
		
		
"	16 EN die elf studente het na Galiléa gegaan, na die berg waar JaHWèshua hulle bestel het.	",
"	17 En toe hulle Hom sien, het hulle neergeval voor Hom; maar sommige het getwyfel.	",
"	18 En JaHWèshua het nader gekom en met hulle gespreek en gesê: Aan My is gegee alle mag in die Hemele en op Aarde. [Boekrol van Henog 55:4; 69:27; DaniEl 4:25; MattithJaHûW 25:31; JeHôWganan 5:22; 13:10; 1 JeHôWganan 3:3]	",
"	19 Gaan dan heen, maak studente van al die [My3] nasies, en was/doop hulle in die Naam4 van die VADER en die Seun en die Gees van die Apartheid; en leer hulle om alles te onderhou wat Ek julle beveel het. [Psalm 51:2; JeshaJaH 1:16]	",
"	20 En kyk, Ek is met julle al die dae tot aan die voleinding van die tyd. Amein.	",

]
}

];
