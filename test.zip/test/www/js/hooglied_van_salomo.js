const hooglied_van_salomoChapters = [

{
book: 'Hooglied_Van_Salomo',
chapter: '1',
content: [

"	1 DIE hooglied van Salomo.	",
"	2 Laat Hy My kus met kusse van Sy Mond; want U liefde is suiwerder as wyn.	",
"	3 Die aroma van U salf is suiwer, U Naam is soos salf wat uitgegiet is; daarom het die maagde U lief.	",
"	4 Trek My agter U aan, laat Ons gou maak! Die Koning het My in Sy binnekamers gebring. Ons wil juig en Ons in U verheug, Ons wil U liefde prys meer as wyn. Met Reg het hulle U lief.	",
"	5 Ek is swart, maar lieflik, o Dogters van Jerusalem, soos die tente van Kedar1, soos die gordyne van Salomo. [Klaagliedere 4:7-8, Klaagliedere 5:2]	",
"	6 Moenie na My kyk omdat Ek so swart is, omdat die Son My verbrand het nie: die Seuns van My Moeder was toornig op My; hulle het My aangestel as oppasser van die Wingerde; My eie Wingerd het Ek nie opgepas nie. [Odes van Salomo 15:6]	",
"	7 Vertel My tog, wie My Siel liefhet, waar laat U wei, waar laat U smiddags die vee lê en rus? Want waarom sou Ek wees soos een wat Haar met ’n sluier toedraai by die kuddes van U metgeselle?	",
"	8 As U dit self nie weet nie, mooiste onder die vroue, gaan dan uit op die spore van die skape en laat U bokkies wei by die Tabernakels van die herders.	",
"	9 Met die perde voor ’n wa van Farao vergelyk Ek U, My vriendin!	",
"	10 Lieflik is U wange tussen die kettinkies, U hals in die snoere.	",
"	11 Ons sal vir U goue kettinkies maak met silwerknoppe.	",
"	12 So lank as die Koning aan Sy tafel was, het My nardus Sy aroma gegee.	",
"	13 My Beminde is vir My ’n bossie mirre wat tussen My borste rus.	",
"	14 My Beminde is vir My ’n tros hennablomme in die Wingerde van Éngedi. [JeségiEl 47:10]	",
"	15 Hoe mooi is U tog, My vriendin! Hoe mooi is U tog, U oë is soos duiwe!	",
"	16 Hoe mooi is U tog, My Beminde, ja lieflik; ook is Ons bed in die groenigheid.	",
"	17 Die balke van Ons huise is seders, Ons paneelwerk sipresse.	",
	
]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '2',
content: [
		
"	1 EK is ’n roos van Saron, ’n lelie van die dale.	",
"	2 Soos ’n lelie tussen die dorings, so is My vriendin onder die Dogters. [2 Ezra 5:24; DaniEl 13:2]	",
"	3 Soos ’n appelboom onder die bome van die bos, so is My Beminde onder die Seuns. Ek het verlang om in Sy skaduwee te sit, en Sy vrugte is soet vir My verhemelte.	",
"	4 Hy het My in die wynhuis ingebring, en Sy vaandel oor My was die liefde.	",
"	5 Versterk My met rosynekoeke, verkwik My met appels, want Ek is krank van liefde.	",
"	6 Laat Sy linkerarm onder My hoof wees en Sy regterarm My omhels.	",
"	7 Ek besweer julle, Dogters van Jerusalem, by die gemsbokke of by die takbokke van die veld, om nie die liefde wakker te maak of op te wek voordat dit die [liefde] behaag nie.	",
"	8 Hoor, My Beminde, kyk, daar kom Hy! Hy spring oor die berge, Hy huppel oor die heuwels.	",
"	9 My Beminde lyk soos ’n gemsbok of soos ’n jong takbok. Daar staan Hy agter Ons muur! Hy kyk deur die vensters in, Hy speur deur die tralies heen. [Psalm 78:61; 88:11; 142:7; Odes van Salomo 21:2]	",
"	10 My Beminde begin toe en sê vir My: Staan op, My vriendin, My skone, kom dan tog!	",
"	11 Want kyk, die winter is verby, die reëntyd is oor, dit het verbygegaan.	",
"	12 Die bloeisels word gesien in die Aarde, die sangtyd het aangebreek, en die Tortelduif laat Haar Stem hoor in Ons Aarde.	",
"	13 Die Vyeboom laat Haar voorvye uitswel, en die Wingerdstokke wat bot, versprei aroma. Staan op, My vriendin, My skone, kom dan tog! [MattithJaHûW 24:32]	",
"	14 My Duif in die rotsklowe, in die skuilplek by die krans, laat My U gedaante sien, laat My U Stem hoor; want U Stem is soet, en U gedaante is lieflik.	",
"	15 Vang julle vir Ons die jakkalse, die klein jakkalse wat die Wingerde verniel, want Ons Wingerde staan in die bot.	",
"	16 My Beminde is Myne, en Ek is Syne wat Herder is onder die lelies.	",
"	17 Totdat die aandwind waai en die skaduwees vlug, kom aan, My Beminde, maak soos die gemsbok of soos die jong takbok op die berge van skeiding.	",
	
]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '3',
content: [
	
"	1 OP My bed snags het Ek na haar[Sy siel] gesoek, wie My Siel liefhet, Ek het na Hom gesoek, maar Hom nie gevind nie.	",
"	2 Ek wil dan opstaan en in die Stad rondgaan, in die strate en op die pleine wil Ek na haar soek[Sy siel], My Siel het haar[Sy siel] lief; Ek het na Hom gesoek, maar Hom nie gevind nie.	",
"	3 Die wagte wat in die Stad rondgaan, het My aangetref. Het julle haar[Sy siel] nie gesien wie My Siel liefhet nie?	",
"	4 Skaars het Ek van hulle af verder gegaan, of het Ek haar gevind[Sy siel] wie My Siel liefhet; Ek het Hom vasgehou en Hom nie gelos voordat Ek Hom gebring het in die Huis van My Moeder en in die binnekamer van Haar wat My gebaar het nie. [Profesie van Barug 4:21]	",
"	5 Ek besweer julle, Dogters van Jerusalem, by die gemsbokke of by die takbokke van die veld om nie die liefde wakker te maak, of op te wek voordat dit die liefde behaag nie.	",
"	6 Wie is daar wat daar opkom uit die wildernis soos rookpilare, gegeur met mirre en wierook, met allerhande speserye van die koopman?	",
"	7 Kyk, dit is die draagstoel van Salomo, sestig dapperes daarom vir Haar, van die dapperes van JisraEl,	",
"	8 hulle almal met ’n swaard gewapend, geoefend vir oorlog, elkeen met Sy swaard aan Sy heup vanweë die nagtelike verskrikking.	",
"	9 Koning Salomo het vir Hom ’n draagstoel gemaak van die hout van die Líbanon;	",
"	10 die steile daarvan het Hy gemaak van silwer, die leuning van goud, die sitplek van purper, die binnekant mooi opgemaak - ’n liefde [gawe] van die Dogters van Jerusalem.	",
"	11 Kom uit, Dogters van Sion, en aanskou met Vreugde die Koning Salomo, die Kroon waarmee Sy Moeder Hom bekroon het op Sy troudag en op die dag dat Sy hart vrolik is. [Boekrol van Henog 48:1; 2 Ezra 7:26; Spreuke 12:4]	",

]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '4',
content: [
	
"	1 HOE mooi is U tog, My vriendin, hoe mooi is U tog, U oë is soos duiwe deur U sluier heen; U hare is soos ’n kudde bokke wat van die gebergte van Gílead afgolf.	",
"	2 U tande is soos ’n kudde pas geskeerde [skape] wat van die drinkplek opkom, wat almal tweelinge het, en geeneen onder hulle is sonder lam nie.	",
"	3 U lippe is soos ’n skarlaken band, en U mond is lieflik. U slape is soos ’n granaatskyf deur U sluier heen.	",
"	4 U hals is soos die Dawidstoring, gebou met muurkranse waar die duisend skilde in hang, almal skilde van dapperes. [Die Profeet Miga 4:8; Spreuke van Salomo 18:10]	",
"	5 U twee borste is soos twee lammers, tweelinge van ’n gemsbok, wat onder die lelies wei.	",
"	6 Totdat die aandwind waai en die skaduwees vlug, sal Ek gaan na die mirreberg en na die wierookheuwel. [Wysheid van Sirah 24:15]	",
"	7 Alles is mooi aan U, My vriendin, en U is nie gekleurd nie.	",
"	8 Saam met My van die Líbanon af, Bruid, saam met My van die Líbanon af, o kom! Trek af van die top van Amána, van die top van Senir en van Hermon, van die lêplekke van die leeus, van die berge van die luiperds. [Deuteronómium 3:9]	",
"	9 U het My Hart gesteel, My Susterbruid, U het My Hart gesteel met een [straal] van U oë, met een kettinkie van U halssieraad.	",
"	10 Hoe skoon is U liefde, My Susterbruid, hoeveel beter is U liefde as wyn en die aroma van U salf as al die speserye!	",
"	11 Heuningstroop drup van U lippe af, Bruid, heuning en melk is onder U tong, en die aroma van U klere is soos die aroma van die Líbanon. [Odes van Salomo 30:4; JeshaJaH 51:3]	",
"	12 My susterbruid is ’n geslote Tuin, ’n geslote Bron, ’n verseëlde Fontein. [JeshaJaH 51:3]	",
"	13 U spruite is ’n park van granate met kostelike vrugte, hennablomme met nardus,	",
"	14 nardus en saffraan, kalmoes en kaneel, met allerhande wierookstruike, mirre en alewee, met allerhande kostelike speserye.	",
"	15 U is ’n Fontein van die tuine, ’n put met lewende water wat van die Líbanon afvloei. [JeHôWshua 4:7]	",
"	16 Word wakker, noordewind, en kom, suidewind, deurwaai My Tuin, laat Sy balsemgeure uitvloei! Laat My Beminde in Sy Tuin kom en van Sy kostelike vrugte eet.	",
	
]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '5',
content: [
		
"	1 EK het in My Tuin gekom, My susterbruid, Ek het My mirre met My balsem gepluk, Ek het geëet van My heuningkoek met My heuning, Ek het gedrink My wyn met My melk; eet, vriende, drink en word vrolik, bemindes. [2 Nikodémus 5:1]	",
"	2 Ek het geslaap, maar My Hart het gewaak. Hoor, My Beminde klop: Maak vir My oop, My suster, My vriendin, My Duif, My rasegte! Want My hoof is vol Dou, My haarlokke vol nagdruppels. [Psalm 74:18; 2 Ezra 2:15]	",
"	3 Ek het My kleed uitgetrek, hoe kan Ek hom weer aantrek? Ek het My voete gewas, hoe kan Ek hulle weer vuil maak? [JeHôWganan 13:8]	",
"	4 My Beminde het Sy hand deur die deuropening gesteek; toe het My binneste oor Hom in beroering gekom; [2 Nikodémus 5:1]	",
"	5 Ek het opgestaan om vir My Beminde oop te maak, terwyl My hande drup van mirre en My vingers van vloeiende mirre op die handpalms van die grendel. [Wysheid van Sirah 24:15]	",
"	6 Ek het vir My Beminde oopgemaak, maar My Beminde het weggedraai, verbygegaan; My Siel het uitgegaan toe Hy gespreek het; Ek het na Hom gesoek, maar Hom nie gevind nie; Ek het na Hom geroep, maar Hy het My nie geantwoord nie. [2 Ezra 10:1, 48; Odes van Salomo 21:6]	",
"	7 Die wagte wat in die Stad rondgaan, het My aangetref; hulle het My geslaan, My gewond; die wagte by die mure het My mantel van My afgeneem.	",
"	8 Ek besweer julle, Dogters van Jerusalem, as julle My Beminde vind, wat sal julle Hom vertel? Dat Ek krank is van liefde.	",
"	9 Wat is U Beminde meer as ’n ander beminde, o skoonste onder die vroue - wat is U Beminde meer as ’n ander beminde, dat U Ons so besweer het?	",
"	10 My Beminde is skitterend wit en rooi, uitnemender as tienduisend.	",
"	11 Sy hoof is soos erts van suiwer goud; Sy haarlokke is golwend, swart soos ’n raaf,	",
"	12 Sy oë soos duiwe by waterstrome, in melk gewas, sittend by ’n volle [bron].	",
"	13 Sy wange is soos balsembeddings, terrasbeddings van geurige plante; Sy lippe is lelies wat van vloeiende mirre drup.	",
"	14 Sy hande is ronde stawe van goud, ingevul met chrisoliet, Sy liggaam ’n kunswerk van ivoor, bedek met saffierstene.	",
"	15 Sy bene is marmerpilare wat rus op voetstukke van fyn goud; Sy gestalte is soos die Líbanon, uitgesoek soos die seders.	",
"	16 Sy verhemelte is pure soetigheid, ja, Hy is geheel en al die lieflikheid self. Hy is My Beminde en Hy is My vriend, Dogters van Jerusalem.	",

]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '6',
content: [
	
"	1 WAAR het U Beminde heengegaan, o skoonste onder die vroue? Waarheen het U Beminde Hom gewend, dat Ons Hom saam met U kan soek?	",
"	2 My Beminde het afgeloop na Sy Tuin, na die balsembeddings om Hom te vermaak in die tuine en om lelies te versamel.	",
"	3 Ek is My Beminde s’n, en My Beminde is Myne - Hy wat Herder is onder die lelies.	",
"	4 Mooi is U, My vriendin, soos Tirsa, lieflik soos Jerusalem, verskriklik soos slagordes met vaandels. [Númeri 27:1]	",
"	5 Draai U oë van My af weg, want hulle verskrik My; U hare is soos ’n kudde bokke wat van Gílead afgolf.	",
"	6 U tande is soos ’n kudde skaapooie wat van die drinkplek af opkom, wat almal tweelinge het, en geeneen onder hulle is sonder lam nie.	",
"	7 U slape is soos ’n granaatskyf deur U sluier heen.	",
"	8 Daar is sestig koninginne en tagtig byvroue en maagde sonder getal. [Spreuke van Salomo 9:3]	",
"	9 Een, dié is My Duif, My rasegte, die enigste vir Haar Moeder; Sy is die Uitverkorene vir die Een wat Haar gebaar het. [Psalm 45:14; Profesie van Barug 4]	",
"	Die Dogters het Haar gesien en Haar geseënd geprys, die koninginne en die byvroue, en Haar geroem:	",
"	10 Wie is dit wat daar opkom soos die dagbreek, mooi soos die maan, helder soos die son, verskriklik soos slagordes met vaandels?	",
"	11 Ek het afgeloop na die neutetuin om te kyk na die uitspruitsels in die dal, om te kyk of die Wingerdstok uitloop, die granate blom.	",
"	12 Voordat Ek dit geweet het, het My Siel My verplaas op die waens van My edele volk.	",
"	13 Kom terug, kom terug; Sulammitiese, kom terug, kom terug, dat Ons U kan aansien. Wat sien julle aan die Sulammitiese? Iets soos die koordans in die soldatekamp.	",
	
]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '7',
content: [
		
"	1 HOE mooi is U skrede in die skoene, o edele Dogter! Die golwende lyne van U heupe is soos halssierade, ’n werk van kunstenaarshande.	",
"	2 U nawel is ’n ronde kom - laat die gemengde wyn nie ontbreek nie. U liggaam is ’n hoop koring, omring deur lelies.	",
"	3 U twee borste is soos twee lammers, tweelinge van ’n gemsbok. [Hoséa 2:2]	",
"	4 U hals is soos ’n ivoortoring, U oë vywers in Hesbon by die Poort Bat-Rabbim; U neus soos die Toring van die Líbanon wat na Damaskus toe uitkyk.	",
"	5 U hoof op U is soos die Karmel, en die golwende hare van U hoof soos purper - ’n Koning gevang in haarlokke!	",
"	6 Hoe mooi en hoe lieflik is U, o liefde, onder al die genietinge!	",
"	7 U hoë gestalte daar lyk soos ’n dadelpalm, en U borste soos vrugtetrosse.	",
"	8 Ek het gedink: Laat Ek op die dadelpalm klim, laat Ek Haar trosse gryp; en laat U borste tog wees soos trosse van die Wingerdstok, en die aroma van U asem soos dié van appels, [Hoséa 2:2]	",
"	9 en U verhemelte soos die suiwerste wyn wat vir My Beminde saggies na binne gly, en oor die lippe vloei en laat die wat slaap, praat.	",
"	10 Ek is My Beminde s’n, en Sy begeerte is na My.	",
"	11 Kom, My Beminde, laat Ons uitgaan in die veld, laat Ons in die dorpe vernag.	",
"	12 Laat Ons vroeg na die Wingerde gaan, laat Ons sien of die Wingerdstok uitloop, die druiwebloeisel oopgaan, die granate blom. Daar sal Ek U My liefde gee. [JeshaJaH 18:5]	",
"	13 Die liefdesappels gee aroma, en by Ons deure is allerhande kostelike vrugte, vars en oud; o My Beminde, dit het Ek vir U weggebêre. [Odes van Salomo 28:2]	",
	
]
},
{
book: 'Hooglied_Van_Salomo',
chapter: '8',
content: [
	
"	1 AG, was U maar vir My soos ’n broer wat aan die borste van My Moeder drink! As Ek U daar buite vind, Ek sou U kus; en tog sou hulle My nie verag nie.	",
"	2 Ek sou U lei, Ek sou U bring in die Huis van My Moeder; Sy sou My leer; Ek sou U laat drink van die gekruide wyn, en van My soet wyn van granaat.	",
"	3 Laat Sy linkerarm onder My hoof wees en Sy regterarm My omhels.	",
"	4 Ek besweer julle, Dogters van Jerusalem: Waarom wil julle wakker maak en waarom wil julle opwek die liefde voordat dit die [liefde] behaag?	",
"	5 Wie is dit wat daar opkom uit die wildernis, wat leun op Haar Beminde? [Openbaring 12:1]	",
"	6 Dra My soos ’n Seëlring op U hart, soos ’n Seëlring op U arm; want die liefde is kragtig soos die Dood, die liefdes-ywer is wreed soos die Doderyk/Sheol, haar gloed is ’n gloed van vuur, ’n vlam. [Wysheid van Sirah 17:22; Haggai 2:23]	",
"	7 Groot waters kan die liefde nie uitblus en riviere haar nie oorstroom nie; al gee ’n man ook al die goed van Sy huis vir die liefde, hulle sou Hom diep verag.	",
"	8 Ons het ’n klein sustertjie wat nog nie borste het nie; wat moet Ons met Ons suster maak dié dag as Sy gevra word?	",
"	9 As Sy ’n muur is, sal Ons ’n silwerrand op Haar bou, en as Sy ’n deur is, sal Ons Haar met ’n sederplank toeslaan.	",
"	10 Ek is ’n muur, en My borste soos torings: toe het Ek in Sy oë geword soos een wat Vrede vind.	",
"	11 Salomo het ’n Wingerd in Baäl-Hamon gehad; Hy het die Wingerd aan die oppassers oorgegee; elkeen moes vir Sy vrugte duisend [sikkels] silwer inbring.	",
"	12 My Wingerd, Myne, is hier voor My, die duisend [sikkels] is vir U, Salomo, en tweehonderd vir die wat Sy vrugte bewaak.	",
"	13 U wat in die tuine woon - vriende luister na U stem; laat My dit hoor.	",
"	14 Vlug, My Beminde, en maak soos die gemsbok of die jong takbok op die balsemberge.	",

]
}
];
