const jonaChapters = [

{
book: 'Jona',
chapter: '1',
content: [
"	1 EN die Woord van JaHWeH het gekom tot Jona, die seun van Amíttai, en gesê:	",
"	2 Maak jou klaar, gaan heen na die groot stad Ninevé en preek teen haar, want hulle besoedeling het opgestyg voor My Aangesig.	",
"	3 Maar Jona het hom klaargemaak om na Tarsis te vlug, van die Aangesig van JaHWeH af weg; en hy het na Jafo afgegaan en ’n skip gevind wat na Tarsis sou vaar. En hy het die reisgeld daarvoor betaal en op haar geklim om saam met hulle na Tarsis te vaar, van die Aangesig van JaHWeH af weg.	",
"	4 Maar JaHWeH het ’n sterk wind op die see gewerp, en toe daar ’n groot storm op die see ontstaan, het die skip gevaar geloop om skipbreuk te ly.	",
"	5 Toe word die seeliede bang - hulle het elkeen tot sy gode geroep en die lading wat in die skip was, in die see gegooi om vir hulle verligting aan te bring. Maar Jona het na die onderste dele van die skip afgeklim en daar gaan lê en vas aan die slaap geraak.	",
"	6 Daarop kom die skeepskaptein na hom toe aan en sê vir hom: Wat makeer jou dat jy so vas slaap? Staan op, roep tot jou Elohey! Miskien sal dié Elohim aan ons dink, sodat ons nie vergaan nie.	",
"	7 Hulle sê toe vir mekaar: Kom en laat ons loot; dan sal ons weet om wie se ontwil hierdie ramp ons getref het. En hulle het geloot, en die lot het op Jona geval.	",
"	8 En hulle sê vir hom: Vertel ons tog om wie se ontwil hierdie ramp ons getref het? Wat is jou beroep? En waar kom jy vandaan? Wat is jou Aarde van geboorte, en uit watter volk is jy?	",
"	9 En hy antwoord hulle: Ek is ’n Hebreër, en ek vrees JaHWeH, die Elohey van die Hemele, wat die see en die droë grond gemaak het.	",
"	10 Toe word die manne baie bang en sê vir hom: Wat het jy nou gedoen! Want die manne het geweet dat hy van die Aangesig van JaHWeH af wegvlug; want hy het hulle dit te kenne gegee.	",
"	11 Verder sê hulle vir hom: Wat moet ons met jou doen, sodat die see om ons heen kan bedaar? - want die see het hoe langer hoe onstuimiger geword.	",
"	12 En hy antwoord hulle: Neem my en gooi my in die see; dan sal die see om julle heen bedaar; want ek weet dat om my ontwil hierdie groot storm oor julle gekom het.	",
"	13 Nogtans het die manne geroei om [die skip] weer grond toe te bring; maar hulle kon nie, omdat die see hoe langer hoe onstuimiger teen hulle geword het.	",
"	14 Toe roep hulle tot JaHWeH en sê: Ag, JaHWeH, laat ons tog nie vergaan weens die siel van hierdie man nie, en bring geen onskuldige bloed oor ons nie; want U, JaHWeH, het gedoen na U welbehae.	",
"	15 En hulle het Jona geneem en hom in die see gegooi. En die see het stil geword van sy onstuimigheid.	",
"	16 Toe het die manne JaHWeH gevrees met ’n groot vrees en slagdiere geslag aan JaHWeH en geloftes gemaak.	",
"	17 En JaHWeH het ’n groot vis beskik om Jona in te sluk; en Jona was drie dae en drie nagte in die ingewande van die vis. [Boekrol van die Opregte 12:6; MattithJaHûW 12:40]	",
		
]
},
{
book: 'Jona',
chapter: '2',
content: [
		
"	1 EN Jona het tot JaHWeH sy Elohey gebid uit die ingewande van die vis	",
"	2 en gesê: Uit my benoudheid het ek JaHWeH aangeroep, en Hy het my verhoor; uit die binneste van die Doderyk /Sheol het ek geroep om hulp - U het my stem gehoor.	",
"	3 U tog het my in die diepte gewerp, in die hart van die see, sodat ’n stroom my omring het; al U bare en U golwe het oor my heengegaan.	",
"	4 Toe het ek gesê: Ek is weggestoot, weg van U Oë; tog sal ek weer kyk na die woning van U Apartheid.	",
"	5 Waters het my omring tot aan die siel toe, die Afgrond was rondom my; seegras was om my hoof gedraai.	",
"	6 Ek het afgedaal tot by die grondslae van die berge, die grendels van die Aarde het my vir altyd ingesluit; maar U het my lewe uit die kuil opgetrek, JaHWeH my Elohey!	",
"	7 Toe my siel in my versmag het, het ek aan JaHWeH gedink; en my gebed het tot by U gekom na die woning van U Apartheid.	",
"	8 Die wat leuenagtige nietighede vereer, verlaat hulle medelye.	",
"	9 Ek daarenteen sal aan U slag met ’n stem van danksegging; wat ek beloof het, sal ek betaal. Die Verlossing behoort aan JaHWeH.	",
"	10 Daarop het JaHWeH die vis beveel om Jona op die droë grond uit te spuug.	",

]
},
{
book: 'Jona',
chapter: '3',
content: [
		
"	1 EN die Woord van JaHWeH het vir die tweede maal na Jona gekom en gesê:	",
"	2 Maak jou klaar, gaan heen na die groot stad Ninevé, en verkondig aan haar die boodskap wat Ek jou sal sê.	",
"	3 Toe maak Jona hom klaar en gaan na Ninevé volgens die Woord van JaHWeH. En Ninevé was ’n groot Stad van Elohim, drie dagreise te voet.	",
"	4 En Jona het begin met een dagreis ver die stad in te gaan en het gepreek en gesê: Nog veertig dae, dan word Ninevé verwoes.	",
"	5 En die manne van Ninevé het Elohim geglo en ’n vasdag uitgeroep, en groot en klein het hulle met rougewaad beklee.	",
"	6 En toe die berig die koning van Ninevé bereik, het hy opgestaan van sy troon en sy mantel afgehaal en in rougewaad gehul in die as gaan sit.	",
"	7 En hy het in Ninevé laat uitroep en sê: Op las van die koning en sy groot manne - geen adamiet of wilde wese, beeste of kleinvee mag aan iets proe nie, hulle mag nie wei of water drink nie;	",
"	8 maar adamiet en wilde wese moet ’n rougewaad om hê, en hulle moet ernstig tot Elohim roep, en elkeen moet hom van sy besoedelde weg bekeer en van die onreg wat aan sy handpalms kleef.	",
"	9 Wie weet of die Elohim nie sal omkeer en berou sal hê nie, sodat Hy Hom afwend van die gloed van Sy brandende Woede en ons nie vergaan nie?	",
"	10 En die Elohim het hulle werke gesien dat hulle hul bekeer het van hulle besoedelde weg; toe het die Elohim berou gehad oor die besoedeling wat Hy gesê het dat Hy hulle sou aandoen, en Hy het dit nie gedoen nie.	",

]
},
{
book: 'Jona',
chapter: '4',
content: [
		
"	1 MAAR Jona was hieroor erg ontstemd en hy het kwaad geword.	",
"	2 Toe bid hy tot JaHWeH en sê: Ag, JaHWeH, het ek dit nie gedink terwyl ek nog in my Adamah [die adamiet se Aarde] was nie? Daarom het ek tevore na Tarsis gevlug; want ek het geweet dat U ’n goedgunstige en barmhartige El is, lankmoedig en groot van Medelye, en Een wat die besoedeling vergewe.	",
"	3 o JaHWeH, neem dan nou tog my siel van my weg, want dit is vir my beter om te sterwe as om te lewe.	",
"	4 Daarop sê JaHWeH: Het jy rede om vertoornd te wees?	",
"	5 En Jona het die stad verlaat en aan die oostekant van die stad gaan sit. Daar maak hy toe vir hom ’n skerm, en hy gaan onder haar in die skaduwee sit, totdat hy sou sien wat met die stad gebeur.	",
"	6 Toe beskik JaHWeH Elohim ’n wonderboom en laat dit oor Jona opskiet om te dien as skaduwee oor sy hoof, om hom van sy ontstemdheid te bevry; en Jona was baie bly oor die wonderboom.	",
"	7 Maar die Elohim het die volgende môre toe die dag breek, ’n wurm beskik; en dié het die wonderboom gesteek, sodat dit verdor het.	",
"	8 En met sonop het Elohim ’n gloeiende oostewind beskik; en toe die son op die hoof van Jona steek, het hy magteloos geword en gewens dat sy siel mag sterwe, en gesê: Dit is vir my beter om te sterwe as om te lewe.	",
"	9 Toe sê Elohim vir Jona: Het jy rede om vertoornd te wees oor die wonderboom? En hy antwoord: Ek het rede om vertoornd te wees tot die dood toe.	",
"	10 Verder sê JaHWeH: Jy wil die wonderboom spaar waar jy geen arbeid aan bestee het nie en wat jy nie grootgemaak het nie, wat in een nag ontstaan en in een nag vergaan het.	",
"	11 Maar Ek mag Ninevé, die groot stad, nie spaar nie, in haar is meer as honderd-en-twintigduisend adamiete wat die onderskeid tussen hulle regter- en hulle linkerhand nie weet nie, en baie vee?	",

]
}
];

