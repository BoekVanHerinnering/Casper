const eerste_brief_van_die_apostel_petrusChapters = [

{
book: 'Eerste_Brief_Van_Die_Apostel_Petrus',
chapter: '1',
content: [

"	1 PETRUS, ’n Apostel van JaHWèshua die Gesalfde, aan die vreemdelinge van die twaalf stamme in verstrooiing in Pontus, Galásië, Kappadócië, Asië en Bithínie,	",
"	2 uitverkore volgens die voorkennis van Elohim die VADER, in die Apartheid van die Gees, tot gehoorsaamheid en besprenkeling met die bloed van JaHWèshua die Gesalfde: Mag Barmhartigheid en Vrede vir julle vermenigvuldig word!	",
"	3 GESEËND is die Elohim en VADER van onse Meester JaHWèshua die Gesalfde wat na SY grote Barmhartigheid ons die wederoprigting geskenk het tot ’n lewende hoop deur die opstanding van JaHWèshua die Gesalfde uit die dode,	",
"	4 sodat ons ’n onverganklike, rasegte en onverwelklike Erfenis kan verkry, wat in die Hemele bewaar is vir ons,	",
"	5 wat in die Krag van Elohim bewaar word deur die Geloof tot die Verlossing wat gereed is om geopenbaar te word in die laaste tyd. [Job 28:20; JôWEl 2:16; 2 Ezra 7:26]	",
"	6 Daarin verheug julle jul, al word julle nou - as dit nodig is - ’n kort tydjie bedroef onder allerhande beproewinge,	",
"	7 sodat die beproefdheid van julle Geloof, wat baie kosbaarder is as goud wat vergaan maar deur vuur gelouter word, bevind mag word tot Lof en Eer en Majesteit by die openbaring van JaHWèshua die Gesalfde; [2 Ezra 16:74]	",
"	8 vir wie julle, al het julle Hom nie gesien nie, tog liefhet; in wie julle, al sien julle Hom nou nie, tog glo en julle verbly met ’n onuitspreeklike en glorieryke blydskap,	",
"	9 en die einddoel van julle Geloof, die Verlossing van julle siele, verkry.	",
"	10 Aangaande hierdie Verlossing het die Profete wat geprofeteer het oor die Barmhartigheid wat vir julle bestem is, ondersoek en nagevors,	",
"	11 en hulle het nagespeur op watter of hoedanige tyd die Gees van die Gesalfde wat in hulle was, gewys het, toe Hy vooruit getuig het van die lyde wat oor die Gesalfde sou kom en die Glansrykheid daarna.	",
"	12 Aan hulle is geopenbaar dat hulle nie vir hulleself nie, maar vir ons dié dinge bedien het wat julle nou aangekondig is deur dié wat die goeie nuus aan julle verkondig het deur die Gees van Apartheid wat van die Hemele gestuur is - dinge waarin die Boodskappers begerig is om in te sien.	",
"	13 DAAROM, omgord die lendene van julle verstand, wees nugter en hoop volkome op die Barmhartigheid wat julle deel word by die openbaring van JaHWèshua die Gesalfde.	",
"	14 Soos gehoorsame kinders moet julle nie jul lewe inrig volgens die begeerlikhede wat tevore in julle onwetendheid bestaan het nie.	",
"	15 Maar soos Hy wat julle geroep het, apart is, moet julle jul ook in jul hele lewenswandel apart word,	",
"	16 omdat daar geskrywe is: Wees apart, want Ek is apart. [Levítikus11:44]	",
"	17 En as julle HOM as VADER aanroep wat sonder aanneming van die persoon oordeel volgens elkeen se werk, wandel dan in Vrees gedurende die tyd van julle vreemdelingskap;	",
"	18 omdat julle weet dat julle nie deur verganklike dinge, silwer of goud, losgekoop is uit julle ydele lewenswandel wat deur die vaders oorgelewer is nie,	",
"	19 maar deur die kosbare Bloed van die Gesalfde, soos die van ’n Rasegte Lam,	",
"	20 wat wel vooruit geken is voor die grondlegging van die wêreld, maar in hierdie laaste tye geopenbaar is om julle ontwil, [Opregte 23:70]	",
"	21 julle wat deur Hom glo in die Elohim wat Hom uit die dode opgewek en Hom Majesteit gegee het, sodat julle Geloof en hoop op Elohim kan wees.	",
"	22 As julle in gehoorsaamheid aan die Waarheid julle siele deur die Gees tot ongeveinsde broederliefde gewas het, moet julle mekaar vurig liefhê uit ’n skoon hart;	",
"	23 want julle is van Bo gebore, nie uit verganklike saad nie, maar uit onverganklike, deur die lewende Woord van Elohim wat tot in ewigheid bly.	",
"	24 Want alle vlees is soos gras, en al die glansrykheid van die adamiet soos ’n blom van die gras. Die gras verdor en sy blom val af,	",
"	25 maar die Woord van JaHWeH bly tot in ewigheid. En dit is die Goeie Nuus wat aan julle verkondig is.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Petrus',
chapter: '2',
content: [
	
"	1 LÊ dan af alle besoedeling en alle bedrog en geveinsdheid en afguns en alle haatspraak;	",
"	2 en verlang sterk soos pasgebore kindertjies na die onvervalste Melk van die Woord, dat julle deur haar kan opgroei,	",
"	3 as julle ten minste gesmaak het dat ons Meester vol Medelye is.	",
"	4 Kom na Haar toe, die Lewende Steen wat deur die adamiete wel verwerp is, maar by Elohim uitverkore en kosbaar is; [Psalm 118:22]	",
"	5 en laat julle ook soos lewende stene opbou, tot ’n geestelike Huis, ’n priesterdom van Apartheid, om geestelike aanbiedinge te bring wat aan Elohim welgevallig is deur JaHWèshua die Gesalfde.	",
"	6 Daarom staan dit ook in die Skrif: Kyk, EK lê in Sion ’n Grondsteen, [‘n beproefde Klip,] ‘n kosbare Hoek[steen wat ‘n vaste fondament is,] hy wat vertrou, sal nie haastig wees nie. [JeshaJaH 28:16]	",
"	 7 Vir julle dan wat glo, is Sy kosbaar; maar vir die ongelowiges geld die Woord: Die Klip wat die bouers verwerp het, Sy het ’n Hoeksteen geword; [Psalm 118:22] en: ’n Klip van aanstoot en ’n Rots van struikeling – [JeshaJaH 8:14]	",
"	8 vir dié wat hulle teen Hom stamp, omdat hulle aan die Woord ongehoorsaam is, waarvoor hulle ook bestem is. [JeshaJaH 8:14]	",
"	9 Maar julle is ’n uitverkore saadlyn, ’n koninklike priesterdom, ’n apartgestelde nasie. ’n Volk as eiendom verkry, om te verkondig die voortreflikheid van Hom wat julle uit die Duisternis geroep het tot Sy wonderbare Lig, [Exodus 19:6]	",
"	10 julle wat vroeër geen volk was nie, maar nou die volk van Elohim is; aan wie toe geen Barmhartigheid bewys is nie, maar nou bewys is. [2 Ezra 1:35, 37; Hoséa 1:6-9]	",
"	11 GELIEFDES, ek vermaan julle as bywoners en vreemdelinge om julle te onthou van vleeslike begeertes wat stryd voer teen die siel;	",
"	12 en hou julle lewenswandel onder die nasies suiwer, sodat as hulle julle laster as misdadigers, hulle op grond van die suiwere werke wat hulle aanskou, die Elohim kan vereer in die dag van besoeking.	",
"	13 Wees dan onderdanig aan elke adamitiese skeppingsorde ter wille van die Meester - of dit die koning is as opperbevel,	",
"	14 of die goewerneurs as sy gesante, om wel misdadigers te straf, maar die wat goed doen, te prys.	",
"	15 Want so is dit die wil van Elohim dat julle deur goed te doen die onkunde van die dwase adamiete tot swye sal bring,	",
"	16 as vrye adamiete en nie asof julle die vryheid het as ’n dekmantel vir die besoedeling nie, maar as diensknegte van Elohim.	",
"	17 Julle moet almal eer, die broederskap liefhê, Elohim vrees, die Koning eer.	",
"	18 DIENSKNEGTE, wees julle meesters onderdanig met alle vrees, nie alleen aan die wat suiwer en vriendelik is nie, maar ook aan die wat verdraaid is.	",
"	19 Want dit is Barmhartigheid as iemand se siel voor Elohim leed verdra deur onregverdig te ly.	",
"	20 Want watter roem is daar as julle verdra wanneer julle oortredinge doen en geslaan word? Maar as julle verdra wanneer julle goed doen en ly - dit is Barmhartigheid by Elohim.	",
"	21 Want hiertoe is julle geroep, omdat die Gesalfde ook vir julle gely het en julle ’n voorbeeld nagelaat het, sodat julle Sy voetstappe kan navolg;	",
"	22 Hy wat geen oortredinge gedoen het nie, en in Wie se Mond geen bedrog gevind is nie;	",
"	23 wat, toe Hy uitgeskel is, nie terug uitgeskel het nie; toe Hy gely het, nie gedreig het nie, maar dit oorgegee het aan HOM wat regverdig oordeel;	",
"	24 wat self ons oortredinge in Sy Liggaam op die folterpaal gedra het, sodat ons die oortredinge kan afsterwe en vir die Geregtigheid lewe; deur Wie se wonde julle genees is. [JeshaJaH 52:14; 53:12]	",
"	25 Want julle was soos dwalende skape, maar nou het julle teruggekeer na die Herder en Opsiener van julle siele.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Petrus',
chapter: '3',
content: [
	
"	1 NET so moet julle, vroue, aan jul eie mans onderdanig wees, sodat, as sommige aan die Woord ongehoorsaam is, hulle ook deur die wandel van die vroue sonder woorde gewin kan word	",
"	2 as hulle jul suiwer wandel in die Vrees aanskou het.	",
"	3 Julle versiering moet nie uiterlik wees nie: haarvlegtery en omhang van goud en aantrek van klere nie,	",
"	4 maar die verborge adamiet van die hart in die onverganklike versiering van ’n sagmoedige en stille gees, wat baie kosbaar is voor Elohim.	",
"	5 Want so het vroeër ook die aparte vroue wat op Elohim gehoop het, hulleself versier, en hulle was aan hul eie mans onderdanig,	",
"	6 soos Sarah gehoorsaam was aan Abraham en hom meester genoem het; wie se kinders julle is as julle goed doen en geen enkele verskrikking vrees nie.	",
"	7 Net so moet julle, manne, verstandig met hulle saamlewe en aan die vroulike geslag, as die swakkere, eer bewys, omdat julle ook mede-erfgename van die Barmhartigheid van die lewe is - sodat julle gebede nie verhinder mag word nie.	",
"	8 EN eindelik, wees almal eensgesind, medelyend, vol broederliefde en ontferming, vriendelik.	",
"	9 Vergeld geen besoedeling met besoedeling of skeldwoorde met skeldwoorde nie, maar seën inteendeel, omdat julle weet dat julle hiertoe geroep is, sodat julle seën kan beërwe.	",
"	10 Want wie die lewe wil liefhê en goeie dae wil sien, moet sy tong bewaar vir wat verkeerd is, en sy lippe dat hulle geen bedrog spreek nie.	",
"	11 Hy moet afwyk van wat verdraaid is, en doen wat suiwer is; hy moet Vrede soek en Hom najaag.	",
"	12 Want die Oë van JaHWèshua is op die regverdiges en Sy Ore tot hulle gebed, maar die Aangesig van JaHWèshua is teen die verdraaides.	",
"	13 En wie is dit wat julle verdruk as julle navolgers is van die suiwere?	",
"	14 Maar as julle ook moet ly ter wille van die Geregtigheid, geseënd is julle. En vrees hulle glad nie, en wees nie ontsteld nie.	",
"	15 Maar stel JaHWeH Elohim apart in julle harte en wees altyd bereid om verantwoording te doen aan elkeen wat van julle rekenskap eis omtrent die hoop wat in julle is, met sagmoedigheid en vrees;	",
"	16 met behoud van ’n gesuiwerde siel, sodat in die saak waarin hulle van julle kwaad spreek soos van misdadigers, húlle beskaam mag word wat julle suiwer lewenswandel in die Gesalfde, belaster.	",
"	17 Want dit is beter, as die wil van die Elohim dit eis, dat julle ly wanneer julle suiwer is, as wanneer julle besoedel is.	",
"	18 Want die Gesalfde het ook eenmaal vir die oortredinge gely, Hy, die Regverdige vir die onregverdiges, om ons tot die Elohim te bring - Hy wat wel gedood is na die vlees, maar lewend gemaak is deur die Gees;	",
"	19 in wie Hy ook heengegaan en afgekondig het vir die geeste in die gevangenis, [2 Nikodemus 5:1]	",
"	20 wat eertyds ongehoorsaam was toe die lankmoedigheid van Elohim eenmaal gewag het in die dae van Noag, onderwyl die Ark gereed gemaak is, waarin weinig, dit is agt, siele deur water heen gered is;	",
"	21 waarvan die teëbeeld, die wassing/doop, ons nou ook red, nie as ’n aflegging van die vuilheid van die vlees nie, maar as ’n bede tot die Elohim om ’n gesuiwerde siel - deur die opstanding van JaHWèshua die Gesalfde	",
"	22 wat heengegaan het na die Hemele en aan die regterkant van die Elohim is, terwyl Boodskappers en Magte en Kragte aan Hom onderwerp is.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Petrus',
chapter: '4',
content: [
		
"	1 OMDAT die Gesalfde dan vir ons na die vlees gely het, moet julle jul ook wapen met dieselfde gedagte, dat wie na die vlees gely het, opgehou het met die oortredinge,	",
"	2 om die orige tyd in die vlees nie meer volgens die begeerlikhede van die mense te leef nie, maar volgens die wil van Elohim.	",
"	3 Want dit is genoeg dat ons die afgelope lewenstyd die wil van die heidene volbring het deur te wandel in verbastering, begeerlikheid, dronkenskap, brasserye, drinkpartye en ongeoorloofde idool-verering.	",
"	4 Daarom vind hulle dit vreemd as julle nie saam loop in dieselfde uitgieting van losbandigheid nie, en hulle laster.	",
"	5 Hulle sal rekenskap gee aan Hom wat gereed staan om die lewende en die dode te oordeel.	",
"	6 Want daarom is ook aan die dode die goeie nuus verkondig, sodat hulle wel geoordeel kan word na die persoon in die vlees, maar lewe na Elohim in die gees.	",
"	7 En die einde van alle dinge is naby; wees dan ingetoë en nugter, om te kan bid.	",
"	8 Maar bo alles moet julle mekaar vurig liefhê, want die liefde sal ’n menigte oortredinge bedek.	",
"	9 Wees gasvry jeens mekaar sonder om te murmureer.	",
"	10 Namate elkeen ’n Gawe van Barmhartigheid ontvang het, moet julle mekaar daarmee dien soos suiwer bedienaars van die veelvuldige Barmhartigheid van Elohim.	",
"	11 As iemand spreek, laat dit wees soos Woorde van Elohim; as iemand dien, laat dit wees soos deur die Krag wat Elohim verleen, sodat Elohim in alles vereer kan word deur JaHWèshua die Gesalfde, aan wie die Majesteit en Krag toekom tot in alle ewigheid. Amein.	",
"	12 Geliefdes, verbaas julle nie oor die vuurgloed van vervolging onder julle wat tot julle beproewing dien, asof iets vreemds oor julle kom nie;	",
"	13 maar namate julle deel het aan die lyde van die Gesalfde, moet julle bly wees, sodat julle ook by die openbaring van Sy Glansrykheid met Blydskap kan jubel.	",
"	14 As julle beledig word oor die Naam van die Gesalfde, is julle geseënd, omdat die Gees van Glansrykheid en van Elohim op julle rus. Wat hulle betref, word Hy wel gelaster; maar wat julle betref, word Hy verhoog.	",
"	15 Want niemand van julle moet ly as moordenaar of dief of besoedelde of as een wat hom met die sake van ’n ander bemoei nie.	",
"	16 Maar wanneer iemand as ’n gelowige ly, moet hy hom nie skaam nie, maar Elohim verhoog in hierdie opsig.	",
"	17 Want die tyd is daar dat die oordeel moet begin by die Huis van die Elohim. En as dit eers by ons begin, wat sal die einde wees van die wat aan die goeie tyding van Elohim ongehoorsaam is?	",
"	18 En as die regverdige nouliks gered word, waar sal die verbasterdes en die oortreders verskyn?	",
"	19 So laat dan ook die wat volgens die wil van Elohim ly, hulle siele aan HOM as die getroue SKEPPER toevertrou met goeie dade.	",

]
},
{
book: 'Eerste_Brief_Van_Die_Apostel_Petrus',
chapter: '5',
content: [
		
"	1 EK vermaan die oudstes onder julle, ek wat ’n mede-oudste en getuie van die lyde van die Gesalfde is, wat ook ’n deelgenoot is van my Meester wat geopenbaar sal word:	",
"	2 Hou as herders toesig oor die kudde van die Elohim wat onder julle is, nie uit dwang nie, maar gewilliglik; nie om vuil gewin nie, maar met bereidwilligheid;	",
"	3 ook nie as vorste oor die Erfdeel nie, maar as voorbeelde vir die kudde.	",
"	4 En wanneer die Opperherder verskyn, sal julle die onverwelklike Kroon van Glansrykheid ontvang.	",
"	5 Net so moet julle, jongeres, aan die oueres onderdanig wees; en wees almal met ootmoed bekleed in onderdanigheid aan mekaar, want Elohim weerstaan die hoogmoediges, maar aan die nederiges gee HY Barmhartigheid.	",
"	6 Verneder julle dan onder die Kragtige Hand van El, sodat Sy julle kan verhoog op die regte tyd.	",
"	7 Werp al julle bekommernis op Haar, want Sy [die Hand] sorg vir julle.	",
"	8 Wees nugter en waaksaam, want julle teëstander, die Satan, loop rond soos ’n brullende leeu en soek wie hy kan verslind.	",
"	9 Hom moet julle teëstaan, standvastig in die Geloof, omdat julle weet dat dieselfde lyding opgelê word aan julle broederskap wat in die wêreld is.	",
"	10 EN mag my Elohey van alle Barmhartigheid self, wat ons geroep het tot Sy ewige Glansrykheid in die Gesalfde JaHWèshua, nadat ons ’n kort tyd gely het, julle volmaak, bevestig, versterk en grondves!	",
"	11 Aan Hom die Glansrykheid en die Krag tot in alle ewigheid! Amein.	",
"	12 Deur Silvánus, die getroue broeder, soos ek meen, het ek kortliks aan julle geskrywe om julle te vermaan en om te betuig dat dit die ware Barmhartigheid van Elohim is waarin julle staan.	",
"	13 Die mede-uitverkorene in Babel en Markus, my seun, groet julle.	",
"	14 Groet mekaar met ’n kus van liefde. Vrede vir julle almal wat in die Gesalfde JaHWèshua is! Amein	",

]
}

];
